-- =================================================================
-- Vista Platform - Consolidated Database Schema
-- =================================================================
-- Single source of truth for database initialization. On fresh deploy,
-- PostgreSQL runs this file as 01-schema.sql from docker-entrypoint-initdb.d.
-- All schema changes are made directly here; no migration scripts are run.
--
-- Last consolidated: 2026-05-05
--
-- This file is re-applied by the chart's schema-migration Job on every
-- helm upgrade under `psql -v ON_ERROR_STOP=1`. Every statement here must
-- be idempotent: CREATE * uses IF NOT EXISTS (or OR REPLACE for views and
-- triggers, or a DO/EXCEPTION wrap for policies which have neither form),
-- ALTER TABLE ADD CONSTRAINT is wrapped in a pg_constraint existence check,
-- and ATTACH PARTITION is gated on pg_inherits. The previous safety
-- override (`\set ON_ERROR_STOP off`) was removed once all non-idempotent
-- statements were patched, so a real schema bug in any future change
-- will now halt the migration instead of being silently swallowed.
-- =================================================================


-- SCHEMA: analytics
CREATE SCHEMA IF NOT EXISTS analytics;


-- SCHEMA: audit
CREATE SCHEMA IF NOT EXISTS audit;


-- SCHEMA: compliance
CREATE SCHEMA IF NOT EXISTS compliance;


-- EXTENSION: pg_trgm
CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


-- EXTENSION: pgcrypto
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


-- EXTENSION: uuid-ossp
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


-- TYPE: device_job_status
DO $$ BEGIN CREATE TYPE public.device_job_status AS ENUM (
    'pending', 'assigned', 'in_progress', 'completed', 'failed', 'cancelled'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: device_job_type
-- NOTE: adding a value here reaches FRESH INSTALLS ONLY — this CREATE is
-- wrapped in `EXCEPTION WHEN duplicate_object`, so on a database that already
-- has the type it silently no-ops. The matching
-- `ALTER TYPE public.device_job_type ADD VALUE IF NOT EXISTS ...` in
-- POST-MIGRATIONS is what carries it to an existing database. Both edits,
-- always.
DO $$ BEGIN CREATE TYPE public.device_job_type AS ENUM (
    'device_interrogation', 'cloud_discovery', 'host_inventory'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: discovery_method
DO $$ BEGIN CREATE TYPE public.discovery_method AS ENUM (
    'passive', 'active', 'manual', 'integration',
    'device_interrogation', 'cloud_api', 'source_code_scan', 'host_scan'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: environment_type
DO $$ BEGIN CREATE TYPE public.environment_type AS ENUM (
    'production', 'staging', 'development', 'test'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: file_format
DO $$ BEGIN CREATE TYPE public.file_format AS ENUM (
    'PDF', 'Excel', 'CSV', 'JSON'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: location_type
DO $$ BEGIN CREATE TYPE public.location_type AS ENUM (
    'region', 'country', 'datacenter', 'cloud_region',
    'office', 'site', 'colo', 'building', 'floor', 'rack'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: protocol_type
--
-- ADDING A VALUE TAKES TWO EDITS, NOT ONE. This DO block swallows
-- duplicate_object, so on any database that already has the type the CREATE is
-- a silent no-op and a value added here alone would never reach an existing
-- install. Every addition therefore ALSO needs an
-- `ALTER TYPE public.protocol_type ADD VALUE IF NOT EXISTS '<value>'` in the
-- POST-MIGRATIONS block at the bottom of this file. Keep the two in step, and
-- keep both in step with cryptoparse.canonicalProtocols (pinned by
-- TestNormalizeProtocol_MatchesSchemaEnum) and resolveProtocol().
-- TestProtocolEnum_AdditionsCarryAnAlterType fails if only one edit is made.
DO $$ BEGIN CREATE TYPE public.protocol_type AS ENUM (
    'TLS', 'SSH', 'IPSec', 'VPN', 'Database', 'API', 'SMB', 'Kerberos',
    -- QUIC is not TLS. Its handshake is TLS 1.3, but the record layer, version
    -- negotiation and transport are QUIC's own, and it runs over UDP -- filing
    -- an HTTP/3 endpoint as TLS asserts a TCP endpoint that does not exist.
    'QUIC',
    -- PPTP is modelled separately from VPN so the single most dangerous VPN
    -- configuration a collector can report never shares a label with WireGuard.
    -- Its risk comes from the PPTP row in the `algorithms` catalogue, linked via
    -- protocol_version -- the protocol column alone scores nothing.
    'PPTP',
    -- OT/ICS protocols the sensor's industrial discovery emits.
    'Modbus', 'DNP3', 'MMS', 'ICCP', 'IEC62351', 'OPC_UA',
    'EtherNet_IP', 'BACnet', 'BACnet_SC', 'HART_IP', 'S7'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: report_status
DO $$ BEGIN CREATE TYPE public.report_status AS ENUM (
    'pending', 'generating', 'completed', 'failed', 'expired'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: report_type
DO $$ BEGIN CREATE TYPE public.report_type AS ENUM (
    'compliance', 'inventory', 'risk', 'certificate'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: sensor_status
DO $$ BEGIN CREATE TYPE public.sensor_status AS ENUM (
    'active', 'inactive', 'error', 'maintenance'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: sensor_type
DO $$ BEGIN CREATE TYPE public.sensor_type AS ENUM (
    'network', 'endpoint', 'cloud', 'api'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: subscription_tier
DO $$ BEGIN CREATE TYPE public.subscription_tier AS ENUM (
    'basic', 'professional', 'enterprise'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- TYPE: user_role
DO $$ BEGIN CREATE TYPE public.user_role AS ENUM (
    'admin', 'analyst', 'viewer'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- FUNCTION: create_activity_logs_partition(integer, integer)
CREATE OR REPLACE FUNCTION audit.create_activity_logs_partition(p_year integer, p_month integer) RETURNS text
    LANGUAGE plpgsql
    -- SECURITY DEFINER so this runs as the function owner (crypto_user, who owns
    -- audit.activity_logs). Under enforced RLS the audit-service calls this as
    -- the non-owner crypto_app role, which cannot CREATE a partition of an
    -- owner-owned table ("must be owner of table activity_logs", #917). Running
    -- the DDL as the definer keeps partition management working without granting
    -- the app role table ownership. search_path is pinned per SECURITY DEFINER
    -- best practice.
    SECURITY DEFINER
    SET search_path = audit, pg_catalog, pg_temp
    AS $$
DECLARE
    partition_name TEXT;
    start_date DATE;
    end_date DATE;
    create_stmt TEXT;
BEGIN
    partition_name := format('activity_logs_y%sm%s', p_year, lpad(p_month::text, 2, '0'));
    start_date := make_date(p_year, p_month, 1);
    end_date := start_date + interval '1 month';


    -- Check if partition already exists
    IF NOT EXISTS (
        SELECT 1 FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'audit' AND c.relname = partition_name
    ) THEN
        create_stmt := format(
            'CREATE TABLE IF NOT EXISTS audit.%I PARTITION OF audit.activity_logs FOR VALUES FROM (%L) TO (%L)',
            partition_name,
            start_date,
            end_date
        );
        EXECUTE create_stmt;
        RETURN partition_name;
    END IF;


    RETURN NULL;
END;
$$;


-- FUNCTION: ensure_future_partitions(integer)
CREATE OR REPLACE FUNCTION audit.ensure_future_partitions(p_months_ahead integer DEFAULT 3) RETURNS TABLE(partition_name text, created boolean)
    LANGUAGE plpgsql
    -- SECURITY DEFINER (see create_activity_logs_partition above, #917): it calls
    -- that function to materialize future partitions and must run as the owner.
    SECURITY DEFINER
    SET search_path = audit, pg_catalog, pg_temp
    AS $$
DECLARE
    current_date_val DATE := CURRENT_DATE;
    target_date DATE;
    i INT;
    part_name TEXT;
BEGIN
    FOR i IN 0..p_months_ahead LOOP
        target_date := current_date_val + (i || ' months')::interval;
        part_name := audit.create_activity_logs_partition(
            EXTRACT(YEAR FROM target_date)::INT,
            EXTRACT(MONTH FROM target_date)::INT
        );
        IF part_name IS NOT NULL THEN
            partition_name := part_name;
            created := true;
            RETURN NEXT;
        END IF;
    END LOOP;
END;
$$;


-- FUNCTION: auto_license_best_practices()
CREATE OR REPLACE FUNCTION public.auto_license_best_practices() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    best_practices_framework_id UUID;
    other_license_count INTEGER;
    default_count INTEGER;
BEGIN
    -- Scope app.tenant_id to the new tenant so the RLS policy on
    -- tenant_framework_licenses passes for both the reads and the INSERT.
    -- is_local=true limits the effect to this transaction.
    PERFORM set_config('app.tenant_id', NEW.id::text, true);


    -- Get Best Practices framework ID
    SELECT id INTO best_practices_framework_id
    FROM platform_frameworks
    WHERE is_platform_default = true AND status = 'published'
    LIMIT 1;


    -- Only proceed if Best Practices framework exists
    IF best_practices_framework_id IS NOT NULL THEN
        -- Check if tenant already has any licenses
        SELECT COUNT(*) INTO other_license_count
        FROM tenant_framework_licenses
        WHERE tenant_id = NEW.id;


        -- Check if tenant already has a default framework
        SELECT COUNT(*) INTO default_count
        FROM tenant_framework_licenses
        WHERE tenant_id = NEW.id
          AND is_default = true;


        -- Create Best Practices license (default if no other licenses OR no default exists)
        INSERT INTO tenant_framework_licenses (
            id, tenant_id, platform_framework_id, is_locked, locked_at, locked_by,
            is_default, purchased_at, created_at, updated_at
        ) VALUES (
            gen_random_uuid(), NEW.id, best_practices_framework_id, false, NULL, NULL,
            (other_license_count = 0 OR default_count = 0), NOW(), NOW(), NOW()
        )
        ON CONFLICT (tenant_id, platform_framework_id) DO UPDATE SET
            -- If license exists but no default, set Best Practices as default
            is_default = CASE
                WHEN default_count = 0 THEN true
                ELSE tenant_framework_licenses.is_default
            END,
            updated_at = NOW();
    END IF;


    RETURN NEW;
END;
$$;


-- FUNCTION: auto_license_iec62351_for_enterprise()
--
-- Auto-licenses the IEC 62351-3 / OT Crypto Profile platform framework
-- to Enterprise-tier tenants on INSERT to public.tenants. Mirrors the
-- auto_license_best_practices() pattern.
--
-- Tier choice: this targets the `enterprise` tier as a stand-in for an
-- explicit Energy/Utility tier that doesn't exist yet — Enterprise is
-- the only tier today that has `ot_active_probing` enabled, so it's the
-- closest match for "tenants who paid to do OT discovery." When an
-- explicit Energy/Utility tier is added to subscription_tiers, update
-- the WHERE clause below to include it.
--
-- is_default stays false: Best Practices keeps the default-framework
-- slot to avoid silently changing existing scoring semantics for
-- tenants who happen to have the IEC 62351-3 framework added.
CREATE OR REPLACE FUNCTION public.auto_license_iec62351_for_enterprise() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    iec62351_framework_id UUID;
    tier_name TEXT;
BEGIN
    -- Scope app.tenant_id to the new tenant so the RLS policy on
    -- tenant_framework_licenses passes for the INSERT below.
    -- is_local=true limits the effect to this transaction.
    PERFORM set_config('app.tenant_id', NEW.id::text, true);


    -- Tier check: only auto-license Enterprise tenants.
    SELECT name INTO tier_name
    FROM subscription_tiers
    WHERE id = NEW.subscription_tier_id;


    IF tier_name IS NULL OR tier_name <> 'enterprise' THEN
        RETURN NEW;
    END IF;


    -- Look up the IEC 62351-3 framework by its stable code. The seed
    -- file UPSERTs this on every install, but during a fresh-install
    -- ordering the seed runs *after* the schema, so for tenants
    -- created from `02-seed.sql` (e.g. democorp) this query returns
    -- NULL and the trigger no-ops gracefully — same defensive pattern
    -- auto_license_best_practices uses.
    SELECT id INTO iec62351_framework_id
    FROM platform_frameworks
    WHERE code = 'iec-62351-3' AND status = 'published'
    ORDER BY version DESC NULLS LAST
    LIMIT 1;


    IF iec62351_framework_id IS NULL THEN
        RETURN NEW;
    END IF;


    -- Idempotent: ON CONFLICT skips when the license already exists.
    INSERT INTO tenant_framework_licenses (
        id, tenant_id, platform_framework_id, is_locked, locked_at, locked_by,
        is_default, purchased_at, created_at, updated_at
    ) VALUES (
        gen_random_uuid(), NEW.id, iec62351_framework_id, false, NULL, NULL,
        false, NOW(), NOW(), NOW()
    )
    ON CONFLICT (tenant_id, platform_framework_id) DO NOTHING;


    RETURN NEW;
END;
$$;


-- FUNCTION: calculate_health_score(uuid, numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, integer, integer, numeric, integer, integer, numeric, numeric, numeric)
CREATE OR REPLACE FUNCTION public.calculate_health_score(p_tenant_id uuid, p_cpu_util numeric, p_memory_util numeric, p_storage_util numeric, p_network_util numeric, p_response_time numeric, p_error_rate numeric, p_throughput numeric, p_uptime numeric, p_failed_logins integer, p_security_alerts integer, p_compliance_score numeric, p_active_users integer, p_api_calls integer, p_user_engagement numeric, p_cost_per_user numeric, p_cost_efficiency numeric) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    resource_score DECIMAL;
    performance_score DECIMAL;
    security_score DECIMAL;
    business_score DECIMAL;
    cost_score DECIMAL;
    overall_score DECIMAL;
BEGIN
    -- Resource Efficiency (25% weight)
    resource_score := (
        GREATEST(0, 100 - ABS(p_cpu_util - 65) * 2) * 0.3 +
        GREATEST(0, 100 - ABS(p_memory_util - 75) * 1.5) * 0.3 +
        GREATEST(0, 100 - ABS(p_storage_util - 80) * 1.2) * 0.25 +
        GREATEST(0, 100 - ABS(p_network_util - 55) * 1.8) * 0.15
    );


    -- Performance Metrics (25% weight)
    performance_score := (
        GREATEST(0, 100 - (p_response_time - 200) / 3) * 0.3 +
        GREATEST(0, 100 - p_error_rate * 5000) * 0.3 +
        LEAST(100, p_throughput / 10) * 0.2 +
        GREATEST(0, (p_uptime - 99) / 0.9 * 100) * 0.2
    );


    -- Security Posture (20% weight)
    security_score := (
        GREATEST(0, 100 - p_failed_logins * 10) * 0.25 +
        GREATEST(0, 100 - p_security_alerts * 20) * 0.25 +
        p_compliance_score * 0.3 +
        CASE
            WHEN p_compliance_score > 0 THEN 100
            ELSE 0
        END * 0.2
    );


    -- Business Activity (15% weight)
    business_score := (
        LEAST(100, p_active_users / 10) * 0.3 +
        LEAST(100, p_api_calls / 100) * 0.3 +
        p_user_engagement * 0.25 +
        50 * 0.15 -- Placeholder for feature usage
    );


    -- Cost Optimization (15% weight)
    cost_score := (
        GREATEST(0, 100 - (p_cost_per_user - 10) * 5) * 0.4 +
        p_cost_efficiency * 0.4 +
        50 * 0.2 -- Placeholder for resource cost optimization
    );


    -- Calculate weighted overall score
    overall_score := (
        resource_score * 0.25 +
        performance_score * 0.25 +
        security_score * 0.20 +
        business_score * 0.15 +
        cost_score * 0.15
    );


    RETURN GREATEST(0, LEAST(100, overall_score));
END;
$$;


-- FUNCTION: cleanup_old_aws_cost_data(integer)
CREATE OR REPLACE FUNCTION public.cleanup_old_aws_cost_data(retention_days integer DEFAULT 365) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    -- Delete AWS cost data older than retention_days
    DELETE FROM aws_cost_data
    WHERE cost_date < CURRENT_DATE - (retention_days || ' days')::INTERVAL;


    GET DIAGNOSTICS deleted_count = ROW_COUNT;


    -- Delete old sync job records (keep last 90 days)
    DELETE FROM aws_cost_sync_jobs
    WHERE created_at < NOW() - INTERVAL '90 days'
    AND status IN ('completed', 'failed');


    RETURN deleted_count;
END;
$$;


-- FUNCTION: cleanup_old_resource_usage()
CREATE OR REPLACE FUNCTION public.cleanup_old_resource_usage() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Delete resource usage data older than 90 days
    DELETE FROM tenant_resource_usage
    WHERE timestamp < NOW() - INTERVAL '90 days';


    -- Delete resolved alerts older than 30 days
    DELETE FROM resource_alerts
    WHERE is_active = false
    AND resolved_at < NOW() - INTERVAL '30 days';
END;
$$;


-- FUNCTION: clear_tenant_context()
CREATE OR REPLACE FUNCTION public.clear_tenant_context() RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    PERFORM set_config('app.tenant_id', '', true);
END;
$$;


-- FUNCTION: create_system_sensors_for_tenant()
CREATE OR REPLACE FUNCTION public.create_system_sensors_for_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Insert Platform Discovery Sensor for the new tenant
    INSERT INTO sensors (
        id, tenant_id, name, description, platform, version, profile,
        sensor_type, status, network_interfaces, tags, last_heartbeat, created_at, updated_at
    ) VALUES (
        gen_random_uuid(),
        NEW.id,
        'Platform Discovery Sensor',
        'Platform-managed sensor for network discovery operations. This shared resource performs cryptographic asset discovery scans on your behalf.',
        'platform',
        'system',
        'discovery',
        'network',
        'active',
        ARRAY[]::TEXT[],
        ARRAY['system', 'platform', 'discovery']::TEXT[],
        NOW(),
        NOW(),
        NOW()
    )
    ON CONFLICT DO NOTHING;


    -- Insert Platform Device Interrogation Agent for the new tenant
    INSERT INTO sensors (
        id, tenant_id, name, description, platform, version, profile,
        sensor_type, status, network_interfaces, tags, last_heartbeat, created_at, updated_at
    ) VALUES (
        gen_random_uuid(),
        NEW.id,
        'Platform Device Interrogation Agent',
        'Platform-managed agent for device interrogation operations. This shared resource queries devices and cloud providers for cryptographic inventory on your behalf.',
        'platform',
        'system',
        'device_interrogation',
        'api',
        'active',
        ARRAY[]::TEXT[],
        ARRAY['system', 'platform', 'device_interrogation']::TEXT[],
        NOW(),
        NOW(),
        NOW()
    )
    ON CONFLICT DO NOTHING;


    RETURN NEW;
END;
$$;


-- FUNCTION: determine_health_status(numeric)
CREATE OR REPLACE FUNCTION public.determine_health_status(p_score numeric) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN
    CASE
        WHEN p_score >= 90 THEN RETURN 'excellent';
        WHEN p_score >= 75 THEN RETURN 'good';
        WHEN p_score >= 60 THEN RETURN 'fair';
        WHEN p_score >= 40 THEN RETURN 'poor';
        ELSE RETURN 'critical';
    END CASE;
END;
$$;


-- FUNCTION: expire_pending_sensors()
CREATE OR REPLACE FUNCTION public.expire_pending_sensors() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE pending_sensor_registrations
    SET status = 'expired'
    WHERE status = 'pending'
      AND expires_at < NOW();
END;
$$;


-- FUNCTION: generate_tenant_slug(text)
CREATE OR REPLACE FUNCTION public.generate_tenant_slug(tenant_name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN lower(regexp_replace(trim(tenant_name), '[^a-zA-Z0-9]+', '-', 'g'));
END;
$$;


-- FUNCTION: get_api_usage_stats(timestamp with time zone, timestamp with time zone)
CREATE OR REPLACE FUNCTION public.get_api_usage_stats(p_start_time timestamp with time zone, p_end_time timestamp with time zone) RETURNS TABLE(endpoint character varying, method character varying, total_requests bigint, avg_response_time numeric, error_count bigint, success_rate numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        aul.endpoint,
        aul.method,
        COUNT(*) as total_requests,
        AVG(aul.response_time_ms) as avg_response_time,
        COUNT(*) FILTER (WHERE aul.status_code >= 400) as error_count,
        (COUNT(*) FILTER (WHERE aul.status_code < 400) * 100.0 / COUNT(*)) as success_rate
    FROM api_usage_logs aul
    WHERE aul.timestamp BETWEEN p_start_time AND p_end_time
    GROUP BY aul.endpoint, aul.method
    ORDER BY total_requests DESC;
END;
$$;


-- FUNCTION: get_platform_setting(character varying, jsonb)
CREATE OR REPLACE FUNCTION public.get_platform_setting(key_name character varying, default_value jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result JSONB;
BEGIN
    SELECT setting_value INTO result
    FROM platform_settings
    WHERE setting_key = key_name;


    RETURN COALESCE(result, default_value);
END;
$$;


-- FUNCTION: get_platform_setting_bool(character varying, boolean)
CREATE OR REPLACE FUNCTION public.get_platform_setting_bool(key_name character varying, default_value boolean DEFAULT false) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    result JSONB;
BEGIN
    SELECT setting_value INTO result
    FROM platform_settings
    WHERE setting_key = key_name;


    IF result IS NULL THEN
        RETURN default_value;
    END IF;


    RETURN (result::text)::boolean;
END;
$$;


-- FUNCTION: get_tenant_email_config(uuid)
CREATE OR REPLACE FUNCTION public.get_tenant_email_config(tenant_uuid uuid) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    tenant_config JSONB;
    platform_config JSONB;
    use_platform_default BOOLEAN;
    tenant_email_config JSONB;
BEGIN
    -- Get platform default email config
    SELECT setting_value INTO platform_config
    FROM platform_settings
    WHERE setting_key = 'email_config';


    -- Get tenant admin settings
    SELECT config INTO tenant_config
    FROM tenant_admin_settings
    WHERE tenant_id = tenant_uuid;


    -- If no tenant settings, return platform default
    IF tenant_config IS NULL THEN
        RETURN platform_config;
    END IF;


    -- Extract email_config from tenant settings
    tenant_email_config := tenant_config->'email_config';


    -- If no email_config in tenant settings, return platform default
    IF tenant_email_config IS NULL THEN
        RETURN platform_config;
    END IF;


    -- Check if tenant wants to use platform default
    use_platform_default := COALESCE((tenant_email_config->>'use_platform_default')::boolean, true);


    IF use_platform_default THEN
        RETURN platform_config;
    END IF;


    -- Check if tenant has SMTP host configured (indicates custom SMTP)
    IF tenant_email_config->>'smtp_host' IS NOT NULL AND tenant_email_config->>'smtp_host' != '' THEN
        -- Return tenant config (password will be decrypted in application code)
        RETURN tenant_email_config;
    END IF;


    -- Fall back to platform default
    RETURN platform_config;
END;
$$;


-- FUNCTION: get_user_permissions(uuid, uuid)
CREATE OR REPLACE FUNCTION public.get_user_permissions(p_user_id uuid, p_tenant_id uuid) RETURNS TABLE(permission_name character varying, resource character varying, action character varying, scope character varying)
    LANGUAGE plpgsql
    SECURITY DEFINER
    SET search_path = public, pg_catalog, pg_temp
    AS $$
BEGIN
    RETURN QUERY
    SELECT tp.name, tp.resource, tp.action, tp.scope
    FROM user_tenant_roles utr
    JOIN tenant_role_permissions trp ON utr.role_id = trp.role_id
    JOIN tenant_permissions tp ON trp.permission_id = tp.id
    WHERE utr.user_id = p_user_id
      AND utr.tenant_id = p_tenant_id
      AND utr.is_active = true
      AND (utr.expires_at IS NULL OR utr.expires_at > NOW());
END;
$$;


-- FUNCTION: get_user_role(uuid, uuid)
CREATE OR REPLACE FUNCTION public.get_user_role(p_user_id uuid, p_tenant_id uuid) RETURNS character varying
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    role_name VARCHAR(50);
BEGIN
    SELECT tr.name
    INTO role_name
    FROM user_tenant_roles utr
    JOIN tenant_roles tr ON utr.role_id = tr.id
    WHERE utr.user_id = p_user_id
      AND utr.tenant_id = p_tenant_id
      AND utr.is_active = true
    ORDER BY utr.assigned_at DESC
    LIMIT 1;


    -- Return default role if none found
    RETURN COALESCE(role_name, 'viewer');
END;
$$;


-- FUNCTION: log_tenant_admin_settings_change()
CREATE OR REPLACE FUNCTION public.log_tenant_admin_settings_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO tenant_admin_settings_audit (
        tenant_id,
        config_before,
        config_after,
        version_before,
        version_after,
        changed_by,
        change_reason,
        created_at
    )
    VALUES (
        NEW.tenant_id,
        OLD.config,
        NEW.config,
        OLD.version,
        NEW.version,
        NEW.updated_by,
        NULL, -- change_reason can be set in application code
        NOW()
    );
    RETURN NEW;
END;
$$;


-- FUNCTION: log_tier_change()
CREATE OR REPLACE FUNCTION public.log_tier_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    change_type_val VARCHAR(50);
    changes_json_val JSONB;
BEGIN
    -- Determine change type
    IF TG_OP = 'INSERT' THEN
        change_type_val := 'created';
        changes_json_val := jsonb_build_object(
            'after', to_jsonb(NEW)
        );
    ELSIF TG_OP = 'UPDATE' THEN
        change_type_val := 'modified';
        changes_json_val := jsonb_build_object(
            'before', to_jsonb(OLD),
            'after', to_jsonb(NEW)
        );
    ELSIF TG_OP = 'DELETE' THEN
        change_type_val := 'deprecated';
        changes_json_val := jsonb_build_object(
            'before', to_jsonb(OLD)
        );
    END IF;


    -- Insert history record
    INSERT INTO subscription_tier_history (tier_id, change_type, changes_json, changed_at)
    VALUES (
        COALESCE(NEW.id, OLD.id),
        change_type_val,
        changes_json_val,
        NOW()
    );


    RETURN COALESCE(NEW, OLD);
END;
$$;


-- FUNCTION: platform_user_has_permission(uuid, character varying)
CREATE OR REPLACE FUNCTION public.platform_user_has_permission(p_user_id uuid, p_permission_name character varying) RETURNS boolean
    LANGUAGE plpgsql
    SECURITY DEFINER
    SET search_path = public, pg_catalog, pg_temp
    AS $$
DECLARE
    has_permission BOOLEAN := FALSE;
BEGIN
    -- Check if platform user has the permission through their role
    SELECT EXISTS(
        SELECT 1
        FROM platform_users pu
        JOIN platform_role_permissions prp ON pu.role_id = prp.role_id
        JOIN platform_permissions pp ON prp.permission_id = pp.id
        WHERE pu.id = p_user_id
          AND pu.is_active = true
          AND pu.deleted_at IS NULL
          AND pp.name = p_permission_name
    ) INTO has_permission;


    RETURN has_permission;
END;
$$;


-- FUNCTION: refresh_operational_views()
CREATE OR REPLACE FUNCTION public.refresh_operational_views() RETURNS void
    LANGUAGE plpgsql
    -- SECURITY DEFINER: REFRESH MATERIALIZED VIEW requires OWNERSHIP of the
    -- matview, and since the Phase 4 role split the caller (inventory-service's
    -- pool) is the non-owner crypto_app role — a plain-invoker call fails with
    -- "must be owner of materialized view" and the operational views silently
    -- go stale. Run as the definer (crypto_user, the owner) instead.
    -- search_path is pinned per SECURITY DEFINER best practice.
    SECURITY DEFINER
    SET search_path = public, pg_catalog, pg_temp
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_location_finding_summary;
    REFRESH MATERIALIZED VIEW mv_remediation_queue;
END;
$$;


-- FUNCTION: refresh_tenant_cost_summary()
-- SECURITY DEFINER for the same ownership reason as refresh_operational_views.
CREATE OR REPLACE FUNCTION public.refresh_tenant_cost_summary() RETURNS void
    LANGUAGE plpgsql
    SECURITY DEFINER
    SET search_path = public, pg_catalog, pg_temp
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY tenant_cost_summary;
END;
$$;


-- FUNCTION: set_tenant_context(uuid)
CREATE OR REPLACE FUNCTION public.set_tenant_context(tenant_uuid uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- NULL tenant_id must raise an error, not silently grant access
    IF tenant_uuid IS NULL THEN
        RAISE EXCEPTION 'tenant_uuid must not be NULL';
    END IF;
    PERFORM set_config('app.tenant_id', tenant_uuid::text, true);
END;
$$;


-- FUNCTION: set_trial_end_date()
CREATE OR REPLACE FUNCTION public.set_trial_end_date() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Set trial end date to 30 days from now if not specified
    IF NEW.trial_ends_at IS NULL THEN
        NEW.trial_ends_at = NOW() + INTERVAL '30 days';
    END IF;
    RETURN NEW;
END;
$$;


-- FUNCTION: update_algorithms_updated_at()
CREATE OR REPLACE FUNCTION public.update_algorithms_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


-- FUNCTION: update_certificates_updated_at()
CREATE OR REPLACE FUNCTION public.update_certificates_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    NEW.last_data_update = NOW();
    RETURN NEW;
END;
$$;


-- FUNCTION: update_device_jobs_updated_at()
CREATE OR REPLACE FUNCTION public.update_device_jobs_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


-- FUNCTION: update_tenant_user_count()
CREATE OR REPLACE FUNCTION public.update_tenant_user_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_tenant_id UUID;
BEGIN
    v_tenant_id := COALESCE(NEW.tenant_id, OLD.tenant_id);


    -- Skip if tenant no longer exists (e.g. during a cascade purge delete).
    -- Attempting to upsert tenant_usage for a deleted tenant violates the FK.
    IF NOT EXISTS (SELECT 1 FROM tenants WHERE id = v_tenant_id) THEN
        RETURN COALESCE(NEW, OLD);
    END IF;


    -- Update user count in current period usage
    INSERT INTO tenant_usage (tenant_id, users_count, billing_period_start, billing_period_end)
    VALUES (
        v_tenant_id,
        (SELECT COUNT(*) FROM users WHERE tenant_id = v_tenant_id AND deleted_at IS NULL),
        DATE_TRUNC('month', NOW())::DATE,
        (DATE_TRUNC('month', NOW()) + INTERVAL '1 month - 1 day')::DATE
    )
    ON CONFLICT (tenant_id, billing_period_start)
    DO UPDATE SET
        users_count = EXCLUDED.users_count,
        last_calculated_at = NOW();


    RETURN COALESCE(NEW, OLD);
END;
$$;


-- FUNCTION: update_updated_at_column()
CREATE OR REPLACE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


-- FUNCTION: user_has_permission(uuid, uuid, character varying)
CREATE OR REPLACE FUNCTION public.user_has_permission(p_user_id uuid, p_tenant_id uuid, p_permission_name character varying) RETURNS boolean
    LANGUAGE plpgsql
    SECURITY DEFINER
    SET search_path = public, pg_catalog, pg_temp
    AS $$
DECLARE
    has_permission BOOLEAN := FALSE;
BEGIN
    -- Check if user has the permission through their tenant role
    SELECT EXISTS(
        SELECT 1
        FROM user_tenant_roles utr
        JOIN tenant_role_permissions trp ON utr.role_id = trp.role_id
        JOIN tenant_permissions tp ON trp.permission_id = tp.id
        WHERE utr.user_id = p_user_id
          AND utr.tenant_id = p_tenant_id
          AND utr.is_active = true
          AND (utr.expires_at IS NULL OR utr.expires_at > NOW())
          AND tp.name = p_permission_name
    ) INTO has_permission;


    RETURN has_permission;
END;
$$;


SET default_tablespace = '';


-- TABLE: activity_logs
CREATE TABLE IF NOT EXISTS audit.activity_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    user_type character varying(20) NOT NULL,
    user_email character varying(255),
    event_type character varying(100) NOT NULL,
    event_category character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    resource_type character varying(100),
    resource_id uuid,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    request_id character varying(255),
    session_id character varying(255),
    success boolean DEFAULT true,
    error_message text,
    error_code character varying(50),
    compliance_tags text[],
    requires_attention boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    tags text[],
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_event_category CHECK (((event_category)::text = ANY ((ARRAY['asset'::character varying, 'discovery'::character varying, 'compliance'::character varying, 'user'::character varying, 'tenant'::character varying, 'system'::character varying, 'report'::character varying, 'certificate'::character varying, 'data'::character varying, 'config'::character varying, 'job'::character varying, 'authentication'::character varying])::text[]))),
    CONSTRAINT valid_user_type CHECK (((user_type)::text = ANY ((ARRAY['tenant'::character varying, 'platform'::character varying])::text[])))
)
PARTITION BY RANGE (occurred_at);


SET default_table_access_method = heap;


-- TABLE: activity_logs_y2026m04
CREATE TABLE IF NOT EXISTS audit.activity_logs_y2026m04 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    user_type character varying(20) NOT NULL,
    user_email character varying(255),
    event_type character varying(100) NOT NULL,
    event_category character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    resource_type character varying(100),
    resource_id uuid,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    request_id character varying(255),
    session_id character varying(255),
    success boolean DEFAULT true,
    error_message text,
    error_code character varying(50),
    compliance_tags text[],
    requires_attention boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    tags text[],
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_event_category CHECK (((event_category)::text = ANY ((ARRAY['asset'::character varying, 'discovery'::character varying, 'compliance'::character varying, 'user'::character varying, 'tenant'::character varying, 'system'::character varying, 'report'::character varying, 'certificate'::character varying, 'data'::character varying, 'config'::character varying, 'job'::character varying, 'authentication'::character varying])::text[]))),
    CONSTRAINT valid_user_type CHECK (((user_type)::text = ANY ((ARRAY['tenant'::character varying, 'platform'::character varying])::text[])))
);


-- TABLE: activity_logs_y2026m05
CREATE TABLE IF NOT EXISTS audit.activity_logs_y2026m05 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    user_type character varying(20) NOT NULL,
    user_email character varying(255),
    event_type character varying(100) NOT NULL,
    event_category character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    resource_type character varying(100),
    resource_id uuid,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    request_id character varying(255),
    session_id character varying(255),
    success boolean DEFAULT true,
    error_message text,
    error_code character varying(50),
    compliance_tags text[],
    requires_attention boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    tags text[],
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_event_category CHECK (((event_category)::text = ANY ((ARRAY['asset'::character varying, 'discovery'::character varying, 'compliance'::character varying, 'user'::character varying, 'tenant'::character varying, 'system'::character varying, 'report'::character varying, 'certificate'::character varying, 'data'::character varying, 'config'::character varying, 'job'::character varying, 'authentication'::character varying])::text[]))),
    CONSTRAINT valid_user_type CHECK (((user_type)::text = ANY ((ARRAY['tenant'::character varying, 'platform'::character varying])::text[])))
);


-- TABLE: activity_logs_y2026m06
CREATE TABLE IF NOT EXISTS audit.activity_logs_y2026m06 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    user_type character varying(20) NOT NULL,
    user_email character varying(255),
    event_type character varying(100) NOT NULL,
    event_category character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    resource_type character varying(100),
    resource_id uuid,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    request_id character varying(255),
    session_id character varying(255),
    success boolean DEFAULT true,
    error_message text,
    error_code character varying(50),
    compliance_tags text[],
    requires_attention boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    tags text[],
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_event_category CHECK (((event_category)::text = ANY ((ARRAY['asset'::character varying, 'discovery'::character varying, 'compliance'::character varying, 'user'::character varying, 'tenant'::character varying, 'system'::character varying, 'report'::character varying, 'certificate'::character varying, 'data'::character varying, 'config'::character varying, 'job'::character varying, 'authentication'::character varying])::text[]))),
    CONSTRAINT valid_user_type CHECK (((user_type)::text = ANY ((ARRAY['tenant'::character varying, 'platform'::character varying])::text[])))
);


-- TABLE: activity_logs_y2026m07
CREATE TABLE IF NOT EXISTS audit.activity_logs_y2026m07 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    user_type character varying(20) NOT NULL,
    user_email character varying(255),
    event_type character varying(100) NOT NULL,
    event_category character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    resource_type character varying(100),
    resource_id uuid,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    request_id character varying(255),
    session_id character varying(255),
    success boolean DEFAULT true,
    error_message text,
    error_code character varying(50),
    compliance_tags text[],
    requires_attention boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    tags text[],
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_event_category CHECK (((event_category)::text = ANY ((ARRAY['asset'::character varying, 'discovery'::character varying, 'compliance'::character varying, 'user'::character varying, 'tenant'::character varying, 'system'::character varying, 'report'::character varying, 'certificate'::character varying, 'data'::character varying, 'config'::character varying, 'job'::character varying, 'authentication'::character varying])::text[]))),
    CONSTRAINT valid_user_type CHECK (((user_type)::text = ANY ((ARRAY['tenant'::character varying, 'platform'::character varying])::text[])))
);


-- TABLE: activity_logs_y2026m08
CREATE TABLE IF NOT EXISTS audit.activity_logs_y2026m08 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    user_type character varying(20) NOT NULL,
    user_email character varying(255),
    event_type character varying(100) NOT NULL,
    event_category character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    resource_type character varying(100),
    resource_id uuid,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    request_id character varying(255),
    session_id character varying(255),
    success boolean DEFAULT true,
    error_message text,
    error_code character varying(50),
    compliance_tags text[],
    requires_attention boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    tags text[],
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_event_category CHECK (((event_category)::text = ANY ((ARRAY['asset'::character varying, 'discovery'::character varying, 'compliance'::character varying, 'user'::character varying, 'tenant'::character varying, 'system'::character varying, 'report'::character varying, 'certificate'::character varying, 'data'::character varying, 'config'::character varying, 'job'::character varying, 'authentication'::character varying])::text[]))),
    CONSTRAINT valid_user_type CHECK (((user_type)::text = ANY ((ARRAY['tenant'::character varying, 'platform'::character varying])::text[])))
);


-- TABLE: alert_rules
CREATE TABLE IF NOT EXISTS audit.alert_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    name character varying(255) NOT NULL,
    description text,
    rule_type character varying(50) NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    severity character varying(20) NOT NULL,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT alert_rules_rule_type_check CHECK (((rule_type)::text = ANY ((ARRAY['threshold'::character varying, 'pattern'::character varying, 'anomaly'::character varying])::text[]))),
    CONSTRAINT alert_rules_severity_check CHECK (((severity)::text = ANY ((ARRAY['critical'::character varying, 'high'::character varying, 'medium'::character varying, 'low'::character varying])::text[])))
);


-- TABLE: job_execution_logs
CREATE TABLE IF NOT EXISTS audit.job_execution_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    job_type character varying(100) NOT NULL,
    job_name character varying(255),
    tenant_id uuid,
    initiated_by uuid,
    status character varying(50) NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    duration_ms integer,
    items_processed integer DEFAULT 0,
    items_succeeded integer DEFAULT 0,
    items_failed integer DEFAULT 0,
    error_message text,
    error_details jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_job_status CHECK (((status)::text = ANY ((ARRAY['queued'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);


-- VIEW: partition_info
CREATE OR REPLACE VIEW audit.partition_info AS
 SELECT c.relname AS partition_name,
    pg_get_expr(c.relpartbound, c.oid, true) AS partition_bounds,
    pg_size_pretty(pg_relation_size((c.oid)::regclass)) AS partition_size,
    pg_stat_user_tables.n_live_tup AS row_count
   FROM ((pg_class c
     JOIN pg_namespace n ON ((n.oid = c.relnamespace)))
     LEFT JOIN pg_stat_user_tables ON ((pg_stat_user_tables.relid = c.oid)))
  WHERE ((n.nspname = 'audit'::name) AND (c.relname ~~ 'activity_logs_y%'::text))
  ORDER BY c.relname;


-- TABLE: retention_policies
CREATE TABLE IF NOT EXISTS audit.retention_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    policy_name character varying(100) NOT NULL,
    event_type character varying(100),
    compliance_framework character varying(50),
    hot_storage_days integer NOT NULL,
    cold_storage_days integer,
    total_retention_days integer NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_compliance_framework CHECK ((((compliance_framework)::text = ANY ((ARRAY['soc2'::character varying, 'iso27001'::character varying, 'gdpr'::character varying, 'hipaa'::character varying, 'pci_dss'::character varying])::text[])) OR (compliance_framework IS NULL))),
    CONSTRAINT valid_retention_days CHECK ((total_retention_days >= hot_storage_days))
);


-- TABLE: scheduled_compliance_reports
CREATE TABLE IF NOT EXISTS audit.scheduled_compliance_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    framework character varying(50) NOT NULL,
    schedule character varying(100) NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    email_recipients jsonb DEFAULT '[]'::jsonb NOT NULL,
    include_summary boolean DEFAULT true NOT NULL,
    include_details boolean DEFAULT true NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    last_run_at timestamp without time zone,
    next_run_at timestamp without time zone,
    CONSTRAINT scheduled_compliance_reports_framework_check CHECK (((framework)::text = ANY ((ARRAY['soc2'::character varying, 'iso27001'::character varying, 'gdpr'::character varying, 'hipaa'::character varying, 'pci_dss'::character varying])::text[])))
);


-- TABLE: scheduled_report_executions
CREATE TABLE IF NOT EXISTS audit.scheduled_report_executions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schedule_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    report_data jsonb,
    error_message text,
    email_sent_at timestamp without time zone,
    email_recipients jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT scheduled_report_executions_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying])::text[])))
);


-- TABLE: siem_health_checks
CREATE TABLE IF NOT EXISTS audit.siem_health_checks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    integration_id uuid NOT NULL,
    checked_at timestamp without time zone DEFAULT now() NOT NULL,
    status character varying(20) NOT NULL,
    response_time_ms integer,
    error_message text,
    metadata jsonb,
    CONSTRAINT siem_health_checks_status_check CHECK (((status)::text = ANY ((ARRAY['healthy'::character varying, 'degraded'::character varying, 'unhealthy'::character varying])::text[])))
);


-- TABLE: siem_integrations
CREATE TABLE IF NOT EXISTS audit.siem_integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb NOT NULL,
    health_status character varying(20) DEFAULT 'unknown'::character varying,
    last_health_check timestamp without time zone,
    last_successful_send timestamp without time zone,
    last_error text,
    consecutive_failures integer DEFAULT 0,
    total_events_sent bigint DEFAULT 0,
    total_events_failed bigint DEFAULT 0,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT siem_integrations_health_status_check CHECK (((health_status)::text = ANY ((ARRAY['healthy'::character varying, 'degraded'::character varying, 'unhealthy'::character varying, 'unknown'::character varying])::text[]))),
    CONSTRAINT siem_integrations_type_check CHECK (((type)::text = ANY ((ARRAY['splunk'::character varying, 'datadog'::character varying, 'elastic'::character varying, 'generic_webhook'::character varying])::text[])))
);


-- TABLE: resource_alerts
CREATE TABLE IF NOT EXISTS public.resource_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    alert_type character varying(50) NOT NULL,
    metric character varying(100) NOT NULL,
    threshold numeric(10,4) NOT NULL,
    current_value numeric(10,4) NOT NULL,
    message text NOT NULL,
    severity character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone
);


-- TABLE: tenants
CREATE TABLE IF NOT EXISTS public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    domain character varying(255),
    subscription_tier_id uuid,
    trial_ends_at timestamp with time zone DEFAULT (now() + '30 days'::interval),
    billing_email character varying(255),
    payment_status character varying(50) DEFAULT 'trial'::character varying,
    stripe_customer_id character varying(255),
    stripe_subscription_id character varying(255),
    sso_enabled boolean DEFAULT false,
    authentication_policy character varying(50) DEFAULT 'password_only'::character varying,
    custom_branding jsonb DEFAULT '{}'::jsonb,
    ui_config jsonb DEFAULT '{}'::jsonb,
    settings jsonb DEFAULT '{}'::jsonb,
    grace_period_ends_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    onboarding_status character varying(50) DEFAULT 'pending'::character varying,
    CONSTRAINT valid_authentication_policy CHECK (((authentication_policy)::text = ANY ((ARRAY['password_only'::character varying, 'prefer_sso'::character varying, 'enforce_sso'::character varying, 'sso_only'::character varying])::text[]))),
    CONSTRAINT valid_onboarding_status CHECK (((onboarding_status)::text = ANY ((ARRAY['pending'::character varying, 'tier_selected'::character varying, 'billing_complete'::character varying, 'onboarding_complete'::character varying])::text[]))),
    CONSTRAINT valid_payment_status CHECK (((payment_status)::text = ANY ((ARRAY['trial'::character varying, 'active'::character varying, 'past_due'::character varying, 'canceled'::character varying, 'incomplete'::character varying, 'suspended'::character varying])::text[]))),
    CONSTRAINT valid_slug CHECK (((slug)::text ~ '^[a-z0-9-]+$'::text))
);


-- VIEW: active_resource_alerts
CREATE OR REPLACE VIEW public.active_resource_alerts AS
 SELECT ra.id,
    ra.tenant_id,
    t.name AS tenant_name,
    ra.alert_type,
    ra.metric,
    ra.threshold,
    ra.current_value,
    ra.message,
    ra.severity,
    ra.created_at
   FROM (public.resource_alerts ra
     JOIN public.tenants t ON ((ra.tenant_id = t.id)))
  WHERE (ra.is_active = true)
  ORDER BY ra.severity DESC, ra.created_at DESC;


-- TABLE: agent_certificates
CREATE TABLE IF NOT EXISTS public.agent_certificates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    certificate_pem text NOT NULL,
    serial_number character varying(255) NOT NULL,
    issued_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revocation_reason character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: algorithms
CREATE TABLE IF NOT EXISTS public.algorithms (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    subcategory character varying(50),
    name character varying(255) NOT NULL,
    description text,
    strength character varying(20) DEFAULT 'acceptable'::character varying NOT NULL,
    deprecation_status character varying(20) DEFAULT 'current'::character varying,
    deprecation_date date,
    risk_score integer DEFAULT 50,
    recommended_alternatives text[],
    migration_guidance text,
    remediation_guidance jsonb DEFAULT '{}'::jsonb,
    compliance_mappings jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_standard boolean DEFAULT true,
    is_pqc boolean DEFAULT false,
    pqc_standardization_status character varying(20) DEFAULT 'none'::character varying,
    algorithm_family character varying(100),
    primitive character varying(50),
    mode character varying(50),
    padding character varying(50),
    oid character varying(100),
    crypto_functions text[],
    classical_security_level integer,
    nist_quantum_security_level integer,
    parameter_set_identifier character varying(100),
    curve character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_category CHECK (((category)::text = ANY ((ARRAY['hash'::character varying, 'symmetric'::character varying, 'key_exchange'::character varying, 'signature'::character varying, 'protocol_version'::character varying, 'cipher_suite'::character varying])::text[]))),
    CONSTRAINT valid_classical_security_level CHECK (((classical_security_level IS NULL) OR (classical_security_level > 0))),
    CONSTRAINT valid_deprecation_status CHECK (((deprecation_status)::text = ANY ((ARRAY['current'::character varying, 'deprecated'::character varying, 'obsolete'::character varying])::text[]))),
    CONSTRAINT valid_nist_quantum_level CHECK (((nist_quantum_security_level IS NULL) OR ((nist_quantum_security_level >= 0) AND (nist_quantum_security_level <= 5)))),
    CONSTRAINT valid_pqc_status CHECK (((pqc_standardization_status)::text = ANY ((ARRAY['none'::character varying, 'standardized'::character varying, 'candidate'::character varying, 'alternative'::character varying])::text[]))),
    CONSTRAINT valid_primitive CHECK (((primitive IS NULL) OR ((primitive)::text = ANY ((ARRAY['ae'::character varying, 'signature'::character varying, 'hash'::character varying, 'kem'::character varying, 'key-agree'::character varying, 'pke'::character varying, 'key-wrap'::character varying, 'combiner'::character varying, 'mac'::character varying, 'block-cipher'::character varying, 'stream-cipher'::character varying, 'kdf'::character varying, 'xof'::character varying, 'drbg'::character varying, 'other'::character varying])::text[])))),
    CONSTRAINT valid_risk_score CHECK (((risk_score >= 0) AND (risk_score <= 100))),
    CONSTRAINT valid_strength CHECK (((strength)::text = ANY ((ARRAY['weak'::character varying, 'acceptable'::character varying, 'strong'::character varying, 'recommended'::character varying])::text[])))
);


-- TABLE: api_usage_logs
CREATE TABLE IF NOT EXISTS public.api_usage_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    endpoint character varying(255) NOT NULL,
    method character varying(10) NOT NULL,
    status_code integer NOT NULL,
    response_time_ms integer NOT NULL,
    user_id uuid,
    tenant_id uuid,
    ip_address inet,
    user_agent text,
    request_size_bytes integer,
    response_size_bytes integer,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: asset_history
CREATE TABLE IF NOT EXISTS public.asset_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    -- The append counter, and the ONLY thing that can order this table.
    -- created_at defaults to now(), which is the TRANSACTION timestamp: the
    -- identification engine writes `created` and then `merge_proposed` for one
    -- observation inside one transaction, so both carry the same instant and an
    -- ORDER BY created_at tells the story in whichever order the planner
    -- happens to return. Added in phase 1 with the table's first writer.
    seq bigserial NOT NULL,
    asset_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    actor_user_id uuid,
    source text NOT NULL,
    action text NOT NULL,
    changes_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: asset_lifecycle_policies
CREATE TABLE IF NOT EXISTS public.asset_lifecycle_policies (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    stale_warning_days integer DEFAULT 30,
    stale_archived_days integer DEFAULT 60,
    auto_archive_enabled boolean DEFAULT true,
    notifications_enabled boolean DEFAULT true,
    revalidation_schedule jsonb DEFAULT '{"enabled": false, "interval_hours": 168}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: auth_audit_log
CREATE TABLE IF NOT EXISTS public.auth_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    event_type character varying(100) NOT NULL,
    event_status character varying(50) NOT NULL,
    auth_method character varying(50),
    ip_address inet,
    user_agent text,
    session_id character varying(255),
    event_data jsonb DEFAULT '{}'::jsonb,
    failure_reason text,
    occurred_at timestamp with time zone DEFAULT now()
);


-- TABLE: aws_cost_data
CREATE TABLE IF NOT EXISTS public.aws_cost_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    cost_date date NOT NULL,
    service_name character varying(100) NOT NULL,
    amount numeric(12,4) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    usage_quantity numeric(15,6),
    usage_unit character varying(50),
    usage_type character varying(200),
    tags jsonb DEFAULT '{}'::jsonb,
    account_id character varying(20),
    region character varying(50),
    synced_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


-- TABLE: aws_cost_sync_jobs
CREATE TABLE IF NOT EXISTS public.aws_cost_sync_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_type character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    tenant_id uuid,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    records_synced integer DEFAULT 0,
    total_cost numeric(12,4),
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT valid_job_type CHECK (((job_type)::text = ANY ((ARRAY['full_sync'::character varying, 'incremental'::character varying, 'tenant_sync'::character varying])::text[]))),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying])::text[])))
);


-- VIEW: aws_daily_cost_summary
CREATE OR REPLACE VIEW public.aws_daily_cost_summary AS
 SELECT aws_cost_data.cost_date,
    aws_cost_data.tenant_id,
    count(DISTINCT aws_cost_data.service_name) AS service_count,
    sum(aws_cost_data.amount) AS total_cost_usd,
    sum(aws_cost_data.usage_quantity) AS total_usage_quantity,
    string_agg(DISTINCT (aws_cost_data.usage_unit)::text, ', '::text) AS usage_units,
    max(aws_cost_data.synced_at) AS last_synced_at
   FROM public.aws_cost_data
  GROUP BY aws_cost_data.cost_date, aws_cost_data.tenant_id;


-- VIEW: aws_daily_service_cost_summary
CREATE OR REPLACE VIEW public.aws_daily_service_cost_summary AS
 SELECT aws_cost_data.cost_date,
    aws_cost_data.service_name,
    count(DISTINCT aws_cost_data.tenant_id) AS tenant_count,
    sum(aws_cost_data.amount) AS total_cost_usd,
    sum(aws_cost_data.usage_quantity) AS total_usage_quantity,
    string_agg(DISTINCT (aws_cost_data.usage_unit)::text, ', '::text) AS usage_units,
    max(aws_cost_data.synced_at) AS last_synced_at
   FROM public.aws_cost_data
  GROUP BY aws_cost_data.cost_date, aws_cost_data.service_name;


-- VIEW: aws_tenant_monthly_cost_summary
CREATE OR REPLACE VIEW public.aws_tenant_monthly_cost_summary AS
 SELECT aws_cost_data.tenant_id,
    (date_trunc('month'::text, (aws_cost_data.cost_date)::timestamp with time zone))::date AS month,
    count(DISTINCT aws_cost_data.service_name) AS service_count,
    sum(aws_cost_data.amount) AS total_cost_usd,
    avg(aws_cost_data.amount) AS avg_daily_cost_usd,
    max(aws_cost_data.amount) AS max_daily_cost_usd,
    min(aws_cost_data.amount) AS min_daily_cost_usd,
    sum(aws_cost_data.usage_quantity) AS total_usage_quantity
   FROM public.aws_cost_data
  WHERE (aws_cost_data.tenant_id IS NOT NULL)
  GROUP BY aws_cost_data.tenant_id, ((date_trunc('month'::text, (aws_cost_data.cost_date)::timestamp with time zone))::date);


-- TABLE: billing_coupon_redemptions
CREATE TABLE IF NOT EXISTS public.billing_coupon_redemptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    coupon_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    subscription_id uuid,
    redeemed_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb
);


-- TABLE: billing_coupons
CREATE TABLE IF NOT EXISTS public.billing_coupons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    discount_type character varying(20) NOT NULL,
    discount_value integer NOT NULL,
    duration character varying(20) NOT NULL,
    duration_in_months integer,
    max_redemptions integer,
    times_redeemed integer DEFAULT 0,
    valid_from timestamp with time zone DEFAULT now(),
    valid_until timestamp with time zone,
    is_active boolean DEFAULT true,
    stripe_coupon_id character varying(255),
    stripe_promotion_code_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: billing_customers
CREATE TABLE IF NOT EXISTS public.billing_customers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    external_customer_id character varying(255) NOT NULL,
    email character varying(255),
    default_payment_method character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: billing_dunning_attempts
CREATE TABLE IF NOT EXISTS public.billing_dunning_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    invoice_id uuid,
    attempt_number integer NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    next_retry_at timestamp with time zone,
    error_message text,
    notification_sent boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: billing_events
CREATE TABLE IF NOT EXISTS public.billing_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    external_event_id character varying(255) NOT NULL,
    payload jsonb NOT NULL,
    received_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    processing_status character varying(50) DEFAULT 'pending'::character varying,
    retry_count integer DEFAULT 0,
    last_error text,
    -- The async WebhookWorker and WebhookProcessor both stamp this when
    -- claiming/retrying/completing an event, and the stuck-event sweep reads it.
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: billing_invoice_line_items
CREATE TABLE IF NOT EXISTS public.billing_invoice_line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    description character varying(255) NOT NULL,
    quantity numeric(10,2) DEFAULT 1 NOT NULL,
    unit_price_cents integer NOT NULL,
    amount_cents integer NOT NULL,
    line_item_type character varying(50) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: billing_invoices
CREATE TABLE IF NOT EXISTS public.billing_invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    external_invoice_id character varying(255) NOT NULL,
    amount_cents integer NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    status character varying(50) NOT NULL,
    issued_at timestamp with time zone,
    due_at timestamp with time zone,
    paid_at timestamp with time zone,
    pdf_url character varying(500),
    pdf_generated_at timestamp with time zone,
    invoice_number character varying(100),
    period_start timestamp with time zone,
    period_end timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    -- WebhookProcessor mirrors Stripe invoices with
    -- ON CONFLICT (provider_id, external_invoice_id); without this the upsert
    -- failed and no invoice ever persisted.
    CONSTRAINT billing_invoices_provider_external_key UNIQUE (provider_id, external_invoice_id)
);


-- TABLE: billing_providers
CREATE TABLE IF NOT EXISTS public.billing_providers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: billing_subscriptions
CREATE TABLE IF NOT EXISTS public.billing_subscriptions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    external_subscription_id character varying(255) NOT NULL,
    plan_key character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    current_period_start timestamp with time zone,
    current_period_end timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false,
    quantity integer DEFAULT 1,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    coupon_id uuid,
    -- 12-month contract model (#1002): every paid subscription is a one-year
    -- agreement. Stamped by admin-service at subscription creation and rolled
    -- forward by the invoice.paid webhook.
    contract_start timestamp with time zone,
    contract_end timestamp with time zone,
    -- HandleCreateSubscription upserts ON CONFLICT (tenant_id, provider_id).
    -- Without this the insert silently failed, so the local subscription cache
    -- was never written and the webhook sync could never flip a tenant to active.
    -- Current-state only; history lives in billing_invoices / billing_events.
    CONSTRAINT billing_subscriptions_tenant_provider_key UNIQUE (tenant_id, provider_id)
);


-- TABLE: billing_trial_tracking
CREATE TABLE IF NOT EXISTS public.billing_trial_tracking (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    trial_start timestamp with time zone NOT NULL,
    trial_end timestamp with time zone NOT NULL,
    notification_7days_sent boolean DEFAULT false,
    notification_1day_sent boolean DEFAULT false,
    trial_ended_notification_sent boolean DEFAULT false,
    converted_to_paid boolean DEFAULT false,
    converted_at timestamp with time zone,
    trial_extended_count integer DEFAULT 0,
    -- Phase-transition timestamps + soft-prompt notification flag. All NULL on a
    -- brand-new trial; soft_prompt_started_at populates at day trial_days_full,
    -- hard_locked_at at day trial_days_full + trial_days_soft.
    soft_prompt_started_at timestamp with time zone,
    hard_locked_at timestamp with time zone,
    notification_soft_prompt_sent boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: certificate_extensions
CREATE TABLE IF NOT EXISTS public.certificate_extensions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    certificate_id uuid NOT NULL,
    extension_type character varying(20) NOT NULL,
    extension_name character varying(255) NOT NULL,
    extension_value text NOT NULL,
    is_critical boolean DEFAULT false,
    extension_oid character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_extension_type CHECK (((extension_type)::text = ANY ((ARRAY['common'::character varying, 'custom'::character varying])::text[])))
);


-- TABLE: certificate_history
CREATE TABLE IF NOT EXISTS public.certificate_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    certificate_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb,
    previous_certificate_id uuid,
    discovered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    created_by uuid,
    CONSTRAINT valid_event_type CHECK (((event_type)::text = ANY ((ARRAY['created'::character varying, 'renewed'::character varying, 'revoked'::character varying, 'expired'::character varying, 'updated'::character varying, 'data_enriched'::character varying])::text[])))
);


-- TABLE: certificates
CREATE TABLE IF NOT EXISTS public.certificates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    serial_number character varying(255),
    subject_dn text NOT NULL,
    issuer_dn text NOT NULL,
    common_name character varying(255),
    subject_alternative_names text[],
    signature_algorithm character varying(100),
    public_key_algorithm character varying(100),
    public_key_size integer,
    not_before timestamp with time zone,
    not_after timestamp with time zone,
    fingerprint_sha1 character varying(40),
    fingerprint_sha256 character varying(64) NOT NULL,
    certificate_pem text,
    is_self_signed boolean DEFAULT false,
    is_ca_certificate boolean DEFAULT false,
    key_usage text[],
    extended_key_usage text[],
    issuer_certificate_id uuid,
    superseded_by_certificate_id uuid,
    certificate_state character varying(20) DEFAULT 'active'::character varying,
    certificate_state_reason text,
    revoked_at timestamp with time zone,
    revocation_discovered_at timestamp with time zone,
    certificate_format character varying(50) DEFAULT 'X.509'::character varying,
    activation_date timestamp with time zone,
    deactivation_date timestamp with time zone,
    destruction_date timestamp with time zone,
    signature_algorithm_oid character varying(100),
    public_key_algorithm_oid character varying(100),
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    data_source character varying(50),
    last_data_update timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    has_sct boolean,
    known_bad_ca character varying(100),
    is_ev boolean DEFAULT false,
    ocsp_status character varying(20),
    ocsp_detail text,
    cert_ownership character varying(50),
    -- Tightest expiry-alert tier (days; 0 = expired) already notified for this
    -- cert, so the scheduled certificate-expiry scan (ADR-0015 §6) escalates once
    -- per tier instead of re-notifying daily. NULL = not yet alerted / renewed
    -- beyond the widest tier.
    expiry_alert_tier integer,
    CONSTRAINT valid_certificate_format CHECK (((certificate_format)::text = ANY ((ARRAY['X.509'::character varying, 'PGP'::character varying, 'PKCS#7'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT valid_certificate_state CHECK (((certificate_state)::text = ANY ((ARRAY['pre-activation'::character varying, 'active'::character varying, 'suspended'::character varying, 'deactivated'::character varying, 'revoked'::character varying, 'expired'::character varying, 'destroyed'::character varying])::text[]))),
    CONSTRAINT valid_cert_ownership CHECK ((cert_ownership IS NULL OR (cert_ownership)::text = ANY ((ARRAY['internal'::character varying, 'third_party'::character varying])::text[]))),
    CONSTRAINT valid_data_completeness CHECK (((data_completeness)::text = ANY ((ARRAY['complete'::character varying, 'partial'::character varying, 'placeholder'::character varying])::text[]))),
    CONSTRAINT valid_fingerprint_sha1 CHECK (((fingerprint_sha1 IS NULL) OR ((fingerprint_sha1)::text ~ '^[a-fA-F0-9]{40}$'::text))),
    CONSTRAINT valid_fingerprint_sha256 CHECK (((fingerprint_sha256)::text ~ '^[a-fA-F0-9]{64}$'::text)),
    CONSTRAINT valid_key_size CHECK (((public_key_size IS NULL) OR (public_key_size > 0)))
);


-- TABLE: cmdb_entity_mappings
CREATE TABLE IF NOT EXISTS public.cmdb_entity_mappings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    local_entity_type character varying(50) NOT NULL,
    local_entity_id uuid NOT NULL,
    cmdb_platform character varying(50) NOT NULL,
    cmdb_ci_type character varying(100) NOT NULL,
    cmdb_ci_id character varying(255),
    cmdb_sys_id character varying(255),
    sync_status character varying(20) DEFAULT 'pending'::character varying,
    last_synced_at timestamp with time zone,
    last_sync_error text,
    sync_direction character varying(20) DEFAULT 'push'::character varying,
    field_hash character varying(64),
    external_url text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_cmdb_entity_type CHECK (((local_entity_type)::text = ANY ((ARRAY['infrastructure_asset'::character varying, 'certificate'::character varying, 'key'::character varying, 'crypto_library'::character varying, 'crypto_configuration'::character varying])::text[]))),
    CONSTRAINT valid_cmdb_mapping_platform CHECK (((cmdb_platform)::text = ANY ((ARRAY['servicenow'::character varying, 'device42'::character varying, 'solarwinds'::character varying, 'oomnitza'::character varying])::text[]))),
    CONSTRAINT valid_cmdb_mapping_status CHECK (((sync_status)::text = ANY ((ARRAY['pending'::character varying, 'synced'::character varying, 'error'::character varying, 'stale'::character varying, 'deleted'::character varying])::text[]))),
    CONSTRAINT valid_cmdb_sync_direction CHECK (((sync_direction)::text = ANY ((ARRAY['push'::character varying, 'reconcile'::character varying])::text[])))
);


-- TABLE: cmdb_sync_jobs
CREATE TABLE IF NOT EXISTS public.cmdb_sync_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    trigger_type character varying(20) DEFAULT 'manual'::character varying NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    items_pushed integer DEFAULT 0,
    items_reconciled integer DEFAULT 0,
    items_failed integer DEFAULT 0,
    items_skipped integer DEFAULT 0,
    error_log jsonb DEFAULT '[]'::jsonb,
    summary jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_sync_job_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'in_progress'::character varying, 'success'::character varying, 'partial'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT valid_sync_trigger_type CHECK (((trigger_type)::text = ANY ((ARRAY['manual'::character varying, 'scheduled'::character varying, 'event'::character varying, 'retry'::character varying])::text[])))
);


-- TABLE: cmdb_sync_profiles
CREATE TABLE IF NOT EXISTS public.cmdb_sync_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    platform_type character varying(50) NOT NULL,
    connection_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    field_mapping_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    sync_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    ci_type_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_enabled boolean DEFAULT false,
    last_sync_at timestamp with time zone,
    last_sync_status character varying(20),
    sync_error text,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT valid_cmdb_platform_type CHECK (((platform_type)::text = ANY ((ARRAY['servicenow'::character varying, 'device42'::character varying, 'solarwinds'::character varying, 'oomnitza'::character varying])::text[]))),
    CONSTRAINT valid_cmdb_sync_status CHECK (((last_sync_status IS NULL) OR ((last_sync_status)::text = ANY ((ARRAY['success'::character varying, 'partial'::character varying, 'failed'::character varying, 'in_progress'::character varying, 'cancelled'::character varying])::text[]))))
);


-- TABLE: compliance_finding_history
CREATE TABLE IF NOT EXISTS public.compliance_finding_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    finding_id uuid NOT NULL,
    changed_by uuid,
    changed_at timestamp with time zone DEFAULT now(),
    field_name character varying(50) NOT NULL,
    old_value text,
    new_value text,
    change_reason text
);


-- TABLE: compliance_overrides
CREATE TABLE IF NOT EXISTS public.compliance_overrides (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    scenario_id uuid,
    control_id uuid NOT NULL,
    override_type character varying(20) NOT NULL,
    severity_from character varying(20),
    severity_to character varying(20),
    rationale text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    framework_type character varying(20) DEFAULT 'platform'::character varying NOT NULL,
    CONSTRAINT compliance_overrides_framework_type_check CHECK (((framework_type)::text = ANY ((ARRAY['platform'::character varying, 'tenant'::character varying])::text[]))),
    CONSTRAINT compliance_overrides_override_type_check CHECK (((override_type)::text = ANY ((ARRAY['disregard'::character varying, 'severity'::character varying])::text[]))),
    CONSTRAINT compliance_overrides_severity_from_check CHECK (((severity_from)::text = ANY ((ARRAY['Low'::character varying, 'Med'::character varying, 'High'::character varying, 'Critical'::character varying])::text[]))),
    CONSTRAINT compliance_overrides_severity_to_check CHECK (((severity_to)::text = ANY ((ARRAY['Low'::character varying, 'Med'::character varying, 'High'::character varying, 'Critical'::character varying])::text[])))
);


-- TABLE: compliance_rules
CREATE TABLE IF NOT EXISTS public.compliance_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT compliance_rules_severity_check CHECK (((severity)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[])))
);


-- TABLE: compliance_scenarios
CREATE TABLE IF NOT EXISTS public.compliance_scenarios (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    framework_id uuid NOT NULL,
    framework_version character varying(20) NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by uuid NOT NULL,
    updated_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    framework_type character varying(20) DEFAULT 'platform'::character varying NOT NULL,
    CONSTRAINT compliance_scenarios_framework_type_check CHECK (((framework_type)::text = ANY ((ARRAY['platform'::character varying, 'tenant'::character varying])::text[])))
);


-- TABLE: connector_connections
--
-- One tenant-configured connection to an external system that is NOT a CMDB
-- sync profile and NOT a cloud/SaaS platform_integration: the
-- `network_source_of_truth` family and whatever joins it.
--
-- Why a third store rather than a column on platform_integrations: that table
-- is the ADMIN-plane integration registry (shared, cross-tenant capable,
-- provider-typed) and cmdb_sync_profiles carries push/field-mapping concepts a
-- pull-only connector has no use for. Stretching either to fit would have made
-- half its columns meaningless for the new rows — which is how a table ends up
-- with a column nobody can explain.
--
-- connector_key is the registry key (standards/connectors.yaml). The CHECK is
-- hand-maintained and audited against the registry by
-- scripts/generate-connectors.mjs --check, exactly like the other two.
CREATE TABLE IF NOT EXISTS public.connector_connections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    connector_key character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    base_url text NOT NULL,
    -- Credential-bearing. Written through shared/security/credentials with
    -- credentials.ConnectorAuthConfigPolicy; the audit at
    -- scripts/audit-credential-encryption.mjs fails any writer that does not.
    auth_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    -- Non-secret connector options (default environment for imported segments,
    -- device-role→class overrides). Deliberately separate from auth_config so
    -- the credential cipher has a narrow, stable blob to protect.
    options jsonb DEFAULT '{}'::jsonb NOT NULL,
    -- Whether this connection may target an RFC1918 / private address.
    -- Defaults TRUE for the network-source-of-truth family because such a
    -- system is on-premises by construction; the SSRF guard still refuses
    -- loopback, link-local and cloud-metadata addresses whatever this says.
    -- Every private-target connection is recorded in the audit log on save.
    allow_private_endpoint boolean DEFAULT true NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    schedule character varying(20) DEFAULT 'manual'::character varying NOT NULL,
    last_run_at timestamp with time zone,
    last_run_status character varying(20),
    last_error text,
    last_tested_at timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT connector_connections_pkey PRIMARY KEY (id),
    CONSTRAINT connector_connections_unique_name UNIQUE (tenant_id, connector_key, name),
    CONSTRAINT valid_connector_key CHECK (((connector_key)::text = ANY ((ARRAY['netbox'::character varying])::text[]))),
    CONSTRAINT valid_connector_schedule CHECK (((schedule)::text = ANY ((ARRAY['manual'::character varying, 'hourly'::character varying, 'daily'::character varying, 'weekly'::character varying])::text[]))),
    CONSTRAINT valid_connector_last_run_status CHECK (((last_run_status IS NULL) OR ((last_run_status)::text = ANY ((ARRAY['success'::character varying, 'partial'::character varying, 'failed'::character varying, 'in_progress'::character varying])::text[]))))
);
CREATE INDEX IF NOT EXISTS idx_connector_connections_tenant ON public.connector_connections USING btree (tenant_id, connector_key) WHERE (deleted_at IS NULL);
CREATE INDEX IF NOT EXISTS idx_connector_connections_due ON public.connector_connections USING btree (schedule, last_run_at) WHERE (deleted_at IS NULL AND is_enabled = true);


-- TABLE: connector_runs
--
-- One execution of a connector_connections row, with the counts the
-- integration's page shows. Counts live in a typed `summary` jsonb rather than
-- twelve integer columns because each connector kind counts different things;
-- what is NOT optional is that a run records them, so "it said success" can be
-- checked against "it imported nothing".
CREATE TABLE IF NOT EXISTS public.connector_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    status character varying(20) DEFAULT 'in_progress'::character varying NOT NULL,
    trigger_type character varying(20) DEFAULT 'manual'::character varying NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_log jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT connector_runs_pkey PRIMARY KEY (id),
    CONSTRAINT valid_connector_run_status CHECK (((status)::text = ANY ((ARRAY['in_progress'::character varying, 'success'::character varying, 'partial'::character varying, 'failed'::character varying])::text[]))),
    CONSTRAINT valid_connector_run_trigger CHECK (((trigger_type)::text = ANY ((ARRAY['manual'::character varying, 'scheduled'::character varying, 'test'::character varying])::text[])))
);
CREATE INDEX IF NOT EXISTS idx_connector_runs_connection ON public.connector_runs USING btree (connection_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_connector_runs_tenant ON public.connector_runs USING btree (tenant_id, started_at DESC);


-- TABLE: control_measurements
CREATE TABLE IF NOT EXISTS public.control_measurements (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    control_id uuid NOT NULL,
    framework_type character varying(20) NOT NULL,
    measurement_type_id uuid NOT NULL,
    rule_type character varying(20) NOT NULL,
    predicate jsonb NOT NULL,
    severity_override character varying(20),
    weight integer DEFAULT 1,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT control_measurements_framework_type_check CHECK (((framework_type)::text = ANY ((ARRAY['platform'::character varying, 'tenant'::character varying])::text[]))),
    CONSTRAINT control_measurements_rule_type_check CHECK (((rule_type)::text = ANY ((ARRAY['threshold'::character varying, 'presence'::character varying, 'pattern'::character varying, 'range'::character varying])::text[]))),
    CONSTRAINT control_measurements_severity_override_check CHECK (((severity_override)::text = ANY ((ARRAY['Low'::character varying, 'Med'::character varying, 'High'::character varying, 'Critical'::character varying])::text[]))),
    CONSTRAINT valid_weight CHECK (((weight >= 1) AND (weight <= 10)))
);


-- TABLE: crypto_applications
CREATE TABLE IF NOT EXISTS public.crypto_applications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid,
    resource_type character varying(50) NOT NULL,
    resource_identifier text NOT NULL,
    resource_name character varying(255),
    encryption_context character varying(50) NOT NULL,
    algorithm_id uuid,
    key_id uuid,
    library_id uuid,
    certificate_id uuid,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    cipher_suite character varying(255),
    key_size integer,
    mode character varying(50),
    configuration_source text,
    configuration_data jsonb DEFAULT '{}'::jsonb,
    discovery_method public.discovery_method DEFAULT 'manual'::public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT valid_crypto_app_confidence CHECK (((confidence_score >= 0.0) AND (confidence_score <= 1.0))),
    CONSTRAINT valid_crypto_app_encryption_context CHECK (((encryption_context)::text = ANY ((ARRAY['at_rest'::character varying, 'in_transit'::character varying, 'in_use'::character varying, 'key_storage'::character varying, 'signing'::character varying, 'hashing'::character varying, 'authentication'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT valid_crypto_app_resource_type CHECK (((resource_type)::text = ANY ((ARRAY['disk_volume'::character varying, 'file'::character varying, 'database'::character varying, 'cloud_storage'::character varying, 'hsm'::character varying, 'application'::character varying, 'build_artifact'::character varying, 'container'::character varying, 'vm_image'::character varying, 'backup'::character varying, 'communication'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT valid_crypto_app_risk CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);




-- TABLE: crypto_implementation_algorithms
CREATE TABLE IF NOT EXISTS public.crypto_implementation_algorithms (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    crypto_implementation_id uuid NOT NULL,
    algorithm_id uuid NOT NULL,
    algorithm_type character varying(50) NOT NULL,
    is_inferred boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_algorithm_type CHECK (((algorithm_type)::text = ANY ((ARRAY['hash'::character varying, 'symmetric'::character varying, 'key_exchange'::character varying, 'signature'::character varying, 'protocol_version'::character varying, 'cipher_suite'::character varying])::text[])))
);


-- TABLE: crypto_implementation_certificates
CREATE TABLE IF NOT EXISTS public.crypto_implementation_certificates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    crypto_implementation_id uuid NOT NULL,
    certificate_id uuid NOT NULL,
    certificate_role character varying(50) DEFAULT 'additional'::character varying,
    certificate_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_certificate_role CHECK (((certificate_role)::text = ANY ((ARRAY['leaf'::character varying, 'primary'::character varying, 'additional'::character varying, 'intermediate'::character varying, 'root'::character varying])::text[])))
);


-- TABLE: crypto_implementations_partitioned
CREATE TABLE IF NOT EXISTS public.crypto_implementations_partitioned (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    -- The endpoint this configuration was measured on (DATA_MODEL §2). NULL for
    -- a configuration that is not tied to one socket: an at-rest cloud resource
    -- has no endpoint at all, which is what retires the "AT-REST" port
    -- sentinel. asset_id stays and is the roll-up target.
    endpoint_id uuid,
    protocol public.protocol_type NOT NULL,
    protocol_version character varying(100),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    signature_algorithm character varying(100),
    symmetric_encryption character varying(100),
    hash_algorithm character varying(100),
    key_size integer,
    certificate_id uuid,
    discovery_method public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    source_sensor_id uuid,
    raw_data jsonb,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    pfs_support boolean,
    tls_compression_enabled boolean,
    certificate_chain_valid boolean,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    components_inferred boolean DEFAULT false,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
)
PARTITION BY HASH (tenant_id);

-- CREATE TABLE IF NOT EXISTS above is a no-op on a database that already has
-- this table, so the new column needs its own statement for existing installs.
-- ADD COLUMN on a partitioned parent propagates to every attached partition, so
-- one statement covers all eight. It sits HERE, not in POST-MIGRATIONS, because
-- the view immediately below selects the column.
ALTER TABLE public.crypto_implementations_partitioned ADD COLUMN IF NOT EXISTS endpoint_id uuid;


-- VIEW: crypto_implementations
-- DROP + CREATE, not CREATE OR REPLACE. `CREATE OR REPLACE VIEW` may only
-- APPEND columns to the end of an existing view's list; inserting one in the
-- middle — `endpoint_id` between asset_id and protocol, below — is refused with
--   ERROR: cannot change name of view column "protocol" to "endpoint_id"
-- on every database that already carries the old view, which aborts the whole
-- apply under ON_ERROR_STOP=1. That is the same class as the `character
-- varying` → `text` note further down: OR REPLACE cannot change a view's
-- column list OR a column's type, only add to the end.
--
-- CASCADE is safe and checked: nothing in this file or in any lab database
-- selects from this view (the only other reference is the security_invoker
-- ALTER in POST-MIGRATIONS, which runs after this and re-applies it). A future
-- dependent added between here and POST-MIGRATIONS would be dropped silently,
-- so add dependents AFTER this statement, never before it.
DROP VIEW IF EXISTS public.crypto_implementations CASCADE;
CREATE VIEW public.crypto_implementations AS
 SELECT crypto_implementations_partitioned.id,
    crypto_implementations_partitioned.tenant_id,
    crypto_implementations_partitioned.asset_id,
    crypto_implementations_partitioned.endpoint_id,
    crypto_implementations_partitioned.protocol,
    crypto_implementations_partitioned.protocol_version,
    crypto_implementations_partitioned.cipher_suite,
    crypto_implementations_partitioned.key_exchange_algorithm,
    crypto_implementations_partitioned.signature_algorithm,
    crypto_implementations_partitioned.symmetric_encryption,
    crypto_implementations_partitioned.hash_algorithm,
    crypto_implementations_partitioned.key_size,
    crypto_implementations_partitioned.certificate_id,
    crypto_implementations_partitioned.discovery_method,
    crypto_implementations_partitioned.confidence_score,
    crypto_implementations_partitioned.source_sensor_id,
    crypto_implementations_partitioned.raw_data,
    crypto_implementations_partitioned.risk_score,
    crypto_implementations_partitioned.compliance_status,
    crypto_implementations_partitioned.pfs_support,
    crypto_implementations_partitioned.tls_compression_enabled,
    crypto_implementations_partitioned.certificate_chain_valid,
    crypto_implementations_partitioned.execution_environment,
    crypto_implementations_partitioned.implementation_platform,
    crypto_implementations_partitioned.certification_level,
    crypto_implementations_partitioned.data_completeness,
    crypto_implementations_partitioned.components_inferred,
    crypto_implementations_partitioned.first_discovered_at,
    crypto_implementations_partitioned.last_verified_at,
    crypto_implementations_partitioned.created_at,
    crypto_implementations_partitioned.updated_at,
    crypto_implementations_partitioned.deleted_at
   FROM public.crypto_implementations_partitioned;


-- TABLE: crypto_implementations_part_0
CREATE TABLE IF NOT EXISTS public.crypto_implementations_part_0 (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    -- The endpoint this configuration was measured on (DATA_MODEL §2). NULL for
    -- a configuration that is not tied to one socket: an at-rest cloud resource
    -- has no endpoint at all, which is what retires the "AT-REST" port
    -- sentinel. asset_id stays and is the roll-up target.
    endpoint_id uuid,
    protocol public.protocol_type NOT NULL,
    protocol_version character varying(100),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    signature_algorithm character varying(100),
    symmetric_encryption character varying(100),
    hash_algorithm character varying(100),
    key_size integer,
    certificate_id uuid,
    discovery_method public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    source_sensor_id uuid,
    raw_data jsonb,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    pfs_support boolean,
    tls_compression_enabled boolean,
    certificate_chain_valid boolean,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    components_inferred boolean DEFAULT false,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


-- TABLE: crypto_implementations_part_1
CREATE TABLE IF NOT EXISTS public.crypto_implementations_part_1 (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    -- The endpoint this configuration was measured on (DATA_MODEL §2). NULL for
    -- a configuration that is not tied to one socket: an at-rest cloud resource
    -- has no endpoint at all, which is what retires the "AT-REST" port
    -- sentinel. asset_id stays and is the roll-up target.
    endpoint_id uuid,
    protocol public.protocol_type NOT NULL,
    protocol_version character varying(100),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    signature_algorithm character varying(100),
    symmetric_encryption character varying(100),
    hash_algorithm character varying(100),
    key_size integer,
    certificate_id uuid,
    discovery_method public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    source_sensor_id uuid,
    raw_data jsonb,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    pfs_support boolean,
    tls_compression_enabled boolean,
    certificate_chain_valid boolean,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    components_inferred boolean DEFAULT false,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


-- TABLE: crypto_implementations_part_2
CREATE TABLE IF NOT EXISTS public.crypto_implementations_part_2 (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    -- The endpoint this configuration was measured on (DATA_MODEL §2). NULL for
    -- a configuration that is not tied to one socket: an at-rest cloud resource
    -- has no endpoint at all, which is what retires the "AT-REST" port
    -- sentinel. asset_id stays and is the roll-up target.
    endpoint_id uuid,
    protocol public.protocol_type NOT NULL,
    protocol_version character varying(100),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    signature_algorithm character varying(100),
    symmetric_encryption character varying(100),
    hash_algorithm character varying(100),
    key_size integer,
    certificate_id uuid,
    discovery_method public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    source_sensor_id uuid,
    raw_data jsonb,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    pfs_support boolean,
    tls_compression_enabled boolean,
    certificate_chain_valid boolean,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    components_inferred boolean DEFAULT false,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


-- TABLE: crypto_implementations_part_3
CREATE TABLE IF NOT EXISTS public.crypto_implementations_part_3 (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    -- The endpoint this configuration was measured on (DATA_MODEL §2). NULL for
    -- a configuration that is not tied to one socket: an at-rest cloud resource
    -- has no endpoint at all, which is what retires the "AT-REST" port
    -- sentinel. asset_id stays and is the roll-up target.
    endpoint_id uuid,
    protocol public.protocol_type NOT NULL,
    protocol_version character varying(100),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    signature_algorithm character varying(100),
    symmetric_encryption character varying(100),
    hash_algorithm character varying(100),
    key_size integer,
    certificate_id uuid,
    discovery_method public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    source_sensor_id uuid,
    raw_data jsonb,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    pfs_support boolean,
    tls_compression_enabled boolean,
    certificate_chain_valid boolean,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    components_inferred boolean DEFAULT false,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


-- TABLE: crypto_implementations_part_4
CREATE TABLE IF NOT EXISTS public.crypto_implementations_part_4 (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    -- The endpoint this configuration was measured on (DATA_MODEL §2). NULL for
    -- a configuration that is not tied to one socket: an at-rest cloud resource
    -- has no endpoint at all, which is what retires the "AT-REST" port
    -- sentinel. asset_id stays and is the roll-up target.
    endpoint_id uuid,
    protocol public.protocol_type NOT NULL,
    protocol_version character varying(100),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    signature_algorithm character varying(100),
    symmetric_encryption character varying(100),
    hash_algorithm character varying(100),
    key_size integer,
    certificate_id uuid,
    discovery_method public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    source_sensor_id uuid,
    raw_data jsonb,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    pfs_support boolean,
    tls_compression_enabled boolean,
    certificate_chain_valid boolean,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    components_inferred boolean DEFAULT false,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


-- TABLE: crypto_implementations_part_5
CREATE TABLE IF NOT EXISTS public.crypto_implementations_part_5 (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    -- The endpoint this configuration was measured on (DATA_MODEL §2). NULL for
    -- a configuration that is not tied to one socket: an at-rest cloud resource
    -- has no endpoint at all, which is what retires the "AT-REST" port
    -- sentinel. asset_id stays and is the roll-up target.
    endpoint_id uuid,
    protocol public.protocol_type NOT NULL,
    protocol_version character varying(100),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    signature_algorithm character varying(100),
    symmetric_encryption character varying(100),
    hash_algorithm character varying(100),
    key_size integer,
    certificate_id uuid,
    discovery_method public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    source_sensor_id uuid,
    raw_data jsonb,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    pfs_support boolean,
    tls_compression_enabled boolean,
    certificate_chain_valid boolean,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    components_inferred boolean DEFAULT false,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


-- TABLE: crypto_implementations_part_6
CREATE TABLE IF NOT EXISTS public.crypto_implementations_part_6 (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    -- The endpoint this configuration was measured on (DATA_MODEL §2). NULL for
    -- a configuration that is not tied to one socket: an at-rest cloud resource
    -- has no endpoint at all, which is what retires the "AT-REST" port
    -- sentinel. asset_id stays and is the roll-up target.
    endpoint_id uuid,
    protocol public.protocol_type NOT NULL,
    protocol_version character varying(100),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    signature_algorithm character varying(100),
    symmetric_encryption character varying(100),
    hash_algorithm character varying(100),
    key_size integer,
    certificate_id uuid,
    discovery_method public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    source_sensor_id uuid,
    raw_data jsonb,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    pfs_support boolean,
    tls_compression_enabled boolean,
    certificate_chain_valid boolean,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    components_inferred boolean DEFAULT false,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


-- TABLE: crypto_implementations_part_7
CREATE TABLE IF NOT EXISTS public.crypto_implementations_part_7 (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    -- The endpoint this configuration was measured on (DATA_MODEL §2). NULL for
    -- a configuration that is not tied to one socket: an at-rest cloud resource
    -- has no endpoint at all, which is what retires the "AT-REST" port
    -- sentinel. asset_id stays and is the roll-up target.
    endpoint_id uuid,
    protocol public.protocol_type NOT NULL,
    protocol_version character varying(100),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    signature_algorithm character varying(100),
    symmetric_encryption character varying(100),
    hash_algorithm character varying(100),
    key_size integer,
    certificate_id uuid,
    discovery_method public.discovery_method NOT NULL,
    confidence_score numeric(3,2) DEFAULT 1.0,
    source_sensor_id uuid,
    raw_data jsonb,
    risk_score integer DEFAULT 0,
    compliance_status jsonb DEFAULT '{}'::jsonb,
    pfs_support boolean,
    tls_compression_enabled boolean,
    certificate_chain_valid boolean,
    execution_environment character varying(50),
    implementation_platform character varying(50),
    certification_level text[],
    data_completeness character varying(20) DEFAULT 'complete'::character varying,
    components_inferred boolean DEFAULT false,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


-- TABLE: crypto_libraries
CREATE TABLE IF NOT EXISTS public.crypto_libraries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    version text NOT NULL,
    vendor text,
    cpe text,
    purl character varying(500),
    certification_level text[],
    build_metadata jsonb DEFAULT '{}'::jsonb,
    known_vulnerabilities jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: tenant_resource_usage
CREATE TABLE IF NOT EXISTS public.tenant_resource_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    api_calls integer DEFAULT 0,
    database_queries integer DEFAULT 0,
    memory_usage_mb integer DEFAULT 0,
    cpu_usage_percent numeric(5,2) DEFAULT 0,
    storage_used_mb integer DEFAULT 0,
    network_bytes bigint DEFAULT 0,
    cost_usd numeric(10,4) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    cost_breakdown jsonb DEFAULT '{}'::jsonb
);


-- VIEW: current_resource_usage_summary
CREATE OR REPLACE VIEW public.current_resource_usage_summary AS
 SELECT t.id AS tenant_id,
    t.name AS tenant_name,
    COALESCE(ru.total_api_calls, (0)::bigint) AS total_api_calls,
    COALESCE(ru.total_db_queries, (0)::bigint) AS total_db_queries,
    COALESCE(ru.avg_memory_mb, (0)::numeric) AS avg_memory_mb,
    COALESCE(ru.avg_cpu_percent, (0)::numeric) AS avg_cpu_percent,
    COALESCE(ru.total_storage_mb, (0)::bigint) AS total_storage_mb,
    COALESCE(ru.total_network_mb, (0)::numeric) AS total_network_mb,
    COALESCE(ru.total_cost_usd, (0)::numeric) AS total_cost_usd
   FROM (public.tenants t
     LEFT JOIN ( SELECT tenant_resource_usage.tenant_id,
            sum(tenant_resource_usage.api_calls) AS total_api_calls,
            sum(tenant_resource_usage.database_queries) AS total_db_queries,
            avg(tenant_resource_usage.memory_usage_mb) AS avg_memory_mb,
            avg(tenant_resource_usage.cpu_usage_percent) AS avg_cpu_percent,
            sum(tenant_resource_usage.storage_used_mb) AS total_storage_mb,
            (sum(tenant_resource_usage.network_bytes) / ((1024 * 1024))::numeric) AS total_network_mb,
            sum(tenant_resource_usage.cost_usd) AS total_cost_usd
           FROM public.tenant_resource_usage
          WHERE (tenant_resource_usage."timestamp" >= (now() - '24:00:00'::interval))
          GROUP BY tenant_resource_usage.tenant_id) ru ON ((t.id = ru.tenant_id)));


-- TABLE: database_encryption_states
CREATE TABLE IF NOT EXISTS public.database_encryption_states (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    -- One asset link, not two. This table carried BOTH device_id (-> devices)
    -- and asset_id (-> network_assets) because a device and the asset the same
    -- host produced through ingest were separate rows with no link between them
    -- (ADR-0002 "the devices table is a second asset table"). With `devices`
    -- merged into `assets` they are the same row, so device_id is dropped and
    -- asset_id is the one link. DATA_MODEL §2's "device_id -> asset_id" reads as
    -- a rename only for tables that had no asset_id already; this one did.
    asset_id uuid,
    db_engine character varying(50) NOT NULL,
    db_version character varying(100),
    hostname character varying(255),
    port integer,
    instance_name character varying(255),
    ssl_enabled boolean,
    ssl_version character varying(50),
    ssl_cipher character varying(255),
    ssl_enforced boolean,
    certificate_id uuid,
    encryption_at_rest_enabled boolean,
    encryption_method character varying(100),
    encryption_algorithm character varying(100),
    encryption_key_source character varying(100),
    password_encryption_method character varying(50),
    ssl_algorithm_id uuid,
    encryption_algorithm_id uuid,
    password_algorithm_id uuid,
    risk_score integer DEFAULT 50,
    discovery_method public.discovery_method DEFAULT 'device_interrogation'::public.discovery_method NOT NULL,
    raw_config jsonb DEFAULT '{}'::jsonb,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT valid_db_encryption_risk CHECK (((risk_score >= 0) AND (risk_score <= 100))),
    CONSTRAINT valid_db_engine CHECK (((db_engine)::text = ANY ((ARRAY['postgresql'::character varying, 'mysql'::character varying, 'sqlserver'::character varying, 'oracle'::character varying, 'mongodb'::character varying])::text[])))
);


-- TABLE: device_agents
CREATE TABLE IF NOT EXISTS public.device_agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    registration_key character varying(255) NOT NULL,
    name character varying(255),
    description text,
    platform character varying(50) NOT NULL,
    version character varying(50) NOT NULL,
    profile character varying(50),
    status character varying(20) DEFAULT 'active'::character varying,
    -- Primary address, self-reported by the agent (parity with sensors.ip_address,
    -- and typed to match it). The platform cannot observe this through NAT.
    ip_address character varying(45),
    last_heartbeat timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'error'::character varying])::text[])))
);


-- TABLE: device_jobs
CREATE TABLE IF NOT EXISTS public.device_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    job_type public.device_job_type NOT NULL,
    -- Renamed from device_id (DATA_MODEL §2): a job targets an asset, because
    -- `devices` is gone and an interrogated device is an asset with an
    -- asset_management row.
    asset_id uuid,
    integration_id uuid,
    agent_id uuid,
    status public.device_job_status DEFAULT 'pending'::public.device_job_status,
    credentials jsonb,
    parameters jsonb DEFAULT '{}'::jsonb,
    results jsonb,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    assigned_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    expires_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT valid_job_assignment CHECK ((((agent_id IS NULL) AND (job_type = 'cloud_discovery'::public.device_job_type)) OR ((agent_id IS NOT NULL) AND (job_type = 'device_interrogation'::public.device_job_type)) OR ((agent_id IS NULL) AND (job_type = 'device_interrogation'::public.device_job_type) AND (asset_id IS NOT NULL)) OR ((agent_id IS NOT NULL) AND (job_type = 'host_inventory'::public.device_job_type))))
);


-- TABLE: discovery_alert_configs
CREATE TABLE IF NOT EXISTS public.discovery_alert_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    alert_type character varying(50) NOT NULL,
    enabled boolean DEFAULT true,
    email_enabled boolean DEFAULT false,
    slack_enabled boolean DEFAULT false,
    slack_webhook_url text,
    slack_channel character varying(255),
    in_app_enabled boolean DEFAULT true,
    conditions jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: discovery_alert_history
CREATE TABLE IF NOT EXISTS public.discovery_alert_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    alert_type character varying(50) NOT NULL,
    job_id uuid,
    finding_id uuid,
    message text NOT NULL,
    sent_via text[] NOT NULL,
    sent_at timestamp with time zone DEFAULT now(),
    status character varying(20) DEFAULT 'sent'::character varying NOT NULL,
    CONSTRAINT discovery_alert_history_status_check CHECK (((status)::text = ANY ((ARRAY['sent'::character varying, 'failed'::character varying, 'pending'::character varying])::text[])))
);


-- TABLE: discovery_auto_approval_rules
CREATE TABLE IF NOT EXISTS public.discovery_auto_approval_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    -- The rule, as a query-language string over the `observation` target
    -- (QUERY_LANGUAGE.md §8). It replaced a jsonb `conditions` object whose
    -- seven keys were interpreted by a hand-written evaluator; the language is
    -- validated on write, so a typo is a 422 rather than a key the evaluator
    -- silently ignores. An EMPTY query matches every observation, which is a
    -- rule that auto-approves everything — deliberately expressible, and
    -- deliberately something a person has to type.
    query text DEFAULT ''::text NOT NULL,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: discovery_findings
CREATE TABLE IF NOT EXISTS public.discovery_findings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    job_id uuid NOT NULL,
    target_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    executed_via text NOT NULL,
    protocol text NOT NULL,
    port integer NOT NULL,
    resolved_ip inet,
    hostname character varying(255),
    details jsonb,
    raw_blob_ref text,
    raw_blob_size integer DEFAULT 0 NOT NULL,
    error_code text,
    confidence_score numeric(3,2) DEFAULT 0.0,
    created_at timestamp with time zone DEFAULT now(),
    "timestamp" timestamp with time zone
);


-- TABLE: discovery_jobs
CREATE TABLE IF NOT EXISTS public.discovery_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    created_by uuid,
    execution_mode text NOT NULL,
    requested_sensor_ids text[],
    fanout boolean DEFAULT true,
    status text DEFAULT 'queued'::text NOT NULL,
    retention_cap_mb integer DEFAULT 25 NOT NULL,
    retention_ttl_hours integer DEFAULT 24 NOT NULL,
    -- Audit column: which OT active probes the operator opted into for this job.
    -- Empty array = no OT active probing was approved; non-empty = the listed
    -- protocols (Modbus, OPC_UA, EtherNet_IP, BACnet) were dispatched.
    ot_probe_protocols text[] DEFAULT '{}'::text[],
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: discovery_rate_limits
CREATE TABLE IF NOT EXISTS public.discovery_rate_limits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    scans_per_hour integer DEFAULT 100 NOT NULL,
    concurrent_jobs integer DEFAULT 5 NOT NULL,
    max_targets_per_job integer DEFAULT 1000 NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: discovery_targets
CREATE TABLE IF NOT EXISTS public.discovery_targets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    job_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    input text NOT NULL,
    protocols text[] NOT NULL,
    ports integer[] NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: external_asset_mappings
CREATE TABLE IF NOT EXISTS public.external_asset_mappings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    local_type text NOT NULL,
    local_id uuid NOT NULL,
    external_system text NOT NULL,
    external_id text NOT NULL,
    sync_status text,
    last_synced_at timestamp with time zone,
    last_sync_error text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: external_connection_history
CREATE TABLE IF NOT EXISTS public.external_connection_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    external_connection_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    change_type character varying(50) NOT NULL,
    previous_protocol_version character varying(50),
    previous_cipher_suite character varying(255),
    previous_crypto_strength character varying(20),
    previous_is_pqc_resistant boolean,
    previous_cert_fingerprint_sha256 character varying(64),
    previous_cert_not_after timestamp with time zone,
    new_protocol_version character varying(50),
    new_cipher_suite character varying(255),
    new_crypto_strength character varying(20),
    new_is_pqc_resistant boolean,
    new_cert_fingerprint_sha256 character varying(64),
    new_cert_not_after timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT external_connection_history_change_type_check CHECK (((change_type)::text = ANY ((ARRAY['first_seen'::character varying, 'cert_rotated'::character varying, 'cipher_changed'::character varying, 'protocol_upgraded'::character varying, 'protocol_downgraded'::character varying, 'crypto_strength_changed'::character varying])::text[])))
);


-- TABLE: external_connections
CREATE TABLE IF NOT EXISTS public.external_connections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    source_ip inet NOT NULL,
    source_hostname character varying(255),
    source_asset_id uuid,
    dest_ip inet NOT NULL,
    dest_hostname character varying(255),
    dest_port integer NOT NULL,
    protocol character varying(50) NOT NULL,
    protocol_version character varying(50),
    cipher_suite character varying(255),
    key_exchange_algorithm character varying(100),
    key_size integer,
    supported_tls_versions text[],
    crypto_strength character varying(20) DEFAULT 'unknown'::character varying NOT NULL,
    is_pqc_resistant boolean DEFAULT false NOT NULL,
    weak_reasons text[] DEFAULT '{}'::text[],
    cert_subject character varying(500),
    cert_issuer character varying(500),
    cert_san text[],
    cert_not_before timestamp with time zone,
    cert_not_after timestamp with time zone,
    cert_fingerprint_sha256 character varying(64),
    cert_public_key_algorithm character varying(50),
    cert_public_key_size integer,
    cert_signature_algorithm character varying(100),
    cert_is_expired boolean DEFAULT false NOT NULL,
    cert_validation_status character varying(30),
    cert_pem text,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    observation_count bigint DEFAULT 1 NOT NULL,
    sensor_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    service_name character varying(100),
    service_version character varying(100),
    service_confidence character varying(20),
    service_identification_method character varying(50),
    -- Non-null once a tenant promotes a 3rd-party connection to a managed asset
    -- (#740); links the connection to that asset. App-managed, no FK: `assets`
    -- is hash-partitioned and soft-deleted.
    elevated_asset_id uuid,
    -- The endpoint of OUR asset the connection leaves from (DATA_MODEL §2).
    -- source_asset_id stays and is the roll-up target.
    --
    -- It is NULL for everything phase 1 writes, and that is a decision rather
    -- than an omission: an outbound connection leaves from an EPHEMERAL socket,
    -- which no producer observes and which is not an inventoried endpoint. The
    -- listening endpoint of the same asset is a different socket, and linking to
    -- it would assert a measurement nobody made. A producer that does report a
    -- source port (a host agent watching its own connections, ADR-0004 D3) fills
    -- it in.
    source_endpoint_id uuid,
    CONSTRAINT external_connections_crypto_strength_check CHECK (((crypto_strength)::text = ANY ((ARRAY['good'::character varying, 'weak'::character varying, 'unknown'::character varying])::text[]))),
    CONSTRAINT external_connections_dest_port_check CHECK (((dest_port >= 1) AND (dest_port <= 65535)))
);


-- TABLE: health_alerts
CREATE TABLE IF NOT EXISTS public.health_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    alert_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    category character varying(50) NOT NULL,
    current_value numeric(10,4) DEFAULT 0,
    threshold numeric(10,4) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone
);


-- TABLE: health_benchmarks
CREATE TABLE IF NOT EXISTS public.health_benchmarks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category character varying(50) NOT NULL,
    benchmark_score numeric(5,2) NOT NULL,
    description text NOT NULL,
    source character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: health_metrics
CREATE TABLE IF NOT EXISTS public.health_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    cpu_utilization numeric(5,2) DEFAULT 0,
    memory_utilization numeric(5,2) DEFAULT 0,
    storage_utilization numeric(5,2) DEFAULT 0,
    network_utilization numeric(5,2) DEFAULT 0,
    avg_response_time numeric(10,3) DEFAULT 0,
    error_rate numeric(5,4) DEFAULT 0,
    throughput numeric(10,2) DEFAULT 0,
    uptime numeric(5,2) DEFAULT 0,
    failed_logins integer DEFAULT 0,
    security_alerts integer DEFAULT 0,
    compliance_score numeric(5,2) DEFAULT 0,
    last_security_update timestamp with time zone,
    active_users integer DEFAULT 0,
    api_calls integer DEFAULT 0,
    feature_usage jsonb DEFAULT '{}'::jsonb,
    user_engagement numeric(5,2) DEFAULT 0,
    resource_cost numeric(10,2) DEFAULT 0,
    cost_per_user numeric(10,2) DEFAULT 0,
    cost_efficiency numeric(5,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


-- VIEW: health_metrics_aggregated_view
CREATE OR REPLACE VIEW public.health_metrics_aggregated_view AS
 SELECT health_metrics.tenant_id,
    date_trunc('hour'::text, health_metrics."timestamp") AS hour,
    avg(health_metrics.cpu_utilization) AS avg_cpu_utilization,
    avg(health_metrics.memory_utilization) AS avg_memory_utilization,
    avg(health_metrics.storage_utilization) AS avg_storage_utilization,
    avg(health_metrics.network_utilization) AS avg_network_utilization,
    avg(health_metrics.avg_response_time) AS avg_response_time,
    avg(health_metrics.error_rate) AS avg_error_rate,
    avg(health_metrics.throughput) AS avg_throughput,
    avg(health_metrics.uptime) AS avg_uptime,
    sum(health_metrics.failed_logins) AS total_failed_logins,
    sum(health_metrics.security_alerts) AS total_security_alerts,
    avg(health_metrics.compliance_score) AS avg_compliance_score,
    avg(health_metrics.active_users) AS avg_active_users,
    sum(health_metrics.api_calls) AS total_api_calls,
    avg(health_metrics.user_engagement) AS avg_user_engagement,
    sum(health_metrics.resource_cost) AS total_resource_cost,
    avg(health_metrics.cost_per_user) AS avg_cost_per_user,
    avg(health_metrics.cost_efficiency) AS avg_cost_efficiency
   FROM public.health_metrics
  GROUP BY health_metrics.tenant_id, (date_trunc('hour'::text, health_metrics."timestamp"))
  ORDER BY health_metrics.tenant_id, (date_trunc('hour'::text, health_metrics."timestamp"));


-- TABLE: implementation_keys
CREATE TABLE IF NOT EXISTS public.implementation_keys (
    implementation_id uuid NOT NULL,
    key_id uuid NOT NULL
);


-- TABLE: implementation_libraries
CREATE TABLE IF NOT EXISTS public.implementation_libraries (
    implementation_id uuid NOT NULL,
    library_id uuid NOT NULL
);


-- TABLE: in_app_notifications
CREATE TABLE IF NOT EXISTS public.in_app_notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    job_id uuid,
    finding_id uuid,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_notification_type CHECK (((type)::text = ANY ((ARRAY['alert'::character varying, 'discovery'::character varying, 'compliance'::character varying, 'system'::character varying, 'billing'::character varying, 'security'::character varying, 'other'::character varying])::text[])))
);


-- TABLE: integrations
CREATE TABLE IF NOT EXISTS public.integrations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    base_url text NOT NULL,
    auth_type text NOT NULL,
    auth_config jsonb NOT NULL,
    mapping_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: interrogation_schedules
CREATE TABLE IF NOT EXISTS public.interrogation_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    cron_expression character varying(100) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    last_run_at timestamp with time zone,
    last_run_status character varying(50),
    last_run_job_id uuid,
    next_run_at timestamp with time zone,
    success_count integer DEFAULT 0 NOT NULL,
    failure_count integer DEFAULT 0 NOT NULL,
    parameters jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT interrogation_schedules_target_type_check CHECK (((target_type)::text = ANY ((ARRAY['device'::character varying, 'cloud_integration'::character varying])::text[])))
);


-- TABLE: keys
CREATE TABLE IF NOT EXISTS public.keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    key_type text NOT NULL,
    key_usage text[],
    public_fingerprint text,
    jwk_thumbprint text,
    size_bits integer,
    curve text,
    material_type character varying(50) DEFAULT 'key'::character varying NOT NULL,
    state character varying(20) DEFAULT 'active'::character varying,
    state_reason text,
    format character varying(50),
    algorithm_id uuid,
    secured_by_mechanism character varying(100),
    secured_by_algorithm_id uuid,
    created_at timestamp with time zone,
    activation_date timestamp with time zone,
    rotated_at timestamp with time zone,
    deactivation_date timestamp with time zone,
    expires_at timestamp with time zone,
    destruction_date timestamp with time zone,
    fingerprint_algorithm character varying(20),
    fingerprint_value character varying(128),
    provenance text,
    metadata jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT valid_key_state CHECK (((state IS NULL) OR ((state)::text = ANY ((ARRAY['pre-activation'::character varying, 'active'::character varying, 'suspended'::character varying, 'deactivated'::character varying, 'compromised'::character varying, 'destroyed'::character varying])::text[])))),
    CONSTRAINT valid_material_type CHECK (((material_type)::text = ANY ((ARRAY['private-key'::character varying, 'public-key'::character varying, 'secret-key'::character varying, 'shared-secret'::character varying, 'key'::character varying, 'password'::character varying, 'credential'::character varying, 'token'::character varying, 'ciphertext'::character varying, 'signature'::character varying, 'digest'::character varying, 'initialization-vector'::character varying, 'nonce'::character varying, 'seed'::character varying, 'salt'::character varying, 'tag'::character varying, 'additional-data'::character varying, 'other'::character varying, 'unknown'::character varying])::text[])))
);


-- TABLE: kms_keys
CREATE TABLE IF NOT EXISTS public.kms_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    integration_id uuid NOT NULL,
    provider character varying(20) NOT NULL,
    key_id character varying(500) NOT NULL,
    key_arn character varying(1000),
    key_name character varying(255),
    description text,
    key_spec character varying(100),
    key_usage character varying(50),
    algorithm_id uuid,
    key_size integer,
    key_state character varying(50) NOT NULL,
    creation_date timestamp with time zone,
    expiration_date timestamp with time zone,
    rotation_enabled boolean,
    last_rotated_at timestamp with time zone,
    rotation_period_days integer,
    origin character varying(50),
    key_manager character varying(50),
    multi_region boolean DEFAULT false,
    hsm_backed boolean DEFAULT false,
    risk_score integer DEFAULT 50,
    days_since_rotation integer,
    region character varying(50),
    account_id character varying(50),
    tags jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    discovery_method public.discovery_method DEFAULT 'cloud_api'::public.discovery_method NOT NULL,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT valid_kms_provider CHECK (((provider)::text = ANY ((ARRAY['aws'::character varying, 'azure'::character varying, 'gcp'::character varying, 'vault'::character varying])::text[]))),
    CONSTRAINT valid_kms_risk CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);


-- TABLE: library_provided_algorithms
CREATE TABLE IF NOT EXISTS public.library_provided_algorithms (
    library_id uuid NOT NULL,
    algorithm_id uuid NOT NULL,
    is_default boolean DEFAULT false,
    is_validated boolean DEFAULT false,
    certification_level text[]
);


-- TABLE: locations
CREATE TABLE IF NOT EXISTS public.locations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    parent_id uuid,
    location_type public.location_type NOT NULL,
    description text,
    address text,
    city character varying(100),
    state_province character varying(100),
    country character varying(100),
    latitude numeric(10,7),
    longitude numeric(10,7),
    timezone character varying(50),
    cloud_provider character varying(50),
    cloud_region character varying(100),
    metadata jsonb DEFAULT '{}'::jsonb,
    full_path text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: maintenance_windows
CREATE TABLE IF NOT EXISTS public.maintenance_windows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    type character varying(50) DEFAULT 'scheduled'::character varying NOT NULL,
    status character varying(50) DEFAULT 'scheduled'::character varying NOT NULL,
    affected_services text[] DEFAULT '{}'::text[],
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    actual_start timestamp with time zone,
    actual_end timestamp with time zone,
    notify_before_minutes integer DEFAULT 60,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: measurement_templates
CREATE TABLE IF NOT EXISTS public.measurement_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    measurement_type_id uuid,
    rule_type character varying(20) NOT NULL,
    predicate jsonb NOT NULL,
    category character varying(50),
    framework_tags text[],
    version integer DEFAULT 1,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT measurement_templates_rule_type_check CHECK (((rule_type)::text = ANY ((ARRAY['threshold'::character varying, 'presence'::character varying, 'pattern'::character varying, 'range'::character varying])::text[]))),
    CONSTRAINT valid_rule_type CHECK (((rule_type)::text = ANY ((ARRAY['threshold'::character varying, 'presence'::character varying, 'pattern'::character varying, 'range'::character varying])::text[])))
);


-- TABLE: measurement_types
CREATE TABLE IF NOT EXISTS public.measurement_types (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    data_type character varying(20) NOT NULL,
    units character varying(50),
    valid_range jsonb,
    allowed_rule_types jsonb,
    enum_values jsonb,
    valid_operators jsonb,
    predicate_schema jsonb,
    category character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT measurement_types_data_type_check CHECK (((data_type)::text = ANY ((ARRAY['integer'::character varying, 'string'::character varying, 'enum'::character varying, 'date'::character varying, 'boolean'::character varying])::text[])))
);


-- TABLE: monitoring_alert_history
CREATE TABLE IF NOT EXISTS public.monitoring_alert_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    threshold_id uuid,
    threshold_name character varying(100) NOT NULL,
    metric_type character varying(50) NOT NULL,
    service_name character varying(100),
    threshold_value numeric(10,3) NOT NULL,
    actual_value numeric(10,3) NOT NULL,
    severity character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    acknowledged_by uuid,
    acknowledged_at timestamp with time zone,
    resolved_at timestamp with time zone,
    notifications_sent jsonb DEFAULT '[]'::jsonb,
    message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    triggered_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_alert_severity CHECK (((severity)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT valid_alert_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'acknowledged'::character varying, 'resolved'::character varying, 'suppressed'::character varying])::text[])))
);


-- TABLE: monitoring_alert_thresholds
CREATE TABLE IF NOT EXISTS public.monitoring_alert_thresholds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    threshold_name character varying(100) NOT NULL,
    metric_type character varying(50) NOT NULL,
    service_name character varying(100),
    warning_threshold numeric(10,3),
    critical_threshold numeric(10,3),
    severity character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    enabled boolean DEFAULT true,
    notify_email boolean DEFAULT false,
    notify_slack boolean DEFAULT false,
    notify_webhook boolean DEFAULT false,
    notify_in_app boolean DEFAULT true,
    comparison_operator character varying(10) DEFAULT 'gt'::character varying,
    duration_minutes integer DEFAULT 5,
    description text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by uuid,
    CONSTRAINT valid_metric_type CHECK (((metric_type)::text = ANY ((ARRAY['response_time'::character varying, 'error_rate'::character varying, 'cpu_usage'::character varying, 'memory_usage'::character varying, 'uptime'::character varying, 'throughput'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT valid_operator CHECK (((comparison_operator)::text = ANY ((ARRAY['gt'::character varying, 'lt'::character varying, 'eq'::character varying, 'gte'::character varying, 'lte'::character varying])::text[]))),
    CONSTRAINT valid_severity CHECK (((severity)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[])))
);


-- TABLE: monitoring_notification_channels
CREATE TABLE IF NOT EXISTS public.monitoring_notification_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_name character varying(100) NOT NULL,
    channel_type character varying(50) NOT NULL,
    config jsonb NOT NULL,
    enabled boolean DEFAULT true,
    test_status character varying(20),
    last_test_at timestamp with time zone,
    description text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by uuid,
    CONSTRAINT valid_channel_type CHECK (((channel_type)::text = ANY ((ARRAY['email'::character varying, 'slack'::character varying, 'webhook'::character varying, 'pagerduty'::character varying, 'custom'::character varying])::text[])))
);


-- ============================================================================
-- GENERAL ASSET INVENTORY — the unit of inventory (ADR-0002 D1)
-- ============================================================================
-- `assets` + `asset_endpoints` (and the `asset_classes` registry they resolve
-- against) sit HERE, where network_assets_partitioned used to, because the
-- operational views immediately below read them. The rest of the inventory
-- tables — identifiers, management, credentials, relationships, facts,
-- software, findings, catalogues — and every policy and trigger for all of
-- them are together further down, in the GENERAL ASSET INVENTORY block.
-- Column design: docsv4/internal/developer/design/asset-inventory/DATA_MODEL.md
-- §1–§2.

-- ----------------------------------------------------------------------------
-- 1. asset_classes — the class registry (DATA_MODEL §1, ADR-0002 D2)
-- ----------------------------------------------------------------------------
-- Hybrid table: platform rows carry tenant_id IS NULL and are seeded from
-- standards/asset-classes.yaml through the generated region in seed.sql;
-- tenant leaf subclasses are runtime rows with tenant_id set and
-- is_fixed = false.
--
-- `key` is unique per SCOPE, not globally: one partial unique index over the
-- platform rows (which is also the arbiter the generated seed's
-- `ON CONFLICT (key) WHERE tenant_id IS NULL` infers) and one over tenant rows.
-- Two tenants may therefore use the same subclass key independently.
--
-- The two indexes are DISJOINT, so they do not — and structurally cannot —
-- stop a tenant subclass from reusing a platform key: `WHERE tenant_id IS NULL`
-- and `WHERE tenant_id IS NOT NULL` never compare a row against the other set.
-- Nothing here forbids shadowing, and nothing here can: a CHECK may not run a
-- subquery, so the rule would need a trigger or an API-layer guard. That
-- matters because assets.class_key is an FK BY VALUE with no tenant qualifier,
-- so a shadowed key makes `class_key = 'server'` ambiguous — which
-- attribute_schema validates the asset, which identifier_precedence the
-- identification engine walks. Whether to forbid shadowing, and where, is
-- workstream 1.1's call (ADR-0002 D2 constrains tenants to leaf subclasses but
-- does not speak to key reuse). Do not read these indexes as enforcing it.
--
-- `path` is the materialised ancestry (`hardware.computer.server`), derived by
-- the generator from `parent`, never stored in the YAML. The btree carries
-- text_pattern_ops so a prefix facet (`path LIKE 'hardware.%'`) is an index
-- scan under any collation; DATA_MODEL floated pg_trgm as an alternative, and
-- text_pattern_ops is preferred because it needs no extension and prefix is the
-- only pattern the facets use.
CREATE TABLE IF NOT EXISTS public.asset_classes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    key text NOT NULL,
    parent_key text,
    path text NOT NULL,
    label text NOT NULL,
    description text,
    icon text,
    attribute_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    identifier_precedence text[] DEFAULT ARRAY[]::text[] NOT NULL,
    cmdb_ci_type text,
    cyclonedx_type text NOT NULL,
    is_fixed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT asset_classes_pkey PRIMARY KEY (id)
);

-- The arbiter scripts/database/seed-asset-classes.sql's upsert infers.
CREATE UNIQUE INDEX IF NOT EXISTS asset_classes_platform_key_uniq
    ON public.asset_classes (key) WHERE tenant_id IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS asset_classes_tenant_key_uniq
    ON public.asset_classes (tenant_id, key) WHERE tenant_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_asset_classes_path
    ON public.asset_classes USING btree (path text_pattern_ops);
CREATE INDEX IF NOT EXISTS idx_asset_classes_parent_key
    ON public.asset_classes USING btree (parent_key) WHERE parent_key IS NOT NULL;



-- ----------------------------------------------------------------------------
-- 2. assets — the unit of inventory (DATA_MODEL §2, ADR-0002 D1)
-- ----------------------------------------------------------------------------
-- THE unit of inventory as of phase 1 (workstream 1.1). Hash-partitioned by
-- tenant_id with the same modulus 8 as crypto_implementations_partitioned and
-- sensor_discoveries_partitioned, so the partition arithmetic across the
-- inventory tables stays uniform.
--
-- PRIMARY KEY is (tenant_id, id), not (id): a unique constraint on a
-- partitioned table must contain the partition key. That is also what makes
-- the child tables' composite FKs possible.
--
-- class_key is an FK BY VALUE to asset_classes.key (ADR-0002 D2, DATA_MODEL
-- §2). It cannot be a real foreign key: `key` is unique only within a scope
-- (two partial unique indexes, above), and a partial index cannot back an FK.
-- class_path is the denormalised ancestry, carried so a prefix facet on the
-- asset list needs no join.
--
-- Deliberately absent, relative to the retired network_assets (DATA_MODEL §2):
-- `port` and the service_* columns (endpoints), `asset_type` (class keys
-- replace the enum, which is dropped), `operating_system` (a class attribute),
-- `mac_addresses` / `serial_number` / `cloud_*` / `fqdns` (identifiers),
-- `last_scanned_at` / `last_scan_status` (endpoint-level).
--
-- risk_score is RECOMPUTED per asset as MAX over active risk-feeding findings
-- (ADR-0005 D4) — not the GREATEST(old, new) write network_assets carried,
-- which could never go down. risk_assessed_by records which producers have
-- evaluated the asset: score 0 with an EMPTY array is *not assessed*, score 0
-- with {crypto,eol,vulnerability} is *assessed clean*. Keeping them distinct is
-- the three-valued rule applied to risk; do not default the array to anything
-- non-empty.
CREATE TABLE IF NOT EXISTS public.assets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    class_key text NOT NULL,
    class_path text NOT NULL,
    class_source_kind text DEFAULT 'measured'::text NOT NULL,
    -- The producer that assigned the class: `classifier:<model>`, `user:<id>`,
    -- `cmdb:<profile>`, `sensor:<id>`, and — when class_source_kind is `rule` —
    -- the classification_rules row id that argued it. Sibling of
    -- class_source_kind: the kind says HOW the class was decided, this says WHO
    -- or WHAT decided it. The query language's `proposed_by` sugar reads it, and
    -- a class proposal that cannot name its producer is not reviewable.
    --
    -- `rule` is the fifth source kind and it is not a synonym for any of the
    -- other four (workstream 2.10b). A class argued from a curated OUI rule is
    -- not `measured` — the MAC was measured, the MAC-to-class mapping was not —
    -- and it is not `inferred`, which ADR-0008 D4.2 defines as "something a
    -- model proposed" and prices accordingly. A deterministic, citable rule row
    -- is neither, and making it claim to be either would put false provenance on
    -- the one field a reviewer uses to audit a class.
    class_source_ref text,
    class_confidence numeric(3,2),
    display_name text,
    hostname text,
    primary_address inet,
    attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    environment public.environment_type,
    business_unit text,
    owner_email text,
    support_group text,
    description text,
    site text,
    region text,
    zone text,
    location_id uuid,
    network_segment_id uuid,
    tags jsonb DEFAULT '{}'::jsonb NOT NULL,
    -- Pipeline state, not class attributes. Two things live here and neither is
    -- an attribute of the thing: the discovery-source attribution the Approvals
    -- filter buttons read (discovery_source / sensor_id / batch_id), and the
    -- DEFERRED FINDINGS holding pen — the raw observations an asset accumulates
    -- while it waits in Approvals, drained into certificates and crypto
    -- configurations the moment it is approved.
    --
    -- Deviation from DATA_MODEL §2, which lists no metadata column: it named
    -- `attributes` for class-specific typed attributes and had no home for
    -- either of these. They cannot go in `attributes`, which is validated
    -- against the class schema and whose names are reserved (ADR-0002 D2
    -- erratum) — a holding pen of raw findings is not a property of a server.
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    asset_status text DEFAULT 'pending_approval'::text NOT NULL,
    asset_ownership text DEFAULT 'unknown'::text NOT NULL,
    stale_status text,
    discovery_method text,
    confidence_score integer,
    first_discovered_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    risk_score integer DEFAULT 0 NOT NULL,
    risk_assessed_by text[] DEFAULT ARRAY[]::text[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT assets_pkey PRIMARY KEY (tenant_id, id),
    CONSTRAINT assets_class_source_kind_check CHECK (class_source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text, 'rule'::text])),
    CONSTRAINT assets_asset_status_check CHECK (asset_status = ANY (ARRAY['pending_approval'::text, 'monitoring'::text, 'denied'::text, 'archived'::text])),
    CONSTRAINT assets_asset_ownership_check CHECK (asset_ownership = ANY (ARRAY['internal'::text, 'third_party'::text, 'unknown'::text])),
    CONSTRAINT assets_stale_status_check CHECK (stale_status IS NULL OR stale_status = ANY (ARRAY['active'::text, 'stale'::text, 'archived'::text])),
    CONSTRAINT assets_risk_score_range_check CHECK (risk_score >= 0 AND risk_score <= 100),
    CONSTRAINT assets_class_confidence_range_check CHECK (class_confidence IS NULL OR (class_confidence >= 0 AND class_confidence <= 1))
)
PARTITION BY HASH (tenant_id);

CREATE TABLE IF NOT EXISTS public.assets_part_0 PARTITION OF public.assets FOR VALUES WITH (modulus 8, remainder 0);
CREATE TABLE IF NOT EXISTS public.assets_part_1 PARTITION OF public.assets FOR VALUES WITH (modulus 8, remainder 1);
CREATE TABLE IF NOT EXISTS public.assets_part_2 PARTITION OF public.assets FOR VALUES WITH (modulus 8, remainder 2);
CREATE TABLE IF NOT EXISTS public.assets_part_3 PARTITION OF public.assets FOR VALUES WITH (modulus 8, remainder 3);
CREATE TABLE IF NOT EXISTS public.assets_part_4 PARTITION OF public.assets FOR VALUES WITH (modulus 8, remainder 4);
CREATE TABLE IF NOT EXISTS public.assets_part_5 PARTITION OF public.assets FOR VALUES WITH (modulus 8, remainder 5);
CREATE TABLE IF NOT EXISTS public.assets_part_6 PARTITION OF public.assets FOR VALUES WITH (modulus 8, remainder 6);
CREATE TABLE IF NOT EXISTS public.assets_part_7 PARTITION OF public.assets FOR VALUES WITH (modulus 8, remainder 7);

-- class_path prefix drives the class facet; the partial index on live rows is
-- what every list query actually scans.
CREATE INDEX IF NOT EXISTS idx_assets_tenant_class_key
    ON public.assets USING btree (tenant_id, class_key) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_assets_tenant_class_path
    ON public.assets USING btree (tenant_id, class_path text_pattern_ops) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_assets_tenant_status
    ON public.assets USING btree (tenant_id, asset_status) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_assets_tenant_last_seen
    ON public.assets USING btree (tenant_id, last_seen_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_assets_tenant_hostname
    ON public.assets USING btree (tenant_id, lower(hostname)) WHERE hostname IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_assets_tenant_risk
    ON public.assets USING btree (tenant_id, risk_score DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_assets_tags
    ON public.assets USING gin (tags);



-- ----------------------------------------------------------------------------
-- asset_endpoints — an asset's reachable (address, port, transport) faces
-- ----------------------------------------------------------------------------
-- DATA_MODEL §2. One row per network face the asset exposes. An asset may have
-- zero (an at-rest bucket, a declared business service) or many; the `AT-REST`
-- port sentinel the old port-as-asset model needed is retired — an at-rest
-- resource simply has no endpoint row at all.
--
-- Hash-partitioned by tenant on the same modulus as assets so the two colocate.
--
-- The uniqueness key differs from DATA_MODEL's literal text, which reads
-- `coalesce(address)`: single-argument coalesce is not valid SQL. The
-- expression below is the intended semantics — NULL and NULL collide, so
-- re-observing the same face updates one row rather than appending. (A plain
-- multi-column unique constraint would NOT do this: in SQL two NULLs are
-- distinct, so every re-observation of an endpoint with no FQDN would insert
-- again. That is the same class of bug as the port sentinel.)
CREATE TABLE IF NOT EXISTS public.asset_endpoints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    address inet,
    fqdn text,
    port integer,
    transport text DEFAULT 'tcp'::text NOT NULL,
    protocol public.protocol_type,
    service_name text,
    service_version text,
    -- Normalised, component-wise sort key derived from service_version on
    -- write, NULL when the version does not parse — the same rule as
    -- software_products.version_sort (QUERY_LANGUAGE §5.5). NULL means the
    -- comparison evaluates UNKNOWN; the query language forbids falling back to
    -- a lexical compare, because "1.10" sorts before "1.9" as text and that
    -- silently inverts every version predicate it touches.
    service_version_sort text,
    service_confidence text DEFAULT 'none'::text,
    service_identification_method text,
    sni text[],
    alpn text[],
    -- Whether the socket is bound to a LOOPBACK address and is therefore
    -- reachable only from the host itself.
    --
    -- NULLABLE and three-valued on purpose. NULL means nobody established it —
    -- which is every endpoint a network scan found, because a scan cannot
    -- establish it even in principle: it only ever sees what answers on the
    -- wire. Only a host's own view of its sockets (the agent's host inventory,
    -- workstream 2.11b) can say true or false, and both of those are real
    -- answers: `false` on a measured endpoint is "this service IS exposed to
    -- the network", which is a finding's input, and defaulting it to false
    -- would have every scanned endpoint assert that for free.
    bound_local boolean,
    source_kind text DEFAULT 'measured'::text NOT NULL,
    source_ref text,
    status text DEFAULT 'active'::text NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_scanned_at timestamp with time zone,
    last_scan_status text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT asset_endpoints_pkey PRIMARY KEY (tenant_id, id),
    CONSTRAINT asset_endpoints_transport_check CHECK (transport = ANY (ARRAY['tcp'::text, 'udp'::text, 'none'::text])),
    CONSTRAINT asset_endpoints_source_kind_check CHECK (source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text])),
    CONSTRAINT asset_endpoints_status_check CHECK (status = ANY (ARRAY['active'::text, 'stale'::text, 'closed'::text])),
    CONSTRAINT asset_endpoints_port_range_check CHECK (port IS NULL OR (port >= 0 AND port <= 65535)),
    -- An endpoint must be addressable somehow. DATA_MODEL: "at least one of
    -- address/fqdn".
    CONSTRAINT asset_endpoints_addressable_check CHECK (address IS NOT NULL OR fqdn IS NOT NULL)
)
PARTITION BY HASH (tenant_id);

CREATE TABLE IF NOT EXISTS public.asset_endpoints_part_0 PARTITION OF public.asset_endpoints FOR VALUES WITH (modulus 8, remainder 0);
CREATE TABLE IF NOT EXISTS public.asset_endpoints_part_1 PARTITION OF public.asset_endpoints FOR VALUES WITH (modulus 8, remainder 1);
CREATE TABLE IF NOT EXISTS public.asset_endpoints_part_2 PARTITION OF public.asset_endpoints FOR VALUES WITH (modulus 8, remainder 2);
CREATE TABLE IF NOT EXISTS public.asset_endpoints_part_3 PARTITION OF public.asset_endpoints FOR VALUES WITH (modulus 8, remainder 3);
CREATE TABLE IF NOT EXISTS public.asset_endpoints_part_4 PARTITION OF public.asset_endpoints FOR VALUES WITH (modulus 8, remainder 4);
CREATE TABLE IF NOT EXISTS public.asset_endpoints_part_5 PARTITION OF public.asset_endpoints FOR VALUES WITH (modulus 8, remainder 5);
CREATE TABLE IF NOT EXISTS public.asset_endpoints_part_6 PARTITION OF public.asset_endpoints FOR VALUES WITH (modulus 8, remainder 6);
CREATE TABLE IF NOT EXISTS public.asset_endpoints_part_7 PARTITION OF public.asset_endpoints FOR VALUES WITH (modulus 8, remainder 7);

CREATE UNIQUE INDEX IF NOT EXISTS asset_endpoints_identity_uniq
    ON public.asset_endpoints (
        tenant_id,
        asset_id,
        coalesce(address::text, ''),
        coalesce(fqdn, ''),
        coalesce(port, -1),
        transport
    );
CREATE INDEX IF NOT EXISTS idx_asset_endpoints_tenant_asset
    ON public.asset_endpoints USING btree (tenant_id, asset_id);
CREATE INDEX IF NOT EXISTS idx_asset_endpoints_tenant_address
    ON public.asset_endpoints USING btree (tenant_id, address) WHERE address IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_asset_endpoints_tenant_port
    ON public.asset_endpoints USING btree (tenant_id, port) WHERE port IS NOT NULL;



-- MATERIALIZED VIEW: mv_location_finding_summary
-- B-40: DROP ... CASCADE + CREATE, not CREATE ... IF NOT EXISTS.
-- `CREATE MATERIALIZED VIEW` has no OR REPLACE, and `IF NOT EXISTS` matches by
-- NAME only — so on any database that already has this matview, an edit to the
-- body below is a silent no-op: schema-migration exits 0 while the cluster
-- keeps the stale definition. (A previous POST-MIGRATIONS block carried a
-- drop+recreate for exactly this reason; it was removed in the POST-MIGRATIONS
-- collapse, and the duplication it required is why it rotted. Keeping the
-- drop AT the definition site means there is only ever one copy of the body.)
--
-- The CASCADE also un-wedges upgrades of installs created before the partition
-- conversion, where this matview still joins network_assets_legacy: dropping
-- it here, before POST-MIGRATIONS' `DROP TABLE ... network_assets_legacy
-- CASCADE`, means that drop no longer takes the matview with it and the
-- wrapper-view CREATEs that follow it no longer fail under ON_ERROR_STOP=1.
--
-- Everything the CASCADE removes is recreated later in this same file:
-- idx_mv_location_finding_summary_key (CREATE INDEX IF NOT EXISTS, further
-- down the body) and mv_location_finding_summary_tenant (CREATE OR REPLACE
-- VIEW, in POST-MIGRATIONS). WITH DATA, because an unpopulated matview raises
-- "has not been populated" on every read until the next
-- refresh_operational_views().
DROP MATERIALIZED VIEW IF EXISTS public.mv_location_finding_summary CASCADE;
CREATE MATERIALIZED VIEW public.mv_location_finding_summary AS
 SELECT l.id AS location_id,
    l.tenant_id,
    l.name AS location_name,
    (l.location_type)::text AS location_type,
    l.full_path,
    COALESCE((a.environment)::text, 'unknown'::text) AS environment,
    count(DISTINCT a.id) AS asset_count,
    count(DISTINCT ci.id) AS crypto_config_count,
    count(DISTINCT c.id) AS certificate_count,
    -- B-18: band assets.risk_score, do NOT read a stored
    -- risk_level column. Nothing anywhere writes risk_level — no INSERT,
    -- UPDATE, trigger or seed — so it sits at its DEFAULT 'Informational'
    -- forever and these four counters were structurally always 0, however
    -- Critical the location's assets actually were.
    --
    -- Bands are the canonical ladder from
    -- services/inventory-service/internal/models/risk_bands.go (RiskBandSQL's
    -- half-open intervals: Critical >= 90, High 70–89, Medium 40–69, Low 1–39,
    -- Informational 0). They must stay mutually exclusive, because each asset
    -- previously contributed to exactly one of these counters.
    count(DISTINCT a.id) FILTER (WHERE (COALESCE(a.risk_score, 0) >= 90)) AS critical_findings,
    count(DISTINCT a.id) FILTER (WHERE (COALESCE(a.risk_score, 0) >= 70 AND COALESCE(a.risk_score, 0) < 90)) AS high_findings,
    count(DISTINCT a.id) FILTER (WHERE (COALESCE(a.risk_score, 0) >= 40 AND COALESCE(a.risk_score, 0) < 70)) AS medium_findings,
    count(DISTINCT a.id) FILTER (WHERE (COALESCE(a.risk_score, 0) >= 1 AND COALESCE(a.risk_score, 0) < 40)) AS low_findings,
    count(DISTINCT c.id) FILTER (WHERE ((c.not_after IS NOT NULL) AND (c.not_after > now()) AND (c.not_after <= (now() + '30 days'::interval)))) AS expiring_certs_30d,
    count(DISTINCT c.id) FILTER (WHERE ((c.not_after IS NOT NULL) AND (c.not_after < now()))) AS expired_certs
   FROM (((public.locations l
     LEFT JOIN public.assets a ON (((a.location_id = l.id) AND (a.deleted_at IS NULL))))
     LEFT JOIN public.crypto_implementations_partitioned ci ON (((ci.asset_id = a.id) AND (ci.deleted_at IS NULL))))
     LEFT JOIN public.certificates c ON ((c.id = ci.certificate_id)))
  GROUP BY l.id, l.tenant_id, l.name, l.location_type, l.full_path, a.environment
  WITH DATA;


-- MATERIALIZED VIEW: mv_remediation_queue
-- B-40: DROP ... CASCADE + CREATE — see the note on
-- mv_location_finding_summary above for why `CREATE ... IF NOT EXISTS` cannot
-- carry an edit onto an existing database. Dependents recreated later in this
-- file: idx_mv_remediation_queue_tenant_severity (body) and
-- mv_remediation_queue_tenant (POST-MIGRATIONS).
DROP MATERIALIZED VIEW IF EXISTS public.mv_remediation_queue CASCADE;
CREATE MATERIALIZED VIEW public.mv_remediation_queue AS
 SELECT a.tenant_id,
    'expiring_cert'::character varying(50) AS finding_type,
        CASE
            WHEN (c.not_after <= now()) THEN 'critical'::text
            ELSE 'high'::text
        END AS severity,
    a.id AS asset_id,
    a.hostname AS asset_hostname,
    COALESCE((e.address)::text, (a.primary_address)::text) AS asset_ip,
    e.port AS asset_port,
    l.name AS location_name,
    l.full_path AS location_full_path,
    (a.environment)::text AS environment,
    e.service_name,
    c.id AS certificate_id,
    ci.id AS crypto_implementation_id,
    ((('Certificate '::text || (COALESCE(c.common_name, (c.subject_dn)::character varying))::text) || ' expires '::text) || (c.not_after)::text) AS detail_text,
    ci.created_at
   FROM ((((public.assets a
     JOIN public.crypto_implementations_partitioned ci ON (((ci.asset_id = a.id) AND (ci.deleted_at IS NULL))))
     JOIN public.certificates c ON (((c.id = ci.certificate_id) AND (c.not_after IS NOT NULL) AND ((c.not_after <= now()) OR (c.not_after <= (now() + '30 days'::interval))))))
     LEFT JOIN public.asset_endpoints e ON (((e.tenant_id = ci.tenant_id) AND (e.id = ci.endpoint_id))))
     LEFT JOIN public.locations l ON ((l.id = a.location_id)))
  WHERE (a.deleted_at IS NULL)
UNION ALL
 SELECT a.tenant_id,
    'weak_cipher'::character varying(50) AS finding_type,
        -- Canonical risk bands (services/inventory-service/internal/models/risk_bands.go):
        -- Critical >= 90, High >= 70, Medium >= 40, Low >= 1, Informational 0.
        -- CVSS v3.1/v4.0 qualitative ratings x10. This ladder previously ran
        -- >= 80 high / >= 60 medium, so an implementation scoring 60-69 was
        -- surfaced here as "medium" while every other surface called it Medium
        -- at >= 40 and High at >= 70 — the same drift risk_bands.go exists to
        -- prevent. Labels are lowercase because the consumer
        -- (OperationalService.GetRemediationQueue) filters and orders on them.
        CASE
            WHEN (ci.risk_score >= 90) THEN 'critical'::text
            WHEN (ci.risk_score >= 70) THEN 'high'::text
            WHEN (ci.risk_score >= 40) THEN 'medium'::text
            WHEN (ci.risk_score >= 1) THEN 'low'::text
            ELSE 'informational'::text
        END AS severity,
    a.id AS asset_id,
    a.hostname AS asset_hostname,
    COALESCE((e.address)::text, (a.primary_address)::text) AS asset_ip,
    e.port AS asset_port,
    l.name AS location_name,
    l.full_path AS location_full_path,
    (a.environment)::text AS environment,
    e.service_name,
    NULL::uuid AS certificate_id,
    ci.id AS crypto_implementation_id,
    ((('Risk score '::text || (ci.risk_score)::text) || ': '::text) || (COALESCE(ci.cipher_suite, ((ci.protocol)::text)::character varying))::text) AS detail_text,
    ci.created_at
   FROM (((public.assets a
     -- >= 40 is the canonical Medium floor (risk_bands.go). It was >= 60, which
     -- silently hid the bottom half of the Medium band from the queue.
     JOIN public.crypto_implementations_partitioned ci ON (((ci.asset_id = a.id) AND (ci.deleted_at IS NULL) AND (ci.risk_score >= 40))))
     LEFT JOIN public.asset_endpoints e ON (((e.tenant_id = ci.tenant_id) AND (e.id = ci.endpoint_id))))
     LEFT JOIN public.locations l ON ((l.id = a.location_id)))
  WHERE (a.deleted_at IS NULL)
UNION ALL
 SELECT a.tenant_id,
    'deprecated_protocol'::character varying(50) AS finding_type,
    'medium'::text AS severity,
    a.id AS asset_id,
    a.hostname AS asset_hostname,
    COALESCE((e.address)::text, (a.primary_address)::text) AS asset_ip,
    e.port AS asset_port,
    l.name AS location_name,
    l.full_path AS location_full_path,
    (a.environment)::text AS environment,
    e.service_name,
    NULL::uuid AS certificate_id,
    ci.id AS crypto_implementation_id,
    ('Protocol '::text || (COALESCE(ci.protocol_version, ((ci.protocol)::text)::character varying))::text) AS detail_text,
    ci.created_at
   FROM (((public.assets a
     JOIN public.crypto_implementations_partitioned ci ON (((ci.asset_id = a.id) AND (ci.deleted_at IS NULL))))
     LEFT JOIN public.asset_endpoints e ON (((e.tenant_id = ci.tenant_id) AND (e.id = ci.endpoint_id))))
     LEFT JOIN public.locations l ON ((l.id = a.location_id)))
  WHERE ((a.deleted_at IS NULL) AND (((ci.protocol_version)::text = ANY ((ARRAY['TLS 1.0'::character varying, 'TLS 1.1'::character varying, 'SSL 3.0'::character varying])::text[])) OR ((ci.protocol_version)::text ~~ '1.0'::text) OR ((ci.protocol_version)::text ~~ '1.1'::text)))
  WITH DATA;


-- TABLE: network_segments
CREATE TABLE IF NOT EXISTS public.network_segments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    segment_type character varying(20) NOT NULL,
    value character varying(512) NOT NULL,
    network_type character varying(20) DEFAULT 'private'::character varying NOT NULL,
    environment public.environment_type NOT NULL,
    location_id uuid,
    business_unit character varying(100),
    owner_email character varying(255),
    description text,
    is_active boolean DEFAULT true,
    auto_approve_discoveries boolean DEFAULT false,
    tags jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    -- The cloud network (VPC / VNet / GCP network) this segment belongs to, as
    -- the provider's own resource id. NULL for every operator-drawn LAN
    -- segment, which is the overwhelming majority.
    --
    -- It is part of the segment's IDENTITY, not a decoration: uniqueness is
    -- (tenant_id, value, coalesce(cloud_network_ref, '')) rather than
    -- (tenant_id, value). Two VPCs using the same CIDR — two Terraform-default
    -- 10.0.0.0/16s in one account is the common shape — are two different
    -- address spaces, and collapsing them into one segment made two instances
    -- with the same private address resolve to one scope and therefore to one
    -- ASSET. See the unique index in POST-MIGRATIONS.
    cloud_network_ref text,
    -- Provenance (ADR-0005 source_kind vocabulary). NULL means "created before
    -- this column existed", deliberately distinct from 'declared': a row that
    -- predates provenance has none, and calling it declared would invent a
    -- fact about who drew this segment. 'imported' is a segment pulled from a
    -- network source of truth (NetBox), with source_ref naming the connection
    -- and the remote id: `netbox:<connection-id>:prefix:<netbox-id>`.
    --
    -- Appended AFTER the timestamps on purpose: ADD COLUMN appends, so a fresh
    -- install and an upgraded one end up with the same column order.
    source_kind character varying(20),
    source_ref character varying(200),
    CONSTRAINT network_segments_source_kind_check CHECK ((source_kind IS NULL OR (source_kind)::text = ANY ((ARRAY['measured'::character varying, 'imported'::character varying, 'declared'::character varying, 'inferred'::character varying])::text[]))),
    CONSTRAINT network_segments_network_type_check CHECK (((network_type)::text = ANY ((ARRAY['private'::character varying, 'public'::character varying, 'vpn'::character varying, 'cloud'::character varying])::text[]))),
    CONSTRAINT network_segments_segment_type_check CHECK (((segment_type)::text = ANY ((ARRAY['cidr'::character varying, 'ip_range'::character varying, 'domain'::character varying, 'cloud_vpc'::character varying])::text[])))
);


-- TABLE: notification_delivery_queue
CREATE TABLE IF NOT EXISTS public.notification_delivery_queue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    notification_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    channel_type character varying(50) NOT NULL,
    payload jsonb NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    retry_count integer DEFAULT 0,
    next_retry_at timestamp with time zone,
    delivered_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_delivery_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'sent'::character varying, 'failed'::character varying, 'retrying'::character varying])::text[])))
);


-- TABLE: notification_history
CREATE TABLE IF NOT EXISTS public.notification_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    notification_type character varying(50) NOT NULL,
    alert_source character varying(50) NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    message text NOT NULL,
    channels_used text[] NOT NULL,
    status character varying(20) DEFAULT 'sent'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_notification_severity CHECK (((severity)::text = ANY ((ARRAY['critical'::character varying, 'high'::character varying, 'medium'::character varying, 'low'::character varying, 'info'::character varying])::text[]))),
    CONSTRAINT valid_notification_status CHECK (((status)::text = ANY ((ARRAY['sent'::character varying, 'failed'::character varying, 'pending'::character varying, 'partial'::character varying])::text[])))
);


-- TABLE: pcap_upload_jobs
CREATE TABLE IF NOT EXISTS public.pcap_upload_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    uploaded_by uuid NOT NULL,
    original_filename text NOT NULL,
    file_size_bytes bigint NOT NULL,
    file_path text,
    status text DEFAULT 'pending'::text NOT NULL,
    discovery_count integer DEFAULT 0,
    packet_count bigint DEFAULT 0,
    protocols_found jsonb DEFAULT '{}'::jsonb,
    capture_time_range jsonb DEFAULT '{}'::jsonb,
    error_message text,
    processing_started_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT pcap_upload_jobs_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'uploading'::text, 'processing'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
);


-- TABLE: pending_sensor_registrations
CREATE TABLE IF NOT EXISTS public.pending_sensor_registrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    registration_key character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    ip_address inet NOT NULL,
    profile character varying(50) DEFAULT 'datacenter_host'::character varying NOT NULL,
    network_interfaces text[] DEFAULT ARRAY[]::text[],
    tags text[] DEFAULT ARRAY[]::text[],
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    CONSTRAINT key_expires_after_creation CHECK ((expires_at > created_at)),
    CONSTRAINT valid_profile CHECK (((profile)::text = ANY ((ARRAY['datacenter_host'::character varying, 'cloud_instance'::character varying, 'end_user_machine'::character varying, 'air_gapped'::character varying, 'device_interrogation'::character varying])::text[]))),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'used'::character varying, 'expired'::character varying, 'cancelled'::character varying])::text[])))
);


-- TABLE: permission_audit_logs
CREATE TABLE IF NOT EXISTS public.permission_audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    tenant_id uuid,
    action character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id uuid,
    permission_required character varying(100),
    permission_granted boolean,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: platform_roles
CREATE TABLE IF NOT EXISTS public.platform_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    description text,
    is_system_role boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: platform_users
CREATE TABLE IF NOT EXISTS public.platform_users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    role_id uuid NOT NULL,
    is_active boolean DEFAULT true,
    email_verified boolean DEFAULT false,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    force_password_change boolean DEFAULT false NOT NULL,
    password_changed_at timestamp with time zone,
    password_reset_token character varying(255),
    password_reset_expires timestamp with time zone,
    invited_by uuid,
    invitation_accepted_at timestamp with time zone,
    -- Account lockout (#594), mirroring the tenant `users` table.
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone
);


-- VIEW: platform_administrators
CREATE OR REPLACE VIEW public.platform_administrators AS
 SELECT pu.id,
    pu.email,
    pu.first_name,
    pu.last_name,
    pr.name AS role_name,
    pr.display_name AS role_display_name,
    pu.is_active,
    pu.last_login_at,
    pu.created_at
   FROM (public.platform_users pu
     JOIN public.platform_roles pr ON ((pu.role_id = pr.id)))
  WHERE (pu.deleted_at IS NULL);


-- TABLE: platform_announcements
CREATE TABLE IF NOT EXISTS public.platform_announcements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    type character varying(50) DEFAULT 'info'::character varying NOT NULL,
    target character varying(50) DEFAULT 'all'::character varying NOT NULL,
    target_ids uuid[] DEFAULT '{}'::uuid[],
    is_active boolean DEFAULT true NOT NULL,
    starts_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: platform_bootstrap_ca
CREATE TABLE IF NOT EXISTS public.platform_bootstrap_ca (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ca_cert_pem text NOT NULL,
    ca_key_pem_encrypted text NOT NULL,
    serial_number bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    is_active boolean DEFAULT true
);


-- TABLE: platform_bootstrap_certificates
CREATE TABLE IF NOT EXISTS public.platform_bootstrap_certificates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(100) NOT NULL,
    certificate_pem text NOT NULL,
    serial_number character varying(255) NOT NULL,
    issued_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revocation_reason character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: platform_framework_controls
CREATE TABLE IF NOT EXISTS public.platform_framework_controls (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    framework_id uuid NOT NULL,
    family_id uuid,
    control_id character varying(100) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    baseline_severity character varying(20) NOT NULL,
    crypto_relevant boolean DEFAULT false NOT NULL,
    -- Provenance (ADR-0005 source_kind vocabulary, ADR-0008 D4.1). NULL means
    -- "created before this column existed" and is deliberately distinct from
    -- 'declared': a row that predates provenance has none, and guessing one for
    -- it would invent a fact about who wrote it.
    source_kind character varying(20),
    source_ref character varying(200),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT platform_framework_controls_source_kind_check CHECK ((source_kind IS NULL OR (source_kind)::text = ANY ((ARRAY['measured'::character varying, 'imported'::character varying, 'declared'::character varying, 'inferred'::character varying])::text[]))),
    CONSTRAINT platform_framework_controls_baseline_severity_check CHECK (((baseline_severity)::text = ANY ((ARRAY['Low'::character varying, 'Med'::character varying, 'High'::character varying, 'Critical'::character varying])::text[])))
);


-- TABLE: platform_framework_versions
CREATE TABLE IF NOT EXISTS public.platform_framework_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    framework_id uuid NOT NULL,
    version character varying(20) NOT NULL,
    snapshot jsonb NOT NULL,
    change_summary text,
    changed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: platform_frameworks
CREATE TABLE IF NOT EXISTS public.platform_frameworks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(20) NOT NULL,
    description text,
    organization character varying(255),
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp with time zone,
    published_by uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_platform_default boolean DEFAULT false NOT NULL,
    CONSTRAINT platform_frameworks_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


-- TABLE: platform_integration_audit_log
CREATE TABLE IF NOT EXISTS public.platform_integration_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    integration_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    performed_by uuid NOT NULL,
    performed_by_email character varying(255) NOT NULL,
    old_config_hash character varying(64),
    new_config_hash character varying(64),
    changed_fields jsonb DEFAULT '{}'::jsonb,
    success boolean DEFAULT true,
    error_message text,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_action CHECK (((action)::text = ANY ((ARRAY['created'::character varying, 'updated'::character varying, 'deleted'::character varying, 'enabled'::character varying, 'disabled'::character varying, 'tested'::character varying, 'credential_rotated'::character varying, 'status_changed'::character varying])::text[])))
);


-- TABLE: platform_integrations
CREATE TABLE IF NOT EXISTS public.platform_integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    integration_type character varying(50) NOT NULL,
    integration_name character varying(100) NOT NULL,
    provider character varying(50) NOT NULL,
    tenant_id uuid,
    is_shared boolean DEFAULT false,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    config_version integer DEFAULT 1,
    is_enabled boolean DEFAULT true,
    is_active boolean DEFAULT true,
    status character varying(20) DEFAULT 'pending'::character varying,
    status_message text,
    last_tested_at timestamp with time zone,
    last_successful_connection_at timestamp with time zone,
    account_id character varying(100),
    region character varying(50),
    environment character varying(50),
    description text,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT valid_integration_type CHECK (((integration_type)::text = ANY ((ARRAY['aws'::character varying, 'azure'::character varying, 'gcp'::character varying, 'slack'::character varying, 'pagerduty'::character varying, 'datadog'::character varying, 'splunk'::character varying, 'custom'::character varying, 'github'::character varying, 'gitlab'::character varying, 'bitbucket'::character varying, 'hashicorp_vault'::character varying])::text[]))),
    CONSTRAINT valid_provider CHECK (((provider)::text = ANY ((ARRAY['cloud'::character varying, 'saas'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'configured'::character varying, 'connected'::character varying, 'error'::character varying, 'disconnected'::character varying])::text[])))
);


-- VIEW: platform_integrations_summary
CREATE OR REPLACE VIEW public.platform_integrations_summary AS
 SELECT platform_integrations.id,
    platform_integrations.integration_type,
    platform_integrations.integration_name,
    platform_integrations.provider,
    platform_integrations.account_id,
    platform_integrations.region,
    platform_integrations.environment,
    platform_integrations.is_enabled,
    platform_integrations.is_active,
    platform_integrations.status,
    platform_integrations.status_message,
    platform_integrations.last_tested_at,
    platform_integrations.last_successful_connection_at,
    platform_integrations.description,
    platform_integrations.tags,
    platform_integrations.metadata,
    platform_integrations.created_at,
    platform_integrations.updated_at,
    (platform_integrations.config ->> 'config_version'::text) AS config_version,
    jsonb_object_keys(platform_integrations.config) AS config_keys
   FROM public.platform_integrations
  WHERE (platform_integrations.deleted_at IS NULL);


-- TABLE: platform_log_access_audit
CREATE TABLE IF NOT EXISTS public.platform_log_access_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    accessed_by_user_id uuid NOT NULL,
    accessed_by_email character varying(255),
    access_type character varying(50) NOT NULL,
    log_id uuid,
    filter_criteria jsonb,
    result_count integer,
    api_endpoint character varying(255),
    request_method character varying(10),
    signed_url_generated boolean DEFAULT false,
    s3_signed_url character varying(2048),
    s3_access_ip inet,
    s3_access_timestamp timestamp with time zone,
    accessed_at timestamp with time zone DEFAULT now(),
    access_duration_ms integer,
    access_result character varying(20) NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_access_result CHECK (((access_result)::text = ANY ((ARRAY['success'::character varying, 'denied'::character varying, 'error'::character varying])::text[]))),
    CONSTRAINT valid_access_type CHECK (((access_type)::text = ANY ((ARRAY['metadata'::character varying, 'download'::character varying, 'export'::character varying, 'delete'::character varying, 'search'::character varying])::text[])))
);


-- TABLE: platform_log_metadata
CREATE TABLE IF NOT EXISTS public.platform_log_metadata (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    log_id character varying(255) NOT NULL,
    correlation_id character varying(255),
    trace_id character varying(255),
    service_name character varying(100) NOT NULL,
    service_version character varying(50),
    environment character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    event_type character varying(100) NOT NULL,
    category character varying(50),
    message_digest character varying(64) NOT NULL,
    message_preview text,
    redaction_mask text,
    tenant_id uuid,
    user_id uuid,
    user_type character varying(20),
    request_id character varying(255),
    source_ip inet,
    user_agent text,
    request_method character varying(10),
    request_path text,
    response_status integer,
    "timestamp" timestamp with time zone NOT NULL,
    duration_ms integer,
    s3_bucket character varying(255) NOT NULL,
    s3_key character varying(512) NOT NULL,
    s3_region character varying(50) NOT NULL,
    s3_etag character varying(64),
    status character varying(20) DEFAULT 'active'::character varying,
    retention_policy character varying(50) DEFAULT '90-days-hot'::character varying,
    archived_at timestamp with time zone,
    deleted_at timestamp with time zone,
    pii_detected boolean DEFAULT false,
    pii_types text[],
    scrubbed_at timestamp with time zone,
    compliance_tags text[],
    encryption_status character varying(20) DEFAULT 'encrypted'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    tags jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_retention_policy CHECK (((retention_policy)::text = ANY ((ARRAY['90-days-hot'::character varying, '365-days-archive'::character varying])::text[]))),
    CONSTRAINT valid_severity CHECK (((severity)::text = ANY ((ARRAY['debug'::character varying, 'info'::character varying, 'warn'::character varying, 'error'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'archived'::character varying, 'deleted'::character varying])::text[]))),
    CONSTRAINT valid_user_type CHECK ((((user_type)::text = ANY ((ARRAY['tenant'::character varying, 'platform'::character varying])::text[])) OR (user_type IS NULL)))
);


-- TABLE: platform_log_pii_rules
CREATE TABLE IF NOT EXISTS public.platform_log_pii_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rule_name character varying(100) NOT NULL,
    pii_type character varying(50) NOT NULL,
    pattern_type character varying(20) NOT NULL,
    pattern character varying(500) NOT NULL,
    redaction_method character varying(20) DEFAULT 'hash'::character varying,
    replacement_value character varying(100),
    priority integer DEFAULT 0,
    is_active boolean DEFAULT true,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_pattern_type CHECK (((pattern_type)::text = ANY ((ARRAY['regex'::character varying, 'keyword'::character varying, 'format'::character varying])::text[]))),
    CONSTRAINT valid_pii_type CHECK (((pii_type)::text = ANY ((ARRAY['email'::character varying, 'ssn'::character varying, 'phone'::character varying, 'credit_card'::character varying, 'ip_address'::character varying, 'name'::character varying, 'address'::character varying, 'date_of_birth'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT valid_redaction_method CHECK (((redaction_method)::text = ANY ((ARRAY['hash'::character varying, 'mask'::character varying, 'remove'::character varying, 'replace'::character varying])::text[])))
);


-- TABLE: platform_log_retention_jobs
CREATE TABLE IF NOT EXISTS public.platform_log_retention_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_type character varying(50) NOT NULL,
    execution_status character varying(20) NOT NULL,
    logs_processed integer DEFAULT 0,
    logs_archived integer DEFAULT 0,
    logs_deleted integer DEFAULT 0,
    logs_scrubbed integer DEFAULT 0,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    duration_ms integer,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_execution_status CHECK (((execution_status)::text = ANY ((ARRAY['running'::character varying, 'completed'::character varying, 'failed'::character varying])::text[]))),
    CONSTRAINT valid_job_type CHECK (((job_type)::text = ANY ((ARRAY['archive'::character varying, 'delete'::character varying, 'scrub_pii'::character varying, 'full_retention'::character varying])::text[])))
);


-- TABLE: platform_metrics_snapshots
CREATE TABLE IF NOT EXISTS public.platform_metrics_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(100) NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_duration integer NOT NULL,
    latency_p50 numeric(10,3),
    latency_p95 numeric(10,3),
    latency_p99 numeric(10,3),
    error_rate numeric(5,4),
    throughput numeric(15,2),
    status character varying(20) DEFAULT 'healthy'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT valid_error_rate CHECK (((error_rate IS NULL) OR ((error_rate >= (0)::numeric) AND (error_rate <= (1)::numeric)))),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['healthy'::character varying, 'degraded'::character varying, 'down'::character varying])::text[]))),
    CONSTRAINT valid_window_duration CHECK ((window_duration = ANY (ARRAY[60, 3600, 86400])))
);


-- VIEW: platform_metrics_aggregations
CREATE OR REPLACE VIEW public.platform_metrics_aggregations AS
 SELECT platform_metrics_snapshots.service_name,
    platform_metrics_snapshots.window_start,
    platform_metrics_snapshots.window_duration,
    count(*) AS sample_count,
    avg(platform_metrics_snapshots.latency_p50) AS avg_latency_p50,
    avg(platform_metrics_snapshots.latency_p95) AS avg_latency_p95,
    avg(platform_metrics_snapshots.latency_p99) AS avg_latency_p99,
    avg(platform_metrics_snapshots.error_rate) AS avg_error_rate,
    sum(platform_metrics_snapshots.throughput) AS total_throughput,
    count(*) FILTER (WHERE ((platform_metrics_snapshots.status)::text = 'healthy'::text)) AS healthy_count,
    count(*) FILTER (WHERE ((platform_metrics_snapshots.status)::text = 'degraded'::text)) AS degraded_count,
    count(*) FILTER (WHERE ((platform_metrics_snapshots.status)::text = 'down'::text)) AS down_count
   FROM public.platform_metrics_snapshots
  GROUP BY platform_metrics_snapshots.service_name, platform_metrics_snapshots.window_start, platform_metrics_snapshots.window_duration;


-- TABLE: platform_notification_channels
CREATE TABLE IF NOT EXISTS public.platform_notification_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_name character varying(100) NOT NULL,
    channel_type character varying(50) NOT NULL,
    config jsonb NOT NULL,
    enabled boolean DEFAULT true,
    test_status character varying(20),
    last_test_at timestamp with time zone,
    last_used_at timestamp with time zone,
    description text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by uuid,
    CONSTRAINT valid_platform_channel_type CHECK (((channel_type)::text = ANY ((ARRAY['email'::character varying, 'slack'::character varying, 'webhook'::character varying, 'pagerduty'::character varying, 'sms'::character varying, 'in_app'::character varying])::text[])))
);


-- TABLE: platform_notification_rules
CREATE TABLE IF NOT EXISTS public.platform_notification_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rule_name character varying(100) NOT NULL,
    alert_source character varying(50) NOT NULL,
    alert_type character varying(100),
    channel_ids uuid[] NOT NULL,
    severity_filter character varying(20)[],
    category_filter character varying(50)[],
    frequency character varying(20) DEFAULT 'immediate'::character varying,
    digest_window integer,
    enabled boolean DEFAULT true,
    priority integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_platform_frequency CHECK (((frequency)::text = ANY ((ARRAY['immediate'::character varying, 'digest_hourly'::character varying, 'digest_daily'::character varying, 'digest_weekly'::character varying])::text[])))
);


-- TABLE: platform_permissions
CREATE TABLE IF NOT EXISTS public.platform_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: platform_refresh_tokens
CREATE TABLE IF NOT EXISTS public.platform_refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    family_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    last_used_at timestamp with time zone DEFAULT now(),
    is_revoked boolean DEFAULT false,
    created_from_ip inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone
);


-- TABLE: platform_role_permissions
CREATE TABLE IF NOT EXISTS public.platform_role_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: platform_service_ca
CREATE TABLE IF NOT EXISTS public.platform_service_ca (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ca_cert_pem text NOT NULL,
    ca_key_pem_encrypted text NOT NULL,
    serial_number bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    is_active boolean DEFAULT true
);


-- TABLE: platform_service_certificates
CREATE TABLE IF NOT EXISTS public.platform_service_certificates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(100) NOT NULL,
    server_cert_pem text NOT NULL,
    server_key_pem_encrypted text NOT NULL,
    client_cert_pem text NOT NULL,
    client_key_pem_encrypted text NOT NULL,
    serial_number character varying(255) NOT NULL,
    issued_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revocation_reason character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: platform_settings
CREATE TABLE IF NOT EXISTS public.platform_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value jsonb NOT NULL,
    description text,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: platform_sso_providers
CREATE TABLE IF NOT EXISTS public.platform_sso_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type character varying(50) NOT NULL,
    provider_name character varying(100) NOT NULL,
    client_id character varying(255) NOT NULL,
    client_secret_encrypted text NOT NULL,
    auth_url character varying(500) NOT NULL,
    token_url character varying(500) NOT NULL,
    userinfo_url character varying(500) NOT NULL,
    scopes character varying(500) DEFAULT 'openid email profile'::character varying NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    -- #899: a platform SSO provider serves one of two purposes — 'signup'
    -- (Vista's own app for tenant founders) and 'admin_login' (staff sign-in to
    -- admin-ui) — so uniqueness is (provider_type, purpose), NOT provider_type
    -- alone. See uq_platform_sso_provider_type_purpose in the index section.
    purpose character varying(20) DEFAULT 'signup' NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_platform_provider_type CHECK (((provider_type)::text = ANY ((ARRAY['google'::character varying, 'microsoft'::character varying])::text[]))),
    CONSTRAINT valid_platform_provider_purpose CHECK (((purpose)::text = ANY ((ARRAY['signup'::character varying, 'admin_login'::character varying])::text[])))
);
-- TABLE: refresh_tokens
CREATE TABLE IF NOT EXISTS public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    family_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    last_used_at timestamp with time zone DEFAULT now(),
    is_revoked boolean DEFAULT false,
    created_from_ip inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone
);


-- TABLE: remediation_plan_items
CREATE TABLE IF NOT EXISTS public.remediation_plan_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    finding_id uuid NOT NULL,
    ticket_id uuid,
    notes text,
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    added_by uuid NOT NULL,
    -- Where this item's notes came from (ADR-0008 D4.1). 'inferred' with a
    -- source_ref of `remediator:<model id>` means a person accepted a drafted
    -- plan; NULL means the item was added the ordinary way, before or after
    -- this column existed. See the ALTER further down for why NULL is not
    -- backfilled.
    source_kind character varying(20),
    source_ref character varying(200),
    CONSTRAINT remediation_plan_items_source_kind_check CHECK ((source_kind IS NULL OR (source_kind)::text = ANY ((ARRAY['measured'::character varying, 'imported'::character varying, 'declared'::character varying, 'inferred'::character varying])::text[])))
);


-- TABLE: remediation_plans
CREATE TABLE IF NOT EXISTS public.remediation_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    plan_type character varying(30) DEFAULT 'remediation'::character varying NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    owner_id uuid,
    target_date timestamp with time zone,
    framework_id uuid,
    completed_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT remediation_plans_plan_type_check CHECK (((plan_type)::text = ANY ((ARRAY['remediation'::character varying, 'framework'::character varying, 'pqc_migration'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT remediation_plans_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT remediation_plans_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'active'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


-- TABLE: rule_vulnerability_mappings
CREATE TABLE IF NOT EXISTS public.rule_vulnerability_mappings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    rule_id uuid NOT NULL,
    finding_type character varying(100) NOT NULL,
    predicate jsonb DEFAULT '{}'::jsonb NOT NULL,
    weight integer DEFAULT 1 NOT NULL,
    framework_id character varying(100),
    framework_version character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT rule_vulnerability_mappings_weight_check CHECK ((weight > 0))
);


-- TABLE: schedule_history
CREATE TABLE IF NOT EXISTS public.schedule_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schedule_id uuid NOT NULL,
    job_id uuid NOT NULL,
    status character varying(50) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    error_message text,
    assets_found integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: security_incident_webhook_deliveries
CREATE TABLE IF NOT EXISTS public.security_incident_webhook_deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    webhook_id uuid NOT NULL,
    incident_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    status_code integer,
    response_body text,
    error_message text,
    attempts integer DEFAULT 1,
    delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'success'::character varying, 'failed'::character varying])::text[]))),
    CONSTRAINT valid_status_code CHECK (((status_code IS NULL) OR ((status_code >= 100) AND (status_code < 600))))
);


-- TABLE: security_incident_webhooks
CREATE TABLE IF NOT EXISTS public.security_incident_webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    url text NOT NULL,
    secret text,
    events jsonb DEFAULT '[]'::jsonb NOT NULL,
    enabled boolean DEFAULT true,
    headers jsonb DEFAULT '{}'::jsonb,
    timeout_seconds integer DEFAULT 30,
    retry_attempts integer DEFAULT 3,
    retry_backoff_ms integer DEFAULT 1000,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_retry_attempts CHECK (((retry_attempts >= 0) AND (retry_attempts <= 10))),
    CONSTRAINT valid_retry_backoff CHECK (((retry_backoff_ms > 0) AND (retry_backoff_ms <= 60000))),
    CONSTRAINT valid_timeout CHECK (((timeout_seconds > 0) AND (timeout_seconds <= 300)))
);


-- TABLE: security_incidents
CREATE TABLE IF NOT EXISTS public.security_incidents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    incident_id character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    severity character varying(20) NOT NULL,
    category character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying,
    priority character varying(20) DEFAULT 'medium'::character varying,
    detected_at timestamp with time zone NOT NULL,
    occurred_at timestamp with time zone,
    contained_at timestamp with time zone,
    resolved_at timestamp with time zone,
    closed_at timestamp with time zone,
    assigned_to uuid,
    reporter_id uuid,
    team character varying(100),
    related_events uuid[],
    related_incidents uuid[],
    affected_tenants uuid[],
    affected_users uuid[],
    impact_description text,
    response_plan text,
    response_actions text[],
    containment_actions text[],
    root_cause text,
    resolution_summary text,
    lessons_learned text,
    requires_notification boolean DEFAULT false,
    notified_authorities text[],
    notification_date timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    tags text[],
    compliance_tags text[],
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by uuid,
    CONSTRAINT valid_category CHECK (((category)::text = ANY ((ARRAY['data_breach'::character varying, 'unauthorized_access'::character varying, 'ddos'::character varying, 'malware'::character varying, 'insider_threat'::character varying, 'phishing'::character varying, 'vulnerability'::character varying, 'compliance_violation'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT valid_priority CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT valid_severity CHECK (((severity)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'investigating'::character varying, 'contained'::character varying, 'resolved'::character varying, 'closed'::character varying, 'archived'::character varying])::text[])))
);


-- TABLE: sensor_ca_certificates
CREATE TABLE IF NOT EXISTS public.sensor_ca_certificates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    ca_cert_pem text NOT NULL,
    ca_key_pem_encrypted text NOT NULL,
    serial_number bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    is_active boolean DEFAULT true
);


-- TABLE: sensor_certificates
CREATE TABLE IF NOT EXISTS public.sensor_certificates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    certificate_pem text NOT NULL,
    serial_number character varying(255) NOT NULL,
    issued_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revocation_reason character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: sensor_commands
CREATE TABLE IF NOT EXISTS public.sensor_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    command_type character varying(50) NOT NULL,
    payload jsonb NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    delivered_at timestamp with time zone,
    acknowledged_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    -- The command round-trip (deliver/acknowledge) writes updated_at and the
    -- sensor's execution result into response_data.
    response_data jsonb,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT sensor_commands_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'delivered'::character varying, 'acknowledged'::character varying, 'completed'::character varying, 'failed'::character varying])::text[])))
);


-- TABLE: sensor_discoveries_partitioned
CREATE TABLE IF NOT EXISTS public.sensor_discoveries_partitioned (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    batch_id character varying(255) NOT NULL,
    protocol character varying(50) NOT NULL,
    dest_ip inet NOT NULL,
    port integer NOT NULL,
    confidence numeric(3,2) DEFAULT 0.0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    auto_approval_rule_id uuid,
    asset_id uuid,
    hostname character varying(255),
    source_ip inet,
    -- Batch claim marker. processNextBatch is triggered from BOTH the NATS
    -- subscription and the poll ticker (and every replica's ticker when scaled
    -- out), and discoveries are only stamped processed at the END of
    -- ProcessBatch — so selecting on `processed_at IS NULL` alone let two
    -- triggers import the same batch twice. NULL means unclaimed; a claim older
    -- than the worker's stale-claim timeout is ignored, so a worker that dies
    -- mid-batch cannot strand a batch.
    claimed_at timestamp with time zone
)
PARTITION BY HASH (tenant_id);


-- Older installs created the partitioned parent before claimed_at existed; the
-- CREATE TABLE IF NOT EXISTS above is a no-op for them, so add the column
-- upgrade-safely before recreating the compatibility view that reads it.
ALTER TABLE IF EXISTS public.sensor_discoveries_partitioned
    ADD COLUMN IF NOT EXISTS claimed_at timestamp with time zone;
DROP VIEW IF EXISTS public.sensor_discoveries;
CREATE OR REPLACE VIEW public.sensor_discoveries AS
 SELECT sensor_discoveries_partitioned.id,
    sensor_discoveries_partitioned.sensor_id,
    sensor_discoveries_partitioned.tenant_id,
    sensor_discoveries_partitioned.batch_id,
    sensor_discoveries_partitioned.protocol,
    sensor_discoveries_partitioned.dest_ip,
    sensor_discoveries_partitioned.port,
    sensor_discoveries_partitioned.confidence,
    sensor_discoveries_partitioned.metadata,
    sensor_discoveries_partitioned."timestamp",
    sensor_discoveries_partitioned.created_at,
    sensor_discoveries_partitioned.processed_at,
    sensor_discoveries_partitioned.approval_status,
    sensor_discoveries_partitioned.auto_approval_rule_id,
    sensor_discoveries_partitioned.asset_id,
    sensor_discoveries_partitioned.hostname,
    sensor_discoveries_partitioned.source_ip,
    sensor_discoveries_partitioned.claimed_at
   FROM public.sensor_discoveries_partitioned;


-- TABLE: sensor_discoveries_part_0
CREATE TABLE IF NOT EXISTS public.sensor_discoveries_part_0 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    batch_id character varying(255) NOT NULL,
    protocol character varying(50) NOT NULL,
    dest_ip inet NOT NULL,
    port integer NOT NULL,
    confidence numeric(3,2) DEFAULT 0.0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    auto_approval_rule_id uuid,
    asset_id uuid,
    hostname character varying(255),
    source_ip inet,
    claimed_at timestamp with time zone
);


-- TABLE: sensor_discoveries_part_1
CREATE TABLE IF NOT EXISTS public.sensor_discoveries_part_1 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    batch_id character varying(255) NOT NULL,
    protocol character varying(50) NOT NULL,
    dest_ip inet NOT NULL,
    port integer NOT NULL,
    confidence numeric(3,2) DEFAULT 0.0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    auto_approval_rule_id uuid,
    asset_id uuid,
    hostname character varying(255),
    source_ip inet,
    claimed_at timestamp with time zone
);


-- TABLE: sensor_discoveries_part_2
CREATE TABLE IF NOT EXISTS public.sensor_discoveries_part_2 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    batch_id character varying(255) NOT NULL,
    protocol character varying(50) NOT NULL,
    dest_ip inet NOT NULL,
    port integer NOT NULL,
    confidence numeric(3,2) DEFAULT 0.0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    auto_approval_rule_id uuid,
    asset_id uuid,
    hostname character varying(255),
    source_ip inet,
    claimed_at timestamp with time zone
);


-- TABLE: sensor_discoveries_part_3
CREATE TABLE IF NOT EXISTS public.sensor_discoveries_part_3 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    batch_id character varying(255) NOT NULL,
    protocol character varying(50) NOT NULL,
    dest_ip inet NOT NULL,
    port integer NOT NULL,
    confidence numeric(3,2) DEFAULT 0.0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    auto_approval_rule_id uuid,
    asset_id uuid,
    hostname character varying(255),
    source_ip inet,
    claimed_at timestamp with time zone
);


-- TABLE: sensor_discoveries_part_4
CREATE TABLE IF NOT EXISTS public.sensor_discoveries_part_4 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    batch_id character varying(255) NOT NULL,
    protocol character varying(50) NOT NULL,
    dest_ip inet NOT NULL,
    port integer NOT NULL,
    confidence numeric(3,2) DEFAULT 0.0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    auto_approval_rule_id uuid,
    asset_id uuid,
    hostname character varying(255),
    source_ip inet,
    claimed_at timestamp with time zone
);


-- TABLE: sensor_discoveries_part_5
CREATE TABLE IF NOT EXISTS public.sensor_discoveries_part_5 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    batch_id character varying(255) NOT NULL,
    protocol character varying(50) NOT NULL,
    dest_ip inet NOT NULL,
    port integer NOT NULL,
    confidence numeric(3,2) DEFAULT 0.0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    auto_approval_rule_id uuid,
    asset_id uuid,
    hostname character varying(255),
    source_ip inet,
    claimed_at timestamp with time zone
);


-- TABLE: sensor_discoveries_part_6
CREATE TABLE IF NOT EXISTS public.sensor_discoveries_part_6 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    batch_id character varying(255) NOT NULL,
    protocol character varying(50) NOT NULL,
    dest_ip inet NOT NULL,
    port integer NOT NULL,
    confidence numeric(3,2) DEFAULT 0.0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    auto_approval_rule_id uuid,
    asset_id uuid,
    hostname character varying(255),
    source_ip inet,
    claimed_at timestamp with time zone
);


-- TABLE: sensor_discoveries_part_7
CREATE TABLE IF NOT EXISTS public.sensor_discoveries_part_7 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    batch_id character varying(255) NOT NULL,
    protocol character varying(50) NOT NULL,
    dest_ip inet NOT NULL,
    port integer NOT NULL,
    confidence numeric(3,2) DEFAULT 0.0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    auto_approval_rule_id uuid,
    asset_id uuid,
    hostname character varying(255),
    source_ip inet,
    claimed_at timestamp with time zone
);


-- TABLE: sensor_health_metrics
CREATE TABLE IF NOT EXISTS public.sensor_health_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sensor_id uuid NOT NULL,
    uptime_seconds bigint NOT NULL,
    memory_usage_bytes bigint NOT NULL,
    cpu_usage_percent numeric(5,2) NOT NULL,
    packets_captured bigint DEFAULT 0 NOT NULL,
    discoveries_made bigint DEFAULT 0 NOT NULL,
    errors_count integer DEFAULT 0 NOT NULL,
    -- Counters the heartbeat carries that have no column of their own.
    --
    -- The sensor reports eight host_observations_* metrics (offered, decoded,
    -- emitted, malformed, queue_dropped, emit_dropped, coalesce_dropped,
    -- pending) and sensor-manager mapped a FIXED column set onto this table, so
    -- all eight were read off the wire and dropped on the floor — the contract
    -- doc had a Metrics table describing numbers no operator could see anywhere.
    --
    -- jsonb rather than eight more columns because the set is a capture
    -- runtime's business and will grow: a decoder added to shared/hostobs brings
    -- its own counters, and an ALTER TABLE per counter is how a diagnostic
    -- stops being worth adding. NULL means the sensor reported none — an older
    -- build, or the feature switched off — which is deliberately distinct from
    -- `{}`, "running and seeing nothing". "Not running" and "running and idle"
    -- must not look the same.
    extra_counters jsonb,
    recorded_at timestamp with time zone DEFAULT now()
);


-- TABLE: sensors
CREATE TABLE IF NOT EXISTS public.sensors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    platform character varying(50) NOT NULL,
    version character varying(50) NOT NULL,
    profile character varying(50) NOT NULL,
    sensor_type public.sensor_type DEFAULT 'network'::public.sensor_type NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    network_interfaces text[],
    -- Full host NIC inventory reported at registration + in heartbeats, so the UI
    -- can offer a real interface picker. Distinct from network_interfaces (the
    -- subset actually being monitored).
    available_interfaces text[] DEFAULT ARRAY[]::text[],
    tags text[],
    ip_address character varying(45),
    -- An air-gapped sensor is not expected to check in, heartbeat, or stream
    -- discoveries; the platform still shows it registered and imports its
    -- findings out-of-band.
    air_gapped boolean DEFAULT false NOT NULL,
    -- The sensor's actual data-send cadence (seconds), reported up at
    -- registration/heartbeat and operator-changeable via an update_config
    -- command. NULL when the sensor does not report one.
    reporting_interval integer,
    last_heartbeat timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT sensors_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'active'::character varying, 'inactive'::character varying, 'error'::character varying, 'offline'::character varying])::text[])))
);


-- TABLE: agent_addresses
-- Every IP an agent (sensor or discovery agent) holds, one row per bound
-- address, refreshed from the agent's own heartbeat.
--
-- A capture host is routinely multi-homed and may observe several segments at
-- once, so a single scalar address cannot describe it. sensors.ip_address /
-- device_agents.ip_address remain the PRIMARY address — the source address the
-- agent's kernel uses to reach the control plane — and this table holds the
-- full set, with the prefix, so "which segments does this fleet actually cover,
-- and what is uncovered?" is an ordinary query rather than an inference from
-- interface names.
--
-- One table serves both runtimes rather than two near-identical ones: the fleet
-- UI already merges them into a single row shape and the offline-alert job
-- already treats them as interchangeable subjects, so forking here is how the
-- two drift apart. The pair of nullable owner columns keeps real foreign keys
-- (a polymorphic owner_type/owner_id pair could not), and the CHECK makes
-- "exactly one owner" a database invariant instead of a convention.
-- The owner foreign keys are added in POST-MIGRATIONS, not inline: this file
-- follows pg_dump layout, so sensors/device_agents do not yet have their primary
-- keys at this point in the script and an inline REFERENCES fails with "no
-- unique constraint matching given keys".
CREATE TABLE IF NOT EXISTS public.agent_addresses (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    sensor_id uuid,
    device_agent_id uuid,
    interface_name character varying(255) NOT NULL,
    address inet NOT NULL,
    -- Prefix length of the address's network (e.g. 24 for 192.0.2.173/24).
    -- NULL when the agent reported a bare address without one.
    prefix_length smallint,
    -- True for the address the agent reaches the control plane from. At most one
    -- per agent, enforced by the partial unique indexes below.
    is_primary boolean DEFAULT false NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_addresses_exactly_one_owner CHECK (
        (sensor_id IS NOT NULL AND device_agent_id IS NULL)
        OR (sensor_id IS NULL AND device_agent_id IS NOT NULL)
    )
);


-- TABLE: agent_config_defaults
-- The tenant-wide desired settings for a runtime — the "fleet defaults" an
-- individual sensor or agent inherits unless it carries its own override.
--
-- One row per (tenant, runtime). The values are a jsonb object keyed by the
-- setting names in shared/agentconfig, NOT a column per setting: the registry
-- there is the source of truth for what is settable, and a column per setting
-- would mean a schema change every time a device gains a knob, with the two
-- definitions free to disagree in between.
CREATE TABLE IF NOT EXISTS public.agent_config_defaults (
    tenant_id uuid NOT NULL,
    -- 'sensor' or 'agent', matching shared/agentconfig.Runtime.
    runtime character varying(16) NOT NULL,
    values jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_config_defaults_pkey PRIMARY KEY (tenant_id, runtime),
    CONSTRAINT agent_config_defaults_runtime_check CHECK (((runtime)::text = ANY ((ARRAY['sensor'::character varying, 'agent'::character varying])::text[])))
);


-- TABLE: agent_config_overrides
-- The per-device desired settings: what an operator has asked THIS sensor or
-- THIS agent to be, over and above the fleet defaults.
--
-- Same two-nullable-owners shape as agent_addresses, and for the same reason
-- given there: one table rather than two near-identical ones, because the two
-- runtimes are halves of one product and forking is how they drift apart. The
-- CHECK makes "exactly one owner" a database invariant.
--
-- A row exists only when there IS an override. Absence means "inherits
-- everything", which is a different statement from a row of nulls — see the
-- three-valued note on Values in shared/agentconfig.
CREATE TABLE IF NOT EXISTS public.agent_config_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    sensor_id uuid,
    device_agent_id uuid,
    values jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_by uuid,
    -- When an operator last asked this device to restart, and who asked.
    --
    -- A timestamp rather than a command queue, and idempotent by construction:
    -- a device that has already restarted has been running for less time than
    -- the request is old, so it does not restart again. Nothing to acknowledge,
    -- nothing to mark delivered, and ten clicks are one restart rather than ten.
    --
    -- The device is sent the request's AGE, never this timestamp, and compares
    -- it with its own uptime. Two DURATIONS, never two clocks: a device whose
    -- clock is behind the platform's would find every request permanently in
    -- its future and restart on every check-in for ever. See
    -- agentconfig.ShouldRestart.
    restart_requested_at timestamp with time zone,
    restart_requested_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_config_overrides_exactly_one_owner CHECK (
        (sensor_id IS NOT NULL AND device_agent_id IS NULL)
        OR (sensor_id IS NULL AND device_agent_id IS NOT NULL)
    )
);


-- TABLE: agent_config_state
-- What a device says it is actually running: the desired revision it has
-- adopted, when it said so, and anything it could not apply.
--
-- Deliberately a DIFFERENT table from agent_config_overrides. Desired state is
-- written by operators and reported state by devices; collapsing them into one
-- row is how a console ends up displaying an intention as though it were a
-- measurement. Everything this product has learned about "reports success while
-- doing nothing" says keep the two apart and compute the difference.
--
-- reported_revision is the content hash from shared/agentconfig.Revision. NULL
-- means the device has never reported one — an older build, or one that has not
-- checked in — and must never be rendered as "up to date".
CREATE TABLE IF NOT EXISTS public.agent_config_state (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    sensor_id uuid,
    device_agent_id uuid,
    reported_revision text,
    reported_at timestamp with time zone,
    -- Per-setting reasons the device gave for not applying something, keyed by
    -- setting name. An empty object means no failures.
    failures jsonb DEFAULT '{}'::jsonb NOT NULL,
    -- Settings the device has accepted but cannot adopt until it restarts.
    pending_restart text[] DEFAULT ARRAY[]::text[] NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_config_state_exactly_one_owner CHECK (
        (sensor_id IS NOT NULL AND device_agent_id IS NULL)
        OR (sensor_id IS NULL AND device_agent_id IS NOT NULL)
    )
);


-- TABLE: agent_config_audit
-- Append-only record of every desired-state change, mirroring scopes_audit.
--
-- Required, not optional: making the sensor's DNS decoder remotely settable was
-- conditioned on the change being confirmed AND audited (feature spec §1a). A
-- setting that turns on a new kind of collection has to leave a trail naming
-- who turned it on.
CREATE TABLE IF NOT EXISTS public.agent_config_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    tenant_id uuid NOT NULL,
    -- The subject: a device, or the tenant's fleet defaults (both owner columns
    -- NULL, scope = 'fleet').
    sensor_id uuid,
    device_agent_id uuid,
    scope character varying(16) NOT NULL,
    runtime character varying(16) NOT NULL,
    -- The values before and after, so a change is reconstructable without
    -- replaying every row.
    values_before jsonb DEFAULT '{}'::jsonb NOT NULL,
    values_after jsonb DEFAULT '{}'::jsonb NOT NULL,
    -- NULL for a change nobody made: 'bootstrap' rows record the position a
    -- device was ALREADY in when it first reported, adopted so that desired
    -- state does not overwrite a file configuration with defaults nobody chose.
    -- Attributing that to a person would make the trail lie.
    changed_by uuid,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_config_audit_scope_check CHECK (((scope)::text = ANY ((ARRAY['device'::character varying, 'fleet'::character varying, 'bootstrap'::character varying])::text[]))),
    CONSTRAINT agent_config_audit_runtime_check CHECK (((runtime)::text = ANY ((ARRAY['sensor'::character varying, 'agent'::character varying])::text[])))
);


-- TABLE: service_accounts
CREATE TABLE IF NOT EXISTS public.service_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(100) NOT NULL,
    token_hash text NOT NULL,
    -- Indexed hex-SHA-256 lookup value that narrows ValidateToken to a single
    -- candidate row in O(1) before bcrypt confirms it (SEC-3). bcrypt is one-way,
    -- so tokens issued before this column existed carry NULL and fall back to the
    -- legacy full scan restricted to `WHERE token_lookup IS NULL`.
    token_lookup text,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_used_at timestamp with time zone
);


-- TABLE: service_health_events
CREATE TABLE IF NOT EXISTS public.service_health_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(100) NOT NULL,
    event_type character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT valid_event_type CHECK (((event_type)::text = ANY ((ARRAY['heartbeat'::character varying, 'dependency_check'::character varying, 'incident'::character varying])::text[]))),
    CONSTRAINT valid_health_status CHECK (((status)::text = ANY ((ARRAY['healthy'::character varying, 'degraded'::character varying, 'down'::character varying, 'warning'::character varying])::text[])))
);


-- TABLE: service_identification_rules
CREATE TABLE IF NOT EXISTS public.service_identification_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    port integer NOT NULL,
    protocol character varying(20) NOT NULL,
    service_name character varying(100) NOT NULL,
    service_category character varying(50),
    is_builtin boolean DEFAULT true,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT service_identification_rules_port_check CHECK (((port >= 1) AND (port <= 65535)))
);


-- TABLE: ssh_keys
CREATE TABLE IF NOT EXISTS public.ssh_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid,
    -- Set for a key observed on one endpoint; NULL for a HOST key, which
    -- belongs to the asset and not to any single socket (ADR-0002 D6).
    endpoint_id uuid,
    key_type character varying(50) NOT NULL,
    key_size integer,
    fingerprint_sha256 character varying(100) NOT NULL,
    public_key text,
    algorithm_id uuid,
    key_source character varying(50) NOT NULL,
    username character varying(255),
    hostname character varying(255),
    ip_address inet,
    file_path character varying(500),
    comment text,
    risk_score integer DEFAULT 50,
    is_weak boolean DEFAULT false,
    discovery_method public.discovery_method DEFAULT 'active'::public.discovery_method NOT NULL,
    first_discovered_at timestamp with time zone DEFAULT now(),
    last_seen_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT valid_ssh_key_risk CHECK (((risk_score >= 0) AND (risk_score <= 100))),
    CONSTRAINT valid_ssh_key_source CHECK (((key_source)::text = ANY ((ARRAY['host_key'::character varying, 'authorized_key'::character varying, 'user_key'::character varying])::text[])))
);


-- TABLE: sso_group_role_mappings
CREATE TABLE IF NOT EXISTS public.sso_group_role_mappings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sso_provider_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    external_group_name character varying(255) NOT NULL,
    role_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: sso_providers
CREATE TABLE IF NOT EXISTS public.sso_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    provider_type character varying(50) NOT NULL,
    provider_name character varying(100) NOT NULL,
    client_id character varying(255),
    client_secret_encrypted text,
    auth_url character varying(500),
    token_url character varying(500),
    userinfo_url character varying(500),
    scopes character varying(500) DEFAULT 'openid email profile'::character varying,
    saml_entity_id character varying(255),
    saml_sso_url character varying(500),
    saml_certificate text,
    saml_private_key_encrypted text,
    is_enabled boolean DEFAULT true,
    is_default boolean DEFAULT false,
    auto_provision_users boolean DEFAULT true,
    attribute_mapping jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    default_role_id uuid,
    allowed_domains text[] DEFAULT '{}'::text[],
    groups_claim_name character varying(100) DEFAULT 'groups'::character varying,
    CONSTRAINT valid_provider_type CHECK (((provider_type)::text = ANY ((ARRAY['google'::character varying, 'microsoft'::character varying, 'azure'::character varying, 'saml'::character varying, 'okta'::character varying])::text[])))
);


-- TABLE: invitations — auth-method-agnostic tenant member invitations (#891).
-- An invitation is a tokenized intent to grant a member access with a role,
-- independent of how they will authenticate. No users row is created until the
-- invitee accepts (avoids the password-account-vs-SSO collision). The raw token
-- lives only in the emailed accept link; we store its SHA-256 hex. The public
-- accept handler reads by token_hash (the token is the authorization); tenant
-- isolation for admin operations is app-enforced via WHERE tenant_id, matching
-- every other handler. The RLS policy below mirrors peer tables for when RLS is
-- enforced (issue #218); a future enforced-RLS accept path needs a tenant-
-- resolution exemption (SECURITY DEFINER lookup) since the token implies tenant.
CREATE TABLE IF NOT EXISTS public.invitations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    invited_by uuid,
    token_hash character varying(64) NOT NULL,
    status character varying(20) NOT NULL DEFAULT 'pending',
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    accepted_at timestamp with time zone,
    accepted_user_id uuid,
    CONSTRAINT invitations_pkey PRIMARY KEY (id),
    CONSTRAINT invitations_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'accepted'::character varying, 'revoked'::character varying, 'expired'::character varying])::text[])))
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_invitations_token_hash ON public.invitations (token_hash);
CREATE INDEX IF NOT EXISTS idx_invitations_tenant_status ON public.invitations (tenant_id, status);
-- At most one live pending invite per (tenant, email).
CREATE UNIQUE INDEX IF NOT EXISTS uq_invitations_pending_email ON public.invitations (tenant_id, lower((email)::text)) WHERE ((status)::text = 'pending'::text);
-- RLS for this table is declared with every other tenant-isolation policy, in
-- the canonical RLS HARDENING block in POST-MIGRATIONS. It used to be declared
-- here with USING only and no WITH CHECK (#1297); it could not be tightened in
-- place because the DO/EXCEPTION duplicate_object form cannot UPDATE an
-- existing policy — on an already-installed database it would hit the
-- duplicate and silently leave the old, write-open policy in force.


-- TABLE: subscription_tier_history
CREATE TABLE IF NOT EXISTS public.subscription_tier_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tier_id uuid NOT NULL,
    change_type character varying(50) NOT NULL,
    changes_json jsonb NOT NULL,
    changed_by uuid,
    changed_at timestamp with time zone DEFAULT now(),
    notes text,
    CONSTRAINT subscription_tier_history_change_type_check CHECK (((change_type)::text = ANY ((ARRAY['created'::character varying, 'modified'::character varying, 'deprecated'::character varying, 'reactivated'::character varying])::text[])))
);


-- TABLE: subscription_tiers
CREATE TABLE IF NOT EXISTS public.subscription_tiers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    max_sensors integer,
    max_assets integer,
    max_users integer,
    retention_days integer,
    price_cents integer,
    billing_interval character varying(20),
    stripe_price_id character varying(255),
    annual_price_cents integer,
    stripe_price_id_annual character varying(255),
    features jsonb DEFAULT '{}'::jsonb,
    limits jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    metadata jsonb DEFAULT '{}'::jsonb,
    addon_pricing jsonb DEFAULT '{}'::jsonb,
    is_custom boolean DEFAULT false,
    display_order integer DEFAULT 0,
    deprecated_at timestamp with time zone,
    -- Trial phase support. The Free tier doubles as the trial: trial_days_full =
    -- days of full access, trial_days_soft = days of soft-prompt access (banners)
    -- after that. Past both, the tenant is hard-locked until they upgrade. NULL on
    -- non-trial tiers; is_trial is the flag the admin UI reads to decide whether to
    -- render trial settings.
    is_trial boolean DEFAULT false NOT NULL,
    trial_days_full integer,
    trial_days_soft integer,
    -- How a plan is collected. 'stripe' = card-on-file (the admin UI
    -- auto-provisions the Stripe Product/Price on save); 'invoice' = record-only,
    -- entitlements enforced but no Stripe subscription created, for enterprise
    -- deals that pay by PO. Standard public tiers are always 'stripe'.
    billing_method character varying(20) DEFAULT 'stripe' NOT NULL,
    -- Scopes a custom plan to exactly one tenant. NULL = a standard/global plan
    -- offered on public signup; a tenant uuid = a private plan visible only to
    -- that tenant. Always paired with is_custom = true. The FK lives in the
    -- constraint section below: tenants' PRIMARY KEY is not in place yet here.
    owner_tenant_id uuid,
    CONSTRAINT subscription_tiers_billing_method_check
        CHECK (billing_method IN ('stripe', 'invoice'))
);


-- TABLE: support_ticket_messages
CREATE TABLE IF NOT EXISTS public.support_ticket_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ticket_id uuid NOT NULL,
    author_id uuid,
    author_type character varying(20) DEFAULT 'admin'::character varying NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: support_tickets
CREATE TABLE IF NOT EXISTS public.support_tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    subject character varying(500) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'open'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    category character varying(100),
    assigned_to uuid,
    created_by uuid,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: tenant_admin_settings
CREATE TABLE IF NOT EXISTS public.tenant_admin_settings (
    tenant_id uuid NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: tenant_admin_settings_audit
CREATE TABLE IF NOT EXISTS public.tenant_admin_settings_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    config_before jsonb,
    config_after jsonb NOT NULL,
    version_before integer NOT NULL,
    version_after integer NOT NULL,
    changed_by uuid,
    change_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


-- MATERIALIZED VIEW: tenant_cost_summary
-- B-40: DROP ... CASCADE + CREATE — see the note on
-- mv_location_finding_summary above. Dependent recreated later in this file:
-- idx_tenant_cost_summary_unique (body). No wrapper view consumes it.
DROP MATERIALIZED VIEW IF EXISTS public.tenant_cost_summary CASCADE;
CREATE MATERIALIZED VIEW public.tenant_cost_summary AS
 SELECT tenant_resource_usage.tenant_id,
    date_trunc('day'::text, tenant_resource_usage."timestamp") AS cost_date,
    sum(tenant_resource_usage.cost_usd) AS daily_cost,
    sum(tenant_resource_usage.api_calls) AS total_api_calls,
    sum(tenant_resource_usage.database_queries) AS total_database_queries,
    sum(tenant_resource_usage.storage_used_mb) AS total_storage_mb,
    sum(tenant_resource_usage.network_bytes) AS total_network_bytes,
    avg(tenant_resource_usage.cpu_usage_percent) AS avg_cpu_usage,
    avg(tenant_resource_usage.memory_usage_mb) AS avg_memory_usage,
    count(*) AS metric_count
   FROM public.tenant_resource_usage
  WHERE (tenant_resource_usage."timestamp" >= (CURRENT_DATE - '90 days'::interval))
  GROUP BY tenant_resource_usage.tenant_id, (date_trunc('day'::text, tenant_resource_usage."timestamp"))
  WITH NO DATA;


-- TABLE: tenant_framework_controls
CREATE TABLE IF NOT EXISTS public.tenant_framework_controls (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    framework_id uuid NOT NULL,
    family_id uuid,
    control_id character varying(100) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    baseline_severity character varying(20) NOT NULL,
    crypto_relevant boolean DEFAULT false NOT NULL,
    -- Provenance (ADR-0005 source_kind vocabulary, ADR-0008 D4.1). NULL means
    -- "created before this column existed" and is deliberately distinct from
    -- 'declared': a row that predates provenance has none, and guessing one for
    -- it would invent a fact about who wrote it.
    source_kind character varying(20),
    source_ref character varying(200),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tenant_framework_controls_source_kind_check CHECK ((source_kind IS NULL OR (source_kind)::text = ANY ((ARRAY['measured'::character varying, 'imported'::character varying, 'declared'::character varying, 'inferred'::character varying])::text[]))),
    CONSTRAINT tenant_framework_controls_baseline_severity_check CHECK (((baseline_severity)::text = ANY ((ARRAY['Low'::character varying, 'Med'::character varying, 'High'::character varying, 'Critical'::character varying])::text[])))
);


-- TABLE: tenant_framework_licenses
CREATE TABLE IF NOT EXISTS public.tenant_framework_licenses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    platform_framework_id uuid NOT NULL,
    is_locked boolean DEFAULT false NOT NULL,
    locked_at timestamp with time zone,
    locked_by uuid,
    is_default boolean DEFAULT false NOT NULL,
    purchased_at timestamp with time zone DEFAULT now(),
    purchase_price_cents integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    subscription_status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    subscription_started_at timestamp with time zone DEFAULT now(),
    subscription_expires_at timestamp with time zone,
    provisioned_by character varying(20) DEFAULT 'admin'::character varying NOT NULL,
    CONSTRAINT tenant_framework_licenses_provisioned_by_check CHECK (((provisioned_by)::text = ANY ((ARRAY['admin'::character varying, 'self_service'::character varying, 'auto'::character varying])::text[]))),
    CONSTRAINT tenant_framework_licenses_subscription_status_check CHECK (((subscription_status)::text = ANY ((ARRAY['active'::character varying, 'expired'::character varying, 'cancelled'::character varying])::text[])))
);


-- TABLE: tenant_frameworks
CREATE TABLE IF NOT EXISTS public.tenant_frameworks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(20) NOT NULL,
    description text,
    source_framework_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: tenant_geographic_data
CREATE TABLE IF NOT EXISTS public.tenant_geographic_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    country_code character varying(2),
    region character varying(100),
    city character varying(100),
    latitude numeric(10,8),
    longitude numeric(11,8),
    timezone character varying(50),
    is_primary boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: tenant_health
CREATE TABLE IF NOT EXISTS public.tenant_health (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    overall_score numeric(5,2) DEFAULT 0 NOT NULL,
    health_status character varying(20) DEFAULT 'unknown'::character varying NOT NULL,
    last_calculated timestamp with time zone DEFAULT now() NOT NULL,
    score_breakdown jsonb DEFAULT '{}'::jsonb NOT NULL,
    recommendations jsonb DEFAULT '[]'::jsonb NOT NULL,
    trends jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


-- VIEW: tenant_health_summary_view
CREATE OR REPLACE VIEW public.tenant_health_summary_view AS
 SELECT th.tenant_id,
    th.overall_score,
    th.health_status,
    th.last_calculated,
    (th.trends ->> 'trend_direction'::text) AS trend_direction,
    COALESCE(alert_counts.critical_alerts, (0)::bigint) AS critical_alerts,
    COALESCE(alert_counts.high_alerts, (0)::bigint) AS high_alerts,
    COALESCE(alert_counts.total_alerts, (0)::bigint) AS total_alerts,
    COALESCE(jsonb_array_length(th.recommendations), 0) AS recommendations_count,
    th.created_at,
    th.updated_at
   FROM (public.tenant_health th
     LEFT JOIN ( SELECT health_alerts.tenant_id,
            count(*) FILTER (WHERE ((health_alerts.severity)::text = 'critical'::text)) AS critical_alerts,
            count(*) FILTER (WHERE ((health_alerts.severity)::text = 'high'::text)) AS high_alerts,
            count(*) AS total_alerts
           FROM public.health_alerts
          WHERE (health_alerts.is_active = true)
          GROUP BY health_alerts.tenant_id) alert_counts ON ((th.tenant_id = alert_counts.tenant_id)));


-- TABLE: tenant_measurement_overrides
CREATE TABLE IF NOT EXISTS public.tenant_measurement_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    control_measurement_id uuid NOT NULL,
    predicate_override jsonb NOT NULL,
    severity_override character varying(20),
    rationale text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tenant_measurement_overrides_severity_override_check CHECK (((severity_override)::text = ANY ((ARRAY['Low'::character varying, 'Med'::character varying, 'High'::character varying, 'Critical'::character varying])::text[])))
);


-- TABLE: tenant_notes
CREATE TABLE IF NOT EXISTS public.tenant_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    author_id uuid,
    content text NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


-- TABLE: tenant_notification_channels
CREATE TABLE IF NOT EXISTS public.tenant_notification_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    channel_name character varying(100) NOT NULL,
    channel_type character varying(50) NOT NULL,
    config jsonb NOT NULL,
    enabled boolean DEFAULT true,
    test_status character varying(20),
    last_test_at timestamp with time zone,
    last_used_at timestamp with time zone,
    description text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_tenant_channel_type CHECK (((channel_type)::text = ANY ((ARRAY['email'::character varying, 'slack'::character varying, 'webhook'::character varying, 'pagerduty'::character varying, 'sms'::character varying, 'in_app'::character varying])::text[])))
);


-- TABLE: tenant_notification_rules
CREATE TABLE IF NOT EXISTS public.tenant_notification_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    rule_name character varying(100) NOT NULL,
    alert_source character varying(50) NOT NULL,
    alert_type character varying(100),
    channel_ids uuid[] NOT NULL,
    severity_filter character varying(20)[],
    category_filter character varying(50)[],
    frequency character varying(20) DEFAULT 'immediate'::character varying,
    digest_window integer,
    enabled boolean DEFAULT true,
    priority integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_frequency CHECK (((frequency)::text = ANY ((ARRAY['immediate'::character varying, 'digest_hourly'::character varying, 'digest_daily'::character varying, 'digest_weekly'::character varying])::text[])))
);


-- TABLE: tenant_permissions
CREATE TABLE IF NOT EXISTS public.tenant_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    scope character varying(50) DEFAULT 'tenant'::character varying,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: tenant_role_permissions
CREATE TABLE IF NOT EXISTS public.tenant_role_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: tenant_roles
CREATE TABLE IF NOT EXISTS public.tenant_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    description text,
    is_system_role boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: tenant_usage
CREATE TABLE IF NOT EXISTS public.tenant_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    sensors_count integer DEFAULT 0,
    assets_count integer DEFAULT 0,
    users_count integer DEFAULT 0,
    storage_bytes bigint DEFAULT 0,
    api_calls_current_month integer DEFAULT 0,
    reports_generated_month integer DEFAULT 0,
    integrations_active integer DEFAULT 0,
    billing_period_start date NOT NULL,
    billing_period_end date NOT NULL,
    last_calculated_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: ticket_comments
CREATE TABLE IF NOT EXISTS public.ticket_comments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid NOT NULL,
    -- NULL means "System": alert-event echoes onto linked tickets (#943) are
    -- system-authored.
    author_id uuid,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


-- TABLE: tickets
CREATE TABLE IF NOT EXISTS public.tickets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    category character varying(30) DEFAULT 'general'::character varying NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    severity character varying(20),
    due_date timestamp with time zone,
    finding_id uuid,
    control_id uuid,
    asset_id uuid,
    certificate_id uuid,
    crypto_implementation_id uuid,
    external_ticket_system character varying(50),
    external_ticket_id character varying(255),
    external_ticket_url text,
    external_sync_status character varying(30) DEFAULT 'none'::character varying,
    source character varying(30) DEFAULT 'manual'::character varying NOT NULL,
    tags text[],
    assigned_to uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    resolution_notes text,
    -- Links a ticket to the alert it was raised from (Remediation → Alerts).
    -- Deliberately unconstrained: alerts are created by the alerting pipeline and
    -- a ticket outlives the alert it came from.
    alert_id uuid,
    CONSTRAINT tickets_category_check CHECK (((category)::text = ANY ((ARRAY['compliance'::character varying, 'certificate'::character varying, 'remediation'::character varying, 'vulnerability'::character varying, 'operational'::character varying, 'general'::character varying])::text[]))),
    CONSTRAINT tickets_external_sync_status_check CHECK (((external_sync_status)::text = ANY ((ARRAY['none'::character varying, 'linked'::character varying, 'syncing'::character varying, 'error'::character varying])::text[]))),
    CONSTRAINT tickets_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT tickets_severity_check CHECK (((severity)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT tickets_source_check CHECK (((source)::text = ANY ((ARRAY['manual'::character varying, 'auto_finding'::character varying, 'auto_expiry'::character varying, 'external_sync'::character varying, 'remediation_queue'::character varying])::text[]))),
    CONSTRAINT tickets_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'in_progress'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


-- TABLE: ui_themes
CREATE TABLE IF NOT EXISTS public.ui_themes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(200) NOT NULL,
    description text,
    theme_config jsonb NOT NULL,
    component_overrides jsonb DEFAULT '{}'::jsonb,
    is_public boolean DEFAULT true,
    is_active boolean DEFAULT true,
    pricing_tier character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_pricing_tier CHECK (((pricing_tier)::text = ANY ((ARRAY['free'::character varying, 'professional'::character varying, 'enterprise'::character varying, 'all'::character varying])::text[])))
);


-- TABLE: user_auth_methods
CREATE TABLE IF NOT EXISTS public.user_auth_methods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    auth_type character varying(50) NOT NULL,
    sso_provider_id uuid,
    external_user_id character varying(255),
    external_email character varying(255),
    is_primary boolean DEFAULT false,
    last_used_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_auth_type CHECK (((auth_type)::text = ANY ((ARRAY['password'::character varying, 'google'::character varying, 'microsoft'::character varying, 'azure'::character varying, 'saml'::character varying, 'okta'::character varying])::text[])))
);


-- TABLE: user_framework_preferences
CREATE TABLE IF NOT EXISTS public.user_framework_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    framework_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE: user_tenant_roles
CREATE TABLE IF NOT EXISTS public.user_tenant_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid,
    assigned_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true
);


-- TABLE: users
CREATE TABLE IF NOT EXISTS public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    email_verified boolean DEFAULT false,
    email_verification_token character varying(255),
    email_verification_expires timestamp with time zone,
    first_name character varying(100),
    last_name character varying(100),
    password_hash character varying(255),
    password_changed_at timestamp with time zone,
    password_reset_token character varying(255),
    password_reset_expires timestamp with time zone,
    password_history jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    last_login_at timestamp with time zone,
    login_count integer DEFAULT 0,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    avatar_url character varying(500),
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    preferences jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    eula_accepted_at timestamp with time zone,
    eula_version character varying(50),
    onboarding_completed_at timestamp with time zone,
    -- Per-user dismissal of the Getting Started wizard (#711), persisted
    -- server-side so it sticks across devices. NULL = not dismissed. Distinct
    -- from onboarding_completed_at (finished) and the tenant-level
    -- onboarding_required setting (org-wide disable).
    onboarding_dismissed_at timestamp with time zone,
    CONSTRAINT valid_email CHECK (((email)::text ~ '^[^@]+@[^@]+\.[^@]+$'::text))
);


-- VIEW: user_tenant_permissions
CREATE OR REPLACE VIEW public.user_tenant_permissions AS
 SELECT u.id AS user_id,
    u.email,
    u.first_name,
    u.last_name,
    t.id AS tenant_id,
    t.name AS tenant_name,
    tr.name AS role_name,
    tr.display_name AS role_display_name,
    tp.name AS permission_name,
    tp.resource,
    tp.action,
    tp.scope,
    utr.assigned_at,
    utr.expires_at,
    utr.is_active
   FROM (((((public.users u
     JOIN public.user_tenant_roles utr ON ((u.id = utr.user_id)))
     JOIN public.tenants t ON ((utr.tenant_id = t.id)))
     JOIN public.tenant_roles tr ON ((utr.role_id = tr.id)))
     JOIN public.tenant_role_permissions trp ON ((tr.id = trp.role_id)))
     JOIN public.tenant_permissions tp ON ((trp.permission_id = tp.id)))
  WHERE ((u.deleted_at IS NULL) AND (utr.is_active = true) AND ((utr.expires_at IS NULL) OR (utr.expires_at > now())));


-- TABLE: user_workflow_progress
CREATE TABLE IF NOT EXISTS public.user_workflow_progress (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    workflow_configuration_id uuid NOT NULL,
    current_step integer DEFAULT 0,
    completed_steps jsonb DEFAULT '[]'::jsonb,
    skipped_steps jsonb DEFAULT '[]'::jsonb,
    step_data jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'in_progress'::character varying,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['not_started'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'abandoned'::character varying])::text[])))
);


-- VIEW: v_ci_inventory
CREATE OR REPLACE VIEW public.v_ci_inventory AS
 SELECT a.id,
    a.tenant_id,
    'infrastructure_asset'::text AS ci_category,
    -- The CMDB CI class comes from the class registry (ADR-0002 D2:
    -- asset_classes.cmdb_ci_type is "the default ServiceNow class for the
    -- sync"), not from a four-arm CASE over the retired asset_type enum. An
    -- empty registry value is NOT a guess: it falls back to the generic
    -- hardware class exactly as the old ELSE arm did.
    COALESCE(NULLIF(ac.cmdb_ci_type, ''::text), 'cmdb_ci_hardware'::text) AS cmdb_ci_type,
    (COALESCE(a.display_name, a.hostname, host(a.primary_address)))::character varying AS display_name,
    a.description,
    a.risk_score,
        -- B-18: band risk_score; do NOT select a stored risk_level column —
        -- `assets` deliberately has none (DATA_MODEL §2), because nothing wrote
        -- the one network_assets carried and an Enterprise CMDB sync profile
        -- mapping it therefore pushed `risk_level: "Informational"` next to
        -- `risk_score: 90` into the customer's system of record. Same canonical
        -- ladder as the crypto_configuration branch below and as
        -- services/inventory-service/internal/models/risk_bands.go
        -- (RiskLevelCaseSQL): Critical >= 90, High >= 70, Medium >= 40,
        -- Low >= 1, Informational 0. Score 0 means NOT ASSESSED, so only 0
        -- bands as Informational.
        --
        -- The ::character varying casts are load-bearing, not decoration.
        -- Postgres resolves a UNION column to the FIRST branch's type when the
        -- conversions are implicit in both directions, so this branch decides
        -- the view's risk_level type; the column has always been `character
        -- varying`. Emitting ::text here flips it, and CREATE OR REPLACE VIEW
        -- cannot change a column's type — it fails with "cannot change data
        -- type of view column", aborting the migration on every EXISTING
        -- install while passing on a fresh one.
        CASE
            WHEN (a.risk_score >= 90) THEN 'Critical'::character varying
            WHEN (a.risk_score >= 70) THEN 'High'::character varying
            WHEN (a.risk_score >= 40) THEN 'Medium'::character varying
            WHEN (a.risk_score >= 1) THEN 'Low'::character varying
            ELSE 'Informational'::character varying
        END AS risk_level,
    a.first_discovered_at,
    a.last_seen_at AS last_verified_at,
    a.created_at,
    a.updated_at,
    a.deleted_at
   FROM (public.assets a
     LEFT JOIN public.asset_classes ac ON (((ac.key = a.class_key) AND (ac.tenant_id IS NULL))))
UNION ALL
 SELECT certificates.id,
    certificates.tenant_id,
    'certificate'::text AS ci_category,
    'cmdb_ci_certificate'::text AS cmdb_ci_type,
    COALESCE(certificates.common_name, (certificates.subject_dn)::character varying) AS display_name,
    ('Certificate: '::text || (COALESCE(certificates.common_name, 'Unknown'::character varying))::text) AS description,
    NULL::integer AS risk_score,
    NULL::character varying AS risk_level,
    certificates.created_at AS first_discovered_at,
    certificates.updated_at AS last_verified_at,
    certificates.created_at,
    certificates.updated_at,
    NULL::timestamp with time zone AS deleted_at
   FROM public.certificates
UNION ALL
 SELECT keys.id,
    keys.tenant_id,
    'key'::text AS ci_category,
    'cmdb_ci_crypto_key'::text AS cmdb_ci_type,
    COALESCE((keys.key_type || ' key'::text), 'Unknown key'::text) AS display_name,
    ('Cryptographic key: '::text || COALESCE(keys.key_type, 'Unknown'::text)) AS description,
    NULL::integer AS risk_score,
    NULL::character varying AS risk_level,
    keys.created_at AS first_discovered_at,
    COALESCE(keys.rotated_at, keys.created_at) AS last_verified_at,
    keys.created_at,
    keys.created_at AS updated_at,
    NULL::timestamp with time zone AS deleted_at
   FROM public.keys
UNION ALL
 SELECT crypto_implementations_partitioned.id,
    crypto_implementations_partitioned.tenant_id,
    'crypto_configuration'::text AS ci_category,
    'cmdb_ci_crypto_config'::text AS cmdb_ci_type,
    COALESCE((((crypto_implementations_partitioned.protocol)::text || ' '::text) || (COALESCE(crypto_implementations_partitioned.protocol_version, ''::character varying))::text), 'Unknown protocol'::text) AS display_name,
    ((('Crypto config: '::text || COALESCE((crypto_implementations_partitioned.protocol)::text, ''::text)) || ' '::text) || (COALESCE(crypto_implementations_partitioned.cipher_suite, ''::character varying))::text) AS description,
    crypto_implementations_partitioned.risk_score,
        -- Canonical risk bands (services/inventory-service/internal/models/risk_bands.go):
        -- Critical >= 90, High >= 70, Medium >= 40, Low >= 1, Informational 0.
        -- Was >= 80 / 60 / 40 / 20, which called a 60 "High" (canonical: Medium)
        -- and a 15 "Informational" (canonical: Low). Score 0 means NOT ASSESSED,
        -- so only 0 may band as Informational.
        CASE
            WHEN (crypto_implementations_partitioned.risk_score >= 90) THEN 'Critical'::text
            WHEN (crypto_implementations_partitioned.risk_score >= 70) THEN 'High'::text
            WHEN (crypto_implementations_partitioned.risk_score >= 40) THEN 'Medium'::text
            WHEN (crypto_implementations_partitioned.risk_score >= 1) THEN 'Low'::text
            ELSE 'Informational'::text
        END AS risk_level,
    crypto_implementations_partitioned.first_discovered_at,
    crypto_implementations_partitioned.last_verified_at,
    crypto_implementations_partitioned.created_at,
    crypto_implementations_partitioned.updated_at,
    crypto_implementations_partitioned.deleted_at
   FROM public.crypto_implementations_partitioned;


-- VIEW: v_tenants
CREATE OR REPLACE VIEW public.v_tenants AS
 SELECT t.id,
    t.name,
    t.slug,
    t.subscription_tier_id,
    t.billing_email,
    t.payment_status,
    ((t.deleted_at IS NULL) AND ((COALESCE(t.payment_status, 'active'::character varying))::text = 'active'::text)) AS is_active,
    t.created_at,
    t.updated_at,
    t.deleted_at
   FROM public.tenants t;


-- TABLE: workflow_configurations
CREATE TABLE IF NOT EXISTS public.workflow_configurations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    workflow_type character varying(100) NOT NULL,
    workflow_name character varying(200) NOT NULL,
    steps jsonb NOT NULL,
    configuration jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    is_default boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


-- TABLE ATTACH: activity_logs_y2026m04
DO $$ BEGIN
  IF to_regclass('audit.activity_logs') IS NOT NULL
     AND to_regclass('audit.activity_logs_y2026m04') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('audit.activity_logs')
         AND inhrelid = to_regclass('audit.activity_logs_y2026m04')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs ATTACH PARTITION audit.activity_logs_y2026m04 FOR VALUES FROM ('2026-04-01 00:00:00+00') TO ('2026-05-01 00:00:00+00');
  END IF;
END $$;


-- TABLE ATTACH: activity_logs_y2026m05
DO $$ BEGIN
  IF to_regclass('audit.activity_logs') IS NOT NULL
     AND to_regclass('audit.activity_logs_y2026m05') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('audit.activity_logs')
         AND inhrelid = to_regclass('audit.activity_logs_y2026m05')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs ATTACH PARTITION audit.activity_logs_y2026m05 FOR VALUES FROM ('2026-05-01 00:00:00+00') TO ('2026-06-01 00:00:00+00');
  END IF;
END $$;


-- TABLE ATTACH: activity_logs_y2026m06
DO $$ BEGIN
  IF to_regclass('audit.activity_logs') IS NOT NULL
     AND to_regclass('audit.activity_logs_y2026m06') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('audit.activity_logs')
         AND inhrelid = to_regclass('audit.activity_logs_y2026m06')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs ATTACH PARTITION audit.activity_logs_y2026m06 FOR VALUES FROM ('2026-06-01 00:00:00+00') TO ('2026-07-01 00:00:00+00');
  END IF;
END $$;


-- TABLE ATTACH: activity_logs_y2026m07
DO $$ BEGIN
  IF to_regclass('audit.activity_logs') IS NOT NULL
     AND to_regclass('audit.activity_logs_y2026m07') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('audit.activity_logs')
         AND inhrelid = to_regclass('audit.activity_logs_y2026m07')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs ATTACH PARTITION audit.activity_logs_y2026m07 FOR VALUES FROM ('2026-07-01 00:00:00+00') TO ('2026-08-01 00:00:00+00');
  END IF;
END $$;


-- TABLE ATTACH: activity_logs_y2026m08
DO $$ BEGIN
  IF to_regclass('audit.activity_logs') IS NOT NULL
     AND to_regclass('audit.activity_logs_y2026m08') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('audit.activity_logs')
         AND inhrelid = to_regclass('audit.activity_logs_y2026m08')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs ATTACH PARTITION audit.activity_logs_y2026m08 FOR VALUES FROM ('2026-08-01 00:00:00+00') TO ('2026-09-01 00:00:00+00');
  END IF;
END $$;


-- TABLE ATTACH: crypto_implementations_part_0
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND to_regclass('public.crypto_implementations_part_0') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.crypto_implementations_partitioned')
         AND inhrelid = to_regclass('public.crypto_implementations_part_0')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementations_partitioned ATTACH PARTITION public.crypto_implementations_part_0 FOR VALUES WITH (modulus 8, remainder 0);
  END IF;
END $$;


-- TABLE ATTACH: crypto_implementations_part_1
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND to_regclass('public.crypto_implementations_part_1') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.crypto_implementations_partitioned')
         AND inhrelid = to_regclass('public.crypto_implementations_part_1')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementations_partitioned ATTACH PARTITION public.crypto_implementations_part_1 FOR VALUES WITH (modulus 8, remainder 1);
  END IF;
END $$;


-- TABLE ATTACH: crypto_implementations_part_2
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND to_regclass('public.crypto_implementations_part_2') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.crypto_implementations_partitioned')
         AND inhrelid = to_regclass('public.crypto_implementations_part_2')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementations_partitioned ATTACH PARTITION public.crypto_implementations_part_2 FOR VALUES WITH (modulus 8, remainder 2);
  END IF;
END $$;


-- TABLE ATTACH: crypto_implementations_part_3
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND to_regclass('public.crypto_implementations_part_3') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.crypto_implementations_partitioned')
         AND inhrelid = to_regclass('public.crypto_implementations_part_3')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementations_partitioned ATTACH PARTITION public.crypto_implementations_part_3 FOR VALUES WITH (modulus 8, remainder 3);
  END IF;
END $$;


-- TABLE ATTACH: crypto_implementations_part_4
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND to_regclass('public.crypto_implementations_part_4') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.crypto_implementations_partitioned')
         AND inhrelid = to_regclass('public.crypto_implementations_part_4')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementations_partitioned ATTACH PARTITION public.crypto_implementations_part_4 FOR VALUES WITH (modulus 8, remainder 4);
  END IF;
END $$;


-- TABLE ATTACH: crypto_implementations_part_5
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND to_regclass('public.crypto_implementations_part_5') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.crypto_implementations_partitioned')
         AND inhrelid = to_regclass('public.crypto_implementations_part_5')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementations_partitioned ATTACH PARTITION public.crypto_implementations_part_5 FOR VALUES WITH (modulus 8, remainder 5);
  END IF;
END $$;


-- TABLE ATTACH: crypto_implementations_part_6
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND to_regclass('public.crypto_implementations_part_6') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.crypto_implementations_partitioned')
         AND inhrelid = to_regclass('public.crypto_implementations_part_6')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementations_partitioned ATTACH PARTITION public.crypto_implementations_part_6 FOR VALUES WITH (modulus 8, remainder 6);
  END IF;
END $$;


-- TABLE ATTACH: crypto_implementations_part_7
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND to_regclass('public.crypto_implementations_part_7') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.crypto_implementations_partitioned')
         AND inhrelid = to_regclass('public.crypto_implementations_part_7')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementations_partitioned ATTACH PARTITION public.crypto_implementations_part_7 FOR VALUES WITH (modulus 8, remainder 7);
  END IF;
END $$;


-- TABLE ATTACH: sensor_discoveries_part_0
DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND to_regclass('public.sensor_discoveries_part_0') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.sensor_discoveries_partitioned')
         AND inhrelid = to_regclass('public.sensor_discoveries_part_0')
     ) THEN
    ALTER TABLE ONLY public.sensor_discoveries_partitioned ATTACH PARTITION public.sensor_discoveries_part_0 FOR VALUES WITH (modulus 8, remainder 0);
  END IF;
END $$;


-- TABLE ATTACH: sensor_discoveries_part_1
DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND to_regclass('public.sensor_discoveries_part_1') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.sensor_discoveries_partitioned')
         AND inhrelid = to_regclass('public.sensor_discoveries_part_1')
     ) THEN
    ALTER TABLE ONLY public.sensor_discoveries_partitioned ATTACH PARTITION public.sensor_discoveries_part_1 FOR VALUES WITH (modulus 8, remainder 1);
  END IF;
END $$;


-- TABLE ATTACH: sensor_discoveries_part_2
DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND to_regclass('public.sensor_discoveries_part_2') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.sensor_discoveries_partitioned')
         AND inhrelid = to_regclass('public.sensor_discoveries_part_2')
     ) THEN
    ALTER TABLE ONLY public.sensor_discoveries_partitioned ATTACH PARTITION public.sensor_discoveries_part_2 FOR VALUES WITH (modulus 8, remainder 2);
  END IF;
END $$;


-- TABLE ATTACH: sensor_discoveries_part_3
DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND to_regclass('public.sensor_discoveries_part_3') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.sensor_discoveries_partitioned')
         AND inhrelid = to_regclass('public.sensor_discoveries_part_3')
     ) THEN
    ALTER TABLE ONLY public.sensor_discoveries_partitioned ATTACH PARTITION public.sensor_discoveries_part_3 FOR VALUES WITH (modulus 8, remainder 3);
  END IF;
END $$;


-- TABLE ATTACH: sensor_discoveries_part_4
DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND to_regclass('public.sensor_discoveries_part_4') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.sensor_discoveries_partitioned')
         AND inhrelid = to_regclass('public.sensor_discoveries_part_4')
     ) THEN
    ALTER TABLE ONLY public.sensor_discoveries_partitioned ATTACH PARTITION public.sensor_discoveries_part_4 FOR VALUES WITH (modulus 8, remainder 4);
  END IF;
END $$;


-- TABLE ATTACH: sensor_discoveries_part_5
DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND to_regclass('public.sensor_discoveries_part_5') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.sensor_discoveries_partitioned')
         AND inhrelid = to_regclass('public.sensor_discoveries_part_5')
     ) THEN
    ALTER TABLE ONLY public.sensor_discoveries_partitioned ATTACH PARTITION public.sensor_discoveries_part_5 FOR VALUES WITH (modulus 8, remainder 5);
  END IF;
END $$;


-- TABLE ATTACH: sensor_discoveries_part_6
DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND to_regclass('public.sensor_discoveries_part_6') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.sensor_discoveries_partitioned')
         AND inhrelid = to_regclass('public.sensor_discoveries_part_6')
     ) THEN
    ALTER TABLE ONLY public.sensor_discoveries_partitioned ATTACH PARTITION public.sensor_discoveries_part_6 FOR VALUES WITH (modulus 8, remainder 6);
  END IF;
END $$;


-- TABLE ATTACH: sensor_discoveries_part_7
DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND to_regclass('public.sensor_discoveries_part_7') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_inherits
       WHERE inhparent = to_regclass('public.sensor_discoveries_partitioned')
         AND inhrelid = to_regclass('public.sensor_discoveries_part_7')
     ) THEN
    ALTER TABLE ONLY public.sensor_discoveries_partitioned ATTACH PARTITION public.sensor_discoveries_part_7 FOR VALUES WITH (modulus 8, remainder 7);
  END IF;
END $$;


-- CONSTRAINT: activity_logs activity_logs_pkey
DO $$ BEGIN
  IF to_regclass('audit.activity_logs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'activity_logs_pkey' AND conrelid = to_regclass('audit.activity_logs')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs
        ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id, occurred_at);
  END IF;
END $$;


-- CONSTRAINT: activity_logs_y2026m04 activity_logs_y2026m04_pkey
DO $$ BEGIN
  IF to_regclass('audit.activity_logs_y2026m04') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'activity_logs_y2026m04_pkey' AND conrelid = to_regclass('audit.activity_logs_y2026m04')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs_y2026m04
        ADD CONSTRAINT activity_logs_y2026m04_pkey PRIMARY KEY (id, occurred_at);
  END IF;
END $$;


-- CONSTRAINT: activity_logs_y2026m05 activity_logs_y2026m05_pkey
DO $$ BEGIN
  IF to_regclass('audit.activity_logs_y2026m05') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'activity_logs_y2026m05_pkey' AND conrelid = to_regclass('audit.activity_logs_y2026m05')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs_y2026m05
        ADD CONSTRAINT activity_logs_y2026m05_pkey PRIMARY KEY (id, occurred_at);
  END IF;
END $$;


-- CONSTRAINT: activity_logs_y2026m06 activity_logs_y2026m06_pkey
DO $$ BEGIN
  IF to_regclass('audit.activity_logs_y2026m06') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'activity_logs_y2026m06_pkey' AND conrelid = to_regclass('audit.activity_logs_y2026m06')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs_y2026m06
        ADD CONSTRAINT activity_logs_y2026m06_pkey PRIMARY KEY (id, occurred_at);
  END IF;
END $$;


-- CONSTRAINT: activity_logs_y2026m07 activity_logs_y2026m07_pkey
DO $$ BEGIN
  IF to_regclass('audit.activity_logs_y2026m07') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'activity_logs_y2026m07_pkey' AND conrelid = to_regclass('audit.activity_logs_y2026m07')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs_y2026m07
        ADD CONSTRAINT activity_logs_y2026m07_pkey PRIMARY KEY (id, occurred_at);
  END IF;
END $$;


-- CONSTRAINT: activity_logs_y2026m08 activity_logs_y2026m08_pkey
DO $$ BEGIN
  IF to_regclass('audit.activity_logs_y2026m08') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'activity_logs_y2026m08_pkey' AND conrelid = to_regclass('audit.activity_logs_y2026m08')
     ) THEN
    ALTER TABLE ONLY audit.activity_logs_y2026m08
        ADD CONSTRAINT activity_logs_y2026m08_pkey PRIMARY KEY (id, occurred_at);
  END IF;
END $$;


-- CONSTRAINT: alert_rules alert_rules_pkey
DO $$ BEGIN
  IF to_regclass('audit.alert_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'alert_rules_pkey' AND conrelid = to_regclass('audit.alert_rules')
     ) THEN
    ALTER TABLE ONLY audit.alert_rules
        ADD CONSTRAINT alert_rules_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: job_execution_logs job_execution_logs_pkey
DO $$ BEGIN
  IF to_regclass('audit.job_execution_logs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'job_execution_logs_pkey' AND conrelid = to_regclass('audit.job_execution_logs')
     ) THEN
    ALTER TABLE ONLY audit.job_execution_logs
        ADD CONSTRAINT job_execution_logs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: retention_policies retention_policies_pkey
DO $$ BEGIN
  IF to_regclass('audit.retention_policies') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'retention_policies_pkey' AND conrelid = to_regclass('audit.retention_policies')
     ) THEN
    ALTER TABLE ONLY audit.retention_policies
        ADD CONSTRAINT retention_policies_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: retention_policies retention_policies_policy_name_key
DO $$ BEGIN
  IF to_regclass('audit.retention_policies') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'retention_policies_policy_name_key' AND conrelid = to_regclass('audit.retention_policies')
     ) THEN
    ALTER TABLE ONLY audit.retention_policies
        ADD CONSTRAINT retention_policies_policy_name_key UNIQUE (policy_name);
  END IF;
END $$;


-- CONSTRAINT: scheduled_compliance_reports scheduled_compliance_reports_pkey
DO $$ BEGIN
  IF to_regclass('audit.scheduled_compliance_reports') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'scheduled_compliance_reports_pkey' AND conrelid = to_regclass('audit.scheduled_compliance_reports')
     ) THEN
    ALTER TABLE ONLY audit.scheduled_compliance_reports
        ADD CONSTRAINT scheduled_compliance_reports_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: scheduled_report_executions scheduled_report_executions_pkey
DO $$ BEGIN
  IF to_regclass('audit.scheduled_report_executions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'scheduled_report_executions_pkey' AND conrelid = to_regclass('audit.scheduled_report_executions')
     ) THEN
    ALTER TABLE ONLY audit.scheduled_report_executions
        ADD CONSTRAINT scheduled_report_executions_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: siem_health_checks siem_health_checks_pkey
DO $$ BEGIN
  IF to_regclass('audit.siem_health_checks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'siem_health_checks_pkey' AND conrelid = to_regclass('audit.siem_health_checks')
     ) THEN
    ALTER TABLE ONLY audit.siem_health_checks
        ADD CONSTRAINT siem_health_checks_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: siem_integrations siem_integrations_pkey
DO $$ BEGIN
  IF to_regclass('audit.siem_integrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'siem_integrations_pkey' AND conrelid = to_regclass('audit.siem_integrations')
     ) THEN
    ALTER TABLE ONLY audit.siem_integrations
        ADD CONSTRAINT siem_integrations_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: agent_certificates agent_certificates_pkey
DO $$ BEGIN
  IF to_regclass('public.agent_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'agent_certificates_pkey' AND conrelid = to_regclass('public.agent_certificates')
     ) THEN
    ALTER TABLE ONLY public.agent_certificates
        ADD CONSTRAINT agent_certificates_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: algorithms algorithms_code_key
DO $$ BEGIN
  IF to_regclass('public.algorithms') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'algorithms_code_key' AND conrelid = to_regclass('public.algorithms')
     ) THEN
    ALTER TABLE ONLY public.algorithms
        ADD CONSTRAINT algorithms_code_key UNIQUE (code);
  END IF;
END $$;


-- CONSTRAINT: algorithms algorithms_pkey
DO $$ BEGIN
  IF to_regclass('public.algorithms') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'algorithms_pkey' AND conrelid = to_regclass('public.algorithms')
     ) THEN
    ALTER TABLE ONLY public.algorithms
        ADD CONSTRAINT algorithms_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: api_usage_logs api_usage_logs_pkey
DO $$ BEGIN
  IF to_regclass('public.api_usage_logs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'api_usage_logs_pkey' AND conrelid = to_regclass('public.api_usage_logs')
     ) THEN
    ALTER TABLE ONLY public.api_usage_logs
        ADD CONSTRAINT api_usage_logs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: asset_history asset_history_pkey
DO $$ BEGIN
  IF to_regclass('public.asset_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_history_pkey' AND conrelid = to_regclass('public.asset_history')
     ) THEN
    ALTER TABLE ONLY public.asset_history
        ADD CONSTRAINT asset_history_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: asset_lifecycle_policies asset_lifecycle_policies_pkey
DO $$ BEGIN
  IF to_regclass('public.asset_lifecycle_policies') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_lifecycle_policies_pkey' AND conrelid = to_regclass('public.asset_lifecycle_policies')
     ) THEN
    ALTER TABLE ONLY public.asset_lifecycle_policies
        ADD CONSTRAINT asset_lifecycle_policies_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: asset_lifecycle_policies asset_lifecycle_policies_tenant_id_key
DO $$ BEGIN
  IF to_regclass('public.asset_lifecycle_policies') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_lifecycle_policies_tenant_id_key' AND conrelid = to_regclass('public.asset_lifecycle_policies')
     ) THEN
    ALTER TABLE ONLY public.asset_lifecycle_policies
        ADD CONSTRAINT asset_lifecycle_policies_tenant_id_key UNIQUE (tenant_id);
  END IF;
END $$;


-- CONSTRAINT: auth_audit_log auth_audit_log_pkey
DO $$ BEGIN
  IF to_regclass('public.auth_audit_log') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'auth_audit_log_pkey' AND conrelid = to_regclass('public.auth_audit_log')
     ) THEN
    ALTER TABLE ONLY public.auth_audit_log
        ADD CONSTRAINT auth_audit_log_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: aws_cost_data aws_cost_data_pkey
DO $$ BEGIN
  IF to_regclass('public.aws_cost_data') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'aws_cost_data_pkey' AND conrelid = to_regclass('public.aws_cost_data')
     ) THEN
    ALTER TABLE ONLY public.aws_cost_data
        ADD CONSTRAINT aws_cost_data_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: aws_cost_sync_jobs aws_cost_sync_jobs_pkey
DO $$ BEGIN
  IF to_regclass('public.aws_cost_sync_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'aws_cost_sync_jobs_pkey' AND conrelid = to_regclass('public.aws_cost_sync_jobs')
     ) THEN
    ALTER TABLE ONLY public.aws_cost_sync_jobs
        ADD CONSTRAINT aws_cost_sync_jobs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_coupon_redemptions billing_coupon_redemptions_coupon_id_tenant_id_key
DO $$ BEGIN
  IF to_regclass('public.billing_coupon_redemptions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_coupon_redemptions_coupon_id_tenant_id_key' AND conrelid = to_regclass('public.billing_coupon_redemptions')
     ) THEN
    ALTER TABLE ONLY public.billing_coupon_redemptions
        ADD CONSTRAINT billing_coupon_redemptions_coupon_id_tenant_id_key UNIQUE (coupon_id, tenant_id);
  END IF;
END $$;


-- CONSTRAINT: billing_coupon_redemptions billing_coupon_redemptions_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_coupon_redemptions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_coupon_redemptions_pkey' AND conrelid = to_regclass('public.billing_coupon_redemptions')
     ) THEN
    ALTER TABLE ONLY public.billing_coupon_redemptions
        ADD CONSTRAINT billing_coupon_redemptions_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_coupons billing_coupons_code_key
DO $$ BEGIN
  IF to_regclass('public.billing_coupons') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_coupons_code_key' AND conrelid = to_regclass('public.billing_coupons')
     ) THEN
    ALTER TABLE ONLY public.billing_coupons
        ADD CONSTRAINT billing_coupons_code_key UNIQUE (code);
  END IF;
END $$;


-- CONSTRAINT: billing_coupons billing_coupons_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_coupons') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_coupons_pkey' AND conrelid = to_regclass('public.billing_coupons')
     ) THEN
    ALTER TABLE ONLY public.billing_coupons
        ADD CONSTRAINT billing_coupons_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_customers billing_customers_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_customers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_customers_pkey' AND conrelid = to_regclass('public.billing_customers')
     ) THEN
    ALTER TABLE ONLY public.billing_customers
        ADD CONSTRAINT billing_customers_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_customers billing_customers_tenant_id_provider_id_key
DO $$ BEGIN
  IF to_regclass('public.billing_customers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_customers_tenant_id_provider_id_key' AND conrelid = to_regclass('public.billing_customers')
     ) THEN
    ALTER TABLE ONLY public.billing_customers
        ADD CONSTRAINT billing_customers_tenant_id_provider_id_key UNIQUE (tenant_id, provider_id);
  END IF;
END $$;


-- CONSTRAINT: billing_dunning_attempts billing_dunning_attempts_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_dunning_attempts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_dunning_attempts_pkey' AND conrelid = to_regclass('public.billing_dunning_attempts')
     ) THEN
    ALTER TABLE ONLY public.billing_dunning_attempts
        ADD CONSTRAINT billing_dunning_attempts_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_events billing_events_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_events') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_events_pkey' AND conrelid = to_regclass('public.billing_events')
     ) THEN
    ALTER TABLE ONLY public.billing_events
        ADD CONSTRAINT billing_events_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_events billing_events_provider_id_external_event_id_key
DO $$ BEGIN
  IF to_regclass('public.billing_events') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_events_provider_id_external_event_id_key' AND conrelid = to_regclass('public.billing_events')
     ) THEN
    ALTER TABLE ONLY public.billing_events
        ADD CONSTRAINT billing_events_provider_id_external_event_id_key UNIQUE (provider_id, external_event_id);
  END IF;
END $$;


-- CONSTRAINT: billing_invoice_line_items billing_invoice_line_items_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_invoice_line_items') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_invoice_line_items_pkey' AND conrelid = to_regclass('public.billing_invoice_line_items')
     ) THEN
    ALTER TABLE ONLY public.billing_invoice_line_items
        ADD CONSTRAINT billing_invoice_line_items_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_invoices billing_invoices_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_invoices') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_invoices_pkey' AND conrelid = to_regclass('public.billing_invoices')
     ) THEN
    ALTER TABLE ONLY public.billing_invoices
        ADD CONSTRAINT billing_invoices_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_providers billing_providers_key_key
DO $$ BEGIN
  IF to_regclass('public.billing_providers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_providers_key_key' AND conrelid = to_regclass('public.billing_providers')
     ) THEN
    ALTER TABLE ONLY public.billing_providers
        ADD CONSTRAINT billing_providers_key_key UNIQUE (key);
  END IF;
END $$;


-- CONSTRAINT: billing_providers billing_providers_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_providers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_providers_pkey' AND conrelid = to_regclass('public.billing_providers')
     ) THEN
    ALTER TABLE ONLY public.billing_providers
        ADD CONSTRAINT billing_providers_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_subscriptions billing_subscriptions_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_subscriptions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_subscriptions_pkey' AND conrelid = to_regclass('public.billing_subscriptions')
     ) THEN
    ALTER TABLE ONLY public.billing_subscriptions
        ADD CONSTRAINT billing_subscriptions_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_trial_tracking billing_trial_tracking_pkey
DO $$ BEGIN
  IF to_regclass('public.billing_trial_tracking') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_trial_tracking_pkey' AND conrelid = to_regclass('public.billing_trial_tracking')
     ) THEN
    ALTER TABLE ONLY public.billing_trial_tracking
        ADD CONSTRAINT billing_trial_tracking_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: billing_trial_tracking billing_trial_tracking_tenant_id_key
DO $$ BEGIN
  IF to_regclass('public.billing_trial_tracking') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_trial_tracking_tenant_id_key' AND conrelid = to_regclass('public.billing_trial_tracking')
     ) THEN
    ALTER TABLE ONLY public.billing_trial_tracking
        ADD CONSTRAINT billing_trial_tracking_tenant_id_key UNIQUE (tenant_id);
  END IF;
END $$;


-- CONSTRAINT: certificate_extensions certificate_extensions_pkey
DO $$ BEGIN
  IF to_regclass('public.certificate_extensions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificate_extensions_pkey' AND conrelid = to_regclass('public.certificate_extensions')
     ) THEN
    ALTER TABLE ONLY public.certificate_extensions
        ADD CONSTRAINT certificate_extensions_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: certificate_history certificate_history_pkey
DO $$ BEGIN
  IF to_regclass('public.certificate_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificate_history_pkey' AND conrelid = to_regclass('public.certificate_history')
     ) THEN
    ALTER TABLE ONLY public.certificate_history
        ADD CONSTRAINT certificate_history_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: certificates certificates_pkey
DO $$ BEGIN
  IF to_regclass('public.certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificates_pkey' AND conrelid = to_regclass('public.certificates')
     ) THEN
    ALTER TABLE ONLY public.certificates
        ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: cmdb_entity_mappings cmdb_entity_mappings_pkey
DO $$ BEGIN
  IF to_regclass('public.cmdb_entity_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'cmdb_entity_mappings_pkey' AND conrelid = to_regclass('public.cmdb_entity_mappings')
     ) THEN
    ALTER TABLE ONLY public.cmdb_entity_mappings
        ADD CONSTRAINT cmdb_entity_mappings_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: cmdb_sync_jobs cmdb_sync_jobs_pkey
DO $$ BEGIN
  IF to_regclass('public.cmdb_sync_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'cmdb_sync_jobs_pkey' AND conrelid = to_regclass('public.cmdb_sync_jobs')
     ) THEN
    ALTER TABLE ONLY public.cmdb_sync_jobs
        ADD CONSTRAINT cmdb_sync_jobs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: cmdb_sync_profiles cmdb_sync_profiles_pkey
DO $$ BEGIN
  IF to_regclass('public.cmdb_sync_profiles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'cmdb_sync_profiles_pkey' AND conrelid = to_regclass('public.cmdb_sync_profiles')
     ) THEN
    ALTER TABLE ONLY public.cmdb_sync_profiles
        ADD CONSTRAINT cmdb_sync_profiles_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: compliance_finding_history compliance_finding_history_pkey
DO $$ BEGIN
  IF to_regclass('public.compliance_finding_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_finding_history_pkey' AND conrelid = to_regclass('public.compliance_finding_history')
     ) THEN
    ALTER TABLE ONLY public.compliance_finding_history
        ADD CONSTRAINT compliance_finding_history_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: compliance_overrides compliance_overrides_pkey
DO $$ BEGIN
  IF to_regclass('public.compliance_overrides') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_overrides_pkey' AND conrelid = to_regclass('public.compliance_overrides')
     ) THEN
    ALTER TABLE ONLY public.compliance_overrides
        ADD CONSTRAINT compliance_overrides_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: compliance_rules compliance_rules_pkey
DO $$ BEGIN
  IF to_regclass('public.compliance_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_rules_pkey' AND conrelid = to_regclass('public.compliance_rules')
     ) THEN
    ALTER TABLE ONLY public.compliance_rules
        ADD CONSTRAINT compliance_rules_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: compliance_scenarios compliance_scenarios_pkey
DO $$ BEGIN
  IF to_regclass('public.compliance_scenarios') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_scenarios_pkey' AND conrelid = to_regclass('public.compliance_scenarios')
     ) THEN
    ALTER TABLE ONLY public.compliance_scenarios
        ADD CONSTRAINT compliance_scenarios_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: control_measurements control_measurements_pkey
DO $$ BEGIN
  IF to_regclass('public.control_measurements') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'control_measurements_pkey' AND conrelid = to_regclass('public.control_measurements')
     ) THEN
    ALTER TABLE ONLY public.control_measurements
        ADD CONSTRAINT control_measurements_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: crypto_applications crypto_applications_pkey
DO $$ BEGIN
  IF to_regclass('public.crypto_applications') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_applications_pkey' AND conrelid = to_regclass('public.crypto_applications')
     ) THEN
    ALTER TABLE ONLY public.crypto_applications
        ADD CONSTRAINT crypto_applications_pkey PRIMARY KEY (id);
  END IF;
END $$;




-- CONSTRAINT: crypto_implementation_algorithms crypto_implementation_algorithms_pkey
DO $$ BEGIN
  IF to_regclass('public.crypto_implementation_algorithms') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_implementation_algorithms_pkey' AND conrelid = to_regclass('public.crypto_implementation_algorithms')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementation_algorithms
        ADD CONSTRAINT crypto_implementation_algorithms_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: crypto_implementation_certificates crypto_implementation_certificates_pkey
DO $$ BEGIN
  IF to_regclass('public.crypto_implementation_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_implementation_certificates_pkey' AND conrelid = to_regclass('public.crypto_implementation_certificates')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementation_certificates
        ADD CONSTRAINT crypto_implementation_certificates_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: crypto_libraries crypto_libraries_pkey
DO $$ BEGIN
  IF to_regclass('public.crypto_libraries') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_libraries_pkey' AND conrelid = to_regclass('public.crypto_libraries')
     ) THEN
    ALTER TABLE ONLY public.crypto_libraries
        ADD CONSTRAINT crypto_libraries_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: database_encryption_states database_encryption_states_pkey
DO $$ BEGIN
  IF to_regclass('public.database_encryption_states') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'database_encryption_states_pkey' AND conrelid = to_regclass('public.database_encryption_states')
     ) THEN
    ALTER TABLE ONLY public.database_encryption_states
        ADD CONSTRAINT database_encryption_states_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: device_agents device_agents_pkey
DO $$ BEGIN
  IF to_regclass('public.device_agents') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'device_agents_pkey' AND conrelid = to_regclass('public.device_agents')
     ) THEN
    ALTER TABLE ONLY public.device_agents
        ADD CONSTRAINT device_agents_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: device_jobs device_jobs_pkey
DO $$ BEGIN
  IF to_regclass('public.device_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'device_jobs_pkey' AND conrelid = to_regclass('public.device_jobs')
     ) THEN
    ALTER TABLE ONLY public.device_jobs
        ADD CONSTRAINT device_jobs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: discovery_alert_configs discovery_alert_configs_pkey
DO $$ BEGIN
  IF to_regclass('public.discovery_alert_configs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_alert_configs_pkey' AND conrelid = to_regclass('public.discovery_alert_configs')
     ) THEN
    ALTER TABLE ONLY public.discovery_alert_configs
        ADD CONSTRAINT discovery_alert_configs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: discovery_alert_configs discovery_alert_configs_tenant_id_alert_type_key
DO $$ BEGIN
  IF to_regclass('public.discovery_alert_configs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_alert_configs_tenant_id_alert_type_key' AND conrelid = to_regclass('public.discovery_alert_configs')
     ) THEN
    ALTER TABLE ONLY public.discovery_alert_configs
        ADD CONSTRAINT discovery_alert_configs_tenant_id_alert_type_key UNIQUE (tenant_id, alert_type);
  END IF;
END $$;


-- CONSTRAINT: discovery_alert_history discovery_alert_history_pkey
DO $$ BEGIN
  IF to_regclass('public.discovery_alert_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_alert_history_pkey' AND conrelid = to_regclass('public.discovery_alert_history')
     ) THEN
    ALTER TABLE ONLY public.discovery_alert_history
        ADD CONSTRAINT discovery_alert_history_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: discovery_auto_approval_rules discovery_auto_approval_rules_pkey
DO $$ BEGIN
  IF to_regclass('public.discovery_auto_approval_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_auto_approval_rules_pkey' AND conrelid = to_regclass('public.discovery_auto_approval_rules')
     ) THEN
    ALTER TABLE ONLY public.discovery_auto_approval_rules
        ADD CONSTRAINT discovery_auto_approval_rules_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: discovery_findings discovery_findings_pkey
DO $$ BEGIN
  IF to_regclass('public.discovery_findings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_findings_pkey' AND conrelid = to_regclass('public.discovery_findings')
     ) THEN
    ALTER TABLE ONLY public.discovery_findings
        ADD CONSTRAINT discovery_findings_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: discovery_jobs discovery_jobs_pkey
DO $$ BEGIN
  IF to_regclass('public.discovery_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_jobs_pkey' AND conrelid = to_regclass('public.discovery_jobs')
     ) THEN
    ALTER TABLE ONLY public.discovery_jobs
        ADD CONSTRAINT discovery_jobs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: discovery_rate_limits discovery_rate_limits_pkey
DO $$ BEGIN
  IF to_regclass('public.discovery_rate_limits') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_rate_limits_pkey' AND conrelid = to_regclass('public.discovery_rate_limits')
     ) THEN
    ALTER TABLE ONLY public.discovery_rate_limits
        ADD CONSTRAINT discovery_rate_limits_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: discovery_rate_limits discovery_rate_limits_tenant_id_key
DO $$ BEGIN
  IF to_regclass('public.discovery_rate_limits') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_rate_limits_tenant_id_key' AND conrelid = to_regclass('public.discovery_rate_limits')
     ) THEN
    ALTER TABLE ONLY public.discovery_rate_limits
        ADD CONSTRAINT discovery_rate_limits_tenant_id_key UNIQUE (tenant_id);
  END IF;
END $$;


-- CONSTRAINT: discovery_targets discovery_targets_pkey
DO $$ BEGIN
  IF to_regclass('public.discovery_targets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_targets_pkey' AND conrelid = to_regclass('public.discovery_targets')
     ) THEN
    ALTER TABLE ONLY public.discovery_targets
        ADD CONSTRAINT discovery_targets_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: external_asset_mappings external_asset_mappings_pkey
DO $$ BEGIN
  IF to_regclass('public.external_asset_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_asset_mappings_pkey' AND conrelid = to_regclass('public.external_asset_mappings')
     ) THEN
    ALTER TABLE ONLY public.external_asset_mappings
        ADD CONSTRAINT external_asset_mappings_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: external_asset_mappings external_asset_mappings_tenant_id_local_type_local_id_exter_key
DO $$ BEGIN
  IF to_regclass('public.external_asset_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_asset_mappings_tenant_id_local_type_local_id_exter_key' AND conrelid = to_regclass('public.external_asset_mappings')
     ) THEN
    ALTER TABLE ONLY public.external_asset_mappings
        ADD CONSTRAINT external_asset_mappings_tenant_id_local_type_local_id_exter_key UNIQUE (tenant_id, local_type, local_id, external_system);
  END IF;
END $$;


-- CONSTRAINT: external_connection_history external_connection_history_pkey
DO $$ BEGIN
  IF to_regclass('public.external_connection_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_connection_history_pkey' AND conrelid = to_regclass('public.external_connection_history')
     ) THEN
    ALTER TABLE ONLY public.external_connection_history
        ADD CONSTRAINT external_connection_history_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: external_connections external_connections_pkey
DO $$ BEGIN
  IF to_regclass('public.external_connections') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_connections_pkey' AND conrelid = to_regclass('public.external_connections')
     ) THEN
    ALTER TABLE ONLY public.external_connections
        ADD CONSTRAINT external_connections_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: health_alerts health_alerts_pkey
DO $$ BEGIN
  IF to_regclass('public.health_alerts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'health_alerts_pkey' AND conrelid = to_regclass('public.health_alerts')
     ) THEN
    ALTER TABLE ONLY public.health_alerts
        ADD CONSTRAINT health_alerts_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: health_benchmarks health_benchmarks_category_key
DO $$ BEGIN
  IF to_regclass('public.health_benchmarks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'health_benchmarks_category_key' AND conrelid = to_regclass('public.health_benchmarks')
     ) THEN
    ALTER TABLE ONLY public.health_benchmarks
        ADD CONSTRAINT health_benchmarks_category_key UNIQUE (category);
  END IF;
END $$;


-- CONSTRAINT: health_benchmarks health_benchmarks_pkey
DO $$ BEGIN
  IF to_regclass('public.health_benchmarks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'health_benchmarks_pkey' AND conrelid = to_regclass('public.health_benchmarks')
     ) THEN
    ALTER TABLE ONLY public.health_benchmarks
        ADD CONSTRAINT health_benchmarks_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: health_metrics health_metrics_pkey
DO $$ BEGIN
  IF to_regclass('public.health_metrics') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'health_metrics_pkey' AND conrelid = to_regclass('public.health_metrics')
     ) THEN
    ALTER TABLE ONLY public.health_metrics
        ADD CONSTRAINT health_metrics_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: implementation_keys implementation_keys_pkey
DO $$ BEGIN
  IF to_regclass('public.implementation_keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'implementation_keys_pkey' AND conrelid = to_regclass('public.implementation_keys')
     ) THEN
    ALTER TABLE ONLY public.implementation_keys
        ADD CONSTRAINT implementation_keys_pkey PRIMARY KEY (implementation_id, key_id);
  END IF;
END $$;


-- CONSTRAINT: implementation_libraries implementation_libraries_pkey
DO $$ BEGIN
  IF to_regclass('public.implementation_libraries') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'implementation_libraries_pkey' AND conrelid = to_regclass('public.implementation_libraries')
     ) THEN
    ALTER TABLE ONLY public.implementation_libraries
        ADD CONSTRAINT implementation_libraries_pkey PRIMARY KEY (implementation_id, library_id);
  END IF;
END $$;


-- CONSTRAINT: in_app_notifications in_app_notifications_pkey
DO $$ BEGIN
  IF to_regclass('public.in_app_notifications') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'in_app_notifications_pkey' AND conrelid = to_regclass('public.in_app_notifications')
     ) THEN
    ALTER TABLE ONLY public.in_app_notifications
        ADD CONSTRAINT in_app_notifications_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: integrations integrations_pkey
DO $$ BEGIN
  IF to_regclass('public.integrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'integrations_pkey' AND conrelid = to_regclass('public.integrations')
     ) THEN
    ALTER TABLE ONLY public.integrations
        ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: integrations integrations_tenant_id_name_key
DO $$ BEGIN
  IF to_regclass('public.integrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'integrations_tenant_id_name_key' AND conrelid = to_regclass('public.integrations')
     ) THEN
    ALTER TABLE ONLY public.integrations
        ADD CONSTRAINT integrations_tenant_id_name_key UNIQUE (tenant_id, name);
  END IF;
END $$;


-- CONSTRAINT: interrogation_schedules interrogation_schedules_pkey
DO $$ BEGIN
  IF to_regclass('public.interrogation_schedules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'interrogation_schedules_pkey' AND conrelid = to_regclass('public.interrogation_schedules')
     ) THEN
    ALTER TABLE ONLY public.interrogation_schedules
        ADD CONSTRAINT interrogation_schedules_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: keys keys_pkey
DO $$ BEGIN
  IF to_regclass('public.keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'keys_pkey' AND conrelid = to_regclass('public.keys')
     ) THEN
    ALTER TABLE ONLY public.keys
        ADD CONSTRAINT keys_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: kms_keys kms_keys_pkey
DO $$ BEGIN
  IF to_regclass('public.kms_keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'kms_keys_pkey' AND conrelid = to_regclass('public.kms_keys')
     ) THEN
    ALTER TABLE ONLY public.kms_keys
        ADD CONSTRAINT kms_keys_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: library_provided_algorithms library_provided_algorithms_pkey
DO $$ BEGIN
  IF to_regclass('public.library_provided_algorithms') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'library_provided_algorithms_pkey' AND conrelid = to_regclass('public.library_provided_algorithms')
     ) THEN
    ALTER TABLE ONLY public.library_provided_algorithms
        ADD CONSTRAINT library_provided_algorithms_pkey PRIMARY KEY (library_id, algorithm_id);
  END IF;
END $$;


-- CONSTRAINT: locations locations_name_unique_per_parent
DO $$ BEGIN
  IF to_regclass('public.locations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'locations_name_unique_per_parent' AND conrelid = to_regclass('public.locations')
     ) THEN
    ALTER TABLE ONLY public.locations
        ADD CONSTRAINT locations_name_unique_per_parent UNIQUE (tenant_id, parent_id, name);
  END IF;
END $$;


-- CONSTRAINT: locations locations_pkey
DO $$ BEGIN
  IF to_regclass('public.locations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'locations_pkey' AND conrelid = to_regclass('public.locations')
     ) THEN
    ALTER TABLE ONLY public.locations
        ADD CONSTRAINT locations_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: maintenance_windows maintenance_windows_pkey
DO $$ BEGIN
  IF to_regclass('public.maintenance_windows') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'maintenance_windows_pkey' AND conrelid = to_regclass('public.maintenance_windows')
     ) THEN
    ALTER TABLE ONLY public.maintenance_windows
        ADD CONSTRAINT maintenance_windows_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: measurement_templates measurement_templates_code_key
DO $$ BEGIN
  IF to_regclass('public.measurement_templates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'measurement_templates_code_key' AND conrelid = to_regclass('public.measurement_templates')
     ) THEN
    ALTER TABLE ONLY public.measurement_templates
        ADD CONSTRAINT measurement_templates_code_key UNIQUE (code);
  END IF;
END $$;


-- CONSTRAINT: measurement_templates measurement_templates_pkey
DO $$ BEGIN
  IF to_regclass('public.measurement_templates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'measurement_templates_pkey' AND conrelid = to_regclass('public.measurement_templates')
     ) THEN
    ALTER TABLE ONLY public.measurement_templates
        ADD CONSTRAINT measurement_templates_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: measurement_types measurement_types_code_key
DO $$ BEGIN
  IF to_regclass('public.measurement_types') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'measurement_types_code_key' AND conrelid = to_regclass('public.measurement_types')
     ) THEN
    ALTER TABLE ONLY public.measurement_types
        ADD CONSTRAINT measurement_types_code_key UNIQUE (code);
  END IF;
END $$;


-- CONSTRAINT: measurement_types measurement_types_pkey
DO $$ BEGIN
  IF to_regclass('public.measurement_types') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'measurement_types_pkey' AND conrelid = to_regclass('public.measurement_types')
     ) THEN
    ALTER TABLE ONLY public.measurement_types
        ADD CONSTRAINT measurement_types_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: monitoring_alert_history monitoring_alert_history_pkey
DO $$ BEGIN
  IF to_regclass('public.monitoring_alert_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'monitoring_alert_history_pkey' AND conrelid = to_regclass('public.monitoring_alert_history')
     ) THEN
    ALTER TABLE ONLY public.monitoring_alert_history
        ADD CONSTRAINT monitoring_alert_history_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: monitoring_alert_thresholds monitoring_alert_thresholds_pkey
DO $$ BEGIN
  IF to_regclass('public.monitoring_alert_thresholds') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'monitoring_alert_thresholds_pkey' AND conrelid = to_regclass('public.monitoring_alert_thresholds')
     ) THEN
    ALTER TABLE ONLY public.monitoring_alert_thresholds
        ADD CONSTRAINT monitoring_alert_thresholds_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: monitoring_alert_thresholds monitoring_alert_thresholds_threshold_name_key
DO $$ BEGIN
  IF to_regclass('public.monitoring_alert_thresholds') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'monitoring_alert_thresholds_threshold_name_key' AND conrelid = to_regclass('public.monitoring_alert_thresholds')
     ) THEN
    ALTER TABLE ONLY public.monitoring_alert_thresholds
        ADD CONSTRAINT monitoring_alert_thresholds_threshold_name_key UNIQUE (threshold_name);
  END IF;
END $$;


-- CONSTRAINT: monitoring_notification_channels monitoring_notification_channels_channel_name_key
DO $$ BEGIN
  IF to_regclass('public.monitoring_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'monitoring_notification_channels_channel_name_key' AND conrelid = to_regclass('public.monitoring_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.monitoring_notification_channels
        ADD CONSTRAINT monitoring_notification_channels_channel_name_key UNIQUE (channel_name);
  END IF;
END $$;


-- CONSTRAINT: monitoring_notification_channels monitoring_notification_channels_pkey
DO $$ BEGIN
  IF to_regclass('public.monitoring_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'monitoring_notification_channels_pkey' AND conrelid = to_regclass('public.monitoring_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.monitoring_notification_channels
        ADD CONSTRAINT monitoring_notification_channels_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: crypto_implementations_partitioned crypto_implementations_partitioned_pkey
-- HASH partitioned on tenant_id, so the PK must lead with the partition column,
-- and the recursive (non-ONLY) form is required for it to be VALID and usable
-- as an FK target. (`assets` states the same rule inline in its CREATE TABLE;
-- this is the older spelling of it.)
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conrelid = to_regclass('public.crypto_implementations_partitioned')
         AND (contype = 'p' OR conname = 'crypto_implementations_partitioned_pkey')
     ) THEN
    ALTER TABLE public.crypto_implementations_partitioned
        ADD CONSTRAINT crypto_implementations_partitioned_pkey PRIMARY KEY (tenant_id, id);
  END IF;
END $$;


-- CONSTRAINT: sensor_discoveries_partitioned sensor_discoveries_partitioned_pkey
-- The ingest hot path stamps discoveries processed by id; without this the
-- planner could neither use an index nor prune partitions, so every single-row
-- update scanned all eight and batch processing was quadratic in batch size.
-- Guarded on contype = 'p' as well as the name, because adding a second primary
-- key under any name is an error rather than a no-op.
DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conrelid = to_regclass('public.sensor_discoveries_partitioned')
         AND (contype = 'p' OR conname = 'sensor_discoveries_partitioned_pkey')
     ) THEN
    ALTER TABLE public.sensor_discoveries_partitioned
        ADD CONSTRAINT sensor_discoveries_partitioned_pkey PRIMARY KEY (tenant_id, id);
  END IF;
END $$;


-- CONSTRAINT: network_segments network_segments_pkey
DO $$ BEGIN
  IF to_regclass('public.network_segments') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'network_segments_pkey' AND conrelid = to_regclass('public.network_segments')
     ) THEN
    ALTER TABLE ONLY public.network_segments
        ADD CONSTRAINT network_segments_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: network_segments network_segments_value_unique_per_tenant
--
-- DELIBERATELY ABSENT. A table constraint cannot be declared over an
-- expression, and the uniqueness this table needs is
-- (tenant_id, value, coalesce(cloud_network_ref, '')) — see the column comment
-- on `cloud_network_ref`. It is a UNIQUE INDEX in POST-MIGRATIONS instead, and
-- the old constraint is dropped there.
--
-- The ADD CONSTRAINT is removed from this body rather than left beside the
-- drop: a statement that re-adds what POST-MIGRATIONS drops puts the file into
-- a loop where every apply undoes the previous one's shape.


-- CONSTRAINT: notification_delivery_queue notification_delivery_queue_pkey
DO $$ BEGIN
  IF to_regclass('public.notification_delivery_queue') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'notification_delivery_queue_pkey' AND conrelid = to_regclass('public.notification_delivery_queue')
     ) THEN
    ALTER TABLE ONLY public.notification_delivery_queue
        ADD CONSTRAINT notification_delivery_queue_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: notification_history notification_history_pkey
DO $$ BEGIN
  IF to_regclass('public.notification_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'notification_history_pkey' AND conrelid = to_regclass('public.notification_history')
     ) THEN
    ALTER TABLE ONLY public.notification_history
        ADD CONSTRAINT notification_history_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: pcap_upload_jobs pcap_upload_jobs_pkey
DO $$ BEGIN
  IF to_regclass('public.pcap_upload_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'pcap_upload_jobs_pkey' AND conrelid = to_regclass('public.pcap_upload_jobs')
     ) THEN
    ALTER TABLE ONLY public.pcap_upload_jobs
        ADD CONSTRAINT pcap_upload_jobs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: pending_sensor_registrations pending_sensor_registrations_pkey
DO $$ BEGIN
  IF to_regclass('public.pending_sensor_registrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'pending_sensor_registrations_pkey' AND conrelid = to_regclass('public.pending_sensor_registrations')
     ) THEN
    ALTER TABLE ONLY public.pending_sensor_registrations
        ADD CONSTRAINT pending_sensor_registrations_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: pending_sensor_registrations pending_sensor_registrations_registration_key_key
DO $$ BEGIN
  IF to_regclass('public.pending_sensor_registrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'pending_sensor_registrations_registration_key_key' AND conrelid = to_regclass('public.pending_sensor_registrations')
     ) THEN
    ALTER TABLE ONLY public.pending_sensor_registrations
        ADD CONSTRAINT pending_sensor_registrations_registration_key_key UNIQUE (registration_key);
  END IF;
END $$;


-- CONSTRAINT: permission_audit_logs permission_audit_logs_pkey
DO $$ BEGIN
  IF to_regclass('public.permission_audit_logs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'permission_audit_logs_pkey' AND conrelid = to_regclass('public.permission_audit_logs')
     ) THEN
    ALTER TABLE ONLY public.permission_audit_logs
        ADD CONSTRAINT permission_audit_logs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_announcements platform_announcements_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_announcements') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_announcements_pkey' AND conrelid = to_regclass('public.platform_announcements')
     ) THEN
    ALTER TABLE ONLY public.platform_announcements
        ADD CONSTRAINT platform_announcements_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_bootstrap_ca platform_bootstrap_ca_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_bootstrap_ca') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_bootstrap_ca_pkey' AND conrelid = to_regclass('public.platform_bootstrap_ca')
     ) THEN
    ALTER TABLE ONLY public.platform_bootstrap_ca
        ADD CONSTRAINT platform_bootstrap_ca_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_bootstrap_certificates platform_bootstrap_certificates_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_bootstrap_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_bootstrap_certificates_pkey' AND conrelid = to_regclass('public.platform_bootstrap_certificates')
     ) THEN
    ALTER TABLE ONLY public.platform_bootstrap_certificates
        ADD CONSTRAINT platform_bootstrap_certificates_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_framework_controls platform_framework_controls_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_framework_controls') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_framework_controls_pkey' AND conrelid = to_regclass('public.platform_framework_controls')
     ) THEN
    ALTER TABLE ONLY public.platform_framework_controls
        ADD CONSTRAINT platform_framework_controls_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_framework_versions platform_framework_versions_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_framework_versions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_framework_versions_pkey' AND conrelid = to_regclass('public.platform_framework_versions')
     ) THEN
    ALTER TABLE ONLY public.platform_framework_versions
        ADD CONSTRAINT platform_framework_versions_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_frameworks platform_frameworks_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_frameworks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_frameworks_pkey' AND conrelid = to_regclass('public.platform_frameworks')
     ) THEN
    ALTER TABLE ONLY public.platform_frameworks
        ADD CONSTRAINT platform_frameworks_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_integration_audit_log platform_integration_audit_log_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_integration_audit_log') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_integration_audit_log_pkey' AND conrelid = to_regclass('public.platform_integration_audit_log')
     ) THEN
    ALTER TABLE ONLY public.platform_integration_audit_log
        ADD CONSTRAINT platform_integration_audit_log_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_integrations platform_integrations_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_integrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_integrations_pkey' AND conrelid = to_regclass('public.platform_integrations')
     ) THEN
    ALTER TABLE ONLY public.platform_integrations
        ADD CONSTRAINT platform_integrations_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_log_access_audit platform_log_access_audit_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_log_access_audit') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_log_access_audit_pkey' AND conrelid = to_regclass('public.platform_log_access_audit')
     ) THEN
    ALTER TABLE ONLY public.platform_log_access_audit
        ADD CONSTRAINT platform_log_access_audit_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_log_metadata platform_log_metadata_log_id_key
DO $$ BEGIN
  IF to_regclass('public.platform_log_metadata') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_log_metadata_log_id_key' AND conrelid = to_regclass('public.platform_log_metadata')
     ) THEN
    ALTER TABLE ONLY public.platform_log_metadata
        ADD CONSTRAINT platform_log_metadata_log_id_key UNIQUE (log_id);
  END IF;
END $$;


-- CONSTRAINT: platform_log_metadata platform_log_metadata_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_log_metadata') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_log_metadata_pkey' AND conrelid = to_regclass('public.platform_log_metadata')
     ) THEN
    ALTER TABLE ONLY public.platform_log_metadata
        ADD CONSTRAINT platform_log_metadata_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_log_pii_rules platform_log_pii_rules_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_log_pii_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_log_pii_rules_pkey' AND conrelid = to_regclass('public.platform_log_pii_rules')
     ) THEN
    ALTER TABLE ONLY public.platform_log_pii_rules
        ADD CONSTRAINT platform_log_pii_rules_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_log_pii_rules platform_log_pii_rules_rule_name_key
DO $$ BEGIN
  IF to_regclass('public.platform_log_pii_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_log_pii_rules_rule_name_key' AND conrelid = to_regclass('public.platform_log_pii_rules')
     ) THEN
    ALTER TABLE ONLY public.platform_log_pii_rules
        ADD CONSTRAINT platform_log_pii_rules_rule_name_key UNIQUE (rule_name);
  END IF;
END $$;


-- CONSTRAINT: platform_log_retention_jobs platform_log_retention_jobs_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_log_retention_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_log_retention_jobs_pkey' AND conrelid = to_regclass('public.platform_log_retention_jobs')
     ) THEN
    ALTER TABLE ONLY public.platform_log_retention_jobs
        ADD CONSTRAINT platform_log_retention_jobs_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_metrics_snapshots platform_metrics_snapshots_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_metrics_snapshots') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_metrics_snapshots_pkey' AND conrelid = to_regclass('public.platform_metrics_snapshots')
     ) THEN
    ALTER TABLE ONLY public.platform_metrics_snapshots
        ADD CONSTRAINT platform_metrics_snapshots_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_notification_channels platform_notification_channels_channel_name_key
DO $$ BEGIN
  IF to_regclass('public.platform_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_notification_channels_channel_name_key' AND conrelid = to_regclass('public.platform_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.platform_notification_channels
        ADD CONSTRAINT platform_notification_channels_channel_name_key UNIQUE (channel_name);
  END IF;
END $$;


-- CONSTRAINT: platform_notification_channels platform_notification_channels_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_notification_channels_pkey' AND conrelid = to_regclass('public.platform_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.platform_notification_channels
        ADD CONSTRAINT platform_notification_channels_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_notification_rules platform_notification_rules_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_notification_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_notification_rules_pkey' AND conrelid = to_regclass('public.platform_notification_rules')
     ) THEN
    ALTER TABLE ONLY public.platform_notification_rules
        ADD CONSTRAINT platform_notification_rules_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_notification_rules platform_notification_rules_rule_name_key
DO $$ BEGIN
  IF to_regclass('public.platform_notification_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_notification_rules_rule_name_key' AND conrelid = to_regclass('public.platform_notification_rules')
     ) THEN
    ALTER TABLE ONLY public.platform_notification_rules
        ADD CONSTRAINT platform_notification_rules_rule_name_key UNIQUE (rule_name);
  END IF;
END $$;


-- CONSTRAINT: platform_permissions platform_permissions_name_key
DO $$ BEGIN
  IF to_regclass('public.platform_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_permissions_name_key' AND conrelid = to_regclass('public.platform_permissions')
     ) THEN
    ALTER TABLE ONLY public.platform_permissions
        ADD CONSTRAINT platform_permissions_name_key UNIQUE (name);
  END IF;
END $$;


-- CONSTRAINT: platform_permissions platform_permissions_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_permissions_pkey' AND conrelid = to_regclass('public.platform_permissions')
     ) THEN
    ALTER TABLE ONLY public.platform_permissions
        ADD CONSTRAINT platform_permissions_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_refresh_tokens platform_refresh_tokens_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_refresh_tokens') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_refresh_tokens_pkey' AND conrelid = to_regclass('public.platform_refresh_tokens')
     ) THEN
    ALTER TABLE ONLY public.platform_refresh_tokens
        ADD CONSTRAINT platform_refresh_tokens_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_role_permissions platform_role_permissions_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_role_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_role_permissions_pkey' AND conrelid = to_regclass('public.platform_role_permissions')
     ) THEN
    ALTER TABLE ONLY public.platform_role_permissions
        ADD CONSTRAINT platform_role_permissions_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_role_permissions platform_role_permissions_role_id_permission_id_key
DO $$ BEGIN
  IF to_regclass('public.platform_role_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_role_permissions_role_id_permission_id_key' AND conrelid = to_regclass('public.platform_role_permissions')
     ) THEN
    ALTER TABLE ONLY public.platform_role_permissions
        ADD CONSTRAINT platform_role_permissions_role_id_permission_id_key UNIQUE (role_id, permission_id);
  END IF;
END $$;


-- CONSTRAINT: platform_roles platform_roles_name_key
DO $$ BEGIN
  IF to_regclass('public.platform_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_roles_name_key' AND conrelid = to_regclass('public.platform_roles')
     ) THEN
    ALTER TABLE ONLY public.platform_roles
        ADD CONSTRAINT platform_roles_name_key UNIQUE (name);
  END IF;
END $$;


-- CONSTRAINT: platform_roles platform_roles_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_roles_pkey' AND conrelid = to_regclass('public.platform_roles')
     ) THEN
    ALTER TABLE ONLY public.platform_roles
        ADD CONSTRAINT platform_roles_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_service_ca platform_service_ca_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_service_ca') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_service_ca_pkey' AND conrelid = to_regclass('public.platform_service_ca')
     ) THEN
    ALTER TABLE ONLY public.platform_service_ca
        ADD CONSTRAINT platform_service_ca_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_service_certificates platform_service_certificates_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_service_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_service_certificates_pkey' AND conrelid = to_regclass('public.platform_service_certificates')
     ) THEN
    ALTER TABLE ONLY public.platform_service_certificates
        ADD CONSTRAINT platform_service_certificates_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_settings platform_settings_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_settings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_settings_pkey' AND conrelid = to_regclass('public.platform_settings')
     ) THEN
    ALTER TABLE ONLY public.platform_settings
        ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_sso_providers platform_sso_providers_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_sso_providers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_sso_providers_pkey' AND conrelid = to_regclass('public.platform_sso_providers')
     ) THEN
    ALTER TABLE ONLY public.platform_sso_providers
        ADD CONSTRAINT platform_sso_providers_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: platform_users platform_users_email_key
DO $$ BEGIN
  IF to_regclass('public.platform_users') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_users_email_key' AND conrelid = to_regclass('public.platform_users')
     ) THEN
    ALTER TABLE ONLY public.platform_users
        ADD CONSTRAINT platform_users_email_key UNIQUE (email);
  END IF;
END $$;


-- CONSTRAINT: platform_users platform_users_pkey
DO $$ BEGIN
  IF to_regclass('public.platform_users') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_users_pkey' AND conrelid = to_regclass('public.platform_users')
     ) THEN
    ALTER TABLE ONLY public.platform_users
        ADD CONSTRAINT platform_users_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: refresh_tokens refresh_tokens_pkey
DO $$ BEGIN
  IF to_regclass('public.refresh_tokens') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'refresh_tokens_pkey' AND conrelid = to_regclass('public.refresh_tokens')
     ) THEN
    ALTER TABLE ONLY public.refresh_tokens
        ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: remediation_plan_items remediation_plan_items_pkey
DO $$ BEGIN
  IF to_regclass('public.remediation_plan_items') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'remediation_plan_items_pkey' AND conrelid = to_regclass('public.remediation_plan_items')
     ) THEN
    ALTER TABLE ONLY public.remediation_plan_items
        ADD CONSTRAINT remediation_plan_items_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: remediation_plans remediation_plans_pkey
DO $$ BEGIN
  IF to_regclass('public.remediation_plans') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'remediation_plans_pkey' AND conrelid = to_regclass('public.remediation_plans')
     ) THEN
    ALTER TABLE ONLY public.remediation_plans
        ADD CONSTRAINT remediation_plans_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: resource_alerts resource_alerts_pkey
DO $$ BEGIN
  IF to_regclass('public.resource_alerts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'resource_alerts_pkey' AND conrelid = to_regclass('public.resource_alerts')
     ) THEN
    ALTER TABLE ONLY public.resource_alerts
        ADD CONSTRAINT resource_alerts_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: rule_vulnerability_mappings rule_vulnerability_mappings_pkey
DO $$ BEGIN
  IF to_regclass('public.rule_vulnerability_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'rule_vulnerability_mappings_pkey' AND conrelid = to_regclass('public.rule_vulnerability_mappings')
     ) THEN
    ALTER TABLE ONLY public.rule_vulnerability_mappings
        ADD CONSTRAINT rule_vulnerability_mappings_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: schedule_history schedule_history_pkey
DO $$ BEGIN
  IF to_regclass('public.schedule_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'schedule_history_pkey' AND conrelid = to_regclass('public.schedule_history')
     ) THEN
    ALTER TABLE ONLY public.schedule_history
        ADD CONSTRAINT schedule_history_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: security_incident_webhook_deliveries security_incident_webhook_deliveries_pkey
DO $$ BEGIN
  IF to_regclass('public.security_incident_webhook_deliveries') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'security_incident_webhook_deliveries_pkey' AND conrelid = to_regclass('public.security_incident_webhook_deliveries')
     ) THEN
    ALTER TABLE ONLY public.security_incident_webhook_deliveries
        ADD CONSTRAINT security_incident_webhook_deliveries_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: security_incident_webhooks security_incident_webhooks_pkey
DO $$ BEGIN
  IF to_regclass('public.security_incident_webhooks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'security_incident_webhooks_pkey' AND conrelid = to_regclass('public.security_incident_webhooks')
     ) THEN
    ALTER TABLE ONLY public.security_incident_webhooks
        ADD CONSTRAINT security_incident_webhooks_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: security_incidents security_incidents_incident_id_key
DO $$ BEGIN
  IF to_regclass('public.security_incidents') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'security_incidents_incident_id_key' AND conrelid = to_regclass('public.security_incidents')
     ) THEN
    ALTER TABLE ONLY public.security_incidents
        ADD CONSTRAINT security_incidents_incident_id_key UNIQUE (incident_id);
  END IF;
END $$;


-- CONSTRAINT: security_incidents security_incidents_pkey
DO $$ BEGIN
  IF to_regclass('public.security_incidents') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'security_incidents_pkey' AND conrelid = to_regclass('public.security_incidents')
     ) THEN
    ALTER TABLE ONLY public.security_incidents
        ADD CONSTRAINT security_incidents_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: sensor_ca_certificates sensor_ca_certificates_pkey
DO $$ BEGIN
  IF to_regclass('public.sensor_ca_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_ca_certificates_pkey' AND conrelid = to_regclass('public.sensor_ca_certificates')
     ) THEN
    ALTER TABLE ONLY public.sensor_ca_certificates
        ADD CONSTRAINT sensor_ca_certificates_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: sensor_certificates sensor_certificates_pkey
DO $$ BEGIN
  IF to_regclass('public.sensor_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_certificates_pkey' AND conrelid = to_regclass('public.sensor_certificates')
     ) THEN
    ALTER TABLE ONLY public.sensor_certificates
        ADD CONSTRAINT sensor_certificates_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: sensor_commands sensor_commands_pkey
DO $$ BEGIN
  IF to_regclass('public.sensor_commands') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_commands_pkey' AND conrelid = to_regclass('public.sensor_commands')
     ) THEN
    ALTER TABLE ONLY public.sensor_commands
        ADD CONSTRAINT sensor_commands_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: sensor_health_metrics sensor_health_metrics_pkey
DO $$ BEGIN
  IF to_regclass('public.sensor_health_metrics') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_health_metrics_pkey' AND conrelid = to_regclass('public.sensor_health_metrics')
     ) THEN
    ALTER TABLE ONLY public.sensor_health_metrics
        ADD CONSTRAINT sensor_health_metrics_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: sensors sensors_pkey
DO $$ BEGIN
  IF to_regclass('public.sensors') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensors_pkey' AND conrelid = to_regclass('public.sensors')
     ) THEN
    ALTER TABLE ONLY public.sensors
        ADD CONSTRAINT sensors_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: service_accounts service_accounts_pkey
DO $$ BEGIN
  IF to_regclass('public.service_accounts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'service_accounts_pkey' AND conrelid = to_regclass('public.service_accounts')
     ) THEN
    ALTER TABLE ONLY public.service_accounts
        ADD CONSTRAINT service_accounts_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: service_accounts service_accounts_service_name_key
DO $$ BEGIN
  IF to_regclass('public.service_accounts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'service_accounts_service_name_key' AND conrelid = to_regclass('public.service_accounts')
     ) THEN
    ALTER TABLE ONLY public.service_accounts
        ADD CONSTRAINT service_accounts_service_name_key UNIQUE (service_name);
  END IF;
END $$;


-- CONSTRAINT: service_health_events service_health_events_pkey
DO $$ BEGIN
  IF to_regclass('public.service_health_events') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'service_health_events_pkey' AND conrelid = to_regclass('public.service_health_events')
     ) THEN
    ALTER TABLE ONLY public.service_health_events
        ADD CONSTRAINT service_health_events_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: service_identification_rules service_identification_rules_pkey
DO $$ BEGIN
  IF to_regclass('public.service_identification_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'service_identification_rules_pkey' AND conrelid = to_regclass('public.service_identification_rules')
     ) THEN
    ALTER TABLE ONLY public.service_identification_rules
        ADD CONSTRAINT service_identification_rules_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_framework_licenses single_default_per_tenant
DO $$ BEGIN
  IF to_regclass('public.tenant_framework_licenses') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'single_default_per_tenant' AND conrelid = to_regclass('public.tenant_framework_licenses')
     ) THEN
    ALTER TABLE ONLY public.tenant_framework_licenses
        ADD CONSTRAINT single_default_per_tenant EXCLUDE USING btree (tenant_id WITH =) WHERE ((is_default = true));
  END IF;
END $$;


-- CONSTRAINT: ssh_keys ssh_keys_pkey
DO $$ BEGIN
  IF to_regclass('public.ssh_keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ssh_keys_pkey' AND conrelid = to_regclass('public.ssh_keys')
     ) THEN
    ALTER TABLE ONLY public.ssh_keys
        ADD CONSTRAINT ssh_keys_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: sso_group_role_mappings sso_group_role_mappings_pkey
DO $$ BEGIN
  IF to_regclass('public.sso_group_role_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sso_group_role_mappings_pkey' AND conrelid = to_regclass('public.sso_group_role_mappings')
     ) THEN
    ALTER TABLE ONLY public.sso_group_role_mappings
        ADD CONSTRAINT sso_group_role_mappings_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: sso_providers sso_providers_pkey
DO $$ BEGIN
  IF to_regclass('public.sso_providers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sso_providers_pkey' AND conrelid = to_regclass('public.sso_providers')
     ) THEN
    ALTER TABLE ONLY public.sso_providers
        ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: subscription_tier_history subscription_tier_history_pkey
DO $$ BEGIN
  IF to_regclass('public.subscription_tier_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'subscription_tier_history_pkey' AND conrelid = to_regclass('public.subscription_tier_history')
     ) THEN
    ALTER TABLE ONLY public.subscription_tier_history
        ADD CONSTRAINT subscription_tier_history_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: subscription_tiers subscription_tiers_name_key
DO $$ BEGIN
  IF to_regclass('public.subscription_tiers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'subscription_tiers_name_key' AND conrelid = to_regclass('public.subscription_tiers')
     ) THEN
    ALTER TABLE ONLY public.subscription_tiers
        ADD CONSTRAINT subscription_tiers_name_key UNIQUE (name);
  END IF;
END $$;


-- CONSTRAINT: subscription_tiers subscription_tiers_pkey
DO $$ BEGIN
  IF to_regclass('public.subscription_tiers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'subscription_tiers_pkey' AND conrelid = to_regclass('public.subscription_tiers')
     ) THEN
    ALTER TABLE ONLY public.subscription_tiers
        ADD CONSTRAINT subscription_tiers_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: support_ticket_messages support_ticket_messages_pkey
DO $$ BEGIN
  IF to_regclass('public.support_ticket_messages') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'support_ticket_messages_pkey' AND conrelid = to_regclass('public.support_ticket_messages')
     ) THEN
    ALTER TABLE ONLY public.support_ticket_messages
        ADD CONSTRAINT support_ticket_messages_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: support_tickets support_tickets_pkey
DO $$ BEGIN
  IF to_regclass('public.support_tickets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'support_tickets_pkey' AND conrelid = to_regclass('public.support_tickets')
     ) THEN
    ALTER TABLE ONLY public.support_tickets
        ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_admin_settings_audit tenant_admin_settings_audit_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_admin_settings_audit') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_admin_settings_audit_pkey' AND conrelid = to_regclass('public.tenant_admin_settings_audit')
     ) THEN
    ALTER TABLE ONLY public.tenant_admin_settings_audit
        ADD CONSTRAINT tenant_admin_settings_audit_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_framework_controls tenant_framework_controls_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_framework_controls') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_framework_controls_pkey' AND conrelid = to_regclass('public.tenant_framework_controls')
     ) THEN
    ALTER TABLE ONLY public.tenant_framework_controls
        ADD CONSTRAINT tenant_framework_controls_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_framework_licenses tenant_framework_licenses_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_framework_licenses') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_framework_licenses_pkey' AND conrelid = to_regclass('public.tenant_framework_licenses')
     ) THEN
    ALTER TABLE ONLY public.tenant_framework_licenses
        ADD CONSTRAINT tenant_framework_licenses_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_frameworks tenant_frameworks_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_frameworks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_frameworks_pkey' AND conrelid = to_regclass('public.tenant_frameworks')
     ) THEN
    ALTER TABLE ONLY public.tenant_frameworks
        ADD CONSTRAINT tenant_frameworks_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_geographic_data tenant_geographic_data_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_geographic_data') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_geographic_data_pkey' AND conrelid = to_regclass('public.tenant_geographic_data')
     ) THEN
    ALTER TABLE ONLY public.tenant_geographic_data
        ADD CONSTRAINT tenant_geographic_data_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_health tenant_health_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_health') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_health_pkey' AND conrelid = to_regclass('public.tenant_health')
     ) THEN
    ALTER TABLE ONLY public.tenant_health
        ADD CONSTRAINT tenant_health_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_health tenant_health_tenant_id_key
DO $$ BEGIN
  IF to_regclass('public.tenant_health') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_health_tenant_id_key' AND conrelid = to_regclass('public.tenant_health')
     ) THEN
    ALTER TABLE ONLY public.tenant_health
        ADD CONSTRAINT tenant_health_tenant_id_key UNIQUE (tenant_id);
  END IF;
END $$;


-- CONSTRAINT: tenant_measurement_overrides tenant_measurement_overrides_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_measurement_overrides') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_measurement_overrides_pkey' AND conrelid = to_regclass('public.tenant_measurement_overrides')
     ) THEN
    ALTER TABLE ONLY public.tenant_measurement_overrides
        ADD CONSTRAINT tenant_measurement_overrides_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_notes tenant_notes_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_notes') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_notes_pkey' AND conrelid = to_regclass('public.tenant_notes')
     ) THEN
    ALTER TABLE ONLY public.tenant_notes
        ADD CONSTRAINT tenant_notes_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_notification_channels tenant_notification_channels_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_notification_channels_pkey' AND conrelid = to_regclass('public.tenant_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.tenant_notification_channels
        ADD CONSTRAINT tenant_notification_channels_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_notification_channels tenant_notification_channels_tenant_id_channel_name_key
DO $$ BEGIN
  IF to_regclass('public.tenant_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_notification_channels_tenant_id_channel_name_key' AND conrelid = to_regclass('public.tenant_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.tenant_notification_channels
        ADD CONSTRAINT tenant_notification_channels_tenant_id_channel_name_key UNIQUE (tenant_id, channel_name);
  END IF;
END $$;


-- CONSTRAINT: tenant_notification_rules tenant_notification_rules_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_notification_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_notification_rules_pkey' AND conrelid = to_regclass('public.tenant_notification_rules')
     ) THEN
    ALTER TABLE ONLY public.tenant_notification_rules
        ADD CONSTRAINT tenant_notification_rules_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_notification_rules tenant_notification_rules_tenant_id_rule_name_key
DO $$ BEGIN
  IF to_regclass('public.tenant_notification_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_notification_rules_tenant_id_rule_name_key' AND conrelid = to_regclass('public.tenant_notification_rules')
     ) THEN
    ALTER TABLE ONLY public.tenant_notification_rules
        ADD CONSTRAINT tenant_notification_rules_tenant_id_rule_name_key UNIQUE (tenant_id, rule_name);
  END IF;
END $$;


-- CONSTRAINT: tenant_permissions tenant_permissions_name_key
DO $$ BEGIN
  IF to_regclass('public.tenant_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_permissions_name_key' AND conrelid = to_regclass('public.tenant_permissions')
     ) THEN
    ALTER TABLE ONLY public.tenant_permissions
        ADD CONSTRAINT tenant_permissions_name_key UNIQUE (name);
  END IF;
END $$;


-- CONSTRAINT: tenant_permissions tenant_permissions_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_permissions_pkey' AND conrelid = to_regclass('public.tenant_permissions')
     ) THEN
    ALTER TABLE ONLY public.tenant_permissions
        ADD CONSTRAINT tenant_permissions_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_resource_usage tenant_resource_usage_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_resource_usage') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_resource_usage_pkey' AND conrelid = to_regclass('public.tenant_resource_usage')
     ) THEN
    ALTER TABLE ONLY public.tenant_resource_usage
        ADD CONSTRAINT tenant_resource_usage_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_role_permissions tenant_role_permissions_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_role_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_role_permissions_pkey' AND conrelid = to_regclass('public.tenant_role_permissions')
     ) THEN
    ALTER TABLE ONLY public.tenant_role_permissions
        ADD CONSTRAINT tenant_role_permissions_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_role_permissions tenant_role_permissions_role_id_permission_id_key
DO $$ BEGIN
  IF to_regclass('public.tenant_role_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_role_permissions_role_id_permission_id_key' AND conrelid = to_regclass('public.tenant_role_permissions')
     ) THEN
    ALTER TABLE ONLY public.tenant_role_permissions
        ADD CONSTRAINT tenant_role_permissions_role_id_permission_id_key UNIQUE (role_id, permission_id);
  END IF;
END $$;


-- CONSTRAINT: tenant_roles tenant_roles_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_roles_pkey' AND conrelid = to_regclass('public.tenant_roles')
     ) THEN
    ALTER TABLE ONLY public.tenant_roles
        ADD CONSTRAINT tenant_roles_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenant_roles tenant_roles_tenant_id_name_key
DO $$ BEGIN
  IF to_regclass('public.tenant_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_roles_tenant_id_name_key' AND conrelid = to_regclass('public.tenant_roles')
     ) THEN
    ALTER TABLE ONLY public.tenant_roles
        ADD CONSTRAINT tenant_roles_tenant_id_name_key UNIQUE (tenant_id, name);
  END IF;
END $$;


-- CONSTRAINT: tenant_usage tenant_usage_pkey
DO $$ BEGIN
  IF to_regclass('public.tenant_usage') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_usage_pkey' AND conrelid = to_regclass('public.tenant_usage')
     ) THEN
    ALTER TABLE ONLY public.tenant_usage
        ADD CONSTRAINT tenant_usage_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenants tenants_pkey
DO $$ BEGIN
  IF to_regclass('public.tenants') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenants_pkey' AND conrelid = to_regclass('public.tenants')
     ) THEN
    ALTER TABLE ONLY public.tenants
        ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tenants tenants_slug_key
DO $$ BEGIN
  IF to_regclass('public.tenants') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenants_slug_key' AND conrelid = to_regclass('public.tenants')
     ) THEN
    ALTER TABLE ONLY public.tenants
        ADD CONSTRAINT tenants_slug_key UNIQUE (slug);
  END IF;
END $$;


-- CONSTRAINT: ticket_comments ticket_comments_pkey
DO $$ BEGIN
  IF to_regclass('public.ticket_comments') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ticket_comments_pkey' AND conrelid = to_regclass('public.ticket_comments')
     ) THEN
    ALTER TABLE ONLY public.ticket_comments
        ADD CONSTRAINT ticket_comments_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: tickets tickets_pkey
DO $$ BEGIN
  IF to_regclass('public.tickets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tickets_pkey' AND conrelid = to_regclass('public.tickets')
     ) THEN
    ALTER TABLE ONLY public.tickets
        ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: ui_themes ui_themes_name_key
DO $$ BEGIN
  IF to_regclass('public.ui_themes') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ui_themes_name_key' AND conrelid = to_regclass('public.ui_themes')
     ) THEN
    ALTER TABLE ONLY public.ui_themes
        ADD CONSTRAINT ui_themes_name_key UNIQUE (name);
  END IF;
END $$;


-- CONSTRAINT: ui_themes ui_themes_pkey
DO $$ BEGIN
  IF to_regclass('public.ui_themes') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ui_themes_pkey' AND conrelid = to_regclass('public.ui_themes')
     ) THEN
    ALTER TABLE ONLY public.ui_themes
        ADD CONSTRAINT ui_themes_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: agent_certificates unique_agent_serial
DO $$ BEGIN
  IF to_regclass('public.agent_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_agent_serial' AND conrelid = to_regclass('public.agent_certificates')
     ) THEN
    ALTER TABLE ONLY public.agent_certificates
        ADD CONSTRAINT unique_agent_serial UNIQUE (agent_id, serial_number);
  END IF;
END $$;


-- CONSTRAINT: cmdb_entity_mappings unique_cmdb_entity_mapping
DO $$ BEGIN
  IF to_regclass('public.cmdb_entity_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_cmdb_entity_mapping' AND conrelid = to_regclass('public.cmdb_entity_mappings')
     ) THEN
    ALTER TABLE ONLY public.cmdb_entity_mappings
        ADD CONSTRAINT unique_cmdb_entity_mapping UNIQUE (tenant_id, profile_id, local_entity_type, local_entity_id);
  END IF;
END $$;


-- CONSTRAINT: cmdb_sync_profiles unique_cmdb_profile_name
DO $$ BEGIN
  IF to_regclass('public.cmdb_sync_profiles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_cmdb_profile_name' AND conrelid = to_regclass('public.cmdb_sync_profiles')
     ) THEN
    ALTER TABLE ONLY public.cmdb_sync_profiles
        ADD CONSTRAINT unique_cmdb_profile_name UNIQUE (tenant_id, name);
  END IF;
END $$;


-- CONSTRAINT: certificates unique_fingerprint_per_tenant
DO $$ BEGIN
  IF to_regclass('public.certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_fingerprint_per_tenant' AND conrelid = to_regclass('public.certificates')
     ) THEN
    ALTER TABLE ONLY public.certificates
        ADD CONSTRAINT unique_fingerprint_per_tenant UNIQUE (tenant_id, fingerprint_sha256);
  END IF;
END $$;


-- CONSTRAINT: crypto_implementation_algorithms unique_impl_algorithm
DO $$ BEGIN
  IF to_regclass('public.crypto_implementation_algorithms') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_impl_algorithm' AND conrelid = to_regclass('public.crypto_implementation_algorithms')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementation_algorithms
        ADD CONSTRAINT unique_impl_algorithm UNIQUE (crypto_implementation_id, algorithm_id, algorithm_type);
  END IF;
END $$;


-- CONSTRAINT: crypto_implementation_certificates unique_impl_cert
DO $$ BEGIN
  IF to_regclass('public.crypto_implementation_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_impl_cert' AND conrelid = to_regclass('public.crypto_implementation_certificates')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementation_certificates
        ADD CONSTRAINT unique_impl_cert UNIQUE (crypto_implementation_id, certificate_id);
  END IF;
END $$;


-- CONSTRAINT: remediation_plan_items unique_plan_finding
DO $$ BEGIN
  IF to_regclass('public.remediation_plan_items') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_plan_finding' AND conrelid = to_regclass('public.remediation_plan_items')
     ) THEN
    ALTER TABLE ONLY public.remediation_plan_items
        ADD CONSTRAINT unique_plan_finding UNIQUE (plan_id, finding_id);
  END IF;
END $$;


-- CONSTRAINT: platform_framework_controls unique_platform_control_per_framework
DO $$ BEGIN
  IF to_regclass('public.platform_framework_controls') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_platform_control_per_framework' AND conrelid = to_regclass('public.platform_framework_controls')
     ) THEN
    ALTER TABLE ONLY public.platform_framework_controls
        ADD CONSTRAINT unique_platform_control_per_framework UNIQUE (framework_id, control_id);
  END IF;
END $$;


-- CONSTRAINT: platform_frameworks unique_platform_framework_code_version
DO $$ BEGIN
  IF to_regclass('public.platform_frameworks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_platform_framework_code_version' AND conrelid = to_regclass('public.platform_frameworks')
     ) THEN
    ALTER TABLE ONLY public.platform_frameworks
        ADD CONSTRAINT unique_platform_framework_code_version UNIQUE (code, version);
  END IF;
END $$;


-- CONSTRAINT: platform_refresh_tokens unique_platform_token_hash
DO $$ BEGIN
  IF to_regclass('public.platform_refresh_tokens') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_platform_token_hash' AND conrelid = to_regclass('public.platform_refresh_tokens')
     ) THEN
    ALTER TABLE ONLY public.platform_refresh_tokens
        ADD CONSTRAINT unique_platform_token_hash UNIQUE (token_hash);
  END IF;
END $$;


-- CONSTRAINT: sso_group_role_mappings unique_provider_group
DO $$ BEGIN
  IF to_regclass('public.sso_group_role_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_provider_group' AND conrelid = to_regclass('public.sso_group_role_mappings')
     ) THEN
    ALTER TABLE ONLY public.sso_group_role_mappings
        ADD CONSTRAINT unique_provider_group UNIQUE (sso_provider_id, external_group_name);
  END IF;
END $$;


-- CONSTRAINT: sensor_certificates unique_sensor_serial
DO $$ BEGIN
  IF to_regclass('public.sensor_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_sensor_serial' AND conrelid = to_regclass('public.sensor_certificates')
     ) THEN
    ALTER TABLE ONLY public.sensor_certificates
        ADD CONSTRAINT unique_sensor_serial UNIQUE (sensor_id, serial_number);
  END IF;
END $$;


-- CONSTRAINT: platform_bootstrap_certificates unique_service_name
DO $$ BEGIN
  IF to_regclass('public.platform_bootstrap_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_service_name' AND conrelid = to_regclass('public.platform_bootstrap_certificates')
     ) THEN
    ALTER TABLE ONLY public.platform_bootstrap_certificates
        ADD CONSTRAINT unique_service_name UNIQUE (service_name);
  END IF;
END $$;


-- CONSTRAINT: platform_service_certificates unique_service_name_cert
DO $$ BEGIN
  IF to_regclass('public.platform_service_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_service_name_cert' AND conrelid = to_regclass('public.platform_service_certificates')
     ) THEN
    ALTER TABLE ONLY public.platform_service_certificates
        ADD CONSTRAINT unique_service_name_cert UNIQUE (service_name);
  END IF;
END $$;


-- CONSTRAINT: platform_settings unique_setting_key
DO $$ BEGIN
  IF to_regclass('public.platform_settings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_setting_key' AND conrelid = to_regclass('public.platform_settings')
     ) THEN
    ALTER TABLE ONLY public.platform_settings
        ADD CONSTRAINT unique_setting_key UNIQUE (setting_key);
  END IF;
END $$;


-- CONSTRAINT: tenant_framework_controls unique_tenant_control_per_framework
DO $$ BEGIN
  IF to_regclass('public.tenant_framework_controls') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_tenant_control_per_framework' AND conrelid = to_regclass('public.tenant_framework_controls')
     ) THEN
    ALTER TABLE ONLY public.tenant_framework_controls
        ADD CONSTRAINT unique_tenant_control_per_framework UNIQUE (framework_id, control_id);
  END IF;
END $$;


-- CONSTRAINT: users unique_tenant_email
DO $$ BEGIN
  IF to_regclass('public.users') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_tenant_email' AND conrelid = to_regclass('public.users')
     ) THEN
    ALTER TABLE ONLY public.users
        ADD CONSTRAINT unique_tenant_email UNIQUE (tenant_id, email);
  END IF;
END $$;


-- CONSTRAINT: tenant_framework_licenses unique_tenant_framework_license
DO $$ BEGIN
  IF to_regclass('public.tenant_framework_licenses') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_tenant_framework_license' AND conrelid = to_regclass('public.tenant_framework_licenses')
     ) THEN
    ALTER TABLE ONLY public.tenant_framework_licenses
        ADD CONSTRAINT unique_tenant_framework_license UNIQUE (tenant_id, platform_framework_id);
  END IF;
END $$;


-- CONSTRAINT: tenant_frameworks unique_tenant_framework_name_version
DO $$ BEGIN
  IF to_regclass('public.tenant_frameworks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_tenant_framework_name_version' AND conrelid = to_regclass('public.tenant_frameworks')
     ) THEN
    ALTER TABLE ONLY public.tenant_frameworks
        ADD CONSTRAINT unique_tenant_framework_name_version UNIQUE (tenant_id, name, version);
  END IF;
END $$;


-- CONSTRAINT: tenant_measurement_overrides unique_tenant_measurement_override
DO $$ BEGIN
  IF to_regclass('public.tenant_measurement_overrides') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_tenant_measurement_override' AND conrelid = to_regclass('public.tenant_measurement_overrides')
     ) THEN
    ALTER TABLE ONLY public.tenant_measurement_overrides
        ADD CONSTRAINT unique_tenant_measurement_override UNIQUE (tenant_id, control_measurement_id);
  END IF;
END $$;


-- CONSTRAINT: tenant_usage unique_tenant_period
DO $$ BEGIN
  IF to_regclass('public.tenant_usage') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_tenant_period' AND conrelid = to_regclass('public.tenant_usage')
     ) THEN
    ALTER TABLE ONLY public.tenant_usage
        ADD CONSTRAINT unique_tenant_period UNIQUE (tenant_id, billing_period_start);
  END IF;
END $$;


-- CONSTRAINT: sso_providers unique_tenant_provider
DO $$ BEGIN
  IF to_regclass('public.sso_providers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_tenant_provider' AND conrelid = to_regclass('public.sso_providers')
     ) THEN
    ALTER TABLE ONLY public.sso_providers
        ADD CONSTRAINT unique_tenant_provider UNIQUE (tenant_id, provider_type, provider_name);
  END IF;
END $$;


-- CONSTRAINT: tenant_admin_settings unique_tenant_settings
DO $$ BEGIN
  IF to_regclass('public.tenant_admin_settings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_tenant_settings' AND conrelid = to_regclass('public.tenant_admin_settings')
     ) THEN
    ALTER TABLE ONLY public.tenant_admin_settings
        ADD CONSTRAINT unique_tenant_settings PRIMARY KEY (tenant_id);
  END IF;
END $$;


-- CONSTRAINT: workflow_configurations unique_tenant_workflow
DO $$ BEGIN
  IF to_regclass('public.workflow_configurations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_tenant_workflow' AND conrelid = to_regclass('public.workflow_configurations')
     ) THEN
    ALTER TABLE ONLY public.workflow_configurations
        ADD CONSTRAINT unique_tenant_workflow UNIQUE (tenant_id, workflow_type, workflow_name);
  END IF;
END $$;


-- CONSTRAINT: refresh_tokens unique_token_hash
DO $$ BEGIN
  IF to_regclass('public.refresh_tokens') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_token_hash' AND conrelid = to_regclass('public.refresh_tokens')
     ) THEN
    ALTER TABLE ONLY public.refresh_tokens
        ADD CONSTRAINT unique_token_hash UNIQUE (token_hash);
  END IF;
END $$;


-- CONSTRAINT: user_auth_methods unique_user_auth_type
DO $$ BEGIN
  IF to_regclass('public.user_auth_methods') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_user_auth_type' AND conrelid = to_regclass('public.user_auth_methods')
     ) THEN
    ALTER TABLE ONLY public.user_auth_methods
        ADD CONSTRAINT unique_user_auth_type UNIQUE (user_id, auth_type, sso_provider_id);
  END IF;
END $$;


-- CONSTRAINT: user_framework_preferences unique_user_framework_preference
DO $$ BEGIN
  IF to_regclass('public.user_framework_preferences') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_user_framework_preference' AND conrelid = to_regclass('public.user_framework_preferences')
     ) THEN
    ALTER TABLE ONLY public.user_framework_preferences
        ADD CONSTRAINT unique_user_framework_preference UNIQUE (user_id, tenant_id);
  END IF;
END $$;


-- CONSTRAINT: user_workflow_progress unique_user_workflow
DO $$ BEGIN
  IF to_regclass('public.user_workflow_progress') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'unique_user_workflow' AND conrelid = to_regclass('public.user_workflow_progress')
     ) THEN
    ALTER TABLE ONLY public.user_workflow_progress
        ADD CONSTRAINT unique_user_workflow UNIQUE (user_id, workflow_configuration_id);
  END IF;
END $$;


-- CONSTRAINT: external_connections uq_external_connection
DO $$ BEGIN
  IF to_regclass('public.external_connections') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'uq_external_connection' AND conrelid = to_regclass('public.external_connections')
     ) THEN
    ALTER TABLE ONLY public.external_connections
        ADD CONSTRAINT uq_external_connection UNIQUE (tenant_id, source_ip, dest_ip, dest_port, protocol);
  END IF;
END $$;


-- CONSTRAINT: user_auth_methods user_auth_methods_pkey
DO $$ BEGIN
  IF to_regclass('public.user_auth_methods') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_auth_methods_pkey' AND conrelid = to_regclass('public.user_auth_methods')
     ) THEN
    ALTER TABLE ONLY public.user_auth_methods
        ADD CONSTRAINT user_auth_methods_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: user_framework_preferences user_framework_preferences_pkey
DO $$ BEGIN
  IF to_regclass('public.user_framework_preferences') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_framework_preferences_pkey' AND conrelid = to_regclass('public.user_framework_preferences')
     ) THEN
    ALTER TABLE ONLY public.user_framework_preferences
        ADD CONSTRAINT user_framework_preferences_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: user_tenant_roles user_tenant_roles_pkey
DO $$ BEGIN
  IF to_regclass('public.user_tenant_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_tenant_roles_pkey' AND conrelid = to_regclass('public.user_tenant_roles')
     ) THEN
    ALTER TABLE ONLY public.user_tenant_roles
        ADD CONSTRAINT user_tenant_roles_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: user_tenant_roles user_tenant_roles_user_id_tenant_id_role_id_key
DO $$ BEGIN
  IF to_regclass('public.user_tenant_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_tenant_roles_user_id_tenant_id_role_id_key' AND conrelid = to_regclass('public.user_tenant_roles')
     ) THEN
    ALTER TABLE ONLY public.user_tenant_roles
        ADD CONSTRAINT user_tenant_roles_user_id_tenant_id_role_id_key UNIQUE (user_id, tenant_id, role_id);
  END IF;
END $$;


-- CONSTRAINT: user_workflow_progress user_workflow_progress_pkey
DO $$ BEGIN
  IF to_regclass('public.user_workflow_progress') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_workflow_progress_pkey' AND conrelid = to_regclass('public.user_workflow_progress')
     ) THEN
    ALTER TABLE ONLY public.user_workflow_progress
        ADD CONSTRAINT user_workflow_progress_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: users users_pkey
DO $$ BEGIN
  IF to_regclass('public.users') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'users_pkey' AND conrelid = to_regclass('public.users')
     ) THEN
    ALTER TABLE ONLY public.users
        ADD CONSTRAINT users_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- CONSTRAINT: workflow_configurations workflow_configurations_pkey
DO $$ BEGIN
  IF to_regclass('public.workflow_configurations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'workflow_configurations_pkey' AND conrelid = to_regclass('public.workflow_configurations')
     ) THEN
    ALTER TABLE ONLY public.workflow_configurations
        ADD CONSTRAINT workflow_configurations_pkey PRIMARY KEY (id);
  END IF;
END $$;


-- INDEX: idx_activity_logs_action
CREATE INDEX IF NOT EXISTS idx_activity_logs_action ON ONLY audit.activity_logs USING btree (action, occurred_at DESC);


-- INDEX: activity_logs_y2026m04_action_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_action_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (action, occurred_at DESC);


-- INDEX: idx_activity_logs_compliance
CREATE INDEX IF NOT EXISTS idx_activity_logs_compliance ON ONLY audit.activity_logs USING gin (compliance_tags);


-- INDEX: activity_logs_y2026m04_compliance_tags_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_compliance_tags_idx ON audit.activity_logs_y2026m04 USING gin (compliance_tags);


-- INDEX: idx_activity_logs_category
CREATE INDEX IF NOT EXISTS idx_activity_logs_category ON ONLY audit.activity_logs USING btree (event_category, occurred_at DESC);


-- INDEX: activity_logs_y2026m04_event_category_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_event_category_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (event_category, occurred_at DESC);


-- INDEX: idx_activity_logs_event_type
CREATE INDEX IF NOT EXISTS idx_activity_logs_event_type ON ONLY audit.activity_logs USING btree (event_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m04_event_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_event_type_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (event_type, occurred_at DESC);


-- INDEX: idx_activity_logs_occurred_at
CREATE INDEX IF NOT EXISTS idx_activity_logs_occurred_at ON ONLY audit.activity_logs USING btree (occurred_at DESC);


-- INDEX: activity_logs_y2026m04_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (occurred_at DESC);


-- INDEX: idx_activity_logs_request_id
CREATE INDEX IF NOT EXISTS idx_activity_logs_request_id ON ONLY audit.activity_logs USING btree (request_id, occurred_at DESC) WHERE (request_id IS NOT NULL);


-- INDEX: activity_logs_y2026m04_request_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_request_id_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (request_id, occurred_at DESC) WHERE (request_id IS NOT NULL);


-- INDEX: idx_activity_logs_requires_attention
CREATE INDEX IF NOT EXISTS idx_activity_logs_requires_attention ON ONLY audit.activity_logs USING btree (requires_attention, occurred_at DESC) WHERE (requires_attention = true);


-- INDEX: activity_logs_y2026m04_requires_attention_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_requires_attention_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (requires_attention, occurred_at DESC) WHERE (requires_attention = true);


-- INDEX: idx_activity_logs_resource
CREATE INDEX IF NOT EXISTS idx_activity_logs_resource ON ONLY audit.activity_logs USING btree (resource_type, resource_id, occurred_at DESC) WHERE ((resource_type IS NOT NULL) AND (resource_id IS NOT NULL));


-- INDEX: activity_logs_y2026m04_resource_type_resource_id_occurred_a_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_resource_type_resource_id_occurred_a_idx ON audit.activity_logs_y2026m04 USING btree (resource_type, resource_id, occurred_at DESC) WHERE ((resource_type IS NOT NULL) AND (resource_id IS NOT NULL));


-- INDEX: idx_activity_logs_success
CREATE INDEX IF NOT EXISTS idx_activity_logs_success ON ONLY audit.activity_logs USING btree (success, occurred_at DESC) WHERE (success = false);


-- INDEX: activity_logs_y2026m04_success_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_success_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (success, occurred_at DESC) WHERE (success = false);


-- INDEX: idx_activity_logs_tenant_time
CREATE INDEX IF NOT EXISTS idx_activity_logs_tenant_time ON ONLY audit.activity_logs USING btree (tenant_id, occurred_at DESC) WHERE (tenant_id IS NOT NULL);


-- INDEX: activity_logs_y2026m04_tenant_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_tenant_id_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (tenant_id, occurred_at DESC) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_activity_logs_user_time
CREATE INDEX IF NOT EXISTS idx_activity_logs_user_time ON ONLY audit.activity_logs USING btree (user_id, occurred_at DESC) WHERE (user_id IS NOT NULL);


-- INDEX: activity_logs_y2026m04_user_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_user_id_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (user_id, occurred_at DESC) WHERE (user_id IS NOT NULL);


-- INDEX: idx_activity_logs_user_type
CREATE INDEX IF NOT EXISTS idx_activity_logs_user_type ON ONLY audit.activity_logs USING btree (user_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m04_user_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m04_user_type_occurred_at_idx ON audit.activity_logs_y2026m04 USING btree (user_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m05_action_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_action_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (action, occurred_at DESC);


-- INDEX: activity_logs_y2026m05_compliance_tags_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_compliance_tags_idx ON audit.activity_logs_y2026m05 USING gin (compliance_tags);


-- INDEX: activity_logs_y2026m05_event_category_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_event_category_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (event_category, occurred_at DESC);


-- INDEX: activity_logs_y2026m05_event_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_event_type_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (event_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m05_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (occurred_at DESC);


-- INDEX: activity_logs_y2026m05_request_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_request_id_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (request_id, occurred_at DESC) WHERE (request_id IS NOT NULL);


-- INDEX: activity_logs_y2026m05_requires_attention_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_requires_attention_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (requires_attention, occurred_at DESC) WHERE (requires_attention = true);


-- INDEX: activity_logs_y2026m05_resource_type_resource_id_occurred_a_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_resource_type_resource_id_occurred_a_idx ON audit.activity_logs_y2026m05 USING btree (resource_type, resource_id, occurred_at DESC) WHERE ((resource_type IS NOT NULL) AND (resource_id IS NOT NULL));


-- INDEX: activity_logs_y2026m05_success_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_success_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (success, occurred_at DESC) WHERE (success = false);


-- INDEX: activity_logs_y2026m05_tenant_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_tenant_id_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (tenant_id, occurred_at DESC) WHERE (tenant_id IS NOT NULL);


-- INDEX: activity_logs_y2026m05_user_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_user_id_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (user_id, occurred_at DESC) WHERE (user_id IS NOT NULL);


-- INDEX: activity_logs_y2026m05_user_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m05_user_type_occurred_at_idx ON audit.activity_logs_y2026m05 USING btree (user_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m06_action_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_action_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (action, occurred_at DESC);


-- INDEX: activity_logs_y2026m06_compliance_tags_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_compliance_tags_idx ON audit.activity_logs_y2026m06 USING gin (compliance_tags);


-- INDEX: activity_logs_y2026m06_event_category_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_event_category_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (event_category, occurred_at DESC);


-- INDEX: activity_logs_y2026m06_event_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_event_type_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (event_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m06_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (occurred_at DESC);


-- INDEX: activity_logs_y2026m06_request_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_request_id_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (request_id, occurred_at DESC) WHERE (request_id IS NOT NULL);


-- INDEX: activity_logs_y2026m06_requires_attention_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_requires_attention_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (requires_attention, occurred_at DESC) WHERE (requires_attention = true);


-- INDEX: activity_logs_y2026m06_resource_type_resource_id_occurred_a_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_resource_type_resource_id_occurred_a_idx ON audit.activity_logs_y2026m06 USING btree (resource_type, resource_id, occurred_at DESC) WHERE ((resource_type IS NOT NULL) AND (resource_id IS NOT NULL));


-- INDEX: activity_logs_y2026m06_success_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_success_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (success, occurred_at DESC) WHERE (success = false);


-- INDEX: activity_logs_y2026m06_tenant_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_tenant_id_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (tenant_id, occurred_at DESC) WHERE (tenant_id IS NOT NULL);


-- INDEX: activity_logs_y2026m06_user_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_user_id_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (user_id, occurred_at DESC) WHERE (user_id IS NOT NULL);


-- INDEX: activity_logs_y2026m06_user_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m06_user_type_occurred_at_idx ON audit.activity_logs_y2026m06 USING btree (user_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m07_action_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_action_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (action, occurred_at DESC);


-- INDEX: activity_logs_y2026m07_compliance_tags_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_compliance_tags_idx ON audit.activity_logs_y2026m07 USING gin (compliance_tags);


-- INDEX: activity_logs_y2026m07_event_category_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_event_category_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (event_category, occurred_at DESC);


-- INDEX: activity_logs_y2026m07_event_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_event_type_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (event_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m07_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (occurred_at DESC);


-- INDEX: activity_logs_y2026m07_request_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_request_id_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (request_id, occurred_at DESC) WHERE (request_id IS NOT NULL);


-- INDEX: activity_logs_y2026m07_requires_attention_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_requires_attention_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (requires_attention, occurred_at DESC) WHERE (requires_attention = true);


-- INDEX: activity_logs_y2026m07_resource_type_resource_id_occurred_a_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_resource_type_resource_id_occurred_a_idx ON audit.activity_logs_y2026m07 USING btree (resource_type, resource_id, occurred_at DESC) WHERE ((resource_type IS NOT NULL) AND (resource_id IS NOT NULL));


-- INDEX: activity_logs_y2026m07_success_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_success_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (success, occurred_at DESC) WHERE (success = false);


-- INDEX: activity_logs_y2026m07_tenant_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_tenant_id_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (tenant_id, occurred_at DESC) WHERE (tenant_id IS NOT NULL);


-- INDEX: activity_logs_y2026m07_user_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_user_id_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (user_id, occurred_at DESC) WHERE (user_id IS NOT NULL);


-- INDEX: activity_logs_y2026m07_user_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m07_user_type_occurred_at_idx ON audit.activity_logs_y2026m07 USING btree (user_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m08_action_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_action_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (action, occurred_at DESC);


-- INDEX: activity_logs_y2026m08_compliance_tags_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_compliance_tags_idx ON audit.activity_logs_y2026m08 USING gin (compliance_tags);


-- INDEX: activity_logs_y2026m08_event_category_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_event_category_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (event_category, occurred_at DESC);


-- INDEX: activity_logs_y2026m08_event_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_event_type_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (event_type, occurred_at DESC);


-- INDEX: activity_logs_y2026m08_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (occurred_at DESC);


-- INDEX: activity_logs_y2026m08_request_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_request_id_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (request_id, occurred_at DESC) WHERE (request_id IS NOT NULL);


-- INDEX: activity_logs_y2026m08_requires_attention_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_requires_attention_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (requires_attention, occurred_at DESC) WHERE (requires_attention = true);


-- INDEX: activity_logs_y2026m08_resource_type_resource_id_occurred_a_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_resource_type_resource_id_occurred_a_idx ON audit.activity_logs_y2026m08 USING btree (resource_type, resource_id, occurred_at DESC) WHERE ((resource_type IS NOT NULL) AND (resource_id IS NOT NULL));


-- INDEX: activity_logs_y2026m08_success_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_success_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (success, occurred_at DESC) WHERE (success = false);


-- INDEX: activity_logs_y2026m08_tenant_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_tenant_id_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (tenant_id, occurred_at DESC) WHERE (tenant_id IS NOT NULL);


-- INDEX: activity_logs_y2026m08_user_id_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_user_id_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (user_id, occurred_at DESC) WHERE (user_id IS NOT NULL);


-- INDEX: activity_logs_y2026m08_user_type_occurred_at_idx
CREATE INDEX IF NOT EXISTS activity_logs_y2026m08_user_type_occurred_at_idx ON audit.activity_logs_y2026m08 USING btree (user_type, occurred_at DESC);


-- INDEX: idx_alert_rules_enabled
CREATE INDEX IF NOT EXISTS idx_alert_rules_enabled ON audit.alert_rules USING btree (is_enabled) WHERE (is_enabled = true);


-- INDEX: idx_alert_rules_severity
CREATE INDEX IF NOT EXISTS idx_alert_rules_severity ON audit.alert_rules USING btree (severity);


-- INDEX: idx_alert_rules_tenant
CREATE INDEX IF NOT EXISTS idx_alert_rules_tenant ON audit.alert_rules USING btree (tenant_id) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_alert_rules_type
CREATE INDEX IF NOT EXISTS idx_alert_rules_type ON audit.alert_rules USING btree (rule_type);


-- INDEX: idx_job_execution_logs_initiated_by
CREATE INDEX IF NOT EXISTS idx_job_execution_logs_initiated_by ON audit.job_execution_logs USING btree (initiated_by, started_at DESC) WHERE (initiated_by IS NOT NULL);


-- INDEX: idx_job_execution_logs_job_id
CREATE INDEX IF NOT EXISTS idx_job_execution_logs_job_id ON audit.job_execution_logs USING btree (job_id, started_at DESC);


-- INDEX: idx_job_execution_logs_job_type
CREATE INDEX IF NOT EXISTS idx_job_execution_logs_job_type ON audit.job_execution_logs USING btree (job_type, started_at DESC);


-- INDEX: idx_job_execution_logs_started_at
CREATE INDEX IF NOT EXISTS idx_job_execution_logs_started_at ON audit.job_execution_logs USING btree (started_at DESC);


-- INDEX: idx_job_execution_logs_status
CREATE INDEX IF NOT EXISTS idx_job_execution_logs_status ON audit.job_execution_logs USING btree (status, started_at DESC);


-- INDEX: idx_job_execution_logs_tenant
CREATE INDEX IF NOT EXISTS idx_job_execution_logs_tenant ON audit.job_execution_logs USING btree (tenant_id, started_at DESC) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_report_executions_schedule
CREATE INDEX IF NOT EXISTS idx_report_executions_schedule ON audit.scheduled_report_executions USING btree (schedule_id);


-- INDEX: idx_report_executions_started
CREATE INDEX IF NOT EXISTS idx_report_executions_started ON audit.scheduled_report_executions USING btree (started_at DESC);


-- INDEX: idx_report_executions_status
CREATE INDEX IF NOT EXISTS idx_report_executions_status ON audit.scheduled_report_executions USING btree (status);


-- INDEX: idx_report_executions_tenant
CREATE INDEX IF NOT EXISTS idx_report_executions_tenant ON audit.scheduled_report_executions USING btree (tenant_id);


-- INDEX: idx_scheduled_reports_enabled
CREATE INDEX IF NOT EXISTS idx_scheduled_reports_enabled ON audit.scheduled_compliance_reports USING btree (is_enabled) WHERE (is_enabled = true);


-- INDEX: idx_scheduled_reports_next_run
CREATE INDEX IF NOT EXISTS idx_scheduled_reports_next_run ON audit.scheduled_compliance_reports USING btree (next_run_at) WHERE ((is_enabled = true) AND (next_run_at IS NOT NULL));


-- INDEX: idx_scheduled_reports_tenant
CREATE INDEX IF NOT EXISTS idx_scheduled_reports_tenant ON audit.scheduled_compliance_reports USING btree (tenant_id);


-- INDEX: idx_siem_health_checks_checked_at
CREATE INDEX IF NOT EXISTS idx_siem_health_checks_checked_at ON audit.siem_health_checks USING btree (checked_at DESC);


-- INDEX: idx_siem_health_checks_integration
CREATE INDEX IF NOT EXISTS idx_siem_health_checks_integration ON audit.siem_health_checks USING btree (integration_id);


-- INDEX: idx_siem_integrations_enabled
CREATE INDEX IF NOT EXISTS idx_siem_integrations_enabled ON audit.siem_integrations USING btree (enabled) WHERE (enabled = true);


-- INDEX: idx_siem_integrations_health
CREATE INDEX IF NOT EXISTS idx_siem_integrations_health ON audit.siem_integrations USING btree (health_status);


-- INDEX: idx_siem_integrations_tenant
CREATE INDEX IF NOT EXISTS idx_siem_integrations_tenant ON audit.siem_integrations USING btree (tenant_id) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_crypto_implementations_partitioned_asset_id
CREATE INDEX IF NOT EXISTS idx_crypto_implementations_partitioned_asset_id ON ONLY public.crypto_implementations_partitioned USING btree (asset_id);


-- INDEX: crypto_implementations_part_0_asset_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_0_asset_id_idx ON public.crypto_implementations_part_0 USING btree (asset_id);


-- INDEX: idx_crypto_implementations_partitioned_deleted_at
CREATE INDEX IF NOT EXISTS idx_crypto_implementations_partitioned_deleted_at ON ONLY public.crypto_implementations_partitioned USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: crypto_implementations_part_0_deleted_at_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_0_deleted_at_idx ON public.crypto_implementations_part_0 USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: idx_crypto_implementations_partitioned_risk_score
CREATE INDEX IF NOT EXISTS idx_crypto_implementations_partitioned_risk_score ON ONLY public.crypto_implementations_partitioned USING btree (risk_score);


-- INDEX: crypto_implementations_part_0_risk_score_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_0_risk_score_idx ON public.crypto_implementations_part_0 USING btree (risk_score);


-- INDEX: idx_crypto_implementations_partitioned_tenant_id
CREATE INDEX IF NOT EXISTS idx_crypto_implementations_partitioned_tenant_id ON ONLY public.crypto_implementations_partitioned USING btree (tenant_id);


-- INDEX: crypto_implementations_part_0_tenant_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_0_tenant_id_idx ON public.crypto_implementations_part_0 USING btree (tenant_id);


-- INDEX: crypto_implementations_part_1_asset_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_1_asset_id_idx ON public.crypto_implementations_part_1 USING btree (asset_id);


-- INDEX: crypto_implementations_part_1_deleted_at_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_1_deleted_at_idx ON public.crypto_implementations_part_1 USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: crypto_implementations_part_1_risk_score_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_1_risk_score_idx ON public.crypto_implementations_part_1 USING btree (risk_score);


-- INDEX: crypto_implementations_part_1_tenant_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_1_tenant_id_idx ON public.crypto_implementations_part_1 USING btree (tenant_id);


-- INDEX: crypto_implementations_part_2_asset_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_2_asset_id_idx ON public.crypto_implementations_part_2 USING btree (asset_id);


-- INDEX: crypto_implementations_part_2_deleted_at_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_2_deleted_at_idx ON public.crypto_implementations_part_2 USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: crypto_implementations_part_2_risk_score_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_2_risk_score_idx ON public.crypto_implementations_part_2 USING btree (risk_score);


-- INDEX: crypto_implementations_part_2_tenant_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_2_tenant_id_idx ON public.crypto_implementations_part_2 USING btree (tenant_id);


-- INDEX: crypto_implementations_part_3_asset_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_3_asset_id_idx ON public.crypto_implementations_part_3 USING btree (asset_id);


-- INDEX: crypto_implementations_part_3_deleted_at_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_3_deleted_at_idx ON public.crypto_implementations_part_3 USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: crypto_implementations_part_3_risk_score_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_3_risk_score_idx ON public.crypto_implementations_part_3 USING btree (risk_score);


-- INDEX: crypto_implementations_part_3_tenant_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_3_tenant_id_idx ON public.crypto_implementations_part_3 USING btree (tenant_id);


-- INDEX: crypto_implementations_part_4_asset_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_4_asset_id_idx ON public.crypto_implementations_part_4 USING btree (asset_id);


-- INDEX: crypto_implementations_part_4_deleted_at_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_4_deleted_at_idx ON public.crypto_implementations_part_4 USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: crypto_implementations_part_4_risk_score_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_4_risk_score_idx ON public.crypto_implementations_part_4 USING btree (risk_score);


-- INDEX: crypto_implementations_part_4_tenant_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_4_tenant_id_idx ON public.crypto_implementations_part_4 USING btree (tenant_id);


-- INDEX: crypto_implementations_part_5_asset_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_5_asset_id_idx ON public.crypto_implementations_part_5 USING btree (asset_id);


-- INDEX: crypto_implementations_part_5_deleted_at_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_5_deleted_at_idx ON public.crypto_implementations_part_5 USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: crypto_implementations_part_5_risk_score_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_5_risk_score_idx ON public.crypto_implementations_part_5 USING btree (risk_score);


-- INDEX: crypto_implementations_part_5_tenant_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_5_tenant_id_idx ON public.crypto_implementations_part_5 USING btree (tenant_id);


-- INDEX: crypto_implementations_part_6_asset_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_6_asset_id_idx ON public.crypto_implementations_part_6 USING btree (asset_id);


-- INDEX: crypto_implementations_part_6_deleted_at_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_6_deleted_at_idx ON public.crypto_implementations_part_6 USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: crypto_implementations_part_6_risk_score_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_6_risk_score_idx ON public.crypto_implementations_part_6 USING btree (risk_score);


-- INDEX: crypto_implementations_part_6_tenant_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_6_tenant_id_idx ON public.crypto_implementations_part_6 USING btree (tenant_id);


-- INDEX: crypto_implementations_part_7_asset_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_7_asset_id_idx ON public.crypto_implementations_part_7 USING btree (asset_id);


-- INDEX: crypto_implementations_part_7_deleted_at_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_7_deleted_at_idx ON public.crypto_implementations_part_7 USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: crypto_implementations_part_7_risk_score_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_7_risk_score_idx ON public.crypto_implementations_part_7 USING btree (risk_score);


-- INDEX: crypto_implementations_part_7_tenant_id_idx
CREATE INDEX IF NOT EXISTS crypto_implementations_part_7_tenant_id_idx ON public.crypto_implementations_part_7 USING btree (tenant_id);


-- INDEX: idx_agent_certificates_agent_id
CREATE INDEX IF NOT EXISTS idx_agent_certificates_agent_id ON public.agent_certificates USING btree (agent_id);


-- INDEX: idx_agent_certificates_expires_at
CREATE INDEX IF NOT EXISTS idx_agent_certificates_expires_at ON public.agent_certificates USING btree (expires_at);


-- INDEX: idx_agent_certificates_revoked
CREATE INDEX IF NOT EXISTS idx_agent_certificates_revoked ON public.agent_certificates USING btree (agent_id, revoked_at) WHERE (revoked_at IS NOT NULL);


-- INDEX: idx_agent_certificates_tenant_id
CREATE INDEX IF NOT EXISTS idx_agent_certificates_tenant_id ON public.agent_certificates USING btree (tenant_id);


-- INDEX: idx_alert_history_service_name
CREATE INDEX IF NOT EXISTS idx_alert_history_service_name ON public.monitoring_alert_history USING btree (service_name);


-- INDEX: idx_alert_history_service_status
CREATE INDEX IF NOT EXISTS idx_alert_history_service_status ON public.monitoring_alert_history USING btree (service_name, status);


-- INDEX: idx_alert_history_status
CREATE INDEX IF NOT EXISTS idx_alert_history_status ON public.monitoring_alert_history USING btree (status);


-- INDEX: idx_alert_history_threshold_id
CREATE INDEX IF NOT EXISTS idx_alert_history_threshold_id ON public.monitoring_alert_history USING btree (threshold_id);


-- INDEX: idx_alert_history_triggered_at
CREATE INDEX IF NOT EXISTS idx_alert_history_triggered_at ON public.monitoring_alert_history USING btree (triggered_at DESC);


-- INDEX: idx_alert_thresholds_enabled
CREATE INDEX IF NOT EXISTS idx_alert_thresholds_enabled ON public.monitoring_alert_thresholds USING btree (enabled);


-- INDEX: idx_alert_thresholds_metric_type
CREATE INDEX IF NOT EXISTS idx_alert_thresholds_metric_type ON public.monitoring_alert_thresholds USING btree (metric_type);


-- INDEX: idx_alert_thresholds_service_name
CREATE INDEX IF NOT EXISTS idx_alert_thresholds_service_name ON public.monitoring_alert_thresholds USING btree (service_name);


-- INDEX: idx_algorithms_category
CREATE INDEX IF NOT EXISTS idx_algorithms_category ON public.algorithms USING btree (category);


-- INDEX: idx_algorithms_code
CREATE INDEX IF NOT EXISTS idx_algorithms_code ON public.algorithms USING btree (code);


-- INDEX: idx_algorithms_family
CREATE INDEX IF NOT EXISTS idx_algorithms_family ON public.algorithms USING btree (algorithm_family) WHERE (algorithm_family IS NOT NULL);


-- INDEX: idx_algorithms_oid
CREATE INDEX IF NOT EXISTS idx_algorithms_oid ON public.algorithms USING btree (oid) WHERE (oid IS NOT NULL);


-- INDEX: idx_algorithms_pqc
CREATE INDEX IF NOT EXISTS idx_algorithms_pqc ON public.algorithms USING btree (is_pqc, pqc_standardization_status);


-- INDEX: idx_algorithms_primitive
CREATE INDEX IF NOT EXISTS idx_algorithms_primitive ON public.algorithms USING btree (primitive) WHERE (primitive IS NOT NULL);


-- INDEX: idx_algorithms_quantum_level
CREATE INDEX IF NOT EXISTS idx_algorithms_quantum_level ON public.algorithms USING btree (nist_quantum_security_level) WHERE (nist_quantum_security_level IS NOT NULL);


-- INDEX: idx_algorithms_remediation
CREATE INDEX IF NOT EXISTS idx_algorithms_remediation ON public.algorithms USING gin (remediation_guidance);


-- INDEX: idx_algorithms_risk_score
CREATE INDEX IF NOT EXISTS idx_algorithms_risk_score ON public.algorithms USING btree (risk_score);


-- INDEX: idx_algorithms_strength
CREATE INDEX IF NOT EXISTS idx_algorithms_strength ON public.algorithms USING btree (strength, deprecation_status);


-- INDEX: idx_api_usage_endpoint_time
CREATE INDEX IF NOT EXISTS idx_api_usage_endpoint_time ON public.api_usage_logs USING btree (endpoint, "timestamp" DESC);


-- INDEX: idx_api_usage_tenant_time
CREATE INDEX IF NOT EXISTS idx_api_usage_tenant_time ON public.api_usage_logs USING btree (tenant_id, "timestamp" DESC);


-- INDEX: idx_asset_lifecycle_policies_tenant
CREATE INDEX IF NOT EXISTS idx_asset_lifecycle_policies_tenant ON public.asset_lifecycle_policies USING btree (tenant_id);


-- INDEX: idx_auth_audit_event_type
CREATE INDEX IF NOT EXISTS idx_auth_audit_event_type ON public.auth_audit_log USING btree (event_type);


-- INDEX: idx_auth_audit_occurred_at
CREATE INDEX IF NOT EXISTS idx_auth_audit_occurred_at ON public.auth_audit_log USING btree (occurred_at);


-- INDEX: idx_auth_audit_tenant_user
CREATE INDEX IF NOT EXISTS idx_auth_audit_tenant_user ON public.auth_audit_log USING btree (tenant_id, user_id);


-- INDEX: idx_aws_cost_data_cost_date
CREATE INDEX IF NOT EXISTS idx_aws_cost_data_cost_date ON public.aws_cost_data USING btree (cost_date);


-- INDEX: idx_aws_cost_data_service
CREATE INDEX IF NOT EXISTS idx_aws_cost_data_service ON public.aws_cost_data USING btree (service_name);


-- INDEX: idx_aws_cost_data_synced_at
CREATE INDEX IF NOT EXISTS idx_aws_cost_data_synced_at ON public.aws_cost_data USING btree (synced_at);


-- INDEX: idx_aws_cost_data_tenant_date
CREATE INDEX IF NOT EXISTS idx_aws_cost_data_tenant_date ON public.aws_cost_data USING btree (tenant_id, cost_date);


-- INDEX: idx_aws_cost_data_tenant_id
CREATE INDEX IF NOT EXISTS idx_aws_cost_data_tenant_id ON public.aws_cost_data USING btree (tenant_id);


-- INDEX: idx_aws_cost_data_unique_v2
-- v2 (B-57): the original idx_aws_cost_data_unique indexed tenant_id directly.
-- Postgres unique indexes treat NULL as distinct from every other value
-- (including another NULL), so the platform-wide sync's tenant_id=NULL rows
-- never collided with the index and StoreCostData's ON CONFLICT arbiter could
-- never match them — every sync attempt re-inserted instead of updating.
-- COALESCE(tenant_id, <sentinel>) collapses NULL onto one concrete value like
-- every other tenant_id, restoring the intended one-row-per-day-per-service
-- upsert. Superseded index dropped in POST-MIGRATIONS below. Kept as a
-- separate name (not a same-name redefinition) because `CREATE ... IF NOT
-- EXISTS` is a no-op by name on an already-migrated database regardless of
-- whether the definition changed.
--
-- MUST be preceded by the de-duplication block below. Collapsing NULL onto a
-- sentinel makes rows that were previously DISTINCT under the old index
-- collide, and duplicate NULL-tenant rows are exactly what the bug produced —
-- so on any database that ran the buggy sync, creating this index without
-- repairing the data first aborts the whole migration under ON_ERROR_STOP=1.
DO $$
BEGIN
    -- Idempotent no-op on a fresh install (the table is empty) and on any
    -- database already carrying the v2 index (it cannot hold duplicates). Only
    -- a database that accumulated duplicates under the old index has anything
    -- to delete. Runs BEFORE the CREATE UNIQUE INDEX below rather than in
    -- POST-MIGRATIONS because the index creation lives here in the pg_dump
    -- body, thousands of lines earlier in the file — a repair appended at the
    -- bottom would run only after the statement it exists to unblock had
    -- already failed and aborted the run.
    IF to_regclass('public.aws_cost_data') IS NOT NULL THEN
        DELETE FROM public.aws_cost_data a
         USING public.aws_cost_data b
         WHERE a.deleted_at IS NULL
           AND b.deleted_at IS NULL
           AND COALESCE(a.tenant_id, '00000000-0000-0000-0000-000000000000'::uuid)
             = COALESCE(b.tenant_id, '00000000-0000-0000-0000-000000000000'::uuid)
           AND a.cost_date = b.cost_date
           AND a.service_name = b.service_name
           AND COALESCE(a.usage_type, ''::character varying) = COALESCE(b.usage_type, ''::character varying)
           -- Total order over the group, so exactly one row survives: keep the
           -- most recently synced, breaking ties on id (the PK, never NULL).
           -- synced_at is NOT NULL in the current definition but is COALESCEd
           -- anyway so the comparison stays total on any older shape.
           AND (COALESCE(a.synced_at, 'epoch'::timestamptz), a.id)
             < (COALESCE(b.synced_at, 'epoch'::timestamptz), b.id);
    END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS idx_aws_cost_data_unique_v2 ON public.aws_cost_data USING btree (COALESCE(tenant_id, '00000000-0000-0000-0000-000000000000'::uuid), cost_date, service_name, COALESCE(usage_type, ''::character varying)) WHERE (deleted_at IS NULL);


-- INDEX: idx_aws_cost_sync_jobs_created
CREATE INDEX IF NOT EXISTS idx_aws_cost_sync_jobs_created ON public.aws_cost_sync_jobs USING btree (created_at DESC);


-- INDEX: idx_aws_cost_sync_jobs_period
CREATE INDEX IF NOT EXISTS idx_aws_cost_sync_jobs_period ON public.aws_cost_sync_jobs USING btree (period_start, period_end);


-- INDEX: idx_aws_cost_sync_jobs_status
CREATE INDEX IF NOT EXISTS idx_aws_cost_sync_jobs_status ON public.aws_cost_sync_jobs USING btree (status);


-- INDEX: idx_aws_cost_sync_jobs_tenant
CREATE INDEX IF NOT EXISTS idx_aws_cost_sync_jobs_tenant ON public.aws_cost_sync_jobs USING btree (tenant_id);


-- INDEX: idx_billing_customers_tenant
CREATE INDEX IF NOT EXISTS idx_billing_customers_tenant ON public.billing_customers USING btree (tenant_id);


-- INDEX: idx_billing_events_status
CREATE INDEX IF NOT EXISTS idx_billing_events_status ON public.billing_events USING btree (processing_status) WHERE ((processing_status)::text = 'pending'::text);


-- INDEX: idx_billing_events_updated_at
CREATE INDEX IF NOT EXISTS idx_billing_events_updated_at ON public.billing_events USING btree (received_at) WHERE ((processing_status)::text = 'pending'::text);


-- INDEX: idx_billing_invoices_tenant
CREATE INDEX IF NOT EXISTS idx_billing_invoices_tenant ON public.billing_invoices USING btree (tenant_id);


-- INDEX: idx_billing_invoices_tenant_status
CREATE INDEX IF NOT EXISTS idx_billing_invoices_tenant_status ON public.billing_invoices USING btree (tenant_id, status);


-- INDEX: idx_billing_subscriptions_tenant
CREATE INDEX IF NOT EXISTS idx_billing_subscriptions_tenant ON public.billing_subscriptions USING btree (tenant_id);


-- INDEX: idx_cert_extensions_cert_id
CREATE INDEX IF NOT EXISTS idx_cert_extensions_cert_id ON public.certificate_extensions USING btree (certificate_id);


-- INDEX: idx_cert_extensions_name
CREATE INDEX IF NOT EXISTS idx_cert_extensions_name ON public.certificate_extensions USING btree (extension_name);


-- INDEX: idx_certificate_history_cert_id
CREATE INDEX IF NOT EXISTS idx_certificate_history_cert_id ON public.certificate_history USING btree (certificate_id, created_at DESC);


-- INDEX: idx_certificate_history_tenant
CREATE INDEX IF NOT EXISTS idx_certificate_history_tenant ON public.certificate_history USING btree (tenant_id, event_type, created_at DESC);


-- INDEX: idx_certificates_algorithm
CREATE INDEX IF NOT EXISTS idx_certificates_algorithm ON public.certificates USING btree (public_key_algorithm) WHERE (public_key_algorithm IS NOT NULL);


-- INDEX: idx_certificates_common_name
CREATE INDEX IF NOT EXISTS idx_certificates_common_name ON public.certificates USING btree (common_name);


-- INDEX: idx_certificates_composite_key
CREATE UNIQUE INDEX IF NOT EXISTS idx_certificates_composite_key ON public.certificates USING btree (tenant_id, fingerprint_sha256, serial_number, issuer_dn) WHERE ((fingerprint_sha256 IS NOT NULL) AND (serial_number IS NOT NULL) AND (issuer_dn IS NOT NULL));


-- INDEX: idx_certificates_expiry
CREATE INDEX IF NOT EXISTS idx_certificates_expiry ON public.certificates USING btree (not_after);


-- INDEX: idx_certificates_fingerprint_sha256
CREATE INDEX IF NOT EXISTS idx_certificates_fingerprint_sha256 ON public.certificates USING btree (fingerprint_sha256);


-- INDEX: idx_certificates_format
CREATE INDEX IF NOT EXISTS idx_certificates_format ON public.certificates USING btree (certificate_format) WHERE ((certificate_format)::text <> 'X.509'::text);


-- INDEX: idx_certificates_issuer
CREATE INDEX IF NOT EXISTS idx_certificates_issuer ON public.certificates USING btree (issuer_dn) WHERE (issuer_dn IS NOT NULL);


-- INDEX: idx_certificates_issuer_dn
CREATE INDEX IF NOT EXISTS idx_certificates_issuer_dn ON public.certificates USING btree (tenant_id, issuer_dn);


-- INDEX: idx_certificates_issuer_id
CREATE INDEX IF NOT EXISTS idx_certificates_issuer_id ON public.certificates USING btree (issuer_certificate_id) WHERE (issuer_certificate_id IS NOT NULL);


-- INDEX: idx_certificates_key_size
CREATE INDEX IF NOT EXISTS idx_certificates_key_size ON public.certificates USING btree (public_key_size) WHERE (public_key_size IS NOT NULL);


-- INDEX: idx_certificates_state
CREATE INDEX IF NOT EXISTS idx_certificates_state ON public.certificates USING btree (tenant_id, certificate_state) WHERE ((certificate_state)::text <> 'active'::text);


-- INDEX: idx_certificates_superseded_by
CREATE INDEX IF NOT EXISTS idx_certificates_superseded_by ON public.certificates USING btree (superseded_by_certificate_id) WHERE (superseded_by_certificate_id IS NOT NULL);


-- INDEX: idx_certificates_tenant_expiry
CREATE INDEX IF NOT EXISTS idx_certificates_tenant_expiry ON public.certificates USING btree (tenant_id, not_after);


-- INDEX: idx_certificates_tenant_id
CREATE INDEX IF NOT EXISTS idx_certificates_tenant_id ON public.certificates USING btree (tenant_id);


-- INDEX: idx_cmdb_entity_mappings_external
CREATE INDEX IF NOT EXISTS idx_cmdb_entity_mappings_external ON public.cmdb_entity_mappings USING btree (cmdb_platform, cmdb_ci_id) WHERE (cmdb_ci_id IS NOT NULL);


-- INDEX: idx_cmdb_entity_mappings_lookup
CREATE INDEX IF NOT EXISTS idx_cmdb_entity_mappings_lookup ON public.cmdb_entity_mappings USING btree (tenant_id, local_entity_type, local_entity_id);


-- INDEX: idx_cmdb_entity_mappings_profile
CREATE INDEX IF NOT EXISTS idx_cmdb_entity_mappings_profile ON public.cmdb_entity_mappings USING btree (profile_id);


-- INDEX: idx_cmdb_entity_mappings_stale
CREATE INDEX IF NOT EXISTS idx_cmdb_entity_mappings_stale ON public.cmdb_entity_mappings USING btree (sync_status) WHERE ((sync_status)::text = ANY ((ARRAY['pending'::character varying, 'error'::character varying, 'stale'::character varying])::text[]));


-- INDEX: idx_cmdb_sync_jobs_profile
CREATE INDEX IF NOT EXISTS idx_cmdb_sync_jobs_profile ON public.cmdb_sync_jobs USING btree (profile_id, created_at DESC);


-- INDEX: idx_cmdb_sync_jobs_status
CREATE INDEX IF NOT EXISTS idx_cmdb_sync_jobs_status ON public.cmdb_sync_jobs USING btree (status) WHERE ((status)::text = ANY ((ARRAY['pending'::character varying, 'in_progress'::character varying])::text[]));


-- INDEX: idx_cmdb_sync_jobs_tenant
CREATE INDEX IF NOT EXISTS idx_cmdb_sync_jobs_tenant ON public.cmdb_sync_jobs USING btree (tenant_id, created_at DESC);


-- INDEX: idx_cmdb_sync_profiles_platform
CREATE INDEX IF NOT EXISTS idx_cmdb_sync_profiles_platform ON public.cmdb_sync_profiles USING btree (tenant_id, platform_type) WHERE (deleted_at IS NULL);


-- INDEX: idx_cmdb_sync_profiles_tenant
CREATE INDEX IF NOT EXISTS idx_cmdb_sync_profiles_tenant ON public.cmdb_sync_profiles USING btree (tenant_id) WHERE (deleted_at IS NULL);


-- INDEX: idx_compliance_overrides_control_id
CREATE INDEX IF NOT EXISTS idx_compliance_overrides_control_id ON public.compliance_overrides USING btree (control_id);


-- INDEX: idx_compliance_overrides_scenario_id
CREATE INDEX IF NOT EXISTS idx_compliance_overrides_scenario_id ON public.compliance_overrides USING btree (scenario_id);


-- INDEX: idx_compliance_overrides_tenant_id
CREATE INDEX IF NOT EXISTS idx_compliance_overrides_tenant_id ON public.compliance_overrides USING btree (tenant_id);


-- INDEX: idx_compliance_overrides_type
CREATE INDEX IF NOT EXISTS idx_compliance_overrides_type ON public.compliance_overrides USING btree (override_type);


-- INDEX: idx_compliance_rules_active
CREATE INDEX IF NOT EXISTS idx_compliance_rules_active ON public.compliance_rules USING btree (is_active);


-- INDEX: idx_compliance_rules_category
CREATE INDEX IF NOT EXISTS idx_compliance_rules_category ON public.compliance_rules USING btree (category);


-- INDEX: idx_compliance_rules_severity
CREATE INDEX IF NOT EXISTS idx_compliance_rules_severity ON public.compliance_rules USING btree (severity);


-- INDEX: idx_compliance_scenarios_framework_id
CREATE INDEX IF NOT EXISTS idx_compliance_scenarios_framework_id ON public.compliance_scenarios USING btree (framework_id);


-- INDEX: idx_compliance_scenarios_name
CREATE INDEX IF NOT EXISTS idx_compliance_scenarios_name ON public.compliance_scenarios USING btree (name);


-- INDEX: idx_compliance_scenarios_tenant_id
CREATE INDEX IF NOT EXISTS idx_compliance_scenarios_tenant_id ON public.compliance_scenarios USING btree (tenant_id);


-- INDEX: idx_control_measurements_control_id
CREATE INDEX IF NOT EXISTS idx_control_measurements_control_id ON public.control_measurements USING btree (control_id);


-- INDEX: idx_control_measurements_framework_type
CREATE INDEX IF NOT EXISTS idx_control_measurements_framework_type ON public.control_measurements USING btree (framework_type);


-- INDEX: idx_control_measurements_measurement_type_id
CREATE INDEX IF NOT EXISTS idx_control_measurements_measurement_type_id ON public.control_measurements USING btree (measurement_type_id);


-- INDEX: idx_control_measurements_rule_type
CREATE INDEX IF NOT EXISTS idx_control_measurements_rule_type ON public.control_measurements USING btree (rule_type);


-- INDEX: idx_coupon_redemptions_active
CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_active ON public.billing_coupon_redemptions USING btree (is_active, expires_at);


-- INDEX: idx_coupon_redemptions_coupon
CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_coupon ON public.billing_coupon_redemptions USING btree (coupon_id);


-- INDEX: idx_coupon_redemptions_tenant
CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_tenant ON public.billing_coupon_redemptions USING btree (tenant_id);


-- INDEX: idx_coupons_active
CREATE INDEX IF NOT EXISTS idx_coupons_active ON public.billing_coupons USING btree (is_active, valid_from, valid_until);


-- INDEX: idx_coupons_code
CREATE INDEX IF NOT EXISTS idx_coupons_code ON public.billing_coupons USING btree (code) WHERE (is_active = true);


-- INDEX: idx_crypto_app_algorithm
CREATE INDEX IF NOT EXISTS idx_crypto_app_algorithm ON public.crypto_applications USING btree (algorithm_id) WHERE (algorithm_id IS NOT NULL);


-- INDEX: idx_crypto_app_asset
CREATE INDEX IF NOT EXISTS idx_crypto_app_asset ON public.crypto_applications USING btree (asset_id) WHERE (asset_id IS NOT NULL);


-- INDEX: idx_crypto_app_encryption_ctx
CREATE INDEX IF NOT EXISTS idx_crypto_app_encryption_ctx ON public.crypto_applications USING btree (tenant_id, encryption_context);


-- INDEX: idx_crypto_app_key
CREATE INDEX IF NOT EXISTS idx_crypto_app_key ON public.crypto_applications USING btree (key_id) WHERE (key_id IS NOT NULL);


-- INDEX: idx_crypto_app_library
CREATE INDEX IF NOT EXISTS idx_crypto_app_library ON public.crypto_applications USING btree (library_id) WHERE (library_id IS NOT NULL);


-- INDEX: idx_crypto_app_resource_type
CREATE INDEX IF NOT EXISTS idx_crypto_app_resource_type ON public.crypto_applications USING btree (tenant_id, resource_type);


-- INDEX: idx_crypto_app_tenant
CREATE INDEX IF NOT EXISTS idx_crypto_app_tenant ON public.crypto_applications USING btree (tenant_id);
















-- INDEX: idx_crypto_impl_algorithms_algorithm_id
CREATE INDEX IF NOT EXISTS idx_crypto_impl_algorithms_algorithm_id ON public.crypto_implementation_algorithms USING btree (algorithm_id);


-- INDEX: idx_crypto_impl_algorithms_impl_id
CREATE INDEX IF NOT EXISTS idx_crypto_impl_algorithms_impl_id ON public.crypto_implementation_algorithms USING btree (crypto_implementation_id);


-- INDEX: idx_crypto_impl_certs_cert_id
CREATE INDEX IF NOT EXISTS idx_crypto_impl_certs_cert_id ON public.crypto_implementation_certificates USING btree (certificate_id);


-- INDEX: idx_crypto_impl_certs_impl_id
CREATE INDEX IF NOT EXISTS idx_crypto_impl_certs_impl_id ON public.crypto_implementation_certificates USING btree (crypto_implementation_id);


-- INDEX: idx_crypto_libs_name_ver
CREATE INDEX IF NOT EXISTS idx_crypto_libs_name_ver ON public.crypto_libraries USING btree (name, version);


-- INDEX: idx_crypto_libs_purl
CREATE INDEX IF NOT EXISTS idx_crypto_libs_purl ON public.crypto_libraries USING btree (purl) WHERE (purl IS NOT NULL);


-- INDEX: idx_crypto_libs_tenant
CREATE INDEX IF NOT EXISTS idx_crypto_libs_tenant ON public.crypto_libraries USING btree (tenant_id);


-- INDEX: idx_db_encryption_states_at_rest
CREATE INDEX IF NOT EXISTS idx_db_encryption_states_at_rest ON public.database_encryption_states USING btree (encryption_at_rest_enabled) WHERE (deleted_at IS NULL);


-- INDEX: idx_db_encryption_states_device
CREATE INDEX IF NOT EXISTS idx_db_encryption_states_asset ON public.database_encryption_states USING btree (asset_id) WHERE ((asset_id IS NOT NULL) AND (deleted_at IS NULL));


-- INDEX: idx_db_encryption_states_engine
CREATE INDEX IF NOT EXISTS idx_db_encryption_states_engine ON public.database_encryption_states USING btree (db_engine) WHERE (deleted_at IS NULL);


-- INDEX: idx_db_encryption_states_ssl
CREATE INDEX IF NOT EXISTS idx_db_encryption_states_ssl ON public.database_encryption_states USING btree (ssl_enabled) WHERE (deleted_at IS NULL);


-- INDEX: idx_db_encryption_states_tenant
CREATE INDEX IF NOT EXISTS idx_db_encryption_states_tenant ON public.database_encryption_states USING btree (tenant_id) WHERE (deleted_at IS NULL);


-- INDEX: idx_device_agents_active
CREATE INDEX IF NOT EXISTS idx_device_agents_active ON public.device_agents USING btree (status) WHERE (deleted_at IS NULL);


-- INDEX: idx_device_agents_registration_key
CREATE INDEX IF NOT EXISTS idx_device_agents_registration_key ON public.device_agents USING btree (registration_key);


-- INDEX: idx_device_agents_status
CREATE INDEX IF NOT EXISTS idx_device_agents_status ON public.device_agents USING btree (status);


-- INDEX: idx_device_agents_tenant_id
CREATE INDEX IF NOT EXISTS idx_device_agents_tenant_id ON public.device_agents USING btree (tenant_id);


-- INDEX: idx_device_jobs_active
CREATE INDEX IF NOT EXISTS idx_device_jobs_active ON public.device_jobs USING btree (tenant_id, status) WHERE (deleted_at IS NULL);


-- INDEX: idx_device_jobs_agent_id
CREATE INDEX IF NOT EXISTS idx_device_jobs_agent_id ON public.device_jobs USING btree (agent_id);


-- INDEX: idx_device_jobs_asset_id
-- NOT here: `device_jobs.asset_id` replaces `device_id`, and on a database that
-- already has the table the CREATE TABLE above is a no-op — the column is added
-- by the phase-1 POST-MIGRATIONS block, which is where this index is created
-- too, alongside the endpoint-link indexes that have the same dependency.
-- Creating it here failed with `column "asset_id" does not exist` and aborted
-- the whole apply under ON_ERROR_STOP=1.


-- INDEX: idx_device_jobs_expires
CREATE INDEX IF NOT EXISTS idx_device_jobs_expires ON public.device_jobs USING btree (expires_at) WHERE ((status = 'pending'::public.device_job_status) AND (expires_at IS NOT NULL));


-- INDEX: idx_device_jobs_job_type
CREATE INDEX IF NOT EXISTS idx_device_jobs_job_type ON public.device_jobs USING btree (job_type);


-- INDEX: idx_device_jobs_pending
CREATE INDEX IF NOT EXISTS idx_device_jobs_pending ON public.device_jobs USING btree (status, created_at) WHERE ((status = 'pending'::public.device_job_status) AND (deleted_at IS NULL));


-- INDEX: idx_device_jobs_status
CREATE INDEX IF NOT EXISTS idx_device_jobs_status ON public.device_jobs USING btree (status);


-- INDEX: idx_device_jobs_tenant_id
CREATE INDEX IF NOT EXISTS idx_device_jobs_tenant_id ON public.device_jobs USING btree (tenant_id);


-- INDEX: idx_device_jobs_updated_at
CREATE INDEX IF NOT EXISTS idx_device_jobs_updated_at ON public.device_jobs USING btree (updated_at);


-- INDEX: idx_discovery_findings_confidence_score
CREATE INDEX IF NOT EXISTS idx_discovery_findings_confidence_score ON public.discovery_findings USING btree (confidence_score);


-- INDEX: idx_discovery_findings_hostname
CREATE INDEX IF NOT EXISTS idx_discovery_findings_hostname ON public.discovery_findings USING btree (hostname);


-- INDEX: idx_discovery_findings_job_id
CREATE INDEX IF NOT EXISTS idx_discovery_findings_job_id ON public.discovery_findings USING btree (job_id);


-- INDEX: idx_discovery_findings_protocol_port
CREATE INDEX IF NOT EXISTS idx_discovery_findings_protocol_port ON public.discovery_findings USING btree (protocol, port);


-- INDEX: idx_discovery_findings_target_id
CREATE INDEX IF NOT EXISTS idx_discovery_findings_target_id ON public.discovery_findings USING btree (target_id);


-- INDEX: idx_discovery_jobs_created_at
CREATE INDEX IF NOT EXISTS idx_discovery_jobs_created_at ON public.discovery_jobs USING btree (created_at);


-- INDEX: idx_discovery_jobs_metadata
CREATE INDEX IF NOT EXISTS idx_discovery_jobs_metadata ON public.discovery_jobs USING gin (metadata);


-- INDEX: idx_discovery_jobs_status
CREATE INDEX IF NOT EXISTS idx_discovery_jobs_status ON public.discovery_jobs USING btree (status);


-- INDEX: idx_discovery_jobs_tenant_id
CREATE INDEX IF NOT EXISTS idx_discovery_jobs_tenant_id ON public.discovery_jobs USING btree (tenant_id);


-- INDEX: idx_discovery_targets_job_id
CREATE INDEX IF NOT EXISTS idx_discovery_targets_job_id ON public.discovery_targets USING btree (job_id);


-- INDEX: idx_discovery_targets_status
CREATE INDEX IF NOT EXISTS idx_discovery_targets_status ON public.discovery_targets USING btree (status);


-- INDEX: idx_dunning_attempts_invoice
CREATE INDEX IF NOT EXISTS idx_dunning_attempts_invoice ON public.billing_dunning_attempts USING btree (invoice_id);


-- INDEX: idx_dunning_attempts_next_retry
CREATE INDEX IF NOT EXISTS idx_dunning_attempts_next_retry ON public.billing_dunning_attempts USING btree (next_retry_at) WHERE ((status)::text = 'pending'::text);


-- INDEX: idx_dunning_attempts_status
CREATE INDEX IF NOT EXISTS idx_dunning_attempts_status ON public.billing_dunning_attempts USING btree (status);


-- INDEX: idx_dunning_attempts_tenant
CREATE INDEX IF NOT EXISTS idx_dunning_attempts_tenant ON public.billing_dunning_attempts USING btree (tenant_id);


-- INDEX: idx_ext_conn_cert_expiry
CREATE INDEX IF NOT EXISTS idx_ext_conn_cert_expiry ON public.external_connections USING btree (tenant_id, cert_not_after) WHERE (cert_not_after IS NOT NULL);


-- INDEX: idx_ext_conn_crypto_strength
CREATE INDEX IF NOT EXISTS idx_ext_conn_crypto_strength ON public.external_connections USING btree (tenant_id, crypto_strength);


-- INDEX: idx_ext_conn_dest
CREATE INDEX IF NOT EXISTS idx_ext_conn_dest ON public.external_connections USING btree (tenant_id, dest_ip, dest_port);


-- INDEX: idx_ext_conn_dest_hostname
CREATE INDEX IF NOT EXISTS idx_ext_conn_dest_hostname ON public.external_connections USING btree (tenant_id, dest_hostname) WHERE (dest_hostname IS NOT NULL);


-- INDEX: idx_ext_conn_history_conn
CREATE INDEX IF NOT EXISTS idx_ext_conn_history_conn ON public.external_connection_history USING btree (external_connection_id, created_at DESC);


-- INDEX: idx_ext_conn_history_tenant
CREATE INDEX IF NOT EXISTS idx_ext_conn_history_tenant ON public.external_connection_history USING btree (tenant_id, created_at DESC);


-- INDEX: idx_ext_conn_last_seen
CREATE INDEX IF NOT EXISTS idx_ext_conn_last_seen ON public.external_connections USING btree (tenant_id, last_seen_at DESC);


-- INDEX: idx_ext_conn_pqc
CREATE INDEX IF NOT EXISTS idx_ext_conn_pqc ON public.external_connections USING btree (tenant_id, is_pqc_resistant);


-- INDEX: idx_ext_conn_source
CREATE INDEX IF NOT EXISTS idx_ext_conn_source ON public.external_connections USING btree (tenant_id, source_ip);


-- INDEX: idx_ext_conn_tenant
CREATE INDEX IF NOT EXISTS idx_ext_conn_tenant ON public.external_connections USING btree (tenant_id);


-- INDEX: idx_external_map_lookup
CREATE INDEX IF NOT EXISTS idx_external_map_lookup ON public.external_asset_mappings USING btree (tenant_id, local_type, local_id);


-- INDEX: idx_finding_history_changed_by
CREATE INDEX IF NOT EXISTS idx_finding_history_changed_by ON public.compliance_finding_history USING btree (changed_by, changed_at DESC) WHERE (changed_by IS NOT NULL);


-- INDEX: idx_finding_history_finding_id
CREATE INDEX IF NOT EXISTS idx_finding_history_finding_id ON public.compliance_finding_history USING btree (finding_id, changed_at DESC);



-- INDEX: idx_framework_versions_created_at
CREATE INDEX IF NOT EXISTS idx_framework_versions_created_at ON public.platform_framework_versions USING btree (created_at);


-- INDEX: idx_framework_versions_framework_id
CREATE INDEX IF NOT EXISTS idx_framework_versions_framework_id ON public.platform_framework_versions USING btree (framework_id);


-- INDEX: idx_health_alerts_created_at
CREATE INDEX IF NOT EXISTS idx_health_alerts_created_at ON public.health_alerts USING btree (created_at);


-- INDEX: idx_health_alerts_is_active
CREATE INDEX IF NOT EXISTS idx_health_alerts_is_active ON public.health_alerts USING btree (is_active);


-- INDEX: idx_health_alerts_severity
CREATE INDEX IF NOT EXISTS idx_health_alerts_severity ON public.health_alerts USING btree (severity);


-- INDEX: idx_health_alerts_tenant_id
CREATE INDEX IF NOT EXISTS idx_health_alerts_tenant_id ON public.health_alerts USING btree (tenant_id);


-- INDEX: idx_health_events_service_time
CREATE INDEX IF NOT EXISTS idx_health_events_service_time ON public.service_health_events USING btree (service_name, "timestamp" DESC);


-- INDEX: idx_health_events_status
CREATE INDEX IF NOT EXISTS idx_health_events_status ON public.service_health_events USING btree (status, "timestamp" DESC) WHERE ((status)::text = ANY ((ARRAY['degraded'::character varying, 'down'::character varying])::text[]));


-- INDEX: idx_health_events_type
CREATE INDEX IF NOT EXISTS idx_health_events_type ON public.service_health_events USING btree (event_type, "timestamp" DESC);


-- INDEX: idx_health_metrics_tenant_id
CREATE INDEX IF NOT EXISTS idx_health_metrics_tenant_id ON public.health_metrics USING btree (tenant_id);


-- INDEX: idx_health_metrics_tenant_id_timestamp
CREATE INDEX IF NOT EXISTS idx_health_metrics_tenant_id_timestamp ON public.health_metrics USING btree (tenant_id, "timestamp");


-- INDEX: idx_health_metrics_timestamp
CREATE INDEX IF NOT EXISTS idx_health_metrics_timestamp ON public.health_metrics USING btree ("timestamp");


-- INDEX: idx_in_app_notifications_created_at
CREATE INDEX IF NOT EXISTS idx_in_app_notifications_created_at ON public.in_app_notifications USING btree (created_at DESC);


-- INDEX: idx_in_app_notifications_finding_id
CREATE INDEX IF NOT EXISTS idx_in_app_notifications_finding_id ON public.in_app_notifications USING btree (finding_id) WHERE (finding_id IS NOT NULL);


-- INDEX: idx_in_app_notifications_job_id
CREATE INDEX IF NOT EXISTS idx_in_app_notifications_job_id ON public.in_app_notifications USING btree (job_id) WHERE (job_id IS NOT NULL);


-- INDEX: idx_in_app_notifications_tenant_id
CREATE INDEX IF NOT EXISTS idx_in_app_notifications_tenant_id ON public.in_app_notifications USING btree (tenant_id);


-- INDEX: idx_in_app_notifications_tenant_unread
CREATE INDEX IF NOT EXISTS idx_in_app_notifications_tenant_unread ON public.in_app_notifications USING btree (tenant_id, read_at) WHERE (read_at IS NULL);


-- INDEX: idx_in_app_notifications_type
CREATE INDEX IF NOT EXISTS idx_in_app_notifications_type ON public.in_app_notifications USING btree (type);


-- INDEX: idx_incident_webhooks_enabled
CREATE INDEX IF NOT EXISTS idx_incident_webhooks_enabled ON public.security_incident_webhooks USING btree (enabled) WHERE (enabled = true);


-- INDEX: idx_incident_webhooks_events
CREATE INDEX IF NOT EXISTS idx_incident_webhooks_events ON public.security_incident_webhooks USING gin (events);


-- INDEX: idx_integration_audit_action
CREATE INDEX IF NOT EXISTS idx_integration_audit_action ON public.platform_integration_audit_log USING btree (action);


-- INDEX: idx_integration_audit_created_at
CREATE INDEX IF NOT EXISTS idx_integration_audit_created_at ON public.platform_integration_audit_log USING btree (created_at DESC);


-- INDEX: idx_integration_audit_integration_id
CREATE INDEX IF NOT EXISTS idx_integration_audit_integration_id ON public.platform_integration_audit_log USING btree (integration_id);


-- INDEX: idx_integration_audit_performed_by
CREATE INDEX IF NOT EXISTS idx_integration_audit_performed_by ON public.platform_integration_audit_log USING btree (performed_by);


-- INDEX: idx_integrations_tenant
CREATE INDEX IF NOT EXISTS idx_integrations_tenant ON public.integrations USING btree (tenant_id);


-- INDEX: idx_integrations_type
CREATE INDEX IF NOT EXISTS idx_integrations_type ON public.integrations USING btree (type);


-- INDEX: idx_interrogation_schedules_enabled
CREATE INDEX IF NOT EXISTS idx_interrogation_schedules_enabled ON public.interrogation_schedules USING btree (is_enabled) WHERE (deleted_at IS NULL);


-- INDEX: idx_interrogation_schedules_next_run
CREATE INDEX IF NOT EXISTS idx_interrogation_schedules_next_run ON public.interrogation_schedules USING btree (next_run_at) WHERE ((is_enabled = true) AND (deleted_at IS NULL));


-- INDEX: idx_interrogation_schedules_target
CREATE INDEX IF NOT EXISTS idx_interrogation_schedules_target ON public.interrogation_schedules USING btree (target_type, target_id);


-- INDEX: idx_interrogation_schedules_tenant_id
CREATE INDEX IF NOT EXISTS idx_interrogation_schedules_tenant_id ON public.interrogation_schedules USING btree (tenant_id);


-- INDEX: idx_invoice_line_items_invoice
CREATE INDEX IF NOT EXISTS idx_invoice_line_items_invoice ON public.billing_invoice_line_items USING btree (invoice_id);


-- INDEX: idx_invoice_line_items_type
CREATE INDEX IF NOT EXISTS idx_invoice_line_items_type ON public.billing_invoice_line_items USING btree (line_item_type);


-- INDEX: idx_keys_algorithm
CREATE INDEX IF NOT EXISTS idx_keys_algorithm ON public.keys USING btree (algorithm_id) WHERE (algorithm_id IS NOT NULL);


-- INDEX: idx_keys_jwk
CREATE INDEX IF NOT EXISTS idx_keys_jwk ON public.keys USING btree (jwk_thumbprint);


-- INDEX: idx_keys_material_type
CREATE INDEX IF NOT EXISTS idx_keys_material_type ON public.keys USING btree (material_type);


-- INDEX: idx_keys_pubfp
CREATE INDEX IF NOT EXISTS idx_keys_pubfp ON public.keys USING btree (public_fingerprint);


-- INDEX: idx_keys_state
CREATE INDEX IF NOT EXISTS idx_keys_state ON public.keys USING btree (tenant_id, state) WHERE ((state)::text <> 'active'::text);


-- INDEX: idx_keys_tenant
CREATE INDEX IF NOT EXISTS idx_keys_tenant ON public.keys USING btree (tenant_id);


-- INDEX: idx_kms_keys_algorithm
CREATE INDEX IF NOT EXISTS idx_kms_keys_algorithm ON public.kms_keys USING btree (algorithm_id) WHERE ((algorithm_id IS NOT NULL) AND (deleted_at IS NULL));


-- INDEX: idx_kms_keys_integration
CREATE INDEX IF NOT EXISTS idx_kms_keys_integration ON public.kms_keys USING btree (integration_id) WHERE (deleted_at IS NULL);


-- INDEX: idx_kms_keys_provider
CREATE INDEX IF NOT EXISTS idx_kms_keys_provider ON public.kms_keys USING btree (provider) WHERE (deleted_at IS NULL);


-- INDEX: idx_kms_keys_rotation
CREATE INDEX IF NOT EXISTS idx_kms_keys_rotation ON public.kms_keys USING btree (rotation_enabled, last_rotated_at) WHERE (deleted_at IS NULL);


-- INDEX: idx_kms_keys_state
CREATE INDEX IF NOT EXISTS idx_kms_keys_state ON public.kms_keys USING btree (key_state) WHERE (deleted_at IS NULL);


-- INDEX: idx_kms_keys_tenant
CREATE INDEX IF NOT EXISTS idx_kms_keys_tenant ON public.kms_keys USING btree (tenant_id) WHERE (deleted_at IS NULL);


-- INDEX: idx_kms_keys_unique_provider_key
CREATE UNIQUE INDEX IF NOT EXISTS idx_kms_keys_unique_provider_key ON public.kms_keys USING btree (tenant_id, provider, key_id) WHERE (deleted_at IS NULL);


-- INDEX: idx_lib_algo_algorithm
CREATE INDEX IF NOT EXISTS idx_lib_algo_algorithm ON public.library_provided_algorithms USING btree (algorithm_id);


-- INDEX: idx_locations_cloud
CREATE INDEX IF NOT EXISTS idx_locations_cloud ON public.locations USING btree (tenant_id, cloud_provider, cloud_region) WHERE (cloud_provider IS NOT NULL);


-- INDEX: idx_locations_parent_id
CREATE INDEX IF NOT EXISTS idx_locations_parent_id ON public.locations USING btree (parent_id) WHERE (parent_id IS NOT NULL);


-- INDEX: idx_locations_tenant_id
CREATE INDEX IF NOT EXISTS idx_locations_tenant_id ON public.locations USING btree (tenant_id);


-- INDEX: idx_log_access_audit_log
CREATE INDEX IF NOT EXISTS idx_log_access_audit_log ON public.platform_log_access_audit USING btree (log_id, accessed_at DESC) WHERE (log_id IS NOT NULL);


-- INDEX: idx_log_access_audit_timestamp
CREATE INDEX IF NOT EXISTS idx_log_access_audit_timestamp ON public.platform_log_access_audit USING btree (accessed_at DESC);


-- INDEX: idx_log_access_audit_type
CREATE INDEX IF NOT EXISTS idx_log_access_audit_type ON public.platform_log_access_audit USING btree (access_type, accessed_at DESC);


-- INDEX: idx_log_access_audit_user
CREATE INDEX IF NOT EXISTS idx_log_access_audit_user ON public.platform_log_access_audit USING btree (accessed_by_user_id, accessed_at DESC);


-- INDEX: idx_log_retention_jobs_status
CREATE INDEX IF NOT EXISTS idx_log_retention_jobs_status ON public.platform_log_retention_jobs USING btree (execution_status, started_at DESC);


-- INDEX: idx_log_retention_jobs_type
CREATE INDEX IF NOT EXISTS idx_log_retention_jobs_type ON public.platform_log_retention_jobs USING btree (job_type, started_at DESC);


-- INDEX: idx_maintenance_windows_status
CREATE INDEX IF NOT EXISTS idx_maintenance_windows_status ON public.maintenance_windows USING btree (status, starts_at);


-- INDEX: idx_measurement_templates_active
CREATE INDEX IF NOT EXISTS idx_measurement_templates_active ON public.measurement_templates USING btree (is_active) WHERE (is_active = true);


-- INDEX: idx_measurement_templates_category
CREATE INDEX IF NOT EXISTS idx_measurement_templates_category ON public.measurement_templates USING btree (category);


-- INDEX: idx_measurement_templates_code
CREATE INDEX IF NOT EXISTS idx_measurement_templates_code ON public.measurement_templates USING btree (code);


-- INDEX: idx_measurement_templates_framework_tags
CREATE INDEX IF NOT EXISTS idx_measurement_templates_framework_tags ON public.measurement_templates USING gin (framework_tags);


-- INDEX: idx_measurement_templates_measurement_type_id
CREATE INDEX IF NOT EXISTS idx_measurement_templates_measurement_type_id ON public.measurement_templates USING btree (measurement_type_id);


-- INDEX: idx_measurement_types_category
CREATE INDEX IF NOT EXISTS idx_measurement_types_category ON public.measurement_types USING btree (category);


-- INDEX: idx_measurement_types_code
CREATE INDEX IF NOT EXISTS idx_measurement_types_code ON public.measurement_types USING btree (code);


-- INDEX: idx_measurement_types_data_type
CREATE INDEX IF NOT EXISTS idx_measurement_types_data_type ON public.measurement_types USING btree (data_type);


-- INDEX: idx_mv_location_finding_summary_key
CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_location_finding_summary_key ON public.mv_location_finding_summary USING btree (location_id, environment);


-- INDEX: idx_mv_remediation_queue_tenant_severity
CREATE INDEX IF NOT EXISTS idx_mv_remediation_queue_tenant_severity ON public.mv_remediation_queue USING btree (tenant_id, severity, created_at);


-- INDEX: idx_network_segments_active
CREATE INDEX IF NOT EXISTS idx_network_segments_active ON public.network_segments USING btree (tenant_id, is_active) WHERE (is_active = true);


-- INDEX: idx_network_segments_location_id
CREATE INDEX IF NOT EXISTS idx_network_segments_location_id ON public.network_segments USING btree (location_id);


-- INDEX: idx_network_segments_tenant_id
CREATE INDEX IF NOT EXISTS idx_network_segments_tenant_id ON public.network_segments USING btree (tenant_id);


-- INDEX: idx_notification_delivery_queue_next_retry
CREATE INDEX IF NOT EXISTS idx_notification_delivery_queue_next_retry ON public.notification_delivery_queue USING btree (next_retry_at) WHERE ((status)::text = 'retrying'::text);


-- INDEX: idx_notification_delivery_queue_notification_id
CREATE INDEX IF NOT EXISTS idx_notification_delivery_queue_notification_id ON public.notification_delivery_queue USING btree (notification_id);


-- INDEX: idx_notification_delivery_queue_status
CREATE INDEX IF NOT EXISTS idx_notification_delivery_queue_status ON public.notification_delivery_queue USING btree (status) WHERE ((status)::text = ANY ((ARRAY['pending'::character varying, 'retrying'::character varying])::text[]));


-- INDEX: idx_notification_delivery_queue_tenant_id
CREATE INDEX IF NOT EXISTS idx_notification_delivery_queue_tenant_id ON public.notification_delivery_queue USING btree (tenant_id) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_notification_history_alert_source
CREATE INDEX IF NOT EXISTS idx_notification_history_alert_source ON public.notification_history USING btree (alert_source);


-- INDEX: idx_notification_history_alert_type
CREATE INDEX IF NOT EXISTS idx_notification_history_alert_type ON public.notification_history USING btree (alert_type);


-- INDEX: idx_notification_history_created_at
CREATE INDEX IF NOT EXISTS idx_notification_history_created_at ON public.notification_history USING btree (created_at DESC);


-- INDEX: idx_notification_history_platform
CREATE INDEX IF NOT EXISTS idx_notification_history_platform ON public.notification_history USING btree (created_at DESC) WHERE (tenant_id IS NULL);


-- INDEX: idx_notification_history_severity
CREATE INDEX IF NOT EXISTS idx_notification_history_severity ON public.notification_history USING btree (severity);


-- INDEX: idx_notification_history_tenant_created
CREATE INDEX IF NOT EXISTS idx_notification_history_tenant_created ON public.notification_history USING btree (tenant_id, created_at DESC) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_notification_history_tenant_id
CREATE INDEX IF NOT EXISTS idx_notification_history_tenant_id ON public.notification_history USING btree (tenant_id) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_pcap_upload_jobs_status
CREATE INDEX IF NOT EXISTS idx_pcap_upload_jobs_status ON public.pcap_upload_jobs USING btree (status) WHERE (status = ANY (ARRAY['pending'::text, 'processing'::text]));


-- INDEX: idx_pcap_upload_jobs_tenant
CREATE INDEX IF NOT EXISTS idx_pcap_upload_jobs_tenant ON public.pcap_upload_jobs USING btree (tenant_id, created_at DESC);


-- INDEX: idx_pending_sensors_tenant_status
CREATE INDEX IF NOT EXISTS idx_pending_sensors_tenant_status ON public.pending_sensor_registrations USING btree (tenant_id, status);


-- INDEX: idx_permission_audit_created
CREATE INDEX IF NOT EXISTS idx_permission_audit_created ON public.permission_audit_logs USING btree (created_at);


-- INDEX: idx_permission_audit_tenant
CREATE INDEX IF NOT EXISTS idx_permission_audit_tenant ON public.permission_audit_logs USING btree (tenant_id);


-- INDEX: idx_permission_audit_user
CREATE INDEX IF NOT EXISTS idx_permission_audit_user ON public.permission_audit_logs USING btree (user_id);


-- INDEX: idx_plan_items_finding
CREATE INDEX IF NOT EXISTS idx_plan_items_finding ON public.remediation_plan_items USING btree (finding_id);


-- INDEX: idx_plan_items_plan
CREATE INDEX IF NOT EXISTS idx_plan_items_plan ON public.remediation_plan_items USING btree (plan_id);


-- INDEX: idx_plan_items_ticket
CREATE INDEX IF NOT EXISTS idx_plan_items_ticket ON public.remediation_plan_items USING btree (ticket_id) WHERE (ticket_id IS NOT NULL);


-- INDEX: idx_platform_announcements_active
CREATE INDEX IF NOT EXISTS idx_platform_announcements_active ON public.platform_announcements USING btree (is_active, starts_at, expires_at);


-- INDEX: idx_platform_bootstrap_ca_active
CREATE INDEX IF NOT EXISTS idx_platform_bootstrap_ca_active ON public.platform_bootstrap_ca USING btree (is_active) WHERE (is_active = true);


-- INDEX: idx_platform_bootstrap_ca_expires_at
CREATE INDEX IF NOT EXISTS idx_platform_bootstrap_ca_expires_at ON public.platform_bootstrap_ca USING btree (expires_at);


-- INDEX: idx_platform_bootstrap_certificates_expires_at
CREATE INDEX IF NOT EXISTS idx_platform_bootstrap_certificates_expires_at ON public.platform_bootstrap_certificates USING btree (expires_at);


-- INDEX: idx_platform_bootstrap_certificates_revoked
CREATE INDEX IF NOT EXISTS idx_platform_bootstrap_certificates_revoked ON public.platform_bootstrap_certificates USING btree (service_name, revoked_at) WHERE (revoked_at IS NOT NULL);


-- INDEX: idx_platform_bootstrap_certificates_service_name
CREATE INDEX IF NOT EXISTS idx_platform_bootstrap_certificates_service_name ON public.platform_bootstrap_certificates USING btree (service_name);


-- INDEX: idx_platform_framework_controls_control_id
CREATE INDEX IF NOT EXISTS idx_platform_framework_controls_control_id ON public.platform_framework_controls USING btree (control_id);


-- INDEX: idx_platform_framework_controls_crypto_relevant
CREATE INDEX IF NOT EXISTS idx_platform_framework_controls_crypto_relevant ON public.platform_framework_controls USING btree (crypto_relevant);


-- INDEX: idx_platform_framework_controls_family_id
CREATE INDEX IF NOT EXISTS idx_platform_framework_controls_family_id ON public.platform_framework_controls USING btree (family_id);


-- INDEX: idx_platform_framework_controls_framework_id
CREATE INDEX IF NOT EXISTS idx_platform_framework_controls_framework_id ON public.platform_framework_controls USING btree (framework_id);


-- INDEX: idx_platform_frameworks_code
CREATE INDEX IF NOT EXISTS idx_platform_frameworks_code ON public.platform_frameworks USING btree (code);


-- INDEX: idx_platform_frameworks_is_platform_default
CREATE INDEX IF NOT EXISTS idx_platform_frameworks_is_platform_default ON public.platform_frameworks USING btree (is_platform_default) WHERE (is_platform_default = true);


-- INDEX: idx_platform_frameworks_published_at
CREATE INDEX IF NOT EXISTS idx_platform_frameworks_published_at ON public.platform_frameworks USING btree (published_at) WHERE ((status)::text = 'published'::text);


-- INDEX: idx_platform_frameworks_single_default
CREATE UNIQUE INDEX IF NOT EXISTS idx_platform_frameworks_single_default ON public.platform_frameworks USING btree (is_platform_default) WHERE (is_platform_default = true);


-- INDEX: idx_platform_frameworks_status
CREATE INDEX IF NOT EXISTS idx_platform_frameworks_status ON public.platform_frameworks USING btree (status);


-- INDEX: idx_platform_integrations_active
CREATE INDEX IF NOT EXISTS idx_platform_integrations_active ON public.platform_integrations USING btree (is_active) WHERE (deleted_at IS NULL);


-- INDEX: idx_platform_integrations_enabled
CREATE INDEX IF NOT EXISTS idx_platform_integrations_enabled ON public.platform_integrations USING btree (is_enabled) WHERE (is_active = true);


-- INDEX: idx_platform_integrations_shared
CREATE INDEX IF NOT EXISTS idx_platform_integrations_shared ON public.platform_integrations USING btree (is_shared) WHERE ((is_shared = true) AND (deleted_at IS NULL));


-- INDEX: idx_platform_integrations_status
CREATE INDEX IF NOT EXISTS idx_platform_integrations_status ON public.platform_integrations USING btree (status);


-- INDEX: idx_platform_integrations_tenant_id
CREATE INDEX IF NOT EXISTS idx_platform_integrations_tenant_id ON public.platform_integrations USING btree (tenant_id) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_platform_integrations_type
CREATE INDEX IF NOT EXISTS idx_platform_integrations_type ON public.platform_integrations USING btree (integration_type);


-- INDEX: idx_platform_integrations_unique_name
CREATE UNIQUE INDEX IF NOT EXISTS idx_platform_integrations_unique_name ON public.platform_integrations USING btree (integration_type, integration_name) WHERE (deleted_at IS NULL);


-- INDEX: idx_platform_log_metadata_compliance
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_compliance ON public.platform_log_metadata USING gin (compliance_tags);


-- INDEX: idx_platform_log_metadata_correlation_id
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_correlation_id ON public.platform_log_metadata USING btree (correlation_id, "timestamp" DESC);


-- INDEX: idx_platform_log_metadata_event_type
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_event_type ON public.platform_log_metadata USING btree (event_type, "timestamp" DESC);


-- INDEX: idx_platform_log_metadata_pii
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_pii ON public.platform_log_metadata USING btree (pii_detected, "timestamp" DESC) WHERE (pii_detected = true);


-- INDEX: idx_platform_log_metadata_retention
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_retention ON public.platform_log_metadata USING btree (retention_policy, archived_at, deleted_at);


-- INDEX: idx_platform_log_metadata_service
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_service ON public.platform_log_metadata USING btree (service_name, "timestamp" DESC);


-- INDEX: idx_platform_log_metadata_severity
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_severity ON public.platform_log_metadata USING btree (severity, "timestamp" DESC);


-- INDEX: idx_platform_log_metadata_status
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_status ON public.platform_log_metadata USING btree (status, "timestamp" DESC);


-- INDEX: idx_platform_log_metadata_tenant
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_tenant ON public.platform_log_metadata USING btree (tenant_id, "timestamp" DESC) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_platform_log_metadata_timestamp
CREATE INDEX IF NOT EXISTS idx_platform_log_metadata_timestamp ON public.platform_log_metadata USING btree ("timestamp" DESC);


-- INDEX: idx_platform_metrics_service_time
CREATE INDEX IF NOT EXISTS idx_platform_metrics_service_time ON public.platform_metrics_snapshots USING btree (service_name, window_start DESC);


-- INDEX: idx_platform_metrics_service_window
CREATE INDEX IF NOT EXISTS idx_platform_metrics_service_window ON public.platform_metrics_snapshots USING btree (service_name, window_duration, window_start DESC);


-- INDEX: idx_platform_metrics_window
CREATE INDEX IF NOT EXISTS idx_platform_metrics_window ON public.platform_metrics_snapshots USING btree (window_start DESC, window_duration);


-- INDEX: idx_platform_notification_channels_enabled
CREATE INDEX IF NOT EXISTS idx_platform_notification_channels_enabled ON public.platform_notification_channels USING btree (enabled) WHERE (enabled = true);


-- INDEX: idx_platform_notification_channels_type
CREATE INDEX IF NOT EXISTS idx_platform_notification_channels_type ON public.platform_notification_channels USING btree (channel_type);


-- INDEX: idx_platform_notification_rules_alert_source
CREATE INDEX IF NOT EXISTS idx_platform_notification_rules_alert_source ON public.platform_notification_rules USING btree (alert_source);


-- INDEX: idx_platform_notification_rules_enabled
CREATE INDEX IF NOT EXISTS idx_platform_notification_rules_enabled ON public.platform_notification_rules USING btree (enabled) WHERE (enabled = true);


-- INDEX: idx_platform_notification_rules_priority
CREATE INDEX IF NOT EXISTS idx_platform_notification_rules_priority ON public.platform_notification_rules USING btree (priority DESC);


-- INDEX: idx_platform_refresh_tokens_expires_at
CREATE INDEX IF NOT EXISTS idx_platform_refresh_tokens_expires_at ON public.platform_refresh_tokens USING btree (expires_at);


-- INDEX: idx_platform_refresh_tokens_family_id
CREATE INDEX IF NOT EXISTS idx_platform_refresh_tokens_family_id ON public.platform_refresh_tokens USING btree (family_id);


-- INDEX: idx_platform_refresh_tokens_user_id
CREATE INDEX IF NOT EXISTS idx_platform_refresh_tokens_user_id ON public.platform_refresh_tokens USING btree (platform_user_id);


-- INDEX: idx_platform_role_permissions_permission
CREATE INDEX IF NOT EXISTS idx_platform_role_permissions_permission ON public.platform_role_permissions USING btree (permission_id);


-- INDEX: idx_platform_role_permissions_role
CREATE INDEX IF NOT EXISTS idx_platform_role_permissions_role ON public.platform_role_permissions USING btree (role_id);


-- INDEX: idx_platform_service_ca_active
CREATE INDEX IF NOT EXISTS idx_platform_service_ca_active ON public.platform_service_ca USING btree (is_active) WHERE (is_active = true);


-- INDEX: idx_platform_service_ca_expires_at
CREATE INDEX IF NOT EXISTS idx_platform_service_ca_expires_at ON public.platform_service_ca USING btree (expires_at);


-- INDEX: idx_platform_service_certificates_expires_at
CREATE INDEX IF NOT EXISTS idx_platform_service_certificates_expires_at ON public.platform_service_certificates USING btree (expires_at);


-- INDEX: idx_platform_service_certificates_revoked
CREATE INDEX IF NOT EXISTS idx_platform_service_certificates_revoked ON public.platform_service_certificates USING btree (service_name, revoked_at) WHERE (revoked_at IS NOT NULL);


-- INDEX: idx_platform_service_certificates_service_name
CREATE INDEX IF NOT EXISTS idx_platform_service_certificates_service_name ON public.platform_service_certificates USING btree (service_name);


-- INDEX: idx_platform_settings_key
CREATE INDEX IF NOT EXISTS idx_platform_settings_key ON public.platform_settings USING btree (setting_key);


-- INDEX: uq_platform_sso_provider_type_purpose
-- One provider row per (provider_type, purpose) — see the note on the purpose
-- column. This replaced a provider_type-only UNIQUE constraint, which allowed
-- only ONE google row across both purposes.
CREATE UNIQUE INDEX IF NOT EXISTS uq_platform_sso_provider_type_purpose ON public.platform_sso_providers USING btree (provider_type, purpose);


-- INDEX: idx_platform_sso_providers_enabled
CREATE INDEX IF NOT EXISTS idx_platform_sso_providers_enabled ON public.platform_sso_providers USING btree (is_enabled) WHERE (is_enabled = true);


-- INDEX: idx_platform_users_email
CREATE INDEX IF NOT EXISTS idx_platform_users_email ON public.platform_users USING btree (email) WHERE (deleted_at IS NULL);


-- INDEX: idx_platform_users_reset_token
CREATE INDEX IF NOT EXISTS idx_platform_users_reset_token ON public.platform_users USING btree (password_reset_token) WHERE (password_reset_token IS NOT NULL);


-- INDEX: idx_platform_users_role
CREATE INDEX IF NOT EXISTS idx_platform_users_role ON public.platform_users USING btree (role_id) WHERE (deleted_at IS NULL);


-- INDEX: idx_refresh_tokens_expires_at
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_expires_at ON public.refresh_tokens USING btree (expires_at);


-- INDEX: idx_refresh_tokens_family_id
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_family_id ON public.refresh_tokens USING btree (family_id);


-- INDEX: idx_refresh_tokens_user_id
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


-- INDEX: idx_remediation_plans_description_trgm
CREATE INDEX IF NOT EXISTS idx_remediation_plans_description_trgm ON public.remediation_plans USING gin (description public.gin_trgm_ops);


-- INDEX: idx_remediation_plans_owner
CREATE INDEX IF NOT EXISTS idx_remediation_plans_owner ON public.remediation_plans USING btree (tenant_id, owner_id) WHERE (owner_id IS NOT NULL);


-- INDEX: idx_remediation_plans_target_date
CREATE INDEX IF NOT EXISTS idx_remediation_plans_target_date ON public.remediation_plans USING btree (tenant_id, target_date) WHERE (target_date IS NOT NULL);


-- INDEX: idx_remediation_plans_tenant
CREATE INDEX IF NOT EXISTS idx_remediation_plans_tenant ON public.remediation_plans USING btree (tenant_id);


-- INDEX: idx_remediation_plans_tenant_status
CREATE INDEX IF NOT EXISTS idx_remediation_plans_tenant_status ON public.remediation_plans USING btree (tenant_id, status);


-- INDEX: idx_remediation_plans_title_trgm
CREATE INDEX IF NOT EXISTS idx_remediation_plans_title_trgm ON public.remediation_plans USING gin (title public.gin_trgm_ops);


-- INDEX: idx_resource_alerts_is_active
CREATE INDEX IF NOT EXISTS idx_resource_alerts_is_active ON public.resource_alerts USING btree (is_active);


-- INDEX: idx_resource_alerts_severity
CREATE INDEX IF NOT EXISTS idx_resource_alerts_severity ON public.resource_alerts USING btree (severity);


-- INDEX: idx_resource_alerts_tenant_id
CREATE INDEX IF NOT EXISTS idx_resource_alerts_tenant_id ON public.resource_alerts USING btree (tenant_id);


-- INDEX: idx_rule_vulnerability_mappings_finding_type
CREATE INDEX IF NOT EXISTS idx_rule_vulnerability_mappings_finding_type ON public.rule_vulnerability_mappings USING btree (finding_type);


-- INDEX: idx_rule_vulnerability_mappings_framework_id
CREATE INDEX IF NOT EXISTS idx_rule_vulnerability_mappings_framework_id ON public.rule_vulnerability_mappings USING btree (framework_id);


-- INDEX: idx_rule_vulnerability_mappings_predicate
CREATE INDEX IF NOT EXISTS idx_rule_vulnerability_mappings_predicate ON public.rule_vulnerability_mappings USING gin (predicate);


-- INDEX: idx_rule_vulnerability_mappings_rule_id
CREATE INDEX IF NOT EXISTS idx_rule_vulnerability_mappings_rule_id ON public.rule_vulnerability_mappings USING btree (rule_id);


-- INDEX: idx_schedule_history_job_id
CREATE INDEX IF NOT EXISTS idx_schedule_history_job_id ON public.schedule_history USING btree (job_id);


-- INDEX: idx_schedule_history_schedule_id
CREATE INDEX IF NOT EXISTS idx_schedule_history_schedule_id ON public.schedule_history USING btree (schedule_id);


-- INDEX: idx_schedule_history_started_at
CREATE INDEX IF NOT EXISTS idx_schedule_history_started_at ON public.schedule_history USING btree (started_at DESC);


-- INDEX: idx_security_incidents_assigned
CREATE INDEX IF NOT EXISTS idx_security_incidents_assigned ON public.security_incidents USING btree (assigned_to, status) WHERE (assigned_to IS NOT NULL);


-- INDEX: idx_security_incidents_detected
CREATE INDEX IF NOT EXISTS idx_security_incidents_detected ON public.security_incidents USING btree (detected_at DESC);


-- INDEX: idx_security_incidents_severity
CREATE INDEX IF NOT EXISTS idx_security_incidents_severity ON public.security_incidents USING btree (severity, detected_at DESC);


-- INDEX: idx_security_incidents_status
CREATE INDEX IF NOT EXISTS idx_security_incidents_status ON public.security_incidents USING btree (status, severity, detected_at DESC);


-- INDEX: idx_security_incidents_tenant
CREATE INDEX IF NOT EXISTS idx_security_incidents_tenant ON public.security_incidents USING gin (affected_tenants);


-- INDEX: idx_sensor_ca_certificates_active
CREATE INDEX IF NOT EXISTS idx_sensor_ca_certificates_active ON public.sensor_ca_certificates USING btree (tenant_id, is_active) WHERE (is_active = true);


-- INDEX: idx_sensor_ca_certificates_expires_at
CREATE INDEX IF NOT EXISTS idx_sensor_ca_certificates_expires_at ON public.sensor_ca_certificates USING btree (expires_at);


-- INDEX: idx_sensor_ca_certificates_tenant_id
CREATE INDEX IF NOT EXISTS idx_sensor_ca_certificates_tenant_id ON public.sensor_ca_certificates USING btree (tenant_id);


-- INDEX: idx_sensor_certificates_expires_at
CREATE INDEX IF NOT EXISTS idx_sensor_certificates_expires_at ON public.sensor_certificates USING btree (expires_at);


-- INDEX: idx_sensor_certificates_revoked
CREATE INDEX IF NOT EXISTS idx_sensor_certificates_revoked ON public.sensor_certificates USING btree (sensor_id, revoked_at) WHERE (revoked_at IS NOT NULL);


-- INDEX: idx_sensor_certificates_sensor_id
CREATE INDEX IF NOT EXISTS idx_sensor_certificates_sensor_id ON public.sensor_certificates USING btree (sensor_id);


-- INDEX: idx_sensor_certificates_tenant_id
CREATE INDEX IF NOT EXISTS idx_sensor_certificates_tenant_id ON public.sensor_certificates USING btree (tenant_id);


-- INDEX: idx_sensor_commands_created_at
CREATE INDEX IF NOT EXISTS idx_sensor_commands_created_at ON public.sensor_commands USING btree (created_at);


-- INDEX: idx_sensor_commands_sensor_id
CREATE INDEX IF NOT EXISTS idx_sensor_commands_sensor_id ON public.sensor_commands USING btree (sensor_id);


-- INDEX: idx_sensor_commands_status
CREATE INDEX IF NOT EXISTS idx_sensor_commands_status ON public.sensor_commands USING btree (status);


-- INDEX: idx_sensor_discoveries_partitioned_batch_id
CREATE INDEX IF NOT EXISTS idx_sensor_discoveries_partitioned_batch_id ON ONLY public.sensor_discoveries_partitioned USING btree (batch_id);


-- INDEX: idx_sensor_discoveries_partitioned_dest_ip
CREATE INDEX IF NOT EXISTS idx_sensor_discoveries_partitioned_dest_ip ON ONLY public.sensor_discoveries_partitioned USING btree (dest_ip);


-- INDEX: idx_sensor_discoveries_partitioned_protocol
CREATE INDEX IF NOT EXISTS idx_sensor_discoveries_partitioned_protocol ON ONLY public.sensor_discoveries_partitioned USING btree (protocol);


-- INDEX: idx_sensor_discoveries_part_unprocessed
-- The poller's index. Partial, so it holds only rows that are still work: on a
-- healthy system that is near-empty and the poll is O(1) rather than O(all
-- discoveries ever).
CREATE INDEX IF NOT EXISTS idx_sensor_discoveries_part_unprocessed ON public.sensor_discoveries_partitioned USING btree (batch_id, tenant_id) WHERE (processed_at IS NULL);


-- INDEX: idx_sensor_discoveries_part_sensor_timestamp
-- sensor-manager ListSensorDiscoveries: WHERE sensor_id = $1 ORDER BY timestamp
-- DESC LIMIT $2 — the composite serves both the filter and the sort.
CREATE INDEX IF NOT EXISTS idx_sensor_discoveries_part_sensor_timestamp ON public.sensor_discoveries_partitioned USING btree (sensor_id, "timestamp" DESC);


-- INDEX: idx_sensor_discoveries_part_claimed
-- Candidate selection reads `claimed_at IS NULL OR claimed_at < now() - ...`
-- alongside `processed_at IS NULL`; same partial shape.
CREATE INDEX IF NOT EXISTS idx_sensor_discoveries_part_claimed ON public.sensor_discoveries_partitioned USING btree (claimed_at) WHERE (processed_at IS NULL);


-- INDEX: idx_sensor_discoveries_partitioned_sensor_id
CREATE INDEX IF NOT EXISTS idx_sensor_discoveries_partitioned_sensor_id ON ONLY public.sensor_discoveries_partitioned USING btree (sensor_id);


-- INDEX: idx_sensor_discoveries_partitioned_tenant_id
CREATE INDEX IF NOT EXISTS idx_sensor_discoveries_partitioned_tenant_id ON ONLY public.sensor_discoveries_partitioned USING btree (tenant_id);


-- INDEX: idx_sensor_discoveries_partitioned_timestamp
CREATE INDEX IF NOT EXISTS idx_sensor_discoveries_partitioned_timestamp ON ONLY public.sensor_discoveries_partitioned USING btree ("timestamp");


-- INDEX: idx_sensor_health_metrics_recorded_at
CREATE INDEX IF NOT EXISTS idx_sensor_health_metrics_recorded_at ON public.sensor_health_metrics USING btree (recorded_at);


-- INDEX: idx_sensor_health_metrics_sensor_id
CREATE INDEX IF NOT EXISTS idx_sensor_health_metrics_sensor_id ON public.sensor_health_metrics USING btree (sensor_id);


-- INDEX: idx_sensors_deleted_at
CREATE INDEX IF NOT EXISTS idx_sensors_deleted_at ON public.sensors USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: idx_sensors_ip_address
CREATE INDEX IF NOT EXISTS idx_sensors_ip_address ON public.sensors USING btree (ip_address);


-- INDEX: idx_sensors_last_heartbeat
CREATE INDEX IF NOT EXISTS idx_sensors_last_heartbeat ON public.sensors USING btree (last_heartbeat);


-- INDEX: idx_sensors_sensor_type
CREATE INDEX IF NOT EXISTS idx_sensors_sensor_type ON public.sensors USING btree (sensor_type);


-- INDEX: idx_sensors_status
CREATE INDEX IF NOT EXISTS idx_sensors_status ON public.sensors USING btree (status);


-- INDEX: idx_sensors_tenant_id
CREATE INDEX IF NOT EXISTS idx_sensors_tenant_id ON public.sensors USING btree (tenant_id);


-- INDEX: idx_service_accounts_is_active
CREATE INDEX IF NOT EXISTS idx_service_accounts_is_active ON public.service_accounts USING btree (is_active) WHERE (is_active = true);


-- INDEX: idx_service_accounts_service_name
CREATE INDEX IF NOT EXISTS idx_service_accounts_service_name ON public.service_accounts USING btree (service_name);


-- INDEX: idx_service_identification_rules_port_protocol
CREATE INDEX IF NOT EXISTS idx_service_identification_rules_port_protocol ON public.service_identification_rules USING btree (port, protocol);


-- INDEX: idx_service_identification_rules_tenant
CREATE INDEX IF NOT EXISTS idx_service_identification_rules_tenant ON public.service_identification_rules USING btree (tenant_id) WHERE (tenant_id IS NOT NULL);


-- INDEX: idx_ssh_keys_asset
CREATE INDEX IF NOT EXISTS idx_ssh_keys_asset ON public.ssh_keys USING btree (asset_id) WHERE ((asset_id IS NOT NULL) AND (deleted_at IS NULL));


-- INDEX: idx_ssh_keys_tenant
CREATE INDEX IF NOT EXISTS idx_ssh_keys_tenant ON public.ssh_keys USING btree (tenant_id) WHERE (deleted_at IS NULL);


-- INDEX: idx_ssh_keys_type
CREATE INDEX IF NOT EXISTS idx_ssh_keys_type ON public.ssh_keys USING btree (key_type) WHERE (deleted_at IS NULL);


-- INDEX: idx_ssh_keys_unique_fingerprint
CREATE UNIQUE INDEX IF NOT EXISTS idx_ssh_keys_unique_fingerprint ON public.ssh_keys USING btree (tenant_id, fingerprint_sha256) WHERE (deleted_at IS NULL);


-- INDEX: idx_ssh_keys_weak
CREATE INDEX IF NOT EXISTS idx_ssh_keys_weak ON public.ssh_keys USING btree (is_weak) WHERE ((is_weak = true) AND (deleted_at IS NULL));


-- INDEX: idx_sso_group_role_mappings_provider
CREATE INDEX IF NOT EXISTS idx_sso_group_role_mappings_provider ON public.sso_group_role_mappings USING btree (sso_provider_id);


-- INDEX: idx_sso_group_role_mappings_tenant
CREATE INDEX IF NOT EXISTS idx_sso_group_role_mappings_tenant ON public.sso_group_role_mappings USING btree (tenant_id);


-- INDEX: idx_sso_providers_tenant_id
CREATE INDEX IF NOT EXISTS idx_sso_providers_tenant_id ON public.sso_providers USING btree (tenant_id);


-- INDEX: idx_sso_providers_type
CREATE INDEX IF NOT EXISTS idx_sso_providers_type ON public.sso_providers USING btree (provider_type);


-- INDEX: idx_subscription_tier_history_change_type
CREATE INDEX IF NOT EXISTS idx_subscription_tier_history_change_type ON public.subscription_tier_history USING btree (change_type);


-- INDEX: idx_subscription_tier_history_changed_at
CREATE INDEX IF NOT EXISTS idx_subscription_tier_history_changed_at ON public.subscription_tier_history USING btree (changed_at);


-- INDEX: idx_subscription_tier_history_tier_id
CREATE INDEX IF NOT EXISTS idx_subscription_tier_history_tier_id ON public.subscription_tier_history USING btree (tier_id);


-- INDEX: idx_subscription_tiers_active
CREATE INDEX IF NOT EXISTS idx_subscription_tiers_active ON public.subscription_tiers USING btree (is_active, deprecated_at) WHERE ((is_active = true) AND (deprecated_at IS NULL));


-- INDEX: idx_subscription_tiers_owner_tenant
CREATE INDEX IF NOT EXISTS idx_subscription_tiers_owner_tenant ON public.subscription_tiers USING btree (owner_tenant_id) WHERE (owner_tenant_id IS NOT NULL);


-- INDEX: idx_subscription_tiers_display_order
CREATE INDEX IF NOT EXISTS idx_subscription_tiers_display_order ON public.subscription_tiers USING btree (display_order) WHERE (deprecated_at IS NULL);


-- INDEX: idx_subscription_tiers_stripe_price_annual
CREATE INDEX IF NOT EXISTS idx_subscription_tiers_stripe_price_annual ON public.subscription_tiers USING btree (stripe_price_id_annual) WHERE (stripe_price_id_annual IS NOT NULL);


-- INDEX: idx_support_ticket_messages_ticket
CREATE INDEX IF NOT EXISTS idx_support_ticket_messages_ticket ON public.support_ticket_messages USING btree (ticket_id);


-- INDEX: idx_support_tickets_status
CREATE INDEX IF NOT EXISTS idx_support_tickets_status ON public.support_tickets USING btree (status);


-- INDEX: idx_support_tickets_tenant
CREATE INDEX IF NOT EXISTS idx_support_tickets_tenant ON public.support_tickets USING btree (tenant_id);


-- INDEX: idx_tenant_admin_settings_audit_tenant_time
CREATE INDEX IF NOT EXISTS idx_tenant_admin_settings_audit_tenant_time ON public.tenant_admin_settings_audit USING btree (tenant_id, created_at DESC);


-- INDEX: idx_tenant_admin_settings_audit_user
CREATE INDEX IF NOT EXISTS idx_tenant_admin_settings_audit_user ON public.tenant_admin_settings_audit USING btree (changed_by, created_at DESC);


-- INDEX: idx_tenant_admin_settings_tenant_id
CREATE INDEX IF NOT EXISTS idx_tenant_admin_settings_tenant_id ON public.tenant_admin_settings USING btree (tenant_id);


-- INDEX: idx_tenant_admin_settings_version
CREATE INDEX IF NOT EXISTS idx_tenant_admin_settings_version ON public.tenant_admin_settings USING btree (tenant_id, version);


-- INDEX: idx_tenant_cost_summary_unique
CREATE UNIQUE INDEX IF NOT EXISTS idx_tenant_cost_summary_unique ON public.tenant_cost_summary USING btree (tenant_id, cost_date);


-- INDEX: idx_tenant_framework_controls_control_id
CREATE INDEX IF NOT EXISTS idx_tenant_framework_controls_control_id ON public.tenant_framework_controls USING btree (control_id);


-- INDEX: idx_tenant_framework_controls_crypto_relevant
CREATE INDEX IF NOT EXISTS idx_tenant_framework_controls_crypto_relevant ON public.tenant_framework_controls USING btree (crypto_relevant);


-- INDEX: idx_tenant_framework_controls_family_id
CREATE INDEX IF NOT EXISTS idx_tenant_framework_controls_family_id ON public.tenant_framework_controls USING btree (family_id);


-- INDEX: idx_tenant_framework_controls_framework_id
CREATE INDEX IF NOT EXISTS idx_tenant_framework_controls_framework_id ON public.tenant_framework_controls USING btree (framework_id);


-- INDEX: idx_tenant_framework_licenses_expires
CREATE INDEX IF NOT EXISTS idx_tenant_framework_licenses_expires ON public.tenant_framework_licenses USING btree (subscription_expires_at) WHERE (subscription_expires_at IS NOT NULL);


-- INDEX: idx_tenant_framework_licenses_is_default
CREATE INDEX IF NOT EXISTS idx_tenant_framework_licenses_is_default ON public.tenant_framework_licenses USING btree (tenant_id, is_default) WHERE (is_default = true);


-- INDEX: idx_tenant_framework_licenses_is_locked
CREATE INDEX IF NOT EXISTS idx_tenant_framework_licenses_is_locked ON public.tenant_framework_licenses USING btree (tenant_id, is_locked);


-- INDEX: idx_tenant_framework_licenses_platform_framework_id
CREATE INDEX IF NOT EXISTS idx_tenant_framework_licenses_platform_framework_id ON public.tenant_framework_licenses USING btree (platform_framework_id);


-- INDEX: idx_tenant_framework_licenses_subscription_status
CREATE INDEX IF NOT EXISTS idx_tenant_framework_licenses_subscription_status ON public.tenant_framework_licenses USING btree (tenant_id, subscription_status);


-- INDEX: idx_tenant_framework_licenses_tenant_id
CREATE INDEX IF NOT EXISTS idx_tenant_framework_licenses_tenant_id ON public.tenant_framework_licenses USING btree (tenant_id);


-- INDEX: idx_tenant_frameworks_name
CREATE INDEX IF NOT EXISTS idx_tenant_frameworks_name ON public.tenant_frameworks USING btree (name);


-- INDEX: idx_tenant_frameworks_source_framework_id
CREATE INDEX IF NOT EXISTS idx_tenant_frameworks_source_framework_id ON public.tenant_frameworks USING btree (source_framework_id);


-- INDEX: idx_tenant_frameworks_tenant_id
CREATE INDEX IF NOT EXISTS idx_tenant_frameworks_tenant_id ON public.tenant_frameworks USING btree (tenant_id);


-- INDEX: idx_tenant_geo_country
CREATE INDEX IF NOT EXISTS idx_tenant_geo_country ON public.tenant_geographic_data USING btree (country_code);


-- INDEX: idx_tenant_geo_tenant_id
CREATE INDEX IF NOT EXISTS idx_tenant_geo_tenant_id ON public.tenant_geographic_data USING btree (tenant_id);


-- INDEX: idx_tenant_health_health_status
CREATE INDEX IF NOT EXISTS idx_tenant_health_health_status ON public.tenant_health USING btree (health_status);


-- INDEX: idx_tenant_health_last_calculated
CREATE INDEX IF NOT EXISTS idx_tenant_health_last_calculated ON public.tenant_health USING btree (last_calculated);


-- INDEX: idx_tenant_health_overall_score
CREATE INDEX IF NOT EXISTS idx_tenant_health_overall_score ON public.tenant_health USING btree (overall_score);


-- INDEX: idx_tenant_health_tenant_id
CREATE INDEX IF NOT EXISTS idx_tenant_health_tenant_id ON public.tenant_health USING btree (tenant_id);


-- INDEX: idx_tenant_measurement_overrides_measurement
CREATE INDEX IF NOT EXISTS idx_tenant_measurement_overrides_measurement ON public.tenant_measurement_overrides USING btree (control_measurement_id);


-- INDEX: idx_tenant_measurement_overrides_tenant
CREATE INDEX IF NOT EXISTS idx_tenant_measurement_overrides_tenant ON public.tenant_measurement_overrides USING btree (tenant_id);


-- INDEX: idx_tenant_notes_tenant
CREATE INDEX IF NOT EXISTS idx_tenant_notes_tenant ON public.tenant_notes USING btree (tenant_id);


-- INDEX: idx_tenant_notification_channels_enabled
CREATE INDEX IF NOT EXISTS idx_tenant_notification_channels_enabled ON public.tenant_notification_channels USING btree (enabled) WHERE (enabled = true);


-- INDEX: idx_tenant_notification_channels_tenant_id
CREATE INDEX IF NOT EXISTS idx_tenant_notification_channels_tenant_id ON public.tenant_notification_channels USING btree (tenant_id);


-- INDEX: idx_tenant_notification_channels_type
CREATE INDEX IF NOT EXISTS idx_tenant_notification_channels_type ON public.tenant_notification_channels USING btree (channel_type);


-- INDEX: idx_tenant_notification_rules_alert_source
CREATE INDEX IF NOT EXISTS idx_tenant_notification_rules_alert_source ON public.tenant_notification_rules USING btree (alert_source);


-- INDEX: idx_tenant_notification_rules_enabled
CREATE INDEX IF NOT EXISTS idx_tenant_notification_rules_enabled ON public.tenant_notification_rules USING btree (enabled) WHERE (enabled = true);


-- INDEX: idx_tenant_notification_rules_priority
CREATE INDEX IF NOT EXISTS idx_tenant_notification_rules_priority ON public.tenant_notification_rules USING btree (priority DESC);


-- INDEX: idx_tenant_notification_rules_tenant_id
CREATE INDEX IF NOT EXISTS idx_tenant_notification_rules_tenant_id ON public.tenant_notification_rules USING btree (tenant_id);


-- INDEX: idx_tenant_resource_usage_tenant_cost
CREATE INDEX IF NOT EXISTS idx_tenant_resource_usage_tenant_cost ON public.tenant_resource_usage USING btree (tenant_id, "timestamp") WHERE (cost_usd > (0)::numeric);


-- INDEX: idx_tenant_resource_usage_tenant_id
CREATE INDEX IF NOT EXISTS idx_tenant_resource_usage_tenant_id ON public.tenant_resource_usage USING btree (tenant_id);


-- INDEX: idx_tenant_resource_usage_tenant_timestamp
CREATE INDEX IF NOT EXISTS idx_tenant_resource_usage_tenant_timestamp ON public.tenant_resource_usage USING btree (tenant_id, "timestamp");


-- INDEX: idx_tenant_resource_usage_timestamp
CREATE INDEX IF NOT EXISTS idx_tenant_resource_usage_timestamp ON public.tenant_resource_usage USING btree ("timestamp");


-- INDEX: idx_tenant_role_permissions_permission
CREATE INDEX IF NOT EXISTS idx_tenant_role_permissions_permission ON public.tenant_role_permissions USING btree (permission_id);


-- INDEX: idx_tenant_role_permissions_role
CREATE INDEX IF NOT EXISTS idx_tenant_role_permissions_role ON public.tenant_role_permissions USING btree (role_id);


-- INDEX: idx_tenant_roles_tenant
CREATE INDEX IF NOT EXISTS idx_tenant_roles_tenant ON public.tenant_roles USING btree (tenant_id);


-- INDEX: idx_tenant_usage_period
CREATE INDEX IF NOT EXISTS idx_tenant_usage_period ON public.tenant_usage USING btree (billing_period_start, billing_period_end);


-- INDEX: idx_tenant_usage_tenant_id
CREATE INDEX IF NOT EXISTS idx_tenant_usage_tenant_id ON public.tenant_usage USING btree (tenant_id);


-- INDEX: idx_tenants_deleted_at
CREATE INDEX IF NOT EXISTS idx_tenants_deleted_at ON public.tenants USING btree (deleted_at) WHERE (deleted_at IS NULL);


-- INDEX: idx_tenants_onboarding_status
CREATE INDEX IF NOT EXISTS idx_tenants_onboarding_status ON public.tenants USING btree (onboarding_status) WHERE ((onboarding_status)::text <> 'onboarding_complete'::text);


-- INDEX: idx_tenants_slug
CREATE INDEX IF NOT EXISTS idx_tenants_slug ON public.tenants USING btree (slug);


-- INDEX: idx_tenants_subscription_tier
CREATE INDEX IF NOT EXISTS idx_tenants_subscription_tier ON public.tenants USING btree (subscription_tier_id);


-- INDEX: idx_ticket_comments_ticket
CREATE INDEX IF NOT EXISTS idx_ticket_comments_ticket ON public.ticket_comments USING btree (ticket_id);


-- INDEX: idx_tickets_asset
CREATE INDEX IF NOT EXISTS idx_tickets_asset ON public.tickets USING btree (asset_id) WHERE (asset_id IS NOT NULL);


-- INDEX: idx_tickets_certificate
CREATE INDEX IF NOT EXISTS idx_tickets_certificate ON public.tickets USING btree (certificate_id) WHERE (certificate_id IS NOT NULL);


-- INDEX: idx_tickets_finding
CREATE INDEX IF NOT EXISTS idx_tickets_finding ON public.tickets USING btree (finding_id) WHERE (finding_id IS NOT NULL);


-- INDEX: idx_tickets_tenant
CREATE INDEX IF NOT EXISTS idx_tickets_tenant ON public.tickets USING btree (tenant_id);


-- INDEX: idx_tickets_tenant_assigned
CREATE INDEX IF NOT EXISTS idx_tickets_tenant_assigned ON public.tickets USING btree (tenant_id, assigned_to) WHERE (assigned_to IS NOT NULL);


-- INDEX: idx_tickets_tenant_category
CREATE INDEX IF NOT EXISTS idx_tickets_tenant_category ON public.tickets USING btree (tenant_id, category);


-- INDEX: idx_tickets_tenant_due
CREATE INDEX IF NOT EXISTS idx_tickets_tenant_due ON public.tickets USING btree (tenant_id, due_date) WHERE (due_date IS NOT NULL);


-- INDEX: idx_tickets_tenant_status
CREATE INDEX IF NOT EXISTS idx_tickets_tenant_status ON public.tickets USING btree (tenant_id, status);


-- INDEX: idx_trial_tracking_notifications
CREATE INDEX IF NOT EXISTS idx_trial_tracking_notifications ON public.billing_trial_tracking USING btree (trial_end, notification_7days_sent, notification_1day_sent) WHERE (converted_to_paid = false);


-- INDEX: idx_trial_tracking_tenant
CREATE INDEX IF NOT EXISTS idx_trial_tracking_tenant ON public.billing_trial_tracking USING btree (tenant_id);


-- INDEX: idx_trial_tracking_trial_end
CREATE INDEX IF NOT EXISTS idx_trial_tracking_trial_end ON public.billing_trial_tracking USING btree (trial_end) WHERE (converted_to_paid = false);


-- INDEX: idx_user_auth_methods_external_id
CREATE INDEX IF NOT EXISTS idx_user_auth_methods_external_id ON public.user_auth_methods USING btree (external_user_id);


-- INDEX: idx_user_auth_methods_user_id
CREATE INDEX IF NOT EXISTS idx_user_auth_methods_user_id ON public.user_auth_methods USING btree (user_id);


-- INDEX: idx_user_framework_preferences_framework
CREATE INDEX IF NOT EXISTS idx_user_framework_preferences_framework ON public.user_framework_preferences USING btree (framework_id);


-- INDEX: idx_user_framework_preferences_user_tenant
CREATE INDEX IF NOT EXISTS idx_user_framework_preferences_user_tenant ON public.user_framework_preferences USING btree (user_id, tenant_id);


-- INDEX: idx_user_tenant_roles_role
CREATE INDEX IF NOT EXISTS idx_user_tenant_roles_role ON public.user_tenant_roles USING btree (role_id);


-- INDEX: idx_user_tenant_roles_tenant
CREATE INDEX IF NOT EXISTS idx_user_tenant_roles_tenant ON public.user_tenant_roles USING btree (tenant_id);


-- INDEX: idx_user_tenant_roles_user
CREATE INDEX IF NOT EXISTS idx_user_tenant_roles_user ON public.user_tenant_roles USING btree (user_id);


-- INDEX: idx_user_workflow_progress_user_id
CREATE INDEX IF NOT EXISTS idx_user_workflow_progress_user_id ON public.user_workflow_progress USING btree (user_id);


-- INDEX: idx_user_workflow_progress_workflow_id
CREATE INDEX IF NOT EXISTS idx_user_workflow_progress_workflow_id ON public.user_workflow_progress USING btree (workflow_configuration_id);


-- INDEX: idx_users_email
CREATE INDEX IF NOT EXISTS idx_users_email ON public.users USING btree (email);


-- INDEX: idx_users_email_verification_token
CREATE INDEX IF NOT EXISTS idx_users_email_verification_token ON public.users USING btree (email_verification_token) WHERE (email_verification_token IS NOT NULL);


-- INDEX: idx_users_eula_accepted_at
CREATE INDEX IF NOT EXISTS idx_users_eula_accepted_at ON public.users USING btree (eula_accepted_at) WHERE (eula_accepted_at IS NOT NULL);


-- INDEX: idx_users_password_reset_token
CREATE INDEX IF NOT EXISTS idx_users_password_reset_token ON public.users USING btree (password_reset_token) WHERE (password_reset_token IS NOT NULL);


-- INDEX: idx_users_tenant_id
CREATE INDEX IF NOT EXISTS idx_users_tenant_id ON public.users USING btree (tenant_id);


-- INDEX: idx_webhook_deliveries_incident
CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_incident ON public.security_incident_webhook_deliveries USING btree (incident_id, created_at DESC);


-- INDEX: idx_webhook_deliveries_status
CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_status ON public.security_incident_webhook_deliveries USING btree (status, created_at DESC);


-- INDEX: idx_webhook_deliveries_webhook
CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_webhook ON public.security_incident_webhook_deliveries USING btree (webhook_id, created_at DESC);


-- INDEX: sensor_discoveries_part_0_batch_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_0_batch_id_idx ON public.sensor_discoveries_part_0 USING btree (batch_id);


-- INDEX: sensor_discoveries_part_0_dest_ip_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_0_dest_ip_idx ON public.sensor_discoveries_part_0 USING btree (dest_ip);


-- INDEX: sensor_discoveries_part_0_protocol_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_0_protocol_idx ON public.sensor_discoveries_part_0 USING btree (protocol);


-- INDEX: sensor_discoveries_part_0_sensor_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_0_sensor_id_idx ON public.sensor_discoveries_part_0 USING btree (sensor_id);


-- INDEX: sensor_discoveries_part_0_tenant_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_0_tenant_id_idx ON public.sensor_discoveries_part_0 USING btree (tenant_id);


-- INDEX: sensor_discoveries_part_0_timestamp_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_0_timestamp_idx ON public.sensor_discoveries_part_0 USING btree ("timestamp");


-- INDEX: sensor_discoveries_part_1_batch_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_1_batch_id_idx ON public.sensor_discoveries_part_1 USING btree (batch_id);


-- INDEX: sensor_discoveries_part_1_dest_ip_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_1_dest_ip_idx ON public.sensor_discoveries_part_1 USING btree (dest_ip);


-- INDEX: sensor_discoveries_part_1_protocol_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_1_protocol_idx ON public.sensor_discoveries_part_1 USING btree (protocol);


-- INDEX: sensor_discoveries_part_1_sensor_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_1_sensor_id_idx ON public.sensor_discoveries_part_1 USING btree (sensor_id);


-- INDEX: sensor_discoveries_part_1_tenant_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_1_tenant_id_idx ON public.sensor_discoveries_part_1 USING btree (tenant_id);


-- INDEX: sensor_discoveries_part_1_timestamp_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_1_timestamp_idx ON public.sensor_discoveries_part_1 USING btree ("timestamp");


-- INDEX: sensor_discoveries_part_2_batch_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_2_batch_id_idx ON public.sensor_discoveries_part_2 USING btree (batch_id);


-- INDEX: sensor_discoveries_part_2_dest_ip_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_2_dest_ip_idx ON public.sensor_discoveries_part_2 USING btree (dest_ip);


-- INDEX: sensor_discoveries_part_2_protocol_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_2_protocol_idx ON public.sensor_discoveries_part_2 USING btree (protocol);


-- INDEX: sensor_discoveries_part_2_sensor_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_2_sensor_id_idx ON public.sensor_discoveries_part_2 USING btree (sensor_id);


-- INDEX: sensor_discoveries_part_2_tenant_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_2_tenant_id_idx ON public.sensor_discoveries_part_2 USING btree (tenant_id);


-- INDEX: sensor_discoveries_part_2_timestamp_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_2_timestamp_idx ON public.sensor_discoveries_part_2 USING btree ("timestamp");


-- INDEX: sensor_discoveries_part_3_batch_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_3_batch_id_idx ON public.sensor_discoveries_part_3 USING btree (batch_id);


-- INDEX: sensor_discoveries_part_3_dest_ip_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_3_dest_ip_idx ON public.sensor_discoveries_part_3 USING btree (dest_ip);


-- INDEX: sensor_discoveries_part_3_protocol_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_3_protocol_idx ON public.sensor_discoveries_part_3 USING btree (protocol);


-- INDEX: sensor_discoveries_part_3_sensor_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_3_sensor_id_idx ON public.sensor_discoveries_part_3 USING btree (sensor_id);


-- INDEX: sensor_discoveries_part_3_tenant_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_3_tenant_id_idx ON public.sensor_discoveries_part_3 USING btree (tenant_id);


-- INDEX: sensor_discoveries_part_3_timestamp_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_3_timestamp_idx ON public.sensor_discoveries_part_3 USING btree ("timestamp");


-- INDEX: sensor_discoveries_part_4_batch_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_4_batch_id_idx ON public.sensor_discoveries_part_4 USING btree (batch_id);


-- INDEX: sensor_discoveries_part_4_dest_ip_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_4_dest_ip_idx ON public.sensor_discoveries_part_4 USING btree (dest_ip);


-- INDEX: sensor_discoveries_part_4_protocol_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_4_protocol_idx ON public.sensor_discoveries_part_4 USING btree (protocol);


-- INDEX: sensor_discoveries_part_4_sensor_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_4_sensor_id_idx ON public.sensor_discoveries_part_4 USING btree (sensor_id);


-- INDEX: sensor_discoveries_part_4_tenant_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_4_tenant_id_idx ON public.sensor_discoveries_part_4 USING btree (tenant_id);


-- INDEX: sensor_discoveries_part_4_timestamp_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_4_timestamp_idx ON public.sensor_discoveries_part_4 USING btree ("timestamp");


-- INDEX: sensor_discoveries_part_5_batch_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_5_batch_id_idx ON public.sensor_discoveries_part_5 USING btree (batch_id);


-- INDEX: sensor_discoveries_part_5_dest_ip_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_5_dest_ip_idx ON public.sensor_discoveries_part_5 USING btree (dest_ip);


-- INDEX: sensor_discoveries_part_5_protocol_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_5_protocol_idx ON public.sensor_discoveries_part_5 USING btree (protocol);


-- INDEX: sensor_discoveries_part_5_sensor_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_5_sensor_id_idx ON public.sensor_discoveries_part_5 USING btree (sensor_id);


-- INDEX: sensor_discoveries_part_5_tenant_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_5_tenant_id_idx ON public.sensor_discoveries_part_5 USING btree (tenant_id);


-- INDEX: sensor_discoveries_part_5_timestamp_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_5_timestamp_idx ON public.sensor_discoveries_part_5 USING btree ("timestamp");


-- INDEX: sensor_discoveries_part_6_batch_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_6_batch_id_idx ON public.sensor_discoveries_part_6 USING btree (batch_id);


-- INDEX: sensor_discoveries_part_6_dest_ip_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_6_dest_ip_idx ON public.sensor_discoveries_part_6 USING btree (dest_ip);


-- INDEX: sensor_discoveries_part_6_protocol_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_6_protocol_idx ON public.sensor_discoveries_part_6 USING btree (protocol);


-- INDEX: sensor_discoveries_part_6_sensor_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_6_sensor_id_idx ON public.sensor_discoveries_part_6 USING btree (sensor_id);


-- INDEX: sensor_discoveries_part_6_tenant_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_6_tenant_id_idx ON public.sensor_discoveries_part_6 USING btree (tenant_id);


-- INDEX: sensor_discoveries_part_6_timestamp_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_6_timestamp_idx ON public.sensor_discoveries_part_6 USING btree ("timestamp");


-- INDEX: sensor_discoveries_part_7_batch_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_7_batch_id_idx ON public.sensor_discoveries_part_7 USING btree (batch_id);


-- INDEX: sensor_discoveries_part_7_dest_ip_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_7_dest_ip_idx ON public.sensor_discoveries_part_7 USING btree (dest_ip);


-- INDEX: sensor_discoveries_part_7_protocol_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_7_protocol_idx ON public.sensor_discoveries_part_7 USING btree (protocol);


-- INDEX: sensor_discoveries_part_7_sensor_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_7_sensor_id_idx ON public.sensor_discoveries_part_7 USING btree (sensor_id);


-- INDEX: sensor_discoveries_part_7_tenant_id_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_7_tenant_id_idx ON public.sensor_discoveries_part_7 USING btree (tenant_id);


-- INDEX: sensor_discoveries_part_7_timestamp_idx
CREATE INDEX IF NOT EXISTS sensor_discoveries_part_7_timestamp_idx ON public.sensor_discoveries_part_7 USING btree ("timestamp");


-- INDEX: service_identification_rules_builtin_unique
CREATE UNIQUE INDEX IF NOT EXISTS service_identification_rules_builtin_unique ON public.service_identification_rules USING btree (port, protocol) WHERE (tenant_id IS NULL);


-- INDEX: service_identification_rules_tenant_unique
CREATE UNIQUE INDEX IF NOT EXISTS service_identification_rules_tenant_unique ON public.service_identification_rules USING btree (port, protocol, tenant_id) WHERE (tenant_id IS NOT NULL);


-- INDEX: unique_active_bootstrap_ca
CREATE UNIQUE INDEX IF NOT EXISTS unique_active_bootstrap_ca ON public.platform_bootstrap_ca USING btree (is_active) WHERE (is_active = true);


-- INDEX: unique_active_ca_per_tenant
CREATE UNIQUE INDEX IF NOT EXISTS unique_active_ca_per_tenant ON public.sensor_ca_certificates USING btree (tenant_id, is_active) WHERE (is_active = true);


-- INDEX: unique_active_service_ca
CREATE UNIQUE INDEX IF NOT EXISTS unique_active_service_ca ON public.platform_service_ca USING btree (is_active) WHERE (is_active = true);


-- INDEX ATTACH: activity_logs_y2026m04_action_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_action ATTACH PARTITION audit.activity_logs_y2026m04_action_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m04_compliance_tags_idx
ALTER INDEX audit.idx_activity_logs_compliance ATTACH PARTITION audit.activity_logs_y2026m04_compliance_tags_idx;


-- INDEX ATTACH: activity_logs_y2026m04_event_category_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_category ATTACH PARTITION audit.activity_logs_y2026m04_event_category_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m04_event_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_event_type ATTACH PARTITION audit.activity_logs_y2026m04_event_type_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m04_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_occurred_at ATTACH PARTITION audit.activity_logs_y2026m04_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m04_pkey
ALTER INDEX audit.activity_logs_pkey ATTACH PARTITION audit.activity_logs_y2026m04_pkey;


-- INDEX ATTACH: activity_logs_y2026m04_request_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_request_id ATTACH PARTITION audit.activity_logs_y2026m04_request_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m04_requires_attention_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_requires_attention ATTACH PARTITION audit.activity_logs_y2026m04_requires_attention_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m04_resource_type_resource_id_occurred_a_idx
ALTER INDEX audit.idx_activity_logs_resource ATTACH PARTITION audit.activity_logs_y2026m04_resource_type_resource_id_occurred_a_idx;


-- INDEX ATTACH: activity_logs_y2026m04_success_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_success ATTACH PARTITION audit.activity_logs_y2026m04_success_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m04_tenant_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_tenant_time ATTACH PARTITION audit.activity_logs_y2026m04_tenant_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m04_user_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_time ATTACH PARTITION audit.activity_logs_y2026m04_user_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m04_user_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_type ATTACH PARTITION audit.activity_logs_y2026m04_user_type_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_action_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_action ATTACH PARTITION audit.activity_logs_y2026m05_action_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_compliance_tags_idx
ALTER INDEX audit.idx_activity_logs_compliance ATTACH PARTITION audit.activity_logs_y2026m05_compliance_tags_idx;


-- INDEX ATTACH: activity_logs_y2026m05_event_category_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_category ATTACH PARTITION audit.activity_logs_y2026m05_event_category_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_event_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_event_type ATTACH PARTITION audit.activity_logs_y2026m05_event_type_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_occurred_at ATTACH PARTITION audit.activity_logs_y2026m05_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_pkey
ALTER INDEX audit.activity_logs_pkey ATTACH PARTITION audit.activity_logs_y2026m05_pkey;


-- INDEX ATTACH: activity_logs_y2026m05_request_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_request_id ATTACH PARTITION audit.activity_logs_y2026m05_request_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_requires_attention_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_requires_attention ATTACH PARTITION audit.activity_logs_y2026m05_requires_attention_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_resource_type_resource_id_occurred_a_idx
ALTER INDEX audit.idx_activity_logs_resource ATTACH PARTITION audit.activity_logs_y2026m05_resource_type_resource_id_occurred_a_idx;


-- INDEX ATTACH: activity_logs_y2026m05_success_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_success ATTACH PARTITION audit.activity_logs_y2026m05_success_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_tenant_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_tenant_time ATTACH PARTITION audit.activity_logs_y2026m05_tenant_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_user_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_time ATTACH PARTITION audit.activity_logs_y2026m05_user_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m05_user_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_type ATTACH PARTITION audit.activity_logs_y2026m05_user_type_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_action_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_action ATTACH PARTITION audit.activity_logs_y2026m06_action_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_compliance_tags_idx
ALTER INDEX audit.idx_activity_logs_compliance ATTACH PARTITION audit.activity_logs_y2026m06_compliance_tags_idx;


-- INDEX ATTACH: activity_logs_y2026m06_event_category_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_category ATTACH PARTITION audit.activity_logs_y2026m06_event_category_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_event_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_event_type ATTACH PARTITION audit.activity_logs_y2026m06_event_type_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_occurred_at ATTACH PARTITION audit.activity_logs_y2026m06_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_pkey
ALTER INDEX audit.activity_logs_pkey ATTACH PARTITION audit.activity_logs_y2026m06_pkey;


-- INDEX ATTACH: activity_logs_y2026m06_request_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_request_id ATTACH PARTITION audit.activity_logs_y2026m06_request_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_requires_attention_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_requires_attention ATTACH PARTITION audit.activity_logs_y2026m06_requires_attention_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_resource_type_resource_id_occurred_a_idx
ALTER INDEX audit.idx_activity_logs_resource ATTACH PARTITION audit.activity_logs_y2026m06_resource_type_resource_id_occurred_a_idx;


-- INDEX ATTACH: activity_logs_y2026m06_success_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_success ATTACH PARTITION audit.activity_logs_y2026m06_success_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_tenant_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_tenant_time ATTACH PARTITION audit.activity_logs_y2026m06_tenant_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_user_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_time ATTACH PARTITION audit.activity_logs_y2026m06_user_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m06_user_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_type ATTACH PARTITION audit.activity_logs_y2026m06_user_type_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_action_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_action ATTACH PARTITION audit.activity_logs_y2026m07_action_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_compliance_tags_idx
ALTER INDEX audit.idx_activity_logs_compliance ATTACH PARTITION audit.activity_logs_y2026m07_compliance_tags_idx;


-- INDEX ATTACH: activity_logs_y2026m07_event_category_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_category ATTACH PARTITION audit.activity_logs_y2026m07_event_category_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_event_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_event_type ATTACH PARTITION audit.activity_logs_y2026m07_event_type_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_occurred_at ATTACH PARTITION audit.activity_logs_y2026m07_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_pkey
ALTER INDEX audit.activity_logs_pkey ATTACH PARTITION audit.activity_logs_y2026m07_pkey;


-- INDEX ATTACH: activity_logs_y2026m07_request_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_request_id ATTACH PARTITION audit.activity_logs_y2026m07_request_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_requires_attention_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_requires_attention ATTACH PARTITION audit.activity_logs_y2026m07_requires_attention_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_resource_type_resource_id_occurred_a_idx
ALTER INDEX audit.idx_activity_logs_resource ATTACH PARTITION audit.activity_logs_y2026m07_resource_type_resource_id_occurred_a_idx;


-- INDEX ATTACH: activity_logs_y2026m07_success_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_success ATTACH PARTITION audit.activity_logs_y2026m07_success_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_tenant_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_tenant_time ATTACH PARTITION audit.activity_logs_y2026m07_tenant_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_user_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_time ATTACH PARTITION audit.activity_logs_y2026m07_user_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m07_user_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_type ATTACH PARTITION audit.activity_logs_y2026m07_user_type_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_action_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_action ATTACH PARTITION audit.activity_logs_y2026m08_action_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_compliance_tags_idx
ALTER INDEX audit.idx_activity_logs_compliance ATTACH PARTITION audit.activity_logs_y2026m08_compliance_tags_idx;


-- INDEX ATTACH: activity_logs_y2026m08_event_category_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_category ATTACH PARTITION audit.activity_logs_y2026m08_event_category_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_event_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_event_type ATTACH PARTITION audit.activity_logs_y2026m08_event_type_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_occurred_at ATTACH PARTITION audit.activity_logs_y2026m08_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_pkey
ALTER INDEX audit.activity_logs_pkey ATTACH PARTITION audit.activity_logs_y2026m08_pkey;


-- INDEX ATTACH: activity_logs_y2026m08_request_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_request_id ATTACH PARTITION audit.activity_logs_y2026m08_request_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_requires_attention_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_requires_attention ATTACH PARTITION audit.activity_logs_y2026m08_requires_attention_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_resource_type_resource_id_occurred_a_idx
ALTER INDEX audit.idx_activity_logs_resource ATTACH PARTITION audit.activity_logs_y2026m08_resource_type_resource_id_occurred_a_idx;


-- INDEX ATTACH: activity_logs_y2026m08_success_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_success ATTACH PARTITION audit.activity_logs_y2026m08_success_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_tenant_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_tenant_time ATTACH PARTITION audit.activity_logs_y2026m08_tenant_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_user_id_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_time ATTACH PARTITION audit.activity_logs_y2026m08_user_id_occurred_at_idx;


-- INDEX ATTACH: activity_logs_y2026m08_user_type_occurred_at_idx
ALTER INDEX audit.idx_activity_logs_user_type ATTACH PARTITION audit.activity_logs_y2026m08_user_type_occurred_at_idx;


-- INDEX ATTACH: crypto_implementations_part_0_asset_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_asset_id ATTACH PARTITION public.crypto_implementations_part_0_asset_id_idx;


-- INDEX ATTACH: crypto_implementations_part_0_deleted_at_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_deleted_at ATTACH PARTITION public.crypto_implementations_part_0_deleted_at_idx;


-- INDEX ATTACH: crypto_implementations_part_0_risk_score_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_risk_score ATTACH PARTITION public.crypto_implementations_part_0_risk_score_idx;


-- INDEX ATTACH: crypto_implementations_part_0_tenant_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_tenant_id ATTACH PARTITION public.crypto_implementations_part_0_tenant_id_idx;


-- INDEX ATTACH: crypto_implementations_part_1_asset_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_asset_id ATTACH PARTITION public.crypto_implementations_part_1_asset_id_idx;


-- INDEX ATTACH: crypto_implementations_part_1_deleted_at_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_deleted_at ATTACH PARTITION public.crypto_implementations_part_1_deleted_at_idx;


-- INDEX ATTACH: crypto_implementations_part_1_risk_score_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_risk_score ATTACH PARTITION public.crypto_implementations_part_1_risk_score_idx;


-- INDEX ATTACH: crypto_implementations_part_1_tenant_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_tenant_id ATTACH PARTITION public.crypto_implementations_part_1_tenant_id_idx;


-- INDEX ATTACH: crypto_implementations_part_2_asset_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_asset_id ATTACH PARTITION public.crypto_implementations_part_2_asset_id_idx;


-- INDEX ATTACH: crypto_implementations_part_2_deleted_at_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_deleted_at ATTACH PARTITION public.crypto_implementations_part_2_deleted_at_idx;


-- INDEX ATTACH: crypto_implementations_part_2_risk_score_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_risk_score ATTACH PARTITION public.crypto_implementations_part_2_risk_score_idx;


-- INDEX ATTACH: crypto_implementations_part_2_tenant_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_tenant_id ATTACH PARTITION public.crypto_implementations_part_2_tenant_id_idx;


-- INDEX ATTACH: crypto_implementations_part_3_asset_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_asset_id ATTACH PARTITION public.crypto_implementations_part_3_asset_id_idx;


-- INDEX ATTACH: crypto_implementations_part_3_deleted_at_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_deleted_at ATTACH PARTITION public.crypto_implementations_part_3_deleted_at_idx;


-- INDEX ATTACH: crypto_implementations_part_3_risk_score_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_risk_score ATTACH PARTITION public.crypto_implementations_part_3_risk_score_idx;


-- INDEX ATTACH: crypto_implementations_part_3_tenant_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_tenant_id ATTACH PARTITION public.crypto_implementations_part_3_tenant_id_idx;


-- INDEX ATTACH: crypto_implementations_part_4_asset_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_asset_id ATTACH PARTITION public.crypto_implementations_part_4_asset_id_idx;


-- INDEX ATTACH: crypto_implementations_part_4_deleted_at_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_deleted_at ATTACH PARTITION public.crypto_implementations_part_4_deleted_at_idx;


-- INDEX ATTACH: crypto_implementations_part_4_risk_score_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_risk_score ATTACH PARTITION public.crypto_implementations_part_4_risk_score_idx;


-- INDEX ATTACH: crypto_implementations_part_4_tenant_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_tenant_id ATTACH PARTITION public.crypto_implementations_part_4_tenant_id_idx;


-- INDEX ATTACH: crypto_implementations_part_5_asset_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_asset_id ATTACH PARTITION public.crypto_implementations_part_5_asset_id_idx;


-- INDEX ATTACH: crypto_implementations_part_5_deleted_at_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_deleted_at ATTACH PARTITION public.crypto_implementations_part_5_deleted_at_idx;


-- INDEX ATTACH: crypto_implementations_part_5_risk_score_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_risk_score ATTACH PARTITION public.crypto_implementations_part_5_risk_score_idx;


-- INDEX ATTACH: crypto_implementations_part_5_tenant_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_tenant_id ATTACH PARTITION public.crypto_implementations_part_5_tenant_id_idx;


-- INDEX ATTACH: crypto_implementations_part_6_asset_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_asset_id ATTACH PARTITION public.crypto_implementations_part_6_asset_id_idx;


-- INDEX ATTACH: crypto_implementations_part_6_deleted_at_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_deleted_at ATTACH PARTITION public.crypto_implementations_part_6_deleted_at_idx;


-- INDEX ATTACH: crypto_implementations_part_6_risk_score_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_risk_score ATTACH PARTITION public.crypto_implementations_part_6_risk_score_idx;


-- INDEX ATTACH: crypto_implementations_part_6_tenant_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_tenant_id ATTACH PARTITION public.crypto_implementations_part_6_tenant_id_idx;


-- INDEX ATTACH: crypto_implementations_part_7_asset_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_asset_id ATTACH PARTITION public.crypto_implementations_part_7_asset_id_idx;


-- INDEX ATTACH: crypto_implementations_part_7_deleted_at_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_deleted_at ATTACH PARTITION public.crypto_implementations_part_7_deleted_at_idx;


-- INDEX ATTACH: crypto_implementations_part_7_risk_score_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_risk_score ATTACH PARTITION public.crypto_implementations_part_7_risk_score_idx;


-- INDEX ATTACH: crypto_implementations_part_7_tenant_id_idx
ALTER INDEX public.idx_crypto_implementations_partitioned_tenant_id ATTACH PARTITION public.crypto_implementations_part_7_tenant_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_0_batch_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_batch_id ATTACH PARTITION public.sensor_discoveries_part_0_batch_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_0_dest_ip_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_dest_ip ATTACH PARTITION public.sensor_discoveries_part_0_dest_ip_idx;


-- INDEX ATTACH: sensor_discoveries_part_0_protocol_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_protocol ATTACH PARTITION public.sensor_discoveries_part_0_protocol_idx;


-- INDEX ATTACH: sensor_discoveries_part_0_sensor_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_sensor_id ATTACH PARTITION public.sensor_discoveries_part_0_sensor_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_0_tenant_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_tenant_id ATTACH PARTITION public.sensor_discoveries_part_0_tenant_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_0_timestamp_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_timestamp ATTACH PARTITION public.sensor_discoveries_part_0_timestamp_idx;


-- INDEX ATTACH: sensor_discoveries_part_1_batch_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_batch_id ATTACH PARTITION public.sensor_discoveries_part_1_batch_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_1_dest_ip_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_dest_ip ATTACH PARTITION public.sensor_discoveries_part_1_dest_ip_idx;


-- INDEX ATTACH: sensor_discoveries_part_1_protocol_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_protocol ATTACH PARTITION public.sensor_discoveries_part_1_protocol_idx;


-- INDEX ATTACH: sensor_discoveries_part_1_sensor_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_sensor_id ATTACH PARTITION public.sensor_discoveries_part_1_sensor_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_1_tenant_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_tenant_id ATTACH PARTITION public.sensor_discoveries_part_1_tenant_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_1_timestamp_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_timestamp ATTACH PARTITION public.sensor_discoveries_part_1_timestamp_idx;


-- INDEX ATTACH: sensor_discoveries_part_2_batch_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_batch_id ATTACH PARTITION public.sensor_discoveries_part_2_batch_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_2_dest_ip_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_dest_ip ATTACH PARTITION public.sensor_discoveries_part_2_dest_ip_idx;


-- INDEX ATTACH: sensor_discoveries_part_2_protocol_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_protocol ATTACH PARTITION public.sensor_discoveries_part_2_protocol_idx;


-- INDEX ATTACH: sensor_discoveries_part_2_sensor_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_sensor_id ATTACH PARTITION public.sensor_discoveries_part_2_sensor_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_2_tenant_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_tenant_id ATTACH PARTITION public.sensor_discoveries_part_2_tenant_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_2_timestamp_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_timestamp ATTACH PARTITION public.sensor_discoveries_part_2_timestamp_idx;


-- INDEX ATTACH: sensor_discoveries_part_3_batch_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_batch_id ATTACH PARTITION public.sensor_discoveries_part_3_batch_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_3_dest_ip_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_dest_ip ATTACH PARTITION public.sensor_discoveries_part_3_dest_ip_idx;


-- INDEX ATTACH: sensor_discoveries_part_3_protocol_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_protocol ATTACH PARTITION public.sensor_discoveries_part_3_protocol_idx;


-- INDEX ATTACH: sensor_discoveries_part_3_sensor_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_sensor_id ATTACH PARTITION public.sensor_discoveries_part_3_sensor_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_3_tenant_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_tenant_id ATTACH PARTITION public.sensor_discoveries_part_3_tenant_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_3_timestamp_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_timestamp ATTACH PARTITION public.sensor_discoveries_part_3_timestamp_idx;


-- INDEX ATTACH: sensor_discoveries_part_4_batch_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_batch_id ATTACH PARTITION public.sensor_discoveries_part_4_batch_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_4_dest_ip_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_dest_ip ATTACH PARTITION public.sensor_discoveries_part_4_dest_ip_idx;


-- INDEX ATTACH: sensor_discoveries_part_4_protocol_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_protocol ATTACH PARTITION public.sensor_discoveries_part_4_protocol_idx;


-- INDEX ATTACH: sensor_discoveries_part_4_sensor_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_sensor_id ATTACH PARTITION public.sensor_discoveries_part_4_sensor_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_4_tenant_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_tenant_id ATTACH PARTITION public.sensor_discoveries_part_4_tenant_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_4_timestamp_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_timestamp ATTACH PARTITION public.sensor_discoveries_part_4_timestamp_idx;


-- INDEX ATTACH: sensor_discoveries_part_5_batch_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_batch_id ATTACH PARTITION public.sensor_discoveries_part_5_batch_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_5_dest_ip_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_dest_ip ATTACH PARTITION public.sensor_discoveries_part_5_dest_ip_idx;


-- INDEX ATTACH: sensor_discoveries_part_5_protocol_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_protocol ATTACH PARTITION public.sensor_discoveries_part_5_protocol_idx;


-- INDEX ATTACH: sensor_discoveries_part_5_sensor_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_sensor_id ATTACH PARTITION public.sensor_discoveries_part_5_sensor_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_5_tenant_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_tenant_id ATTACH PARTITION public.sensor_discoveries_part_5_tenant_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_5_timestamp_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_timestamp ATTACH PARTITION public.sensor_discoveries_part_5_timestamp_idx;


-- INDEX ATTACH: sensor_discoveries_part_6_batch_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_batch_id ATTACH PARTITION public.sensor_discoveries_part_6_batch_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_6_dest_ip_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_dest_ip ATTACH PARTITION public.sensor_discoveries_part_6_dest_ip_idx;


-- INDEX ATTACH: sensor_discoveries_part_6_protocol_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_protocol ATTACH PARTITION public.sensor_discoveries_part_6_protocol_idx;


-- INDEX ATTACH: sensor_discoveries_part_6_sensor_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_sensor_id ATTACH PARTITION public.sensor_discoveries_part_6_sensor_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_6_tenant_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_tenant_id ATTACH PARTITION public.sensor_discoveries_part_6_tenant_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_6_timestamp_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_timestamp ATTACH PARTITION public.sensor_discoveries_part_6_timestamp_idx;


-- INDEX ATTACH: sensor_discoveries_part_7_batch_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_batch_id ATTACH PARTITION public.sensor_discoveries_part_7_batch_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_7_dest_ip_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_dest_ip ATTACH PARTITION public.sensor_discoveries_part_7_dest_ip_idx;


-- INDEX ATTACH: sensor_discoveries_part_7_protocol_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_protocol ATTACH PARTITION public.sensor_discoveries_part_7_protocol_idx;


-- INDEX ATTACH: sensor_discoveries_part_7_sensor_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_sensor_id ATTACH PARTITION public.sensor_discoveries_part_7_sensor_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_7_tenant_id_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_tenant_id ATTACH PARTITION public.sensor_discoveries_part_7_tenant_id_idx;


-- INDEX ATTACH: sensor_discoveries_part_7_timestamp_idx
ALTER INDEX public.idx_sensor_discoveries_partitioned_timestamp ATTACH PARTITION public.sensor_discoveries_part_7_timestamp_idx;


-- TRIGGER: tenants auto_license_best_practices_on_tenant_create
CREATE OR REPLACE TRIGGER auto_license_best_practices_on_tenant_create AFTER INSERT ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.auto_license_best_practices();


-- TRIGGER: tenants auto_license_iec62351_for_enterprise_on_tenant_create
CREATE OR REPLACE TRIGGER auto_license_iec62351_for_enterprise_on_tenant_create AFTER INSERT ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.auto_license_iec62351_for_enterprise();


-- TRIGGER: tenants create_system_sensors_on_tenant_create
CREATE OR REPLACE TRIGGER create_system_sensors_on_tenant_create AFTER INSERT ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.create_system_sensors_for_tenant();


-- TRIGGER: tenants set_tenant_trial_end
CREATE OR REPLACE TRIGGER set_tenant_trial_end BEFORE INSERT ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.set_trial_end_date();


-- TRIGGER: subscription_tiers subscription_tiers_change_log
CREATE OR REPLACE TRIGGER subscription_tiers_change_log AFTER INSERT OR DELETE OR UPDATE ON public.subscription_tiers FOR EACH ROW EXECUTE FUNCTION public.log_tier_change();


-- TRIGGER: tenant_admin_settings tenant_admin_settings_audit_trigger
CREATE OR REPLACE TRIGGER tenant_admin_settings_audit_trigger AFTER UPDATE ON public.tenant_admin_settings FOR EACH ROW WHEN (((old.config IS DISTINCT FROM new.config) OR (old.version IS DISTINCT FROM new.version))) EXECUTE FUNCTION public.log_tenant_admin_settings_change();


-- TRIGGER: device_jobs trigger_device_jobs_updated_at
CREATE OR REPLACE TRIGGER trigger_device_jobs_updated_at BEFORE UPDATE ON public.device_jobs FOR EACH ROW EXECUTE FUNCTION public.update_device_jobs_updated_at();


-- TRIGGER: algorithms update_algorithms_updated_at
CREATE OR REPLACE TRIGGER update_algorithms_updated_at BEFORE UPDATE ON public.algorithms FOR EACH ROW EXECUTE FUNCTION public.update_algorithms_updated_at();


-- TRIGGER: certificates update_certificates_updated_at
CREATE OR REPLACE TRIGGER update_certificates_updated_at BEFORE UPDATE ON public.certificates FOR EACH ROW EXECUTE FUNCTION public.update_certificates_updated_at();


-- TRIGGER: cmdb_entity_mappings update_cmdb_entity_mappings_updated_at
CREATE OR REPLACE TRIGGER update_cmdb_entity_mappings_updated_at BEFORE UPDATE ON public.cmdb_entity_mappings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: cmdb_sync_jobs update_cmdb_sync_jobs_updated_at
CREATE OR REPLACE TRIGGER update_cmdb_sync_jobs_updated_at BEFORE UPDATE ON public.cmdb_sync_jobs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: cmdb_sync_profiles update_cmdb_sync_profiles_updated_at
CREATE OR REPLACE TRIGGER update_cmdb_sync_profiles_updated_at BEFORE UPDATE ON public.cmdb_sync_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();



-- TRIGGER: compliance_overrides update_compliance_overrides_updated_at
CREATE OR REPLACE TRIGGER update_compliance_overrides_updated_at BEFORE UPDATE ON public.compliance_overrides FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: compliance_rules update_compliance_rules_updated_at
CREATE OR REPLACE TRIGGER update_compliance_rules_updated_at BEFORE UPDATE ON public.compliance_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: compliance_scenarios update_compliance_scenarios_updated_at
CREATE OR REPLACE TRIGGER update_compliance_scenarios_updated_at BEFORE UPDATE ON public.compliance_scenarios FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: control_measurements update_control_measurements_updated_at
CREATE OR REPLACE TRIGGER update_control_measurements_updated_at BEFORE UPDATE ON public.control_measurements FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: crypto_applications update_crypto_applications_updated_at
CREATE OR REPLACE TRIGGER update_crypto_applications_updated_at BEFORE UPDATE ON public.crypto_applications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: discovery_alert_configs update_discovery_alert_configs_updated_at
CREATE OR REPLACE TRIGGER update_discovery_alert_configs_updated_at BEFORE UPDATE ON public.discovery_alert_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: discovery_auto_approval_rules update_discovery_auto_approval_rules_updated_at
CREATE OR REPLACE TRIGGER update_discovery_auto_approval_rules_updated_at BEFORE UPDATE ON public.discovery_auto_approval_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: discovery_jobs update_discovery_jobs_updated_at
CREATE OR REPLACE TRIGGER update_discovery_jobs_updated_at BEFORE UPDATE ON public.discovery_jobs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: discovery_rate_limits update_discovery_rate_limits_updated_at
CREATE OR REPLACE TRIGGER update_discovery_rate_limits_updated_at BEFORE UPDATE ON public.discovery_rate_limits FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: discovery_targets update_discovery_targets_updated_at
CREATE OR REPLACE TRIGGER update_discovery_targets_updated_at BEFORE UPDATE ON public.discovery_targets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: health_benchmarks update_health_benchmarks_updated_at
CREATE OR REPLACE TRIGGER update_health_benchmarks_updated_at BEFORE UPDATE ON public.health_benchmarks FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: measurement_templates update_measurement_templates_updated_at
CREATE OR REPLACE TRIGGER update_measurement_templates_updated_at BEFORE UPDATE ON public.measurement_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: measurement_types update_measurement_types_updated_at
CREATE OR REPLACE TRIGGER update_measurement_types_updated_at BEFORE UPDATE ON public.measurement_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: pcap_upload_jobs update_pcap_upload_jobs_updated_at
CREATE OR REPLACE TRIGGER update_pcap_upload_jobs_updated_at BEFORE UPDATE ON public.pcap_upload_jobs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: platform_framework_controls update_platform_framework_controls_updated_at
CREATE OR REPLACE TRIGGER update_platform_framework_controls_updated_at BEFORE UPDATE ON public.platform_framework_controls FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: platform_frameworks update_platform_frameworks_updated_at
CREATE OR REPLACE TRIGGER update_platform_frameworks_updated_at BEFORE UPDATE ON public.platform_frameworks FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: platform_notification_channels update_platform_notification_channels_updated_at
CREATE OR REPLACE TRIGGER update_platform_notification_channels_updated_at BEFORE UPDATE ON public.platform_notification_channels FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: platform_notification_rules update_platform_notification_rules_updated_at
CREATE OR REPLACE TRIGGER update_platform_notification_rules_updated_at BEFORE UPDATE ON public.platform_notification_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: platform_roles update_platform_roles_updated_at
CREATE OR REPLACE TRIGGER update_platform_roles_updated_at BEFORE UPDATE ON public.platform_roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: platform_settings update_platform_settings_updated_at
CREATE OR REPLACE TRIGGER update_platform_settings_updated_at BEFORE UPDATE ON public.platform_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: rule_vulnerability_mappings update_rule_vulnerability_mappings_updated_at
CREATE OR REPLACE TRIGGER update_rule_vulnerability_mappings_updated_at BEFORE UPDATE ON public.rule_vulnerability_mappings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: sensors update_sensors_updated_at
CREATE OR REPLACE TRIGGER update_sensors_updated_at BEFORE UPDATE ON public.sensors FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: sso_group_role_mappings update_sso_group_role_mappings_updated_at
CREATE OR REPLACE TRIGGER update_sso_group_role_mappings_updated_at BEFORE UPDATE ON public.sso_group_role_mappings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: sso_providers update_sso_providers_updated_at
CREATE OR REPLACE TRIGGER update_sso_providers_updated_at BEFORE UPDATE ON public.sso_providers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_admin_settings update_tenant_admin_settings_updated_at
CREATE OR REPLACE TRIGGER update_tenant_admin_settings_updated_at BEFORE UPDATE ON public.tenant_admin_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_framework_controls update_tenant_framework_controls_updated_at
CREATE OR REPLACE TRIGGER update_tenant_framework_controls_updated_at BEFORE UPDATE ON public.tenant_framework_controls FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_framework_licenses update_tenant_framework_licenses_updated_at
CREATE OR REPLACE TRIGGER update_tenant_framework_licenses_updated_at BEFORE UPDATE ON public.tenant_framework_licenses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_frameworks update_tenant_frameworks_updated_at
CREATE OR REPLACE TRIGGER update_tenant_frameworks_updated_at BEFORE UPDATE ON public.tenant_frameworks FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_health update_tenant_health_updated_at
CREATE OR REPLACE TRIGGER update_tenant_health_updated_at BEFORE UPDATE ON public.tenant_health FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_measurement_overrides update_tenant_measurement_overrides_updated_at
CREATE OR REPLACE TRIGGER update_tenant_measurement_overrides_updated_at BEFORE UPDATE ON public.tenant_measurement_overrides FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_notification_channels update_tenant_notification_channels_updated_at
CREATE OR REPLACE TRIGGER update_tenant_notification_channels_updated_at BEFORE UPDATE ON public.tenant_notification_channels FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_notification_rules update_tenant_notification_rules_updated_at
CREATE OR REPLACE TRIGGER update_tenant_notification_rules_updated_at BEFORE UPDATE ON public.tenant_notification_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_roles update_tenant_roles_updated_at
CREATE OR REPLACE TRIGGER update_tenant_roles_updated_at BEFORE UPDATE ON public.tenant_roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenant_usage update_tenant_usage_updated_at
CREATE OR REPLACE TRIGGER update_tenant_usage_updated_at BEFORE UPDATE ON public.tenant_usage FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tenants update_tenants_updated_at
CREATE OR REPLACE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: tickets update_tickets_updated_at
CREATE OR REPLACE TRIGGER update_tickets_updated_at BEFORE UPDATE ON public.tickets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: ui_themes update_ui_themes_updated_at
CREATE OR REPLACE TRIGGER update_ui_themes_updated_at BEFORE UPDATE ON public.ui_themes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: user_auth_methods update_user_auth_methods_updated_at
CREATE OR REPLACE TRIGGER update_user_auth_methods_updated_at BEFORE UPDATE ON public.user_auth_methods FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: users update_user_count_on_delete
CREATE OR REPLACE TRIGGER update_user_count_on_delete AFTER DELETE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_tenant_user_count();


-- TRIGGER: users update_user_count_on_insert
CREATE OR REPLACE TRIGGER update_user_count_on_insert AFTER INSERT ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_tenant_user_count();


-- TRIGGER: users update_user_count_on_update
CREATE OR REPLACE TRIGGER update_user_count_on_update AFTER UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_tenant_user_count();


-- TRIGGER: user_framework_preferences update_user_framework_preferences_updated_at
CREATE OR REPLACE TRIGGER update_user_framework_preferences_updated_at BEFORE UPDATE ON public.user_framework_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: user_workflow_progress update_user_workflow_progress_updated_at
CREATE OR REPLACE TRIGGER update_user_workflow_progress_updated_at BEFORE UPDATE ON public.user_workflow_progress FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: users update_users_updated_at
CREATE OR REPLACE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- TRIGGER: workflow_configurations update_workflow_configurations_updated_at
CREATE OR REPLACE TRIGGER update_workflow_configurations_updated_at BEFORE UPDATE ON public.workflow_configurations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- FK CONSTRAINT: activity_logs activity_logs_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('audit.activity_logs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'activity_logs_tenant_id_fkey' AND conrelid = to_regclass('audit.activity_logs')
     ) THEN
    ALTER TABLE audit.activity_logs
        ADD CONSTRAINT activity_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: alert_rules alert_rules_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('audit.alert_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'alert_rules_tenant_id_fkey' AND conrelid = to_regclass('audit.alert_rules')
     ) THEN
    ALTER TABLE ONLY audit.alert_rules
        ADD CONSTRAINT alert_rules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: job_execution_logs job_execution_logs_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('audit.job_execution_logs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'job_execution_logs_tenant_id_fkey' AND conrelid = to_regclass('audit.job_execution_logs')
     ) THEN
    ALTER TABLE ONLY audit.job_execution_logs
        ADD CONSTRAINT job_execution_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: scheduled_compliance_reports scheduled_compliance_reports_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('audit.scheduled_compliance_reports') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'scheduled_compliance_reports_tenant_id_fkey' AND conrelid = to_regclass('audit.scheduled_compliance_reports')
     ) THEN
    ALTER TABLE ONLY audit.scheduled_compliance_reports
        ADD CONSTRAINT scheduled_compliance_reports_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: scheduled_report_executions scheduled_report_executions_schedule_id_fkey
DO $$ BEGIN
  IF to_regclass('audit.scheduled_report_executions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'scheduled_report_executions_schedule_id_fkey' AND conrelid = to_regclass('audit.scheduled_report_executions')
     ) THEN
    ALTER TABLE ONLY audit.scheduled_report_executions
        ADD CONSTRAINT scheduled_report_executions_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES audit.scheduled_compliance_reports(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: scheduled_report_executions scheduled_report_executions_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('audit.scheduled_report_executions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'scheduled_report_executions_tenant_id_fkey' AND conrelid = to_regclass('audit.scheduled_report_executions')
     ) THEN
    ALTER TABLE ONLY audit.scheduled_report_executions
        ADD CONSTRAINT scheduled_report_executions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: siem_health_checks siem_health_checks_integration_id_fkey
DO $$ BEGIN
  IF to_regclass('audit.siem_health_checks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'siem_health_checks_integration_id_fkey' AND conrelid = to_regclass('audit.siem_health_checks')
     ) THEN
    ALTER TABLE ONLY audit.siem_health_checks
        ADD CONSTRAINT siem_health_checks_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES audit.siem_integrations(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: siem_integrations siem_integrations_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('audit.siem_integrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'siem_integrations_tenant_id_fkey' AND conrelid = to_regclass('audit.siem_integrations')
     ) THEN
    ALTER TABLE ONLY audit.siem_integrations
        ADD CONSTRAINT siem_integrations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: agent_certificates agent_certificates_agent_id_fkey
DO $$ BEGIN
  IF to_regclass('public.agent_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'agent_certificates_agent_id_fkey' AND conrelid = to_regclass('public.agent_certificates')
     ) THEN
    ALTER TABLE ONLY public.agent_certificates
        ADD CONSTRAINT agent_certificates_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.device_agents(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: agent_certificates agent_certificates_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.agent_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'agent_certificates_tenant_id_fkey' AND conrelid = to_regclass('public.agent_certificates')
     ) THEN
    ALTER TABLE ONLY public.agent_certificates
        ADD CONSTRAINT agent_certificates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: asset_history asset_history_actor_user_id_fkey
DO $$ BEGIN
  IF to_regclass('public.asset_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_history_actor_user_id_fkey' AND conrelid = to_regclass('public.asset_history')
     ) THEN
    ALTER TABLE ONLY public.asset_history
        ADD CONSTRAINT asset_history_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: asset_history asset_history_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.asset_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_history_tenant_id_fkey' AND conrelid = to_regclass('public.asset_history')
     ) THEN
    ALTER TABLE ONLY public.asset_history
        ADD CONSTRAINT asset_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: asset_lifecycle_policies asset_lifecycle_policies_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.asset_lifecycle_policies') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_lifecycle_policies_tenant_id_fkey' AND conrelid = to_regclass('public.asset_lifecycle_policies')
     ) THEN
    ALTER TABLE ONLY public.asset_lifecycle_policies
        ADD CONSTRAINT asset_lifecycle_policies_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: auth_audit_log auth_audit_log_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.auth_audit_log') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'auth_audit_log_tenant_id_fkey' AND conrelid = to_regclass('public.auth_audit_log')
     ) THEN
    ALTER TABLE ONLY public.auth_audit_log
        ADD CONSTRAINT auth_audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: auth_audit_log auth_audit_log_user_id_fkey
DO $$ BEGIN
  IF to_regclass('public.auth_audit_log') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'auth_audit_log_user_id_fkey' AND conrelid = to_regclass('public.auth_audit_log')
     ) THEN
    ALTER TABLE ONLY public.auth_audit_log
        ADD CONSTRAINT auth_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: aws_cost_data aws_cost_data_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.aws_cost_data') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'aws_cost_data_tenant_id_fkey' AND conrelid = to_regclass('public.aws_cost_data')
     ) THEN
    ALTER TABLE ONLY public.aws_cost_data
        ADD CONSTRAINT aws_cost_data_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: aws_cost_sync_jobs aws_cost_sync_jobs_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.aws_cost_sync_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'aws_cost_sync_jobs_tenant_id_fkey' AND conrelid = to_regclass('public.aws_cost_sync_jobs')
     ) THEN
    ALTER TABLE ONLY public.aws_cost_sync_jobs
        ADD CONSTRAINT aws_cost_sync_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: billing_coupon_redemptions billing_coupon_redemptions_coupon_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_coupon_redemptions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_coupon_redemptions_coupon_id_fkey' AND conrelid = to_regclass('public.billing_coupon_redemptions')
     ) THEN
    ALTER TABLE ONLY public.billing_coupon_redemptions
        ADD CONSTRAINT billing_coupon_redemptions_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.billing_coupons(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: billing_coupon_redemptions billing_coupon_redemptions_subscription_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_coupon_redemptions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_coupon_redemptions_subscription_id_fkey' AND conrelid = to_regclass('public.billing_coupon_redemptions')
     ) THEN
    ALTER TABLE ONLY public.billing_coupon_redemptions
        ADD CONSTRAINT billing_coupon_redemptions_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.billing_subscriptions(id);
  END IF;
END $$;


-- FK CONSTRAINT: billing_coupon_redemptions billing_coupon_redemptions_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_coupon_redemptions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_coupon_redemptions_tenant_id_fkey' AND conrelid = to_regclass('public.billing_coupon_redemptions')
     ) THEN
    ALTER TABLE ONLY public.billing_coupon_redemptions
        ADD CONSTRAINT billing_coupon_redemptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: billing_customers billing_customers_provider_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_customers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_customers_provider_id_fkey' AND conrelid = to_regclass('public.billing_customers')
     ) THEN
    ALTER TABLE ONLY public.billing_customers
        ADD CONSTRAINT billing_customers_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.billing_providers(id) ON DELETE RESTRICT;
  END IF;
END $$;


-- FK CONSTRAINT: billing_customers billing_customers_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_customers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_customers_tenant_id_fkey' AND conrelid = to_regclass('public.billing_customers')
     ) THEN
    ALTER TABLE ONLY public.billing_customers
        ADD CONSTRAINT billing_customers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: billing_dunning_attempts billing_dunning_attempts_invoice_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_dunning_attempts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_dunning_attempts_invoice_id_fkey' AND conrelid = to_regclass('public.billing_dunning_attempts')
     ) THEN
    ALTER TABLE ONLY public.billing_dunning_attempts
        ADD CONSTRAINT billing_dunning_attempts_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.billing_invoices(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: billing_dunning_attempts billing_dunning_attempts_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_dunning_attempts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_dunning_attempts_tenant_id_fkey' AND conrelid = to_regclass('public.billing_dunning_attempts')
     ) THEN
    ALTER TABLE ONLY public.billing_dunning_attempts
        ADD CONSTRAINT billing_dunning_attempts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: billing_events billing_events_provider_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_events') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_events_provider_id_fkey' AND conrelid = to_regclass('public.billing_events')
     ) THEN
    ALTER TABLE ONLY public.billing_events
        ADD CONSTRAINT billing_events_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.billing_providers(id) ON DELETE RESTRICT;
  END IF;
END $$;


-- FK CONSTRAINT: billing_invoice_line_items billing_invoice_line_items_invoice_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_invoice_line_items') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_invoice_line_items_invoice_id_fkey' AND conrelid = to_regclass('public.billing_invoice_line_items')
     ) THEN
    ALTER TABLE ONLY public.billing_invoice_line_items
        ADD CONSTRAINT billing_invoice_line_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.billing_invoices(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: billing_invoices billing_invoices_provider_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_invoices') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_invoices_provider_id_fkey' AND conrelid = to_regclass('public.billing_invoices')
     ) THEN
    ALTER TABLE ONLY public.billing_invoices
        ADD CONSTRAINT billing_invoices_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.billing_providers(id) ON DELETE RESTRICT;
  END IF;
END $$;


-- FK CONSTRAINT: billing_invoices billing_invoices_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_invoices') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_invoices_tenant_id_fkey' AND conrelid = to_regclass('public.billing_invoices')
     ) THEN
    ALTER TABLE ONLY public.billing_invoices
        ADD CONSTRAINT billing_invoices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: billing_subscriptions billing_subscriptions_coupon_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_subscriptions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_subscriptions_coupon_id_fkey' AND conrelid = to_regclass('public.billing_subscriptions')
     ) THEN
    ALTER TABLE ONLY public.billing_subscriptions
        ADD CONSTRAINT billing_subscriptions_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.billing_coupons(id);
  END IF;
END $$;


-- FK CONSTRAINT: billing_subscriptions billing_subscriptions_provider_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_subscriptions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_subscriptions_provider_id_fkey' AND conrelid = to_regclass('public.billing_subscriptions')
     ) THEN
    ALTER TABLE ONLY public.billing_subscriptions
        ADD CONSTRAINT billing_subscriptions_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.billing_providers(id) ON DELETE RESTRICT;
  END IF;
END $$;


-- FK CONSTRAINT: billing_subscriptions billing_subscriptions_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_subscriptions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_subscriptions_tenant_id_fkey' AND conrelid = to_regclass('public.billing_subscriptions')
     ) THEN
    ALTER TABLE ONLY public.billing_subscriptions
        ADD CONSTRAINT billing_subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: billing_trial_tracking billing_trial_tracking_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.billing_trial_tracking') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'billing_trial_tracking_tenant_id_fkey' AND conrelid = to_regclass('public.billing_trial_tracking')
     ) THEN
    ALTER TABLE ONLY public.billing_trial_tracking
        ADD CONSTRAINT billing_trial_tracking_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: certificate_extensions certificate_extensions_certificate_id_fkey
DO $$ BEGIN
  IF to_regclass('public.certificate_extensions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificate_extensions_certificate_id_fkey' AND conrelid = to_regclass('public.certificate_extensions')
     ) THEN
    ALTER TABLE ONLY public.certificate_extensions
        ADD CONSTRAINT certificate_extensions_certificate_id_fkey FOREIGN KEY (certificate_id) REFERENCES public.certificates(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: certificate_history certificate_history_certificate_id_fkey
DO $$ BEGIN
  IF to_regclass('public.certificate_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificate_history_certificate_id_fkey' AND conrelid = to_regclass('public.certificate_history')
     ) THEN
    ALTER TABLE ONLY public.certificate_history
        ADD CONSTRAINT certificate_history_certificate_id_fkey FOREIGN KEY (certificate_id) REFERENCES public.certificates(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: certificate_history certificate_history_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.certificate_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificate_history_created_by_fkey' AND conrelid = to_regclass('public.certificate_history')
     ) THEN
    ALTER TABLE ONLY public.certificate_history
        ADD CONSTRAINT certificate_history_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: certificate_history certificate_history_previous_certificate_id_fkey
DO $$ BEGIN
  IF to_regclass('public.certificate_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificate_history_previous_certificate_id_fkey' AND conrelid = to_regclass('public.certificate_history')
     ) THEN
    ALTER TABLE ONLY public.certificate_history
        ADD CONSTRAINT certificate_history_previous_certificate_id_fkey FOREIGN KEY (previous_certificate_id) REFERENCES public.certificates(id);
  END IF;
END $$;


-- FK CONSTRAINT: certificate_history certificate_history_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.certificate_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificate_history_tenant_id_fkey' AND conrelid = to_regclass('public.certificate_history')
     ) THEN
    ALTER TABLE ONLY public.certificate_history
        ADD CONSTRAINT certificate_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: certificates certificates_issuer_certificate_id_fkey
DO $$ BEGIN
  IF to_regclass('public.certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificates_issuer_certificate_id_fkey' AND conrelid = to_regclass('public.certificates')
     ) THEN
    ALTER TABLE ONLY public.certificates
        ADD CONSTRAINT certificates_issuer_certificate_id_fkey FOREIGN KEY (issuer_certificate_id) REFERENCES public.certificates(id);
  END IF;
END $$;


-- FK CONSTRAINT: certificates certificates_superseded_by_certificate_id_fkey
DO $$ BEGIN
  IF to_regclass('public.certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificates_superseded_by_certificate_id_fkey' AND conrelid = to_regclass('public.certificates')
     ) THEN
    ALTER TABLE ONLY public.certificates
        ADD CONSTRAINT certificates_superseded_by_certificate_id_fkey FOREIGN KEY (superseded_by_certificate_id) REFERENCES public.certificates(id);
  END IF;
END $$;


-- FK CONSTRAINT: certificates certificates_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'certificates_tenant_id_fkey' AND conrelid = to_regclass('public.certificates')
     ) THEN
    ALTER TABLE ONLY public.certificates
        ADD CONSTRAINT certificates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: cmdb_entity_mappings cmdb_entity_mappings_profile_id_fkey
DO $$ BEGIN
  IF to_regclass('public.cmdb_entity_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'cmdb_entity_mappings_profile_id_fkey' AND conrelid = to_regclass('public.cmdb_entity_mappings')
     ) THEN
    ALTER TABLE ONLY public.cmdb_entity_mappings
        ADD CONSTRAINT cmdb_entity_mappings_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.cmdb_sync_profiles(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: cmdb_entity_mappings cmdb_entity_mappings_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.cmdb_entity_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'cmdb_entity_mappings_tenant_id_fkey' AND conrelid = to_regclass('public.cmdb_entity_mappings')
     ) THEN
    ALTER TABLE ONLY public.cmdb_entity_mappings
        ADD CONSTRAINT cmdb_entity_mappings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: cmdb_sync_jobs cmdb_sync_jobs_profile_id_fkey
DO $$ BEGIN
  IF to_regclass('public.cmdb_sync_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'cmdb_sync_jobs_profile_id_fkey' AND conrelid = to_regclass('public.cmdb_sync_jobs')
     ) THEN
    ALTER TABLE ONLY public.cmdb_sync_jobs
        ADD CONSTRAINT cmdb_sync_jobs_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.cmdb_sync_profiles(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: cmdb_sync_jobs cmdb_sync_jobs_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.cmdb_sync_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'cmdb_sync_jobs_tenant_id_fkey' AND conrelid = to_regclass('public.cmdb_sync_jobs')
     ) THEN
    ALTER TABLE ONLY public.cmdb_sync_jobs
        ADD CONSTRAINT cmdb_sync_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: cmdb_sync_profiles cmdb_sync_profiles_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.cmdb_sync_profiles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'cmdb_sync_profiles_tenant_id_fkey' AND conrelid = to_regclass('public.cmdb_sync_profiles')
     ) THEN
    ALTER TABLE ONLY public.cmdb_sync_profiles
        ADD CONSTRAINT cmdb_sync_profiles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: compliance_finding_history compliance_finding_history_changed_by_fkey
DO $$ BEGIN
  IF to_regclass('public.compliance_finding_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_finding_history_changed_by_fkey' AND conrelid = to_regclass('public.compliance_finding_history')
     ) THEN
    ALTER TABLE ONLY public.compliance_finding_history
        ADD CONSTRAINT compliance_finding_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;



-- FK CONSTRAINT: compliance_overrides compliance_overrides_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.compliance_overrides') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_overrides_created_by_fkey' AND conrelid = to_regclass('public.compliance_overrides')
     ) THEN
    ALTER TABLE ONLY public.compliance_overrides
        ADD CONSTRAINT compliance_overrides_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: compliance_overrides compliance_overrides_scenario_id_fkey
DO $$ BEGIN
  IF to_regclass('public.compliance_overrides') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_overrides_scenario_id_fkey' AND conrelid = to_regclass('public.compliance_overrides')
     ) THEN
    ALTER TABLE ONLY public.compliance_overrides
        ADD CONSTRAINT compliance_overrides_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES public.compliance_scenarios(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: compliance_overrides compliance_overrides_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.compliance_overrides') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_overrides_tenant_id_fkey' AND conrelid = to_regclass('public.compliance_overrides')
     ) THEN
    ALTER TABLE ONLY public.compliance_overrides
        ADD CONSTRAINT compliance_overrides_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: compliance_scenarios compliance_scenarios_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.compliance_scenarios') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_scenarios_created_by_fkey' AND conrelid = to_regclass('public.compliance_scenarios')
     ) THEN
    ALTER TABLE ONLY public.compliance_scenarios
        ADD CONSTRAINT compliance_scenarios_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: compliance_scenarios compliance_scenarios_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.compliance_scenarios') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_scenarios_tenant_id_fkey' AND conrelid = to_regclass('public.compliance_scenarios')
     ) THEN
    ALTER TABLE ONLY public.compliance_scenarios
        ADD CONSTRAINT compliance_scenarios_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: compliance_scenarios compliance_scenarios_updated_by_fkey
DO $$ BEGIN
  IF to_regclass('public.compliance_scenarios') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_scenarios_updated_by_fkey' AND conrelid = to_regclass('public.compliance_scenarios')
     ) THEN
    ALTER TABLE ONLY public.compliance_scenarios
        ADD CONSTRAINT compliance_scenarios_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: control_measurements control_measurements_measurement_type_id_fkey
DO $$ BEGIN
  IF to_regclass('public.control_measurements') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'control_measurements_measurement_type_id_fkey' AND conrelid = to_regclass('public.control_measurements')
     ) THEN
    ALTER TABLE ONLY public.control_measurements
        ADD CONSTRAINT control_measurements_measurement_type_id_fkey FOREIGN KEY (measurement_type_id) REFERENCES public.measurement_types(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: crypto_applications crypto_applications_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.crypto_applications') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_applications_algorithm_id_fkey' AND conrelid = to_regclass('public.crypto_applications')
     ) THEN
    ALTER TABLE ONLY public.crypto_applications
        ADD CONSTRAINT crypto_applications_algorithm_id_fkey FOREIGN KEY (algorithm_id) REFERENCES public.algorithms(id);
  END IF;
END $$;


-- FK CONSTRAINT: crypto_applications crypto_applications_certificate_id_fkey
DO $$ BEGIN
  IF to_regclass('public.crypto_applications') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_applications_certificate_id_fkey' AND conrelid = to_regclass('public.crypto_applications')
     ) THEN
    ALTER TABLE ONLY public.crypto_applications
        ADD CONSTRAINT crypto_applications_certificate_id_fkey FOREIGN KEY (certificate_id) REFERENCES public.certificates(id);
  END IF;
END $$;


-- FK CONSTRAINT: crypto_applications crypto_applications_key_id_fkey
DO $$ BEGIN
  IF to_regclass('public.crypto_applications') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_applications_key_id_fkey' AND conrelid = to_regclass('public.crypto_applications')
     ) THEN
    ALTER TABLE ONLY public.crypto_applications
        ADD CONSTRAINT crypto_applications_key_id_fkey FOREIGN KEY (key_id) REFERENCES public.keys(id);
  END IF;
END $$;


-- FK CONSTRAINT: crypto_applications crypto_applications_library_id_fkey
DO $$ BEGIN
  IF to_regclass('public.crypto_applications') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_applications_library_id_fkey' AND conrelid = to_regclass('public.crypto_applications')
     ) THEN
    ALTER TABLE ONLY public.crypto_applications
        ADD CONSTRAINT crypto_applications_library_id_fkey FOREIGN KEY (library_id) REFERENCES public.crypto_libraries(id);
  END IF;
END $$;


-- FK CONSTRAINT: crypto_applications crypto_applications_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.crypto_applications') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_applications_tenant_id_fkey' AND conrelid = to_regclass('public.crypto_applications')
     ) THEN
    ALTER TABLE ONLY public.crypto_applications
        ADD CONSTRAINT crypto_applications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;








-- FK CONSTRAINT: crypto_implementation_algorithms crypto_implementation_algorithms_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.crypto_implementation_algorithms') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_implementation_algorithms_algorithm_id_fkey' AND conrelid = to_regclass('public.crypto_implementation_algorithms')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementation_algorithms
        ADD CONSTRAINT crypto_implementation_algorithms_algorithm_id_fkey FOREIGN KEY (algorithm_id) REFERENCES public.algorithms(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: crypto_implementation_algorithms_crypto_implementation_id_fkey -- REMOVED.
-- Targeted crypto_implementations_legacy(id), an empty residual table, so it
-- could never be satisfied by live (partitioned) implementations. It is dropped
-- in POST-MIGRATIONS below; re-adding it here as well made the file NON-IDEMPOTENT
-- once the junction had rows: the ADD would fail against existing data and abort
-- the schema-migration Job under ON_ERROR_STOP=1, breaking helm upgrade.


-- FK CONSTRAINT: crypto_implementation_certificate_crypto_implementation_id_fkey -- REMOVED.
-- Targeted crypto_implementations_legacy(id), an empty residual table, so it
-- could never be satisfied by live (partitioned) implementations. It is dropped
-- in POST-MIGRATIONS below; re-adding it here as well made the file NON-IDEMPOTENT
-- once the junction had rows: the ADD would fail against existing data and abort
-- the schema-migration Job under ON_ERROR_STOP=1, breaking helm upgrade.


-- FK CONSTRAINT: crypto_implementation_certificates crypto_implementation_certificates_certificate_id_fkey
DO $$ BEGIN
  IF to_regclass('public.crypto_implementation_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_implementation_certificates_certificate_id_fkey' AND conrelid = to_regclass('public.crypto_implementation_certificates')
     ) THEN
    ALTER TABLE ONLY public.crypto_implementation_certificates
        ADD CONSTRAINT crypto_implementation_certificates_certificate_id_fkey FOREIGN KEY (certificate_id) REFERENCES public.certificates(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: crypto_libraries crypto_libraries_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.crypto_libraries') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_libraries_tenant_id_fkey' AND conrelid = to_regclass('public.crypto_libraries')
     ) THEN
    ALTER TABLE ONLY public.crypto_libraries
        ADD CONSTRAINT crypto_libraries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: database_encryption_states database_encryption_states_certificate_id_fkey
DO $$ BEGIN
  IF to_regclass('public.database_encryption_states') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'database_encryption_states_certificate_id_fkey' AND conrelid = to_regclass('public.database_encryption_states')
     ) THEN
    ALTER TABLE ONLY public.database_encryption_states
        ADD CONSTRAINT database_encryption_states_certificate_id_fkey FOREIGN KEY (certificate_id) REFERENCES public.certificates(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: database_encryption_states database_encryption_states_encryption_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.database_encryption_states') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'database_encryption_states_encryption_algorithm_id_fkey' AND conrelid = to_regclass('public.database_encryption_states')
     ) THEN
    ALTER TABLE ONLY public.database_encryption_states
        ADD CONSTRAINT database_encryption_states_encryption_algorithm_id_fkey FOREIGN KEY (encryption_algorithm_id) REFERENCES public.algorithms(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: database_encryption_states database_encryption_states_password_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.database_encryption_states') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'database_encryption_states_password_algorithm_id_fkey' AND conrelid = to_regclass('public.database_encryption_states')
     ) THEN
    ALTER TABLE ONLY public.database_encryption_states
        ADD CONSTRAINT database_encryption_states_password_algorithm_id_fkey FOREIGN KEY (password_algorithm_id) REFERENCES public.algorithms(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: database_encryption_states database_encryption_states_ssl_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.database_encryption_states') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'database_encryption_states_ssl_algorithm_id_fkey' AND conrelid = to_regclass('public.database_encryption_states')
     ) THEN
    ALTER TABLE ONLY public.database_encryption_states
        ADD CONSTRAINT database_encryption_states_ssl_algorithm_id_fkey FOREIGN KEY (ssl_algorithm_id) REFERENCES public.algorithms(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: database_encryption_states database_encryption_states_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.database_encryption_states') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'database_encryption_states_tenant_id_fkey' AND conrelid = to_regclass('public.database_encryption_states')
     ) THEN
    ALTER TABLE ONLY public.database_encryption_states
        ADD CONSTRAINT database_encryption_states_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: device_agents device_agents_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.device_agents') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'device_agents_tenant_id_fkey' AND conrelid = to_regclass('public.device_agents')
     ) THEN
    ALTER TABLE ONLY public.device_agents
        ADD CONSTRAINT device_agents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: device_jobs device_jobs_agent_id_fkey
DO $$ BEGIN
  IF to_regclass('public.device_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'device_jobs_agent_id_fkey' AND conrelid = to_regclass('public.device_jobs')
     ) THEN
    ALTER TABLE ONLY public.device_jobs
        ADD CONSTRAINT device_jobs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.device_agents(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: device_jobs device_jobs_integration_id_fkey
DO $$ BEGIN
  IF to_regclass('public.device_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'device_jobs_integration_id_fkey' AND conrelid = to_regclass('public.device_jobs')
     ) THEN
    ALTER TABLE ONLY public.device_jobs
        ADD CONSTRAINT device_jobs_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.platform_integrations(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: device_jobs device_jobs_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.device_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'device_jobs_tenant_id_fkey' AND conrelid = to_regclass('public.device_jobs')
     ) THEN
    ALTER TABLE ONLY public.device_jobs
        ADD CONSTRAINT device_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_alert_configs discovery_alert_configs_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_alert_configs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_alert_configs_tenant_id_fkey' AND conrelid = to_regclass('public.discovery_alert_configs')
     ) THEN
    ALTER TABLE ONLY public.discovery_alert_configs
        ADD CONSTRAINT discovery_alert_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_alert_history discovery_alert_history_finding_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_alert_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_alert_history_finding_id_fkey' AND conrelid = to_regclass('public.discovery_alert_history')
     ) THEN
    ALTER TABLE ONLY public.discovery_alert_history
        ADD CONSTRAINT discovery_alert_history_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.discovery_findings(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_alert_history discovery_alert_history_job_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_alert_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_alert_history_job_id_fkey' AND conrelid = to_regclass('public.discovery_alert_history')
     ) THEN
    ALTER TABLE ONLY public.discovery_alert_history
        ADD CONSTRAINT discovery_alert_history_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.discovery_jobs(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_alert_history discovery_alert_history_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_alert_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_alert_history_tenant_id_fkey' AND conrelid = to_regclass('public.discovery_alert_history')
     ) THEN
    ALTER TABLE ONLY public.discovery_alert_history
        ADD CONSTRAINT discovery_alert_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_auto_approval_rules discovery_auto_approval_rules_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_auto_approval_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_auto_approval_rules_created_by_fkey' AND conrelid = to_regclass('public.discovery_auto_approval_rules')
     ) THEN
    ALTER TABLE ONLY public.discovery_auto_approval_rules
        ADD CONSTRAINT discovery_auto_approval_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_auto_approval_rules discovery_auto_approval_rules_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_auto_approval_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_auto_approval_rules_tenant_id_fkey' AND conrelid = to_regclass('public.discovery_auto_approval_rules')
     ) THEN
    ALTER TABLE ONLY public.discovery_auto_approval_rules
        ADD CONSTRAINT discovery_auto_approval_rules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_findings discovery_findings_job_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_findings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_findings_job_id_fkey' AND conrelid = to_regclass('public.discovery_findings')
     ) THEN
    ALTER TABLE ONLY public.discovery_findings
        ADD CONSTRAINT discovery_findings_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.discovery_jobs(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_findings discovery_findings_target_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_findings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_findings_target_id_fkey' AND conrelid = to_regclass('public.discovery_findings')
     ) THEN
    ALTER TABLE ONLY public.discovery_findings
        ADD CONSTRAINT discovery_findings_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.discovery_targets(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_findings discovery_findings_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_findings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_findings_tenant_id_fkey' AND conrelid = to_regclass('public.discovery_findings')
     ) THEN
    ALTER TABLE ONLY public.discovery_findings
        ADD CONSTRAINT discovery_findings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_jobs discovery_jobs_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_jobs_created_by_fkey' AND conrelid = to_regclass('public.discovery_jobs')
     ) THEN
    ALTER TABLE ONLY public.discovery_jobs
        ADD CONSTRAINT discovery_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_jobs discovery_jobs_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_jobs_tenant_id_fkey' AND conrelid = to_regclass('public.discovery_jobs')
     ) THEN
    ALTER TABLE ONLY public.discovery_jobs
        ADD CONSTRAINT discovery_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_rate_limits discovery_rate_limits_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_rate_limits') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_rate_limits_tenant_id_fkey' AND conrelid = to_regclass('public.discovery_rate_limits')
     ) THEN
    ALTER TABLE ONLY public.discovery_rate_limits
        ADD CONSTRAINT discovery_rate_limits_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_targets discovery_targets_job_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_targets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_targets_job_id_fkey' AND conrelid = to_regclass('public.discovery_targets')
     ) THEN
    ALTER TABLE ONLY public.discovery_targets
        ADD CONSTRAINT discovery_targets_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.discovery_jobs(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: discovery_targets discovery_targets_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.discovery_targets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'discovery_targets_tenant_id_fkey' AND conrelid = to_regclass('public.discovery_targets')
     ) THEN
    ALTER TABLE ONLY public.discovery_targets
        ADD CONSTRAINT discovery_targets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: external_asset_mappings external_asset_mappings_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.external_asset_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_asset_mappings_tenant_id_fkey' AND conrelid = to_regclass('public.external_asset_mappings')
     ) THEN
    ALTER TABLE ONLY public.external_asset_mappings
        ADD CONSTRAINT external_asset_mappings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: external_connection_history external_connection_history_external_connection_id_fkey
DO $$ BEGIN
  IF to_regclass('public.external_connection_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_connection_history_external_connection_id_fkey' AND conrelid = to_regclass('public.external_connection_history')
     ) THEN
    ALTER TABLE ONLY public.external_connection_history
        ADD CONSTRAINT external_connection_history_external_connection_id_fkey FOREIGN KEY (external_connection_id) REFERENCES public.external_connections(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: external_connection_history external_connection_history_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.external_connection_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_connection_history_tenant_id_fkey' AND conrelid = to_regclass('public.external_connection_history')
     ) THEN
    ALTER TABLE ONLY public.external_connection_history
        ADD CONSTRAINT external_connection_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: external_connections external_connections_sensor_id_fkey
DO $$ BEGIN
  IF to_regclass('public.external_connections') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_connections_sensor_id_fkey' AND conrelid = to_regclass('public.external_connections')
     ) THEN
    ALTER TABLE ONLY public.external_connections
        ADD CONSTRAINT external_connections_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.sensors(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: external_connections external_connections_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.external_connections') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_connections_tenant_id_fkey' AND conrelid = to_regclass('public.external_connections')
     ) THEN
    ALTER TABLE ONLY public.external_connections
        ADD CONSTRAINT external_connections_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: implementation_keys_implementation_id_fkey -- REMOVED.
-- Targeted crypto_implementations_legacy(id), an empty residual table, so it
-- could never be satisfied by live (partitioned) implementations. It is dropped
-- in POST-MIGRATIONS below; re-adding it here as well made the file NON-IDEMPOTENT
-- once the junction had rows: the ADD would fail against existing data and abort
-- the schema-migration Job under ON_ERROR_STOP=1, breaking helm upgrade.


-- FK CONSTRAINT: implementation_keys implementation_keys_key_id_fkey
DO $$ BEGIN
  IF to_regclass('public.implementation_keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'implementation_keys_key_id_fkey' AND conrelid = to_regclass('public.implementation_keys')
     ) THEN
    ALTER TABLE ONLY public.implementation_keys
        ADD CONSTRAINT implementation_keys_key_id_fkey FOREIGN KEY (key_id) REFERENCES public.keys(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: implementation_libraries_implementation_id_fkey -- REMOVED.
-- Targeted crypto_implementations_legacy(id), an empty residual table, so it
-- could never be satisfied by live (partitioned) implementations. It is dropped
-- in POST-MIGRATIONS below; re-adding it here as well made the file NON-IDEMPOTENT
-- once the junction had rows: the ADD would fail against existing data and abort
-- the schema-migration Job under ON_ERROR_STOP=1, breaking helm upgrade.


-- FK CONSTRAINT: implementation_libraries implementation_libraries_library_id_fkey
DO $$ BEGIN
  IF to_regclass('public.implementation_libraries') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'implementation_libraries_library_id_fkey' AND conrelid = to_regclass('public.implementation_libraries')
     ) THEN
    ALTER TABLE ONLY public.implementation_libraries
        ADD CONSTRAINT implementation_libraries_library_id_fkey FOREIGN KEY (library_id) REFERENCES public.crypto_libraries(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: in_app_notifications in_app_notifications_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.in_app_notifications') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'in_app_notifications_tenant_id_fkey' AND conrelid = to_regclass('public.in_app_notifications')
     ) THEN
    ALTER TABLE ONLY public.in_app_notifications
        ADD CONSTRAINT in_app_notifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: integrations integrations_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.integrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'integrations_tenant_id_fkey' AND conrelid = to_regclass('public.integrations')
     ) THEN
    ALTER TABLE ONLY public.integrations
        ADD CONSTRAINT integrations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: interrogation_schedules interrogation_schedules_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.interrogation_schedules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'interrogation_schedules_tenant_id_fkey' AND conrelid = to_regclass('public.interrogation_schedules')
     ) THEN
    ALTER TABLE ONLY public.interrogation_schedules
        ADD CONSTRAINT interrogation_schedules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: keys keys_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'keys_algorithm_id_fkey' AND conrelid = to_regclass('public.keys')
     ) THEN
    ALTER TABLE ONLY public.keys
        ADD CONSTRAINT keys_algorithm_id_fkey FOREIGN KEY (algorithm_id) REFERENCES public.algorithms(id);
  END IF;
END $$;


-- FK CONSTRAINT: keys keys_secured_by_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'keys_secured_by_algorithm_id_fkey' AND conrelid = to_regclass('public.keys')
     ) THEN
    ALTER TABLE ONLY public.keys
        ADD CONSTRAINT keys_secured_by_algorithm_id_fkey FOREIGN KEY (secured_by_algorithm_id) REFERENCES public.algorithms(id);
  END IF;
END $$;


-- FK CONSTRAINT: keys keys_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'keys_tenant_id_fkey' AND conrelid = to_regclass('public.keys')
     ) THEN
    ALTER TABLE ONLY public.keys
        ADD CONSTRAINT keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: kms_keys kms_keys_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.kms_keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'kms_keys_algorithm_id_fkey' AND conrelid = to_regclass('public.kms_keys')
     ) THEN
    ALTER TABLE ONLY public.kms_keys
        ADD CONSTRAINT kms_keys_algorithm_id_fkey FOREIGN KEY (algorithm_id) REFERENCES public.algorithms(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: kms_keys kms_keys_integration_id_fkey
DO $$ BEGIN
  IF to_regclass('public.kms_keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'kms_keys_integration_id_fkey' AND conrelid = to_regclass('public.kms_keys')
     ) THEN
    ALTER TABLE ONLY public.kms_keys
        ADD CONSTRAINT kms_keys_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.platform_integrations(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: kms_keys kms_keys_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.kms_keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'kms_keys_tenant_id_fkey' AND conrelid = to_regclass('public.kms_keys')
     ) THEN
    ALTER TABLE ONLY public.kms_keys
        ADD CONSTRAINT kms_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: library_provided_algorithms library_provided_algorithms_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.library_provided_algorithms') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'library_provided_algorithms_algorithm_id_fkey' AND conrelid = to_regclass('public.library_provided_algorithms')
     ) THEN
    ALTER TABLE ONLY public.library_provided_algorithms
        ADD CONSTRAINT library_provided_algorithms_algorithm_id_fkey FOREIGN KEY (algorithm_id) REFERENCES public.algorithms(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: library_provided_algorithms library_provided_algorithms_library_id_fkey
DO $$ BEGIN
  IF to_regclass('public.library_provided_algorithms') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'library_provided_algorithms_library_id_fkey' AND conrelid = to_regclass('public.library_provided_algorithms')
     ) THEN
    ALTER TABLE ONLY public.library_provided_algorithms
        ADD CONSTRAINT library_provided_algorithms_library_id_fkey FOREIGN KEY (library_id) REFERENCES public.crypto_libraries(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: locations locations_parent_id_fkey
DO $$ BEGIN
  IF to_regclass('public.locations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'locations_parent_id_fkey' AND conrelid = to_regclass('public.locations')
     ) THEN
    ALTER TABLE ONLY public.locations
        ADD CONSTRAINT locations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.locations(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: locations locations_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.locations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'locations_tenant_id_fkey' AND conrelid = to_regclass('public.locations')
     ) THEN
    ALTER TABLE ONLY public.locations
        ADD CONSTRAINT locations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: measurement_templates measurement_templates_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.measurement_templates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'measurement_templates_created_by_fkey' AND conrelid = to_regclass('public.measurement_templates')
     ) THEN
    ALTER TABLE ONLY public.measurement_templates
        ADD CONSTRAINT measurement_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: measurement_templates measurement_templates_measurement_type_id_fkey
DO $$ BEGIN
  IF to_regclass('public.measurement_templates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'measurement_templates_measurement_type_id_fkey' AND conrelid = to_regclass('public.measurement_templates')
     ) THEN
    ALTER TABLE ONLY public.measurement_templates
        ADD CONSTRAINT measurement_templates_measurement_type_id_fkey FOREIGN KEY (measurement_type_id) REFERENCES public.measurement_types(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: monitoring_alert_history monitoring_alert_history_threshold_id_fkey
DO $$ BEGIN
  IF to_regclass('public.monitoring_alert_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'monitoring_alert_history_threshold_id_fkey' AND conrelid = to_regclass('public.monitoring_alert_history')
     ) THEN
    ALTER TABLE ONLY public.monitoring_alert_history
        ADD CONSTRAINT monitoring_alert_history_threshold_id_fkey FOREIGN KEY (threshold_id) REFERENCES public.monitoring_alert_thresholds(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: network_segments network_segments_location_id_fkey
DO $$ BEGIN
  IF to_regclass('public.network_segments') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'network_segments_location_id_fkey' AND conrelid = to_regclass('public.network_segments')
     ) THEN
    ALTER TABLE ONLY public.network_segments
        ADD CONSTRAINT network_segments_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: network_segments network_segments_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.network_segments') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'network_segments_tenant_id_fkey' AND conrelid = to_regclass('public.network_segments')
     ) THEN
    ALTER TABLE ONLY public.network_segments
        ADD CONSTRAINT network_segments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: notification_delivery_queue notification_delivery_queue_notification_id_fkey
DO $$ BEGIN
  IF to_regclass('public.notification_delivery_queue') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'notification_delivery_queue_notification_id_fkey' AND conrelid = to_regclass('public.notification_delivery_queue')
     ) THEN
    ALTER TABLE ONLY public.notification_delivery_queue
        ADD CONSTRAINT notification_delivery_queue_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notification_history(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: notification_delivery_queue notification_delivery_queue_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.notification_delivery_queue') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'notification_delivery_queue_tenant_id_fkey' AND conrelid = to_regclass('public.notification_delivery_queue')
     ) THEN
    ALTER TABLE ONLY public.notification_delivery_queue
        ADD CONSTRAINT notification_delivery_queue_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: notification_history notification_history_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.notification_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'notification_history_tenant_id_fkey' AND conrelid = to_regclass('public.notification_history')
     ) THEN
    ALTER TABLE ONLY public.notification_history
        ADD CONSTRAINT notification_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: pcap_upload_jobs pcap_upload_jobs_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.pcap_upload_jobs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'pcap_upload_jobs_tenant_id_fkey' AND conrelid = to_regclass('public.pcap_upload_jobs')
     ) THEN
    ALTER TABLE ONLY public.pcap_upload_jobs
        ADD CONSTRAINT pcap_upload_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: pending_sensor_registrations pending_sensor_registrations_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.pending_sensor_registrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'pending_sensor_registrations_tenant_id_fkey' AND conrelid = to_regclass('public.pending_sensor_registrations')
     ) THEN
    ALTER TABLE ONLY public.pending_sensor_registrations
        ADD CONSTRAINT pending_sensor_registrations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: permission_audit_logs permission_audit_logs_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.permission_audit_logs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'permission_audit_logs_tenant_id_fkey' AND conrelid = to_regclass('public.permission_audit_logs')
     ) THEN
    ALTER TABLE ONLY public.permission_audit_logs
        ADD CONSTRAINT permission_audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: permission_audit_logs permission_audit_logs_user_id_fkey
DO $$ BEGIN
  IF to_regclass('public.permission_audit_logs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'permission_audit_logs_user_id_fkey' AND conrelid = to_regclass('public.permission_audit_logs')
     ) THEN
    ALTER TABLE ONLY public.permission_audit_logs
        ADD CONSTRAINT permission_audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: platform_framework_controls platform_framework_controls_framework_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_framework_controls') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_framework_controls_framework_id_fkey' AND conrelid = to_regclass('public.platform_framework_controls')
     ) THEN
    ALTER TABLE ONLY public.platform_framework_controls
        ADD CONSTRAINT platform_framework_controls_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.platform_frameworks(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: platform_framework_versions platform_framework_versions_changed_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_framework_versions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_framework_versions_changed_by_fkey' AND conrelid = to_regclass('public.platform_framework_versions')
     ) THEN
    ALTER TABLE ONLY public.platform_framework_versions
        ADD CONSTRAINT platform_framework_versions_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.platform_users(id);
  END IF;
END $$;


-- FK CONSTRAINT: platform_framework_versions platform_framework_versions_framework_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_framework_versions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_framework_versions_framework_id_fkey' AND conrelid = to_regclass('public.platform_framework_versions')
     ) THEN
    ALTER TABLE ONLY public.platform_framework_versions
        ADD CONSTRAINT platform_framework_versions_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.platform_frameworks(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: platform_frameworks platform_frameworks_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_frameworks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_frameworks_created_by_fkey' AND conrelid = to_regclass('public.platform_frameworks')
     ) THEN
    ALTER TABLE ONLY public.platform_frameworks
        ADD CONSTRAINT platform_frameworks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.platform_users(id);
  END IF;
END $$;


-- FK CONSTRAINT: platform_frameworks platform_frameworks_published_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_frameworks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_frameworks_published_by_fkey' AND conrelid = to_regclass('public.platform_frameworks')
     ) THEN
    ALTER TABLE ONLY public.platform_frameworks
        ADD CONSTRAINT platform_frameworks_published_by_fkey FOREIGN KEY (published_by) REFERENCES public.platform_users(id);
  END IF;
END $$;


-- FK CONSTRAINT: platform_integration_audit_log platform_integration_audit_log_integration_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_integration_audit_log') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_integration_audit_log_integration_id_fkey' AND conrelid = to_regclass('public.platform_integration_audit_log')
     ) THEN
    ALTER TABLE ONLY public.platform_integration_audit_log
        ADD CONSTRAINT platform_integration_audit_log_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.platform_integrations(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: platform_integration_audit_log platform_integration_audit_log_performed_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_integration_audit_log') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_integration_audit_log_performed_by_fkey' AND conrelid = to_regclass('public.platform_integration_audit_log')
     ) THEN
    ALTER TABLE ONLY public.platform_integration_audit_log
        ADD CONSTRAINT platform_integration_audit_log_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.platform_users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: platform_integrations platform_integrations_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_integrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_integrations_created_by_fkey' AND conrelid = to_regclass('public.platform_integrations')
     ) THEN
    ALTER TABLE ONLY public.platform_integrations
        ADD CONSTRAINT platform_integrations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.platform_users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: platform_integrations platform_integrations_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_integrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_integrations_tenant_id_fkey' AND conrelid = to_regclass('public.platform_integrations')
     ) THEN
    ALTER TABLE ONLY public.platform_integrations
        ADD CONSTRAINT platform_integrations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: platform_integrations platform_integrations_updated_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_integrations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_integrations_updated_by_fkey' AND conrelid = to_regclass('public.platform_integrations')
     ) THEN
    ALTER TABLE ONLY public.platform_integrations
        ADD CONSTRAINT platform_integrations_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.platform_users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: platform_log_access_audit platform_log_access_audit_log_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_log_access_audit') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_log_access_audit_log_id_fkey' AND conrelid = to_regclass('public.platform_log_access_audit')
     ) THEN
    ALTER TABLE ONLY public.platform_log_access_audit
        ADD CONSTRAINT platform_log_access_audit_log_id_fkey FOREIGN KEY (log_id) REFERENCES public.platform_log_metadata(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: platform_log_metadata platform_log_metadata_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_log_metadata') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_log_metadata_tenant_id_fkey' AND conrelid = to_regclass('public.platform_log_metadata')
     ) THEN
    ALTER TABLE ONLY public.platform_log_metadata
        ADD CONSTRAINT platform_log_metadata_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: platform_notification_channels platform_notification_channels_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_notification_channels_created_by_fkey' AND conrelid = to_regclass('public.platform_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.platform_notification_channels
        ADD CONSTRAINT platform_notification_channels_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.platform_users(id);
  END IF;
END $$;


-- FK CONSTRAINT: platform_notification_channels platform_notification_channels_updated_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_notification_channels_updated_by_fkey' AND conrelid = to_regclass('public.platform_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.platform_notification_channels
        ADD CONSTRAINT platform_notification_channels_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.platform_users(id);
  END IF;
END $$;


-- FK CONSTRAINT: platform_refresh_tokens platform_refresh_tokens_platform_user_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_refresh_tokens') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_refresh_tokens_platform_user_id_fkey' AND conrelid = to_regclass('public.platform_refresh_tokens')
     ) THEN
    ALTER TABLE ONLY public.platform_refresh_tokens
        ADD CONSTRAINT platform_refresh_tokens_platform_user_id_fkey FOREIGN KEY (platform_user_id) REFERENCES public.platform_users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: platform_role_permissions platform_role_permissions_permission_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_role_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_role_permissions_permission_id_fkey' AND conrelid = to_regclass('public.platform_role_permissions')
     ) THEN
    ALTER TABLE ONLY public.platform_role_permissions
        ADD CONSTRAINT platform_role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.platform_permissions(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: platform_role_permissions platform_role_permissions_role_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_role_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_role_permissions_role_id_fkey' AND conrelid = to_regclass('public.platform_role_permissions')
     ) THEN
    ALTER TABLE ONLY public.platform_role_permissions
        ADD CONSTRAINT platform_role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.platform_roles(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: platform_settings platform_settings_updated_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_settings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_settings_updated_by_fkey' AND conrelid = to_regclass('public.platform_settings')
     ) THEN
    ALTER TABLE ONLY public.platform_settings
        ADD CONSTRAINT platform_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.platform_users(id);
  END IF;
END $$;


-- FK CONSTRAINT: platform_users platform_users_invited_by_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_users') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_users_invited_by_fkey' AND conrelid = to_regclass('public.platform_users')
     ) THEN
    ALTER TABLE ONLY public.platform_users
        ADD CONSTRAINT platform_users_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.platform_users(id);
  END IF;
END $$;


-- FK CONSTRAINT: platform_users platform_users_role_id_fkey
DO $$ BEGIN
  IF to_regclass('public.platform_users') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'platform_users_role_id_fkey' AND conrelid = to_regclass('public.platform_users')
     ) THEN
    ALTER TABLE ONLY public.platform_users
        ADD CONSTRAINT platform_users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.platform_roles(id);
  END IF;
END $$;


-- FK CONSTRAINT: refresh_tokens refresh_tokens_user_id_fkey
DO $$ BEGIN
  IF to_regclass('public.refresh_tokens') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'refresh_tokens_user_id_fkey' AND conrelid = to_regclass('public.refresh_tokens')
     ) THEN
    ALTER TABLE ONLY public.refresh_tokens
        ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: remediation_plan_items remediation_plan_items_added_by_fkey
DO $$ BEGIN
  IF to_regclass('public.remediation_plan_items') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'remediation_plan_items_added_by_fkey' AND conrelid = to_regclass('public.remediation_plan_items')
     ) THEN
    ALTER TABLE ONLY public.remediation_plan_items
        ADD CONSTRAINT remediation_plan_items_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);
  END IF;
END $$;



-- FK CONSTRAINT: remediation_plan_items remediation_plan_items_plan_id_fkey
DO $$ BEGIN
  IF to_regclass('public.remediation_plan_items') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'remediation_plan_items_plan_id_fkey' AND conrelid = to_regclass('public.remediation_plan_items')
     ) THEN
    ALTER TABLE ONLY public.remediation_plan_items
        ADD CONSTRAINT remediation_plan_items_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.remediation_plans(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: remediation_plan_items remediation_plan_items_ticket_id_fkey
DO $$ BEGIN
  IF to_regclass('public.remediation_plan_items') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'remediation_plan_items_ticket_id_fkey' AND conrelid = to_regclass('public.remediation_plan_items')
     ) THEN
    ALTER TABLE ONLY public.remediation_plan_items
        ADD CONSTRAINT remediation_plan_items_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: remediation_plans remediation_plans_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.remediation_plans') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'remediation_plans_created_by_fkey' AND conrelid = to_regclass('public.remediation_plans')
     ) THEN
    ALTER TABLE ONLY public.remediation_plans
        ADD CONSTRAINT remediation_plans_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);
  END IF;
END $$;


-- FK CONSTRAINT: remediation_plans remediation_plans_owner_id_fkey
DO $$ BEGIN
  IF to_regclass('public.remediation_plans') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'remediation_plans_owner_id_fkey' AND conrelid = to_regclass('public.remediation_plans')
     ) THEN
    ALTER TABLE ONLY public.remediation_plans
        ADD CONSTRAINT remediation_plans_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: remediation_plans remediation_plans_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.remediation_plans') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'remediation_plans_tenant_id_fkey' AND conrelid = to_regclass('public.remediation_plans')
     ) THEN
    ALTER TABLE ONLY public.remediation_plans
        ADD CONSTRAINT remediation_plans_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: resource_alerts resource_alerts_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.resource_alerts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'resource_alerts_tenant_id_fkey' AND conrelid = to_regclass('public.resource_alerts')
     ) THEN
    ALTER TABLE ONLY public.resource_alerts
        ADD CONSTRAINT resource_alerts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: rule_vulnerability_mappings rule_vulnerability_mappings_rule_id_fkey
DO $$ BEGIN
  IF to_regclass('public.rule_vulnerability_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'rule_vulnerability_mappings_rule_id_fkey' AND conrelid = to_regclass('public.rule_vulnerability_mappings')
     ) THEN
    ALTER TABLE ONLY public.rule_vulnerability_mappings
        ADD CONSTRAINT rule_vulnerability_mappings_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.compliance_rules(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: schedule_history schedule_history_schedule_id_fkey
DO $$ BEGIN
  IF to_regclass('public.schedule_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'schedule_history_schedule_id_fkey' AND conrelid = to_regclass('public.schedule_history')
     ) THEN
    ALTER TABLE ONLY public.schedule_history
        ADD CONSTRAINT schedule_history_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.interrogation_schedules(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: security_incident_webhook_deliveries security_incident_webhook_deliveries_incident_id_fkey
DO $$ BEGIN
  IF to_regclass('public.security_incident_webhook_deliveries') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'security_incident_webhook_deliveries_incident_id_fkey' AND conrelid = to_regclass('public.security_incident_webhook_deliveries')
     ) THEN
    ALTER TABLE ONLY public.security_incident_webhook_deliveries
        ADD CONSTRAINT security_incident_webhook_deliveries_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.security_incidents(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: security_incident_webhook_deliveries security_incident_webhook_deliveries_webhook_id_fkey
DO $$ BEGIN
  IF to_regclass('public.security_incident_webhook_deliveries') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'security_incident_webhook_deliveries_webhook_id_fkey' AND conrelid = to_regclass('public.security_incident_webhook_deliveries')
     ) THEN
    ALTER TABLE ONLY public.security_incident_webhook_deliveries
        ADD CONSTRAINT security_incident_webhook_deliveries_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.security_incident_webhooks(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sensor_ca_certificates sensor_ca_certificates_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sensor_ca_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_ca_certificates_tenant_id_fkey' AND conrelid = to_regclass('public.sensor_ca_certificates')
     ) THEN
    ALTER TABLE ONLY public.sensor_ca_certificates
        ADD CONSTRAINT sensor_ca_certificates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sensor_certificates sensor_certificates_sensor_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sensor_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_certificates_sensor_id_fkey' AND conrelid = to_regclass('public.sensor_certificates')
     ) THEN
    ALTER TABLE ONLY public.sensor_certificates
        ADD CONSTRAINT sensor_certificates_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.sensors(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sensor_certificates sensor_certificates_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sensor_certificates') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_certificates_tenant_id_fkey' AND conrelid = to_regclass('public.sensor_certificates')
     ) THEN
    ALTER TABLE ONLY public.sensor_certificates
        ADD CONSTRAINT sensor_certificates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sensor_commands sensor_commands_sensor_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sensor_commands') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_commands_sensor_id_fkey' AND conrelid = to_regclass('public.sensor_commands')
     ) THEN
    ALTER TABLE ONLY public.sensor_commands
        ADD CONSTRAINT sensor_commands_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.sensors(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sensor_health_metrics sensor_health_metrics_sensor_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sensor_health_metrics') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_health_metrics_sensor_id_fkey' AND conrelid = to_regclass('public.sensor_health_metrics')
     ) THEN
    ALTER TABLE ONLY public.sensor_health_metrics
        ADD CONSTRAINT sensor_health_metrics_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.sensors(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sensors sensors_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sensors') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensors_tenant_id_fkey' AND conrelid = to_regclass('public.sensors')
     ) THEN
    ALTER TABLE ONLY public.sensors
        ADD CONSTRAINT sensors_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: service_identification_rules service_identification_rules_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.service_identification_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'service_identification_rules_tenant_id_fkey' AND conrelid = to_regclass('public.service_identification_rules')
     ) THEN
    ALTER TABLE ONLY public.service_identification_rules
        ADD CONSTRAINT service_identification_rules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: ssh_keys ssh_keys_algorithm_id_fkey
DO $$ BEGIN
  IF to_regclass('public.ssh_keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ssh_keys_algorithm_id_fkey' AND conrelid = to_regclass('public.ssh_keys')
     ) THEN
    ALTER TABLE ONLY public.ssh_keys
        ADD CONSTRAINT ssh_keys_algorithm_id_fkey FOREIGN KEY (algorithm_id) REFERENCES public.algorithms(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: ssh_keys ssh_keys_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.ssh_keys') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ssh_keys_tenant_id_fkey' AND conrelid = to_regclass('public.ssh_keys')
     ) THEN
    ALTER TABLE ONLY public.ssh_keys
        ADD CONSTRAINT ssh_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sso_group_role_mappings sso_group_role_mappings_role_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sso_group_role_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sso_group_role_mappings_role_id_fkey' AND conrelid = to_regclass('public.sso_group_role_mappings')
     ) THEN
    ALTER TABLE ONLY public.sso_group_role_mappings
        ADD CONSTRAINT sso_group_role_mappings_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.tenant_roles(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sso_group_role_mappings sso_group_role_mappings_sso_provider_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sso_group_role_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sso_group_role_mappings_sso_provider_id_fkey' AND conrelid = to_regclass('public.sso_group_role_mappings')
     ) THEN
    ALTER TABLE ONLY public.sso_group_role_mappings
        ADD CONSTRAINT sso_group_role_mappings_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES public.sso_providers(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sso_group_role_mappings sso_group_role_mappings_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sso_group_role_mappings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sso_group_role_mappings_tenant_id_fkey' AND conrelid = to_regclass('public.sso_group_role_mappings')
     ) THEN
    ALTER TABLE ONLY public.sso_group_role_mappings
        ADD CONSTRAINT sso_group_role_mappings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: sso_providers sso_providers_default_role_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sso_providers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sso_providers_default_role_id_fkey' AND conrelid = to_regclass('public.sso_providers')
     ) THEN
    ALTER TABLE ONLY public.sso_providers
        ADD CONSTRAINT sso_providers_default_role_id_fkey FOREIGN KEY (default_role_id) REFERENCES public.tenant_roles(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: sso_providers sso_providers_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.sso_providers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sso_providers_tenant_id_fkey' AND conrelid = to_regclass('public.sso_providers')
     ) THEN
    ALTER TABLE ONLY public.sso_providers
        ADD CONSTRAINT sso_providers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: subscription_tier_history subscription_tier_history_changed_by_fkey
DO $$ BEGIN
  IF to_regclass('public.subscription_tier_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'subscription_tier_history_changed_by_fkey' AND conrelid = to_regclass('public.subscription_tier_history')
     ) THEN
    ALTER TABLE ONLY public.subscription_tier_history
        ADD CONSTRAINT subscription_tier_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.platform_users(id);
  END IF;
END $$;


-- FK CONSTRAINT: subscription_tier_history subscription_tier_history_tier_id_fkey
DO $$ BEGIN
  IF to_regclass('public.subscription_tier_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'subscription_tier_history_tier_id_fkey' AND conrelid = to_regclass('public.subscription_tier_history')
     ) THEN
    ALTER TABLE ONLY public.subscription_tier_history
        ADD CONSTRAINT subscription_tier_history_tier_id_fkey FOREIGN KEY (tier_id) REFERENCES public.subscription_tiers(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: support_ticket_messages support_ticket_messages_ticket_id_fkey
DO $$ BEGIN
  IF to_regclass('public.support_ticket_messages') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'support_ticket_messages_ticket_id_fkey' AND conrelid = to_regclass('public.support_ticket_messages')
     ) THEN
    ALTER TABLE ONLY public.support_ticket_messages
        ADD CONSTRAINT support_ticket_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: support_tickets support_tickets_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.support_tickets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'support_tickets_tenant_id_fkey' AND conrelid = to_regclass('public.support_tickets')
     ) THEN
    ALTER TABLE ONLY public.support_tickets
        ADD CONSTRAINT support_tickets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_admin_settings_audit tenant_admin_settings_audit_changed_by_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_admin_settings_audit') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_admin_settings_audit_changed_by_fkey' AND conrelid = to_regclass('public.tenant_admin_settings_audit')
     ) THEN
    ALTER TABLE ONLY public.tenant_admin_settings_audit
        ADD CONSTRAINT tenant_admin_settings_audit_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_admin_settings_audit tenant_admin_settings_audit_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_admin_settings_audit') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_admin_settings_audit_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_admin_settings_audit')
     ) THEN
    ALTER TABLE ONLY public.tenant_admin_settings_audit
        ADD CONSTRAINT tenant_admin_settings_audit_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_admin_settings tenant_admin_settings_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_admin_settings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_admin_settings_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_admin_settings')
     ) THEN
    ALTER TABLE ONLY public.tenant_admin_settings
        ADD CONSTRAINT tenant_admin_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_admin_settings tenant_admin_settings_updated_by_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_admin_settings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_admin_settings_updated_by_fkey' AND conrelid = to_regclass('public.tenant_admin_settings')
     ) THEN
    ALTER TABLE ONLY public.tenant_admin_settings
        ADD CONSTRAINT tenant_admin_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_framework_controls tenant_framework_controls_framework_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_framework_controls') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_framework_controls_framework_id_fkey' AND conrelid = to_regclass('public.tenant_framework_controls')
     ) THEN
    ALTER TABLE ONLY public.tenant_framework_controls
        ADD CONSTRAINT tenant_framework_controls_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.tenant_frameworks(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_framework_licenses tenant_framework_licenses_locked_by_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_framework_licenses') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_framework_licenses_locked_by_fkey' AND conrelid = to_regclass('public.tenant_framework_licenses')
     ) THEN
    ALTER TABLE ONLY public.tenant_framework_licenses
        ADD CONSTRAINT tenant_framework_licenses_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_framework_licenses tenant_framework_licenses_platform_framework_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_framework_licenses') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_framework_licenses_platform_framework_id_fkey' AND conrelid = to_regclass('public.tenant_framework_licenses')
     ) THEN
    ALTER TABLE ONLY public.tenant_framework_licenses
        ADD CONSTRAINT tenant_framework_licenses_platform_framework_id_fkey FOREIGN KEY (platform_framework_id) REFERENCES public.platform_frameworks(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_framework_licenses tenant_framework_licenses_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_framework_licenses') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_framework_licenses_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_framework_licenses')
     ) THEN
    ALTER TABLE ONLY public.tenant_framework_licenses
        ADD CONSTRAINT tenant_framework_licenses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_frameworks tenant_frameworks_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_frameworks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_frameworks_created_by_fkey' AND conrelid = to_regclass('public.tenant_frameworks')
     ) THEN
    ALTER TABLE ONLY public.tenant_frameworks
        ADD CONSTRAINT tenant_frameworks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_frameworks tenant_frameworks_source_framework_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_frameworks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_frameworks_source_framework_id_fkey' AND conrelid = to_regclass('public.tenant_frameworks')
     ) THEN
    ALTER TABLE ONLY public.tenant_frameworks
        ADD CONSTRAINT tenant_frameworks_source_framework_id_fkey FOREIGN KEY (source_framework_id) REFERENCES public.platform_frameworks(id);
  END IF;
END $$;


-- FK CONSTRAINT: tenant_frameworks tenant_frameworks_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_frameworks') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_frameworks_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_frameworks')
     ) THEN
    ALTER TABLE ONLY public.tenant_frameworks
        ADD CONSTRAINT tenant_frameworks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_measurement_overrides tenant_measurement_overrides_control_measurement_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_measurement_overrides') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_measurement_overrides_control_measurement_id_fkey' AND conrelid = to_regclass('public.tenant_measurement_overrides')
     ) THEN
    ALTER TABLE ONLY public.tenant_measurement_overrides
        ADD CONSTRAINT tenant_measurement_overrides_control_measurement_id_fkey FOREIGN KEY (control_measurement_id) REFERENCES public.control_measurements(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_measurement_overrides tenant_measurement_overrides_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_measurement_overrides') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_measurement_overrides_created_by_fkey' AND conrelid = to_regclass('public.tenant_measurement_overrides')
     ) THEN
    ALTER TABLE ONLY public.tenant_measurement_overrides
        ADD CONSTRAINT tenant_measurement_overrides_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);
  END IF;
END $$;


-- FK CONSTRAINT: tenant_measurement_overrides tenant_measurement_overrides_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_measurement_overrides') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_measurement_overrides_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_measurement_overrides')
     ) THEN
    ALTER TABLE ONLY public.tenant_measurement_overrides
        ADD CONSTRAINT tenant_measurement_overrides_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_notes tenant_notes_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_notes') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_notes_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_notes')
     ) THEN
    ALTER TABLE ONLY public.tenant_notes
        ADD CONSTRAINT tenant_notes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_notification_channels tenant_notification_channels_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_notification_channels_created_by_fkey' AND conrelid = to_regclass('public.tenant_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.tenant_notification_channels
        ADD CONSTRAINT tenant_notification_channels_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_notification_channels tenant_notification_channels_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_notification_channels') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_notification_channels_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_notification_channels')
     ) THEN
    ALTER TABLE ONLY public.tenant_notification_channels
        ADD CONSTRAINT tenant_notification_channels_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_notification_rules tenant_notification_rules_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_notification_rules') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_notification_rules_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_notification_rules')
     ) THEN
    ALTER TABLE ONLY public.tenant_notification_rules
        ADD CONSTRAINT tenant_notification_rules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_resource_usage tenant_resource_usage_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_resource_usage') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_resource_usage_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_resource_usage')
     ) THEN
    ALTER TABLE ONLY public.tenant_resource_usage
        ADD CONSTRAINT tenant_resource_usage_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_role_permissions tenant_role_permissions_permission_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_role_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_role_permissions_permission_id_fkey' AND conrelid = to_regclass('public.tenant_role_permissions')
     ) THEN
    ALTER TABLE ONLY public.tenant_role_permissions
        ADD CONSTRAINT tenant_role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.tenant_permissions(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_role_permissions tenant_role_permissions_role_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_role_permissions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_role_permissions_role_id_fkey' AND conrelid = to_regclass('public.tenant_role_permissions')
     ) THEN
    ALTER TABLE ONLY public.tenant_role_permissions
        ADD CONSTRAINT tenant_role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.tenant_roles(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_roles tenant_roles_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_roles_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_roles')
     ) THEN
    ALTER TABLE ONLY public.tenant_roles
        ADD CONSTRAINT tenant_roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenant_usage tenant_usage_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenant_usage') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_usage_tenant_id_fkey' AND conrelid = to_regclass('public.tenant_usage')
     ) THEN
    ALTER TABLE ONLY public.tenant_usage
        ADD CONSTRAINT tenant_usage_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: subscription_tiers subscription_tiers_owner_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.subscription_tiers') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'subscription_tiers_owner_tenant_id_fkey' AND conrelid = to_regclass('public.subscription_tiers')
     ) THEN
    ALTER TABLE ONLY public.subscription_tiers
        ADD CONSTRAINT subscription_tiers_owner_tenant_id_fkey FOREIGN KEY (owner_tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tenants tenants_subscription_tier_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tenants') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenants_subscription_tier_id_fkey' AND conrelid = to_regclass('public.tenants')
     ) THEN
    ALTER TABLE ONLY public.tenants
        ADD CONSTRAINT tenants_subscription_tier_id_fkey FOREIGN KEY (subscription_tier_id) REFERENCES public.subscription_tiers(id);
  END IF;
END $$;


-- FK CONSTRAINT: ticket_comments ticket_comments_author_id_fkey
DO $$ BEGIN
  IF to_regclass('public.ticket_comments') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ticket_comments_author_id_fkey' AND conrelid = to_regclass('public.ticket_comments')
     ) THEN
    ALTER TABLE ONLY public.ticket_comments
        ADD CONSTRAINT ticket_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: ticket_comments ticket_comments_ticket_id_fkey
DO $$ BEGIN
  IF to_regclass('public.ticket_comments') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ticket_comments_ticket_id_fkey' AND conrelid = to_regclass('public.ticket_comments')
     ) THEN
    ALTER TABLE ONLY public.ticket_comments
        ADD CONSTRAINT ticket_comments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tickets tickets_asset_id_fkey — INTENTIONALLY OMITTED
-- Live asset data is in `assets`, whose only unique key is the composite
-- (tenant_id, id) every hash-partitioned table here needs — so a FK from
-- tickets.asset_id ALONE cannot reference it. Adding one would mean adding
-- tenant_id to the reference, which is a ticketing change, not an inventory
-- one. The application validates asset_id via uuid.Parse and joins by id at
-- read time. Same situation for tickets_crypto_implementation_id_fkey below.


-- FK CONSTRAINT: tickets tickets_assigned_to_fkey
DO $$ BEGIN
  IF to_regclass('public.tickets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tickets_assigned_to_fkey' AND conrelid = to_regclass('public.tickets')
     ) THEN
    ALTER TABLE ONLY public.tickets
        ADD CONSTRAINT tickets_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: tickets tickets_certificate_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tickets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tickets_certificate_id_fkey' AND conrelid = to_regclass('public.tickets')
     ) THEN
    ALTER TABLE ONLY public.tickets
        ADD CONSTRAINT tickets_certificate_id_fkey FOREIGN KEY (certificate_id) REFERENCES public.certificates(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: tickets tickets_created_by_fkey
DO $$ BEGIN
  IF to_regclass('public.tickets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tickets_created_by_fkey' AND conrelid = to_regclass('public.tickets')
     ) THEN
    ALTER TABLE ONLY public.tickets
        ADD CONSTRAINT tickets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: tickets tickets_crypto_implementation_id_fkey — INTENTIONALLY OMITTED
-- See note on tickets_asset_id_fkey above. crypto_implementations_legacy
-- is empty; live data lives in crypto_implementations_partitioned, which
-- has no PK on id alone, so no FK can target it.



-- FK CONSTRAINT: tickets tickets_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.tickets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tickets_tenant_id_fkey' AND conrelid = to_regclass('public.tickets')
     ) THEN
    ALTER TABLE ONLY public.tickets
        ADD CONSTRAINT tickets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: user_auth_methods user_auth_methods_sso_provider_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_auth_methods') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_auth_methods_sso_provider_id_fkey' AND conrelid = to_regclass('public.user_auth_methods')
     ) THEN
    ALTER TABLE ONLY public.user_auth_methods
        ADD CONSTRAINT user_auth_methods_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES public.sso_providers(id);
  END IF;
END $$;


-- FK CONSTRAINT: user_auth_methods user_auth_methods_user_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_auth_methods') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_auth_methods_user_id_fkey' AND conrelid = to_regclass('public.user_auth_methods')
     ) THEN
    ALTER TABLE ONLY public.user_auth_methods
        ADD CONSTRAINT user_auth_methods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: user_framework_preferences user_framework_preferences_framework_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_framework_preferences') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_framework_preferences_framework_id_fkey' AND conrelid = to_regclass('public.user_framework_preferences')
     ) THEN
    ALTER TABLE ONLY public.user_framework_preferences
        ADD CONSTRAINT user_framework_preferences_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.platform_frameworks(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: user_framework_preferences user_framework_preferences_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_framework_preferences') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_framework_preferences_tenant_id_fkey' AND conrelid = to_regclass('public.user_framework_preferences')
     ) THEN
    ALTER TABLE ONLY public.user_framework_preferences
        ADD CONSTRAINT user_framework_preferences_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: user_framework_preferences user_framework_preferences_user_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_framework_preferences') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_framework_preferences_user_id_fkey' AND conrelid = to_regclass('public.user_framework_preferences')
     ) THEN
    ALTER TABLE ONLY public.user_framework_preferences
        ADD CONSTRAINT user_framework_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: user_tenant_roles user_tenant_roles_assigned_by_fkey
DO $$ BEGIN
  IF to_regclass('public.user_tenant_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_tenant_roles_assigned_by_fkey' AND conrelid = to_regclass('public.user_tenant_roles')
     ) THEN
    ALTER TABLE ONLY public.user_tenant_roles
        ADD CONSTRAINT user_tenant_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;


-- FK CONSTRAINT: user_tenant_roles user_tenant_roles_role_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_tenant_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_tenant_roles_role_id_fkey' AND conrelid = to_regclass('public.user_tenant_roles')
     ) THEN
    ALTER TABLE ONLY public.user_tenant_roles
        ADD CONSTRAINT user_tenant_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.tenant_roles(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: user_tenant_roles user_tenant_roles_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_tenant_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_tenant_roles_tenant_id_fkey' AND conrelid = to_regclass('public.user_tenant_roles')
     ) THEN
    ALTER TABLE ONLY public.user_tenant_roles
        ADD CONSTRAINT user_tenant_roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: user_tenant_roles user_tenant_roles_user_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_tenant_roles') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_tenant_roles_user_id_fkey' AND conrelid = to_regclass('public.user_tenant_roles')
     ) THEN
    ALTER TABLE ONLY public.user_tenant_roles
        ADD CONSTRAINT user_tenant_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: user_workflow_progress user_workflow_progress_user_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_workflow_progress') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_workflow_progress_user_id_fkey' AND conrelid = to_regclass('public.user_workflow_progress')
     ) THEN
    ALTER TABLE ONLY public.user_workflow_progress
        ADD CONSTRAINT user_workflow_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: user_workflow_progress user_workflow_progress_workflow_configuration_id_fkey
DO $$ BEGIN
  IF to_regclass('public.user_workflow_progress') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'user_workflow_progress_workflow_configuration_id_fkey' AND conrelid = to_regclass('public.user_workflow_progress')
     ) THEN
    ALTER TABLE ONLY public.user_workflow_progress
        ADD CONSTRAINT user_workflow_progress_workflow_configuration_id_fkey FOREIGN KEY (workflow_configuration_id) REFERENCES public.workflow_configurations(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: users users_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.users') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'users_tenant_id_fkey' AND conrelid = to_regclass('public.users')
     ) THEN
    ALTER TABLE ONLY public.users
        ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- FK CONSTRAINT: workflow_configurations workflow_configurations_tenant_id_fkey
DO $$ BEGIN
  IF to_regclass('public.workflow_configurations') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'workflow_configurations_tenant_id_fkey' AND conrelid = to_regclass('public.workflow_configurations')
     ) THEN
    ALTER TABLE ONLY public.workflow_configurations
        ADD CONSTRAINT workflow_configurations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- tenant_id FKs for the partitioned parents and the health tables (#739).
-- These were skipped when partitioning was introduced, which left orphaned rows
-- behind PurgeTenant (which relies solely on ON DELETE CASCADE).


DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_implementations_partitioned_tenant_id_fkey'
         AND conrelid = to_regclass('public.crypto_implementations_partitioned')
     ) THEN
    ALTER TABLE public.crypto_implementations_partitioned
      ADD CONSTRAINT crypto_implementations_partitioned_tenant_id_fkey
      FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


DO $$ BEGIN
  IF to_regclass('public.sensor_discoveries_partitioned') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'sensor_discoveries_partitioned_tenant_id_fkey'
         AND conrelid = to_regclass('public.sensor_discoveries_partitioned')
     ) THEN
    ALTER TABLE public.sensor_discoveries_partitioned
      ADD CONSTRAINT sensor_discoveries_partitioned_tenant_id_fkey
      FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


DO $$ BEGIN
  IF to_regclass('public.health_alerts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'health_alerts_tenant_id_fkey'
         AND conrelid = to_regclass('public.health_alerts')
     ) THEN
    ALTER TABLE public.health_alerts
      ADD CONSTRAINT health_alerts_tenant_id_fkey
      FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


DO $$ BEGIN
  IF to_regclass('public.health_metrics') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'health_metrics_tenant_id_fkey'
         AND conrelid = to_regclass('public.health_metrics')
     ) THEN
    ALTER TABLE public.health_metrics
      ADD CONSTRAINT health_metrics_tenant_id_fkey
      FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


DO $$ BEGIN
  IF to_regclass('public.tenant_health') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tenant_health_tenant_id_fkey'
         AND conrelid = to_regclass('public.tenant_health')
     ) THEN
    ALTER TABLE public.tenant_health
      ADD CONSTRAINT tenant_health_tenant_id_fkey
      FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


-- =================================================================
-- ROW SECURITY: ticket_comments (tenant scope inherited via tickets.tenant_id;
-- ticket_comments has no tenant_id column of its own — see issue #26 H1)
ALTER TABLE public.ticket_comments ENABLE ROW LEVEL SECURITY;


--
-- PostgreSQL database dump complete
--


-- =================================================================
-- POST-MIGRATIONS (idempotent, run after the pg_dump body above)
-- =================================================================
-- These statements live outside the pg_dump-style schema body so they
-- survive future schema regenerations. The chart's `schema-migration`
-- Job applies this whole file via `psql -v ON_ERROR_STOP=1`, so every
-- statement here must be safely idempotent against any prior schema
-- version.
--
-- =========================================================================
-- protocol_type: values added after the type first shipped
-- =========================================================================
-- The `CREATE TYPE public.protocol_type` near the top of this file is wrapped in
-- `EXCEPTION WHEN duplicate_object THEN NULL`, so on any database that already
-- has the type it is a silent no-op — a value added to that list alone reaches
-- fresh installs ONLY. These ALTERs are what carry the same values to an
-- existing database, and they are why the two edits must always be made
-- together. Removing them does not fail anything at apply time: psql exits 0,
-- the enum keeps its old values, and ingest starts failing much later with
-- "invalid input value for enum protocol_type". That silence is what
-- TestProtocolEnum_AdditionsCarryAnAlterType exists to break.
--
-- Bare statements, deliberately: `ALTER TYPE ... ADD VALUE` cannot run inside a
-- function or DO block ("ALTER TYPE ... ADD cannot be executed from a
-- function"), so the DO/EXCEPTION idiom this file uses everywhere else is not
-- available here. `IF NOT EXISTS` (PG 12+) supplies the idempotency instead.
--
-- BEFORE 'Modbus' places them exactly where the CREATE TYPE list has them, so
-- pg_enum reads identically on a fresh install and on an upgraded one. Nothing
-- today sorts on the enum's ordinal (the one ORDER BY over this column casts to
-- text first), which is precisely why it is worth pinning now rather than
-- discovering the divergence from a query written later.
ALTER TYPE public.protocol_type ADD VALUE IF NOT EXISTS 'QUIC' BEFORE 'Modbus';
ALTER TYPE public.protocol_type ADD VALUE IF NOT EXISTS 'PPTP' BEFORE 'Modbus';


-- =========================================================================
-- device_job_type: values added after the type first shipped
-- =========================================================================
-- The SECOND half of the two-edit enum rule, for exactly the reasons spelled
-- out above protocol_type: the `CREATE TYPE public.device_job_type` near the
-- top of this file is a silent no-op on any database that already has the
-- type, so without this line `host_inventory` would reach fresh installs only
-- and an existing cluster would start failing much later with
-- "invalid input value for enum device_job_type" the first time an agent
-- submitted a host inventory.
--
-- No BEFORE clause: host_inventory is LAST in the CREATE TYPE list too, so
-- appending gives pg_enum the same ordering on a fresh install and an upgraded
-- one.
ALTER TYPE public.device_job_type ADD VALUE IF NOT EXISTS 'host_inventory';




-- =========================================================================
-- CBOM-CENTRIC REPORTING REDESIGN — Phase 1
-- Scopes: tenant-owned, named, versioned predicate definitions that define
-- "what's in a CBOM." A Scope is the boundary an auditor or compliance team
-- attests to. Default scopes (All, Production, Non-Dev/Test) are seeded
-- lazily on first cbom-service contact for a tenant.
-- =========================================================================


-- TABLE: scopes
CREATE TABLE IF NOT EXISTS public.scopes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    -- The boundary, as a query-language string (QUERY_LANGUAGE.md, ADR-0006
    -- D2). It replaced a jsonb include/exclude predicate whose vocabulary was
    -- a third of the language's and which nothing but cbom-service could
    -- evaluate. Empty string = every asset under RLS, which is what the `All`
    -- scope is. Validated on write; a scope whose query stops validating is a
    -- 422 on save, never a silently wider artifact.
    query text DEFAULT ''::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid NOT NULL,
    updated_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT scopes_pkey PRIMARY KEY (id),
    CONSTRAINT scopes_unique_name_per_tenant UNIQUE (tenant_id, name)
);
CREATE INDEX IF NOT EXISTS idx_scopes_tenant_id ON public.scopes USING btree (tenant_id);
CREATE INDEX IF NOT EXISTS idx_scopes_tenant_default ON public.scopes USING btree (tenant_id, is_default) WHERE (is_default = true);
-- TABLE: scopes_audit
-- Mirrors the tenant_admin_settings_audit pattern: every UPDATE writes a row
-- recording the prior state. The current scope row holds the latest version;
-- prior versions live in scopes_audit, keyed by (scope_id, version).
CREATE TABLE IF NOT EXISTS public.scopes_audit (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    scope_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name_before character varying(255) NOT NULL,
    name_after character varying(255) NOT NULL,
    query_before text NOT NULL,
    query_after text NOT NULL,
    version_before integer NOT NULL,
    version_after integer NOT NULL,
    changed_by uuid,
    change_reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT scopes_audit_pkey PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS idx_scopes_audit_scope_time ON public.scopes_audit USING btree (scope_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_scopes_audit_tenant_time ON public.scopes_audit USING btree (tenant_id, created_at DESC);
-- FUNCTION: log_scope_change()
-- Mirrors log_tenant_admin_settings_change(): inserts a scopes_audit row
-- whenever a scope's name, predicate, or version changes. Triggered AFTER UPDATE.
CREATE OR REPLACE FUNCTION public.log_scope_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO scopes_audit (
        scope_id,
        tenant_id,
        name_before,
        name_after,
        query_before,
        query_after,
        version_before,
        version_after,
        changed_by,
        change_reason,
        created_at
    )
    VALUES (
        NEW.id,
        NEW.tenant_id,
        OLD.name,
        NEW.name,
        OLD.query,
        NEW.query,
        OLD.version,
        NEW.version,
        NEW.updated_by,
        NULL,
        NOW()
    );
    RETURN NEW;
END;
$$;


-- The `query` columns MUST exist before the trigger below is created.
--
-- These ALTERs live here, in the middle of the pg_dump body, for one reason:
-- `scopes_audit_trigger`'s WHEN clause names `OLD.query` / `NEW.query`, and
-- Postgres validates a trigger's WHEN clause at CREATE time. On a database that
-- still has the PRE-query `scopes` shape — jsonb `predicate`, no `query` — the
-- CREATE TRIGGER therefore fails, and under `ON_ERROR_STOP=1` the file stops
-- right there. The ALTERs that would have fixed it were three thousand lines
-- further down in POST-MIGRATIONS and never ran, while the `DROP TRIGGER IF
-- EXISTS` on the line above had already committed: the database was left with
-- no audit trigger on scopes and no way to re-apply the file, permanently.
--
-- A fresh double-apply cannot see this — both of its passes build TODAY's shape
-- — which is why it is a statement-ordering rule written down here rather than
-- a test result. TestIntegration_Schema_AppliesOverThePreQueryScopesShape
-- builds the old shape deliberately and applies the file over it.
--
-- The `predicate` DROP stays with its ADD: they are one change, and splitting
-- them would leave the file able to create the column and never retire the old
-- one. ADR-0007 D2 is the no-migration path — there are no installs to carry
-- forward and no translation is attempted.
ALTER TABLE IF EXISTS public.scopes
    ADD COLUMN IF NOT EXISTS query text DEFAULT ''::text NOT NULL;
ALTER TABLE IF EXISTS public.scopes DROP COLUMN IF EXISTS predicate;

ALTER TABLE IF EXISTS public.scopes_audit
    ADD COLUMN IF NOT EXISTS query_before text DEFAULT ''::text NOT NULL,
    ADD COLUMN IF NOT EXISTS query_after  text DEFAULT ''::text NOT NULL;
ALTER TABLE IF EXISTS public.scopes_audit DROP COLUMN IF EXISTS predicate_before;
ALTER TABLE IF EXISTS public.scopes_audit DROP COLUMN IF EXISTS predicate_after;


DROP TRIGGER IF EXISTS scopes_audit_trigger ON public.scopes;
CREATE OR REPLACE TRIGGER scopes_audit_trigger
    AFTER UPDATE ON public.scopes
    FOR EACH ROW
    WHEN (((OLD.name IS DISTINCT FROM NEW.name)
        OR (OLD.query IS DISTINCT FROM NEW.query)
        OR (OLD.version IS DISTINCT FROM NEW.version)))
    EXECUTE FUNCTION public.log_scope_change();


DROP TRIGGER IF EXISTS update_scopes_updated_at ON public.scopes;
CREATE OR REPLACE TRIGGER update_scopes_updated_at
    BEFORE UPDATE ON public.scopes
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();


-- =========================================================================
-- CBOM ARTIFACTS — Phase 2 of the CBOM-centric reporting redesign
--
-- A `cbom_artifacts` row is an immutable, dated, hashed snapshot of every
-- crypto-relevant asset matching a Scope at the moment of generation. It is
-- the deliverable a tenant attaches to an audit submission, a customer
-- compliance package, or an internal posture review.
--
-- Storage strategy (dual-path):
--   • If shared/storage is configured for ArtifactTypeCBOM, the canonical
--     CycloneDX 1.6 JSON lives in S3 and `storage_key` points to it.
--   • If storage is not configured (typical dev / brand-new install), the
--     JSON lives inline in `inline_content` so the feature still works.
--   • Exactly one of storage_key / inline_content is populated. We never
--     store both — that would create a drift risk against `content_hash`.
--
-- Provenance fields (scope_version, content_hash, generated_at,
-- generated_by, input_data_freshness_at) capture enough to reproduce the
-- artifact deterministically against the inventory state at generation
-- time, and to prove tamper-evidence later (Phase 4 HMAC signing reuses
-- the same content_hash).
-- =========================================================================


CREATE TABLE IF NOT EXISTS public.cbom_artifacts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    scope_id uuid NOT NULL,
    -- Snapshotted at generation time so the artifact is reproducible against
    -- the exact scope definition that was in force, even if the scope is
    -- later edited. (Scope edits bump scope.version and write a scopes_audit row.)
    scope_version integer NOT NULL,
    scope_name_snapshot character varying(255) NOT NULL,


    -- Optional human-meaningful name (e.g. "Q2 2026 PCI Submission").
    -- Falls back to scope_name_snapshot + generated_at when not set.
    name character varying(255),


    -- Storage location. Exactly one of these is populated.
    storage_key text,
    inline_content text,


    -- The private, non-published view of the snapshot. inline_content holds the
    -- CANONICAL bytes (CycloneDX), which is what we hash, sign and serve; but
    -- CycloneDX is a publishing format and has no home for the deprecation
    -- status, known-vulnerability counts and PQC flags the Enterprise diff
    -- categorises on. This column is never served to a client and never enters
    -- the content hash — it exists so a later comparison can read the same
    -- snapshot the generator saw.
    internal_content text,


    content_hash character varying(64) NOT NULL,
    size_bytes bigint NOT NULL,
    component_count integer NOT NULL,


    -- CycloneDX spec version we emitted (currently 1.6).
    cyclonedx_spec_version character varying(10) DEFAULT '1.6' NOT NULL,


    -- When was the inventory data last refreshed (e.g. by the most-recent
    -- sensor sweep) at the moment of generation? Helps the customer judge
    -- "is this snapshot fresh enough for my audit?"
    input_data_freshness_at timestamp with time zone NOT NULL,


    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    generated_by uuid NOT NULL,


    -- Phase 4 signing — populated when the tenant enables signing. Recompute
    -- HMAC-SHA256(content_hash || tenant_id || scope_id) over the secret
    -- with kid=signature_kid, compare against signature_hmac on verify.
    signature_hmac character varying(128),
    signature_kid character varying(64),


    -- Provenance: who/what/when context that doesn't fit columns.
    -- e.g. { "generator_version": "2.2.0", "request_id": "...", "ip": "..." }
    provenance jsonb DEFAULT '{}'::jsonb NOT NULL,


    -- Phase 4 optional layers attached to the artifact, e.g. a
    -- compliance_attestation layer carrying the framework evaluation snapshot.
    -- Each layer is { "type": "...", "version": "...", "data": {...} }.
    layers jsonb DEFAULT '[]'::jsonb NOT NULL,


    -- Soft-delete preserves the row (so dangling references from comparison
    -- runs surface as "deleted by tenant X on …" rather than 404).
    deleted_at timestamp with time zone,


    created_at timestamp with time zone DEFAULT now(),


    -- Which bill of materials this artifact is (ADR-0005 D6). The CBOM is one
    -- KIND of snapshot, not the only one: the same scope → assemble → hash →
    -- sign → compare pipeline also produces a software BOM, a hardware BOM and
    -- a whole-inventory BOM. 'cbom' is the default so every row written before
    -- this column existed is what it always was.
    artifact_kind text DEFAULT 'cbom'::text NOT NULL,


    CONSTRAINT cbom_artifacts_pkey PRIMARY KEY (id),
    CONSTRAINT cbom_artifacts_storage_or_inline CHECK (
        (storage_key IS NOT NULL AND inline_content IS NULL) OR
        (storage_key IS NULL AND inline_content IS NOT NULL)
    )
);


-- artifact_kind, for a database that already has this table.
--
-- `CREATE TABLE IF NOT EXISTS` above is a NO-OP on such a database, so a column
-- added to the literal never reaches it — the column arrives only on a fresh
-- install, and the first INSERT naming it fails at runtime with "column does
-- not exist". cbom_artifacts shipped in v2.2.0, so every database created since
-- then has the table WITHOUT this column. Two edits, both required — the same
-- treatment `findings`' workflow columns get.
ALTER TABLE public.cbom_artifacts ADD COLUMN IF NOT EXISTS artifact_kind text DEFAULT 'cbom'::text NOT NULL;

-- The kind vocabulary is a CHECK rather than an enum: adding a kind is then one
-- statement instead of the two-edit ALTER TYPE dance, and there is no ordering
-- to keep identical between fresh and upgraded installs.
DO $$ BEGIN
  IF to_regclass('public.cbom_artifacts') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'cbom_artifacts_artifact_kind_check' AND conrelid = to_regclass('public.cbom_artifacts')
     ) THEN
    ALTER TABLE ONLY public.cbom_artifacts
        ADD CONSTRAINT cbom_artifacts_artifact_kind_check
        CHECK (artifact_kind = ANY (ARRAY['cbom'::text, 'sbom'::text, 'hbom'::text, 'inventory'::text]));
  END IF;
END $$;


-- The list page filters by kind, and the kind badge is on every row.
CREATE INDEX IF NOT EXISTS idx_cbom_artifacts_tenant_kind
    ON public.cbom_artifacts USING btree (tenant_id, artifact_kind, generated_at DESC)
    WHERE (deleted_at IS NULL);


CREATE INDEX IF NOT EXISTS idx_cbom_artifacts_tenant_generated
    ON public.cbom_artifacts USING btree (tenant_id, generated_at DESC)
    WHERE (deleted_at IS NULL);


CREATE INDEX IF NOT EXISTS idx_cbom_artifacts_scope
    ON public.cbom_artifacts USING btree (scope_id, generated_at DESC)
    WHERE (deleted_at IS NULL);


CREATE INDEX IF NOT EXISTS idx_cbom_artifacts_content_hash
    ON public.cbom_artifacts USING btree (tenant_id, content_hash)
    WHERE (deleted_at IS NULL);


-- =========================================================================
-- CBOM SUBSCRIPTIONS — STUB for roadmap (Phase 2 ships table only, no consumers)
--
-- "Email me a CBOM for scope X every Monday." Real implementation is
-- deferred to a later phase; the schema is in place so the column shape is
-- known and a future cron worker can come along and start consuming.
-- =========================================================================


CREATE TABLE IF NOT EXISTS public.cbom_subscriptions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    scope_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    -- Cron expression, e.g. "0 6 * * MON" for 06:00 every Monday.
    schedule_cron character varying(64) NOT NULL,
    -- Delivery target: { "type": "email", "to": "...", "format": "pdf" } or
    -- { "type": "webhook", "url": "https://...", "format": "cyclonedx" }.
    delivery jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    last_run_at timestamp with time zone,
    last_artifact_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT cbom_subscriptions_pkey PRIMARY KEY (id)
);


CREATE INDEX IF NOT EXISTS idx_cbom_subscriptions_tenant
    ON public.cbom_subscriptions USING btree (tenant_id);


--
--
--
--
-- =========================================================================
-- ENTITLEMENT CATALOG — PR 1 of the billing/tier-flexibility redesign
--
-- Replaces the hardcoded knownFeatures list + features JSONB + per-resource
-- max_* columns on subscription_tiers with a structured catalog:
--
--   billable_items     — every gateable/billable concept (sensors, assets,
--                        SSO, storage GB, PCAP overage, etc.). Platform-
--                        wide; no tenant scope; no RLS.
--   tier_entitlements  — what each tier includes by default. Composes a
--                        tier as (tier_id, item_id, included_value).
--   tenant_entitlements— per-tenant overrides (trials, promos, enterprise
--                        custom deals). Replaces tenant_limit_overrides in
--                        a later PR; both coexist until cutover.
--
-- The existing billing_* tables (Stripe customers, subscriptions, invoices,
-- trial_tracking) are unchanged. (billing_overage_pricing was dropped in
-- 2026-07 when metered/overage billing was removed — billing is flat
-- per-tier; tier_entitlements' overage_* columns remain as catalog
-- metadata only, nothing bills from them.)
-- =========================================================================


CREATE TABLE IF NOT EXISTS public.billable_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    -- Stable code identifier (snake_case). What Go and TS reference. Never rename.
    key text NOT NULL,
    display_name text NOT NULL,
    description text,
    -- Drives admin-UI grouping; not consumed by enforcement code.
    category text NOT NULL,
    -- How the resolver interprets included_value / override_value.
    --   boolean         : {"enabled": true|false}
    --   numeric_cap     : {"quantity": N}  (N=null means unlimited)
    --   numeric_metered : {"quantity": N}  (included quota; overage billed)
    --   enum_choice     : {"value": "..."}
    kind text NOT NULL,
    -- Display-only ("sensors", "GB", "calls"). NULL for booleans.
    unit text,
    -- Resolver fallback when neither tier nor tenant sets a value.
    default_value jsonb DEFAULT '{}'::jsonb NOT NULL,
    -- True when this item can be purchased outside its included tier
    -- (e.g. a Starter tenant adding OT active probing for $X/month).
    is_addon_eligible boolean DEFAULT false NOT NULL,
    -- Platform-default a la carte price for add-on purchases.
    default_addon_price_cents integer,
    -- Sunset switch. Deactivated items keep existing assignments but
    -- cannot be added to new tiers via the admin UI.
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT billable_items_pkey PRIMARY KEY (id),
    CONSTRAINT billable_items_key_unique UNIQUE (key),
    CONSTRAINT billable_items_category_check
        CHECK (category IN ('capacity','meter','capability','support','addon')),
    CONSTRAINT billable_items_kind_check
        CHECK (kind IN ('boolean','numeric_cap','numeric_metered','enum_choice'))
);
CREATE INDEX IF NOT EXISTS idx_billable_items_category ON public.billable_items USING btree (category) WHERE (is_active = true);
CREATE INDEX IF NOT EXISTS idx_billable_items_active_sort ON public.billable_items USING btree (sort_order) WHERE (is_active = true);


DROP TRIGGER IF EXISTS update_billable_items_updated_at ON public.billable_items;
CREATE OR REPLACE TRIGGER update_billable_items_updated_at
    BEFORE UPDATE ON public.billable_items
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();


-- tier_entitlements: tier × item → included default. Platform-wide table;
-- no tenant scope; no RLS. Composite PK enforces one row per (tier, item).
CREATE TABLE IF NOT EXISTS public.tier_entitlements (
    tier_id uuid NOT NULL,
    item_id uuid NOT NULL,
    -- Resolver-typed value matching billable_items.kind.
    included_value jsonb DEFAULT '{}'::jsonb NOT NULL,
    -- Metered items only. Price per overage_unit_size beyond the included
    -- quota. NULL on non-metered items.
    overage_price_cents integer,
    overage_unit_size integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tier_entitlements_pkey PRIMARY KEY (tier_id, item_id)
);


-- FKs added in a DO block so re-running the schema doesn't fail with
-- "constraint already exists" — see CLAUDE.md idempotency rules.
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tier_entitlements_tier_id_fkey') THEN
    ALTER TABLE public.tier_entitlements
      ADD CONSTRAINT tier_entitlements_tier_id_fkey
      FOREIGN KEY (tier_id) REFERENCES public.subscription_tiers(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tier_entitlements_item_id_fkey') THEN
    ALTER TABLE public.tier_entitlements
      ADD CONSTRAINT tier_entitlements_item_id_fkey
      FOREIGN KEY (item_id) REFERENCES public.billable_items(id) ON DELETE RESTRICT;
  END IF;
END $$;


DROP TRIGGER IF EXISTS update_tier_entitlements_updated_at ON public.tier_entitlements;
CREATE OR REPLACE TRIGGER update_tier_entitlements_updated_at
    BEFORE UPDATE ON public.tier_entitlements
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();


-- tenant_entitlements: per-tenant deltas to the tier baseline.
--
-- Generalizes tenant_limit_overrides (8-type CHECK) into one table that
-- can override any billable_items entry. effective_from/expires_at let
-- this carry trials, promos, and enterprise add-ons; the unique index
-- preserves history so override changes are auditable rather than a
-- destructive update.
--
-- Plan Exceptions are non-billing (ADR-0004): an override is a pure
-- entitlement grant — a lever bumped for one tenant, never a charge.
CREATE TABLE IF NOT EXISTS public.tenant_entitlements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    item_id uuid NOT NULL,
    override_value jsonb DEFAULT '{}'::jsonb NOT NULL,
    reason text,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tenant_entitlements_pkey PRIMARY KEY (id),
    CONSTRAINT tenant_entitlements_unique_per_period UNIQUE (tenant_id, item_id, effective_from)
);
CREATE INDEX IF NOT EXISTS idx_tenant_entitlements_tenant_item ON public.tenant_entitlements USING btree (tenant_id, item_id);
CREATE INDEX IF NOT EXISTS idx_tenant_entitlements_expires ON public.tenant_entitlements USING btree (expires_at) WHERE (expires_at IS NOT NULL);


DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tenant_entitlements_item_id_fkey') THEN
    ALTER TABLE public.tenant_entitlements
      ADD CONSTRAINT tenant_entitlements_item_id_fkey
      FOREIGN KEY (item_id) REFERENCES public.billable_items(id) ON DELETE RESTRICT;
  END IF;
END $$;


DROP TRIGGER IF EXISTS update_tenant_entitlements_updated_at ON public.tenant_entitlements;
CREATE OR REPLACE TRIGGER update_tenant_entitlements_updated_at
    BEFORE UPDATE ON public.tenant_entitlements
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();


-- =========================================================================
-- API TOKENS (tenant-scoped personal access tokens)
--
-- Bearer credentials for programmatic access — v1 consumer is the MCP
-- service (services/mcp-service), which exchanges a token for a short-lived
-- user JWT via auth-service's HMAC-guarded /internal/api-tokens/exchange.
--
-- token_hash is hex SHA-256 of the full plaintext token (qvpat_<random>).
-- Unlike service_accounts (bcrypt + scan-all), tokens here are looked up
-- O(1) by hash: the plaintext is 256 bits of CSPRNG output, so offline
-- brute force of a leaked hash is infeasible without a KDF, and per-tenant
-- token counts make a full-table bcrypt scan per request unscalable.
-- Tokens are revoked (revoked_at), never deleted — the row is the audit
-- record of the credential's existence.
CREATE TABLE IF NOT EXISTS public.api_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    token_hash character(64) NOT NULL,
    token_prefix character varying(16) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    expires_at timestamp with time zone,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


DO $$ BEGIN
  IF to_regclass('public.api_tokens') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'api_tokens_pkey' AND conrelid = to_regclass('public.api_tokens')
     ) THEN
    ALTER TABLE ONLY public.api_tokens ADD CONSTRAINT api_tokens_pkey PRIMARY KEY (id);
  END IF;
END $$;


CREATE UNIQUE INDEX IF NOT EXISTS idx_api_tokens_token_hash ON public.api_tokens (token_hash);
CREATE INDEX IF NOT EXISTS idx_api_tokens_tenant_user ON public.api_tokens (tenant_id, user_id);


DO $$ BEGIN
  IF to_regclass('public.api_tokens') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'api_tokens_tenant_id_fkey' AND conrelid = to_regclass('public.api_tokens')
     ) THEN
    ALTER TABLE public.api_tokens
      ADD CONSTRAINT api_tokens_tenant_id_fkey
      FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;


DO $$ BEGIN
  IF to_regclass('public.api_tokens') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'api_tokens_user_id_fkey' AND conrelid = to_regclass('public.api_tokens')
     ) THEN
    ALTER TABLE public.api_tokens
      ADD CONSTRAINT api_tokens_user_id_fkey
      FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;
  END IF;
END $$;


-- OAuth 2.0 authorization codes (#716). Short-lived (10 min) codes issued by
-- the OAuth /authorize endpoint and exchanged once for a PAT at /token.
-- Single-use enforced by used_at: a second exchange returns invalid_grant.
-- No RLS — auth-service owns this table exclusively, queries by code_hash.
CREATE TABLE IF NOT EXISTS public.oauth_authorization_codes (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code_hash            TEXT NOT NULL UNIQUE,
    client_id            TEXT NOT NULL,
    redirect_uri         TEXT NOT NULL,
    user_id              UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    tenant_id            UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    code_challenge       TEXT NOT NULL,
    scopes               TEXT[] NOT NULL DEFAULT '{}',
    expires_at           TIMESTAMPTZ NOT NULL,
    used_at              TIMESTAMPTZ,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_oauth_codes_expires ON public.oauth_authorization_codes (expires_at);


-- Per-(tenant, framework) score rollup written by the evaluation engine
-- reconcile (services/compliance-engine .../evaluation_engine.go). One row per
-- published framework per tenant — read for posture scorecards and the preview
-- score on unactivated frameworks. Findings (failures) live in `findings`, as
-- the compliance producer's rows; this is just the rollup.
-- =====================================================================
-- score is NULLable on purpose (#1369): a framework with no ASSESSED control has
-- no score, and the rollup must be able to say so. It used to be NOT NULL
-- DEFAULT 0, which forced the writer to pick a sentinel — and it picked 100,
-- so a half-authored framework or an empty inventory previewed as perfect.
CREATE TABLE IF NOT EXISTS public.tenant_framework_scores (
    tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    platform_framework_id uuid NOT NULL REFERENCES public.platform_frameworks(id) ON DELETE CASCADE,
    score integer,
    controls_total integer NOT NULL DEFAULT 0,
    controls_passing integer NOT NULL DEFAULT 0,
    controls_failing integer NOT NULL DEFAULT 0,
    controls_not_assessed integer NOT NULL DEFAULT 0,
    computed_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT tenant_framework_scores_pkey PRIMARY KEY (tenant_id, platform_framework_id)
);

-- Existing installs: CREATE TABLE IF NOT EXISTS above is a no-op for them, so
-- the same two changes are applied as idempotent ALTERs. DROP NOT NULL and DROP
-- DEFAULT are both no-ops when already applied.
ALTER TABLE public.tenant_framework_scores
  ADD COLUMN IF NOT EXISTS controls_not_assessed integer NOT NULL DEFAULT 0;
ALTER TABLE public.tenant_framework_scores ALTER COLUMN score DROP NOT NULL;
ALTER TABLE public.tenant_framework_scores ALTER COLUMN score DROP DEFAULT;


CREATE INDEX IF NOT EXISTS idx_tenant_framework_scores_tenant
  ON public.tenant_framework_scores (tenant_id);


-- =====================================================================
-- Framework-control provenance (ADR-0008 D4.1 — "provenance on every fact")
-- =====================================================================
-- Where a control came from: a person typing it in the authoring form
-- ('declared'), the Author seam drafting it from a pasted standard and a person
-- accepting the draft ('inferred', with source_ref naming the model), or a
-- content bundle ('imported').
--
-- NULL is a real, distinct state and is NOT backfilled: it means the row was
-- created before this column existed. Backfilling it to 'declared' would be
-- asserting that a person wrote every historical control, which we do not know
-- — the same "did not check, rendered as passed" shape these columns exist to
-- prevent. Nothing reads NULL as inferred, so the only cost is that old rows
-- carry no badge.
--
-- Both ALTERs are safe on a populated table: the columns are nullable with no
-- default, so no row is rewritten and no existing row can violate the CHECK
-- (which admits NULL). That is the reason the CHECK is written with an explicit
-- `IS NULL OR`, rather than relying on SQL's three-valued CHECK semantics — the
-- rule is load-bearing and should read as a rule, not as a side effect.
ALTER TABLE public.platform_framework_controls
  ADD COLUMN IF NOT EXISTS source_kind character varying(20),
  ADD COLUMN IF NOT EXISTS source_ref  character varying(200);

ALTER TABLE public.tenant_framework_controls
  ADD COLUMN IF NOT EXISTS source_kind character varying(20),
  ADD COLUMN IF NOT EXISTS source_ref  character varying(200);

DO $$
BEGIN
  IF to_regclass('public.platform_framework_controls') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
        WHERE conname = 'platform_framework_controls_source_kind_check'
          AND conrelid = to_regclass('public.platform_framework_controls'))
  THEN
    ALTER TABLE public.platform_framework_controls
      ADD CONSTRAINT platform_framework_controls_source_kind_check
      CHECK (source_kind IS NULL OR source_kind IN ('measured', 'imported', 'declared', 'inferred'));
  END IF;
END $$;

DO $$
BEGIN
  IF to_regclass('public.tenant_framework_controls') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
        WHERE conname = 'tenant_framework_controls_source_kind_check'
          AND conrelid = to_regclass('public.tenant_framework_controls'))
  THEN
    ALTER TABLE public.tenant_framework_controls
      ADD CONSTRAINT tenant_framework_controls_source_kind_check
      CHECK (source_kind IS NULL OR source_kind IN ('measured', 'imported', 'declared', 'inferred'));
  END IF;
END $$;


-- =====================================================================
-- Remediation-plan-item provenance (ADR-0008 D4.1 / D5)
-- =====================================================================
-- Where a plan item's notes came from: a person typing them (NULL, the
-- ordinary path), or a person ACCEPTING a plan the Remediator seam drafted
-- ('inferred', with source_ref naming the model — `remediator:<model id>`).
--
-- The acting user is already on the row as `added_by`, and that is the half
-- ADR-0008 D5 is about: a seam proposes, a human approves. The two columns say
-- what was proposed and by what; `added_by` says who admitted it. Neither is
-- derivable from the other and the row needs both to be readable a year later.
--
-- NULL is a real, distinct state and is NOT backfilled — for the reason the
-- framework-control columns above give: backfilling to 'declared' would assert
-- that a person wrote every historical item, which we do not know.
--
-- Safe on a populated table: nullable, no default, so no row is rewritten and
-- no existing row can violate the CHECK, which admits NULL explicitly rather
-- than relying on SQL's three-valued CHECK semantics.
ALTER TABLE public.remediation_plan_items
  ADD COLUMN IF NOT EXISTS source_kind character varying(20),
  ADD COLUMN IF NOT EXISTS source_ref  character varying(200);

DO $$
BEGIN
  IF to_regclass('public.remediation_plan_items') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
        WHERE conname = 'remediation_plan_items_source_kind_check'
          AND conrelid = to_regclass('public.remediation_plan_items'))
  THEN
    ALTER TABLE public.remediation_plan_items
      ADD CONSTRAINT remediation_plan_items_source_kind_check
      CHECK (source_kind IS NULL OR source_kind IN ('measured', 'imported', 'declared', 'inferred'));
  END IF;
END $$;


--
--
-- =====================================================================
-- ADR-0007: Posture & Findings Read Models — posture trend time-series.
-- One row per tenant per day capturing the crypto-risk posture (the same
-- counts inventory-service GET /risk/summary returns). Written by the
-- audit-service nightly posture-snapshot job
-- (services/audit-service/internal/jobs/posture_snapshot_job.go), which calls
-- /risk/summary per tenant and upserts here (idempotent on the PK). Read by
-- inventory-service GET /risk/posture/trend?days=N for the dashboard posture
-- trend line. Forward-accruing only — a new tenant's pre-history days are
-- seeded at the current live posture by the read endpoint, never stored.
-- =====================================================================
CREATE TABLE IF NOT EXISTS public.posture_daily_snapshots (
    tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    snapshot_date date NOT NULL,
    total_assets integer NOT NULL DEFAULT 0,
    high_risk integer NOT NULL DEFAULT 0,
    medium_risk integer NOT NULL DEFAULT 0,
    low_risk integer NOT NULL DEFAULT 0,
    unknown_risk integer NOT NULL DEFAULT 0,
    total_crypto integer NOT NULL DEFAULT 0,
    critical_findings integer NOT NULL DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT posture_daily_snapshots_pkey PRIMARY KEY (tenant_id, snapshot_date)
);


-- The PK (tenant_id, snapshot_date) already serves the trend range read
-- (WHERE tenant_id = $1 AND snapshot_date >= $2 ORDER BY snapshot_date); a
-- btree scans backwards for DESC, so no separate index is needed.


-- ============================================================================
-- RLS HARDENING (ADR platform-0001) — authoritative tenant-isolation policies
-- Idempotent: DROP POLICY IF EXISTS + CREATE so WITH CHECK changes re-apply on
-- every upgrade (the DO/EXCEPTION duplicate_object pattern in the pg_dump body
-- above CANNOT update an existing policy). This block is the source of truth.
-- This block is the ONLY place tenant-isolation policies are defined; the
-- pg_dump body above no longer carries duplicates. As of #1297 that is
-- literally true: invitations and legal_acceptances, the last two declared at
-- their tables with the DO/EXCEPTION form, were moved here.
--
-- On the omitted-WITH-CHECK question (#1297), for the record, because the
-- original analysis got it backwards: Postgres REUSES the USING expression as
-- the WITH CHECK when WITH CHECK is omitted (see CREATE POLICY). A USING-only
-- tenant-isolation policy therefore already rejected cross-tenant INSERTs —
-- there was no write hole. Stating both clauses is a legibility and uniformity
-- fix, not a security fix: no reader should have to know that fallback rule to
-- audit a policy. TestIntegration_RLS_EveryTenantPolicyHasWithCheck keeps every
-- policy explicit so the question cannot arise again.
-- USING governs read/visibility; WITH CHECK governs the new-row image on
-- INSERT/UPDATE (closes the cross-tenant write hole). No FORCE here — the app
-- still connects as the table owner until the Phase 4 role flip, so this block
-- is behavior-neutral (owner bypasses RLS).
-- ============================================================================


-- Canonical tenant isolation: direct tenant_id column. 119 tables.
-- (The count is a hand-maintained comment and had drifted to "124" against an
-- actual 118 before invitations was added here — treat it as approximate. What
-- is actually enforced is the PROPERTY, by
-- TestIntegration_RLS_EveryTenantPolicyHasWithCheck: every *_tenant_isolation
-- policy in the database carries a WITH CHECK, whatever the count.)
ALTER TABLE audit.activity_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS activity_logs_tenant_isolation ON audit.activity_logs;
CREATE POLICY activity_logs_tenant_isolation ON audit.activity_logs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE audit.alert_rules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS alert_rules_tenant_isolation ON audit.alert_rules;
CREATE POLICY alert_rules_tenant_isolation ON audit.alert_rules
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE audit.job_execution_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS job_execution_logs_tenant_isolation ON audit.job_execution_logs;
CREATE POLICY job_execution_logs_tenant_isolation ON audit.job_execution_logs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE audit.scheduled_compliance_reports ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS scheduled_compliance_reports_tenant_isolation ON audit.scheduled_compliance_reports;
CREATE POLICY scheduled_compliance_reports_tenant_isolation ON audit.scheduled_compliance_reports
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE audit.scheduled_report_executions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS scheduled_report_executions_tenant_isolation ON audit.scheduled_report_executions;
CREATE POLICY scheduled_report_executions_tenant_isolation ON audit.scheduled_report_executions
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE audit.siem_integrations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS siem_integrations_tenant_isolation ON audit.siem_integrations;
CREATE POLICY siem_integrations_tenant_isolation ON audit.siem_integrations
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.agent_certificates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS agent_certificates_tenant_isolation ON public.agent_certificates;
CREATE POLICY agent_certificates_tenant_isolation ON public.agent_certificates
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.api_tokens ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS api_tokens_tenant_isolation ON public.api_tokens;
CREATE POLICY api_tokens_tenant_isolation ON public.api_tokens
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.api_usage_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS api_usage_logs_tenant_isolation ON public.api_usage_logs;
CREATE POLICY api_usage_logs_tenant_isolation ON public.api_usage_logs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.asset_history ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_history_tenant_isolation ON public.asset_history;
CREATE POLICY asset_history_tenant_isolation ON public.asset_history
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.asset_lifecycle_policies ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_lifecycle_policies_tenant_isolation ON public.asset_lifecycle_policies;
CREATE POLICY asset_lifecycle_policies_tenant_isolation ON public.asset_lifecycle_policies
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.auth_audit_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS auth_audit_log_tenant_isolation ON public.auth_audit_log;
CREATE POLICY auth_audit_log_tenant_isolation ON public.auth_audit_log
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.aws_cost_data ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS aws_cost_data_tenant_isolation ON public.aws_cost_data;
CREATE POLICY aws_cost_data_tenant_isolation ON public.aws_cost_data
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.aws_cost_sync_jobs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS aws_cost_sync_jobs_tenant_isolation ON public.aws_cost_sync_jobs;
CREATE POLICY aws_cost_sync_jobs_tenant_isolation ON public.aws_cost_sync_jobs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.billing_coupon_redemptions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS billing_coupon_redemptions_tenant_isolation ON public.billing_coupon_redemptions;
CREATE POLICY billing_coupon_redemptions_tenant_isolation ON public.billing_coupon_redemptions
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.billing_customers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS billing_customers_tenant_isolation ON public.billing_customers;
CREATE POLICY billing_customers_tenant_isolation ON public.billing_customers
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.billing_dunning_attempts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS billing_dunning_attempts_tenant_isolation ON public.billing_dunning_attempts;
CREATE POLICY billing_dunning_attempts_tenant_isolation ON public.billing_dunning_attempts
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.billing_invoices ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS billing_invoices_tenant_isolation ON public.billing_invoices;
CREATE POLICY billing_invoices_tenant_isolation ON public.billing_invoices
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.billing_subscriptions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS billing_subscriptions_tenant_isolation ON public.billing_subscriptions;
CREATE POLICY billing_subscriptions_tenant_isolation ON public.billing_subscriptions
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.billing_trial_tracking ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS billing_trial_tracking_tenant_isolation ON public.billing_trial_tracking;
CREATE POLICY billing_trial_tracking_tenant_isolation ON public.billing_trial_tracking
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.cbom_artifacts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS cbom_artifacts_tenant_isolation ON public.cbom_artifacts;
CREATE POLICY cbom_artifacts_tenant_isolation ON public.cbom_artifacts
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.cbom_subscriptions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS cbom_subscriptions_tenant_isolation ON public.cbom_subscriptions;
CREATE POLICY cbom_subscriptions_tenant_isolation ON public.cbom_subscriptions
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.certificate_history ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS certificate_history_tenant_isolation ON public.certificate_history;
CREATE POLICY certificate_history_tenant_isolation ON public.certificate_history
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS certificates_tenant_isolation ON public.certificates;
CREATE POLICY certificates_tenant_isolation ON public.certificates
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.cmdb_entity_mappings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS cmdb_entity_mappings_tenant_isolation ON public.cmdb_entity_mappings;
CREATE POLICY cmdb_entity_mappings_tenant_isolation ON public.cmdb_entity_mappings
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.cmdb_sync_jobs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS cmdb_sync_jobs_tenant_isolation ON public.cmdb_sync_jobs;
CREATE POLICY cmdb_sync_jobs_tenant_isolation ON public.cmdb_sync_jobs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.cmdb_sync_profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS cmdb_sync_profiles_tenant_isolation ON public.cmdb_sync_profiles;
CREATE POLICY cmdb_sync_profiles_tenant_isolation ON public.cmdb_sync_profiles
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.compliance_overrides ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS compliance_overrides_tenant_isolation ON public.compliance_overrides;
CREATE POLICY compliance_overrides_tenant_isolation ON public.compliance_overrides
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.compliance_scenarios ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS compliance_scenarios_tenant_isolation ON public.compliance_scenarios;
CREATE POLICY compliance_scenarios_tenant_isolation ON public.compliance_scenarios
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.crypto_applications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS crypto_applications_tenant_isolation ON public.crypto_applications;
CREATE POLICY crypto_applications_tenant_isolation ON public.crypto_applications
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.crypto_implementations_partitioned ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS crypto_implementations_partitioned_tenant_isolation ON public.crypto_implementations_partitioned;
CREATE POLICY crypto_implementations_partitioned_tenant_isolation ON public.crypto_implementations_partitioned
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.crypto_libraries ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS crypto_libraries_tenant_isolation ON public.crypto_libraries;
CREATE POLICY crypto_libraries_tenant_isolation ON public.crypto_libraries
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.database_encryption_states ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS database_encryption_states_tenant_isolation ON public.database_encryption_states;
CREATE POLICY database_encryption_states_tenant_isolation ON public.database_encryption_states
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.device_agents ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS device_agents_tenant_isolation ON public.device_agents;
CREATE POLICY device_agents_tenant_isolation ON public.device_agents
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.device_jobs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS device_jobs_tenant_isolation ON public.device_jobs;
CREATE POLICY device_jobs_tenant_isolation ON public.device_jobs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.discovery_alert_configs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS discovery_alert_configs_tenant_isolation ON public.discovery_alert_configs;
CREATE POLICY discovery_alert_configs_tenant_isolation ON public.discovery_alert_configs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.discovery_alert_history ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS discovery_alert_history_tenant_isolation ON public.discovery_alert_history;
CREATE POLICY discovery_alert_history_tenant_isolation ON public.discovery_alert_history
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.discovery_auto_approval_rules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS discovery_auto_approval_rules_tenant_isolation ON public.discovery_auto_approval_rules;
CREATE POLICY discovery_auto_approval_rules_tenant_isolation ON public.discovery_auto_approval_rules
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.discovery_findings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS discovery_findings_tenant_isolation ON public.discovery_findings;
CREATE POLICY discovery_findings_tenant_isolation ON public.discovery_findings
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.discovery_jobs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS discovery_jobs_tenant_isolation ON public.discovery_jobs;
CREATE POLICY discovery_jobs_tenant_isolation ON public.discovery_jobs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.discovery_rate_limits ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS discovery_rate_limits_tenant_isolation ON public.discovery_rate_limits;
CREATE POLICY discovery_rate_limits_tenant_isolation ON public.discovery_rate_limits
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.discovery_targets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS discovery_targets_tenant_isolation ON public.discovery_targets;
CREATE POLICY discovery_targets_tenant_isolation ON public.discovery_targets
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.external_asset_mappings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS external_asset_mappings_tenant_isolation ON public.external_asset_mappings;
CREATE POLICY external_asset_mappings_tenant_isolation ON public.external_asset_mappings
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.external_connection_history ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS external_connection_history_tenant_isolation ON public.external_connection_history;
CREATE POLICY external_connection_history_tenant_isolation ON public.external_connection_history
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.external_connections ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS external_connections_tenant_isolation ON public.external_connections;
CREATE POLICY external_connections_tenant_isolation ON public.external_connections
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.health_alerts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS health_alerts_tenant_isolation ON public.health_alerts;
CREATE POLICY health_alerts_tenant_isolation ON public.health_alerts
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.health_metrics ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS health_metrics_tenant_isolation ON public.health_metrics;
CREATE POLICY health_metrics_tenant_isolation ON public.health_metrics
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.in_app_notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS in_app_notifications_tenant_isolation ON public.in_app_notifications;
CREATE POLICY in_app_notifications_tenant_isolation ON public.in_app_notifications
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.integrations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS integrations_tenant_isolation ON public.integrations;
CREATE POLICY integrations_tenant_isolation ON public.integrations
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.interrogation_schedules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS interrogation_schedules_tenant_isolation ON public.interrogation_schedules;
CREATE POLICY interrogation_schedules_tenant_isolation ON public.interrogation_schedules
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
-- invitations was the last USING-only policy (#1297). The DROP+CREATE here is
-- what actually tightens an EXISTING install: it replaces the write-open policy
-- the pg_dump body used to declare at the table. Every write already runs
-- inside WithTenantTx (auth-service invitations.go), so WITH CHECK is
-- behaviour-neutral for legitimate callers.
ALTER TABLE public.invitations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS invitations_tenant_isolation ON public.invitations;
CREATE POLICY invitations_tenant_isolation ON public.invitations
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.keys ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS keys_tenant_isolation ON public.keys;
CREATE POLICY keys_tenant_isolation ON public.keys
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.kms_keys ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS kms_keys_tenant_isolation ON public.kms_keys;
CREATE POLICY kms_keys_tenant_isolation ON public.kms_keys
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
-- NB: public.legal_acceptances is NOT declared here, and cannot be. It is one
-- of the tables appended to the file BELOW this block (the same late-created
-- set whose privileges #1299 had to move the blanket GRANTs to fix), so at this
-- point in the apply it does not exist yet and a policy on it aborts the run
-- under ON_ERROR_STOP=1. Its policy is tightened in place at its own
-- definition instead.
ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS locations_tenant_isolation ON public.locations;
CREATE POLICY locations_tenant_isolation ON public.locations
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.network_segments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS network_segments_tenant_isolation ON public.network_segments;
CREATE POLICY network_segments_tenant_isolation ON public.network_segments
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.oauth_authorization_codes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS oauth_authorization_codes_tenant_isolation ON public.oauth_authorization_codes;
CREATE POLICY oauth_authorization_codes_tenant_isolation ON public.oauth_authorization_codes
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.pcap_upload_jobs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS pcap_upload_jobs_tenant_isolation ON public.pcap_upload_jobs;
CREATE POLICY pcap_upload_jobs_tenant_isolation ON public.pcap_upload_jobs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.pending_sensor_registrations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS pending_sensor_registrations_tenant_isolation ON public.pending_sensor_registrations;
CREATE POLICY pending_sensor_registrations_tenant_isolation ON public.pending_sensor_registrations
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.permission_audit_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS permission_audit_logs_tenant_isolation ON public.permission_audit_logs;
CREATE POLICY permission_audit_logs_tenant_isolation ON public.permission_audit_logs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.platform_integrations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS platform_integrations_tenant_isolation ON public.platform_integrations;
CREATE POLICY platform_integrations_tenant_isolation ON public.platform_integrations
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.platform_log_metadata ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS platform_log_metadata_tenant_isolation ON public.platform_log_metadata;
CREATE POLICY platform_log_metadata_tenant_isolation ON public.platform_log_metadata
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.posture_daily_snapshots ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS posture_daily_snapshots_tenant_isolation ON public.posture_daily_snapshots;
CREATE POLICY posture_daily_snapshots_tenant_isolation ON public.posture_daily_snapshots
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.remediation_plans ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS remediation_plans_tenant_isolation ON public.remediation_plans;
CREATE POLICY remediation_plans_tenant_isolation ON public.remediation_plans
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.resource_alerts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS resource_alerts_tenant_isolation ON public.resource_alerts;
CREATE POLICY resource_alerts_tenant_isolation ON public.resource_alerts
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.scopes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS scopes_tenant_isolation ON public.scopes;
CREATE POLICY scopes_tenant_isolation ON public.scopes
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.scopes_audit ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS scopes_audit_tenant_isolation ON public.scopes_audit;
CREATE POLICY scopes_audit_tenant_isolation ON public.scopes_audit
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.sensor_ca_certificates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS sensor_ca_certificates_tenant_isolation ON public.sensor_ca_certificates;
CREATE POLICY sensor_ca_certificates_tenant_isolation ON public.sensor_ca_certificates
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.sensor_certificates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS sensor_certificates_tenant_isolation ON public.sensor_certificates;
CREATE POLICY sensor_certificates_tenant_isolation ON public.sensor_certificates
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.sensor_discoveries_partitioned ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS sensor_discoveries_partitioned_tenant_isolation ON public.sensor_discoveries_partitioned;
CREATE POLICY sensor_discoveries_partitioned_tenant_isolation ON public.sensor_discoveries_partitioned
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.sensors ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS sensors_tenant_isolation ON public.sensors;
CREATE POLICY sensors_tenant_isolation ON public.sensors
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.service_identification_rules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS service_identification_rules_tenant_isolation ON public.service_identification_rules;
CREATE POLICY service_identification_rules_tenant_isolation ON public.service_identification_rules
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.ssh_keys ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS ssh_keys_tenant_isolation ON public.ssh_keys;
CREATE POLICY ssh_keys_tenant_isolation ON public.ssh_keys
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.sso_group_role_mappings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS sso_group_role_mappings_tenant_isolation ON public.sso_group_role_mappings;
CREATE POLICY sso_group_role_mappings_tenant_isolation ON public.sso_group_role_mappings
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.sso_providers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS sso_providers_tenant_isolation ON public.sso_providers;
CREATE POLICY sso_providers_tenant_isolation ON public.sso_providers
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS support_tickets_tenant_isolation ON public.support_tickets;
CREATE POLICY support_tickets_tenant_isolation ON public.support_tickets
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_admin_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_admin_settings_tenant_isolation ON public.tenant_admin_settings;
CREATE POLICY tenant_admin_settings_tenant_isolation ON public.tenant_admin_settings
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_admin_settings_audit ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_admin_settings_audit_tenant_isolation ON public.tenant_admin_settings_audit;
CREATE POLICY tenant_admin_settings_audit_tenant_isolation ON public.tenant_admin_settings_audit
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_entitlements ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_entitlements_tenant_isolation ON public.tenant_entitlements;
CREATE POLICY tenant_entitlements_tenant_isolation ON public.tenant_entitlements
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_framework_licenses ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_framework_licenses_tenant_isolation ON public.tenant_framework_licenses;
CREATE POLICY tenant_framework_licenses_tenant_isolation ON public.tenant_framework_licenses
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_framework_scores ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_framework_scores_tenant_isolation ON public.tenant_framework_scores;
CREATE POLICY tenant_framework_scores_tenant_isolation ON public.tenant_framework_scores
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_frameworks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_frameworks_tenant_isolation ON public.tenant_frameworks;
CREATE POLICY tenant_frameworks_tenant_isolation ON public.tenant_frameworks
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_geographic_data ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_geographic_data_tenant_isolation ON public.tenant_geographic_data;
CREATE POLICY tenant_geographic_data_tenant_isolation ON public.tenant_geographic_data
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_health ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_health_tenant_isolation ON public.tenant_health;
CREATE POLICY tenant_health_tenant_isolation ON public.tenant_health
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_measurement_overrides ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_measurement_overrides_tenant_isolation ON public.tenant_measurement_overrides;
CREATE POLICY tenant_measurement_overrides_tenant_isolation ON public.tenant_measurement_overrides
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_notes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_notes_tenant_isolation ON public.tenant_notes;
CREATE POLICY tenant_notes_tenant_isolation ON public.tenant_notes
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_notification_channels ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_notification_channels_tenant_isolation ON public.tenant_notification_channels;
CREATE POLICY tenant_notification_channels_tenant_isolation ON public.tenant_notification_channels
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_notification_rules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_notification_rules_tenant_isolation ON public.tenant_notification_rules;
CREATE POLICY tenant_notification_rules_tenant_isolation ON public.tenant_notification_rules
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_resource_usage ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_resource_usage_tenant_isolation ON public.tenant_resource_usage;
CREATE POLICY tenant_resource_usage_tenant_isolation ON public.tenant_resource_usage
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_roles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_roles_tenant_isolation ON public.tenant_roles;
CREATE POLICY tenant_roles_tenant_isolation ON public.tenant_roles
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tenant_usage ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_usage_tenant_isolation ON public.tenant_usage;
CREATE POLICY tenant_usage_tenant_isolation ON public.tenant_usage
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tickets_tenant_isolation ON public.tickets;
CREATE POLICY tickets_tenant_isolation ON public.tickets
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.user_framework_preferences ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS user_framework_preferences_tenant_isolation ON public.user_framework_preferences;
CREATE POLICY user_framework_preferences_tenant_isolation ON public.user_framework_preferences
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.user_tenant_roles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS user_tenant_roles_tenant_isolation ON public.user_tenant_roles;
CREATE POLICY user_tenant_roles_tenant_isolation ON public.user_tenant_roles
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS users_tenant_isolation ON public.users;
CREATE POLICY users_tenant_isolation ON public.users
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.workflow_configurations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS workflow_configurations_tenant_isolation ON public.workflow_configurations;
CREATE POLICY workflow_configurations_tenant_isolation ON public.workflow_configurations
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);


-- Notification tables that also expose platform-broadcast rows (tenant_id IS NULL):
-- USING lets a tenant SEE broadcasts; WITH CHECK is strict (a tenant may only
-- write its own rows — broadcasts are inserted via the bypass role).
ALTER TABLE public.notification_delivery_queue ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS notification_delivery_queue_tenant_isolation ON public.notification_delivery_queue;
CREATE POLICY notification_delivery_queue_tenant_isolation ON public.notification_delivery_queue
  USING (tenant_id IS NULL OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.notification_history ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS notification_history_tenant_isolation ON public.notification_history;
CREATE POLICY notification_history_tenant_isolation ON public.notification_history
  USING (tenant_id IS NULL OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);


-- Parent-join tables (no own tenant_id) — isolate via the owning parent row.
-- WITH CHECK uses the same EXISTS so an INSERT must reference a parent the
-- caller's tenant owns.
ALTER TABLE public.sensor_commands ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS sensor_commands_tenant_isolation ON public.sensor_commands;
CREATE POLICY sensor_commands_tenant_isolation ON public.sensor_commands
  USING (EXISTS (SELECT 1 FROM public.sensors WHERE sensors.id = sensor_commands.sensor_id AND sensors.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid))
  WITH CHECK (EXISTS (SELECT 1 FROM public.sensors WHERE sensors.id = sensor_commands.sensor_id AND sensors.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid));
ALTER TABLE public.sensor_health_metrics ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS sensor_health_metrics_tenant_isolation ON public.sensor_health_metrics;
CREATE POLICY sensor_health_metrics_tenant_isolation ON public.sensor_health_metrics
  USING (EXISTS (SELECT 1 FROM public.sensors WHERE sensors.id = sensor_health_metrics.sensor_id AND sensors.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid))
  WITH CHECK (EXISTS (SELECT 1 FROM public.sensors WHERE sensors.id = sensor_health_metrics.sensor_id AND sensors.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid));
ALTER TABLE public.schedule_history ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS schedule_history_tenant_isolation ON public.schedule_history;
CREATE POLICY schedule_history_tenant_isolation ON public.schedule_history
  USING (EXISTS (SELECT 1 FROM public.interrogation_schedules s WHERE s.id = schedule_history.schedule_id AND s.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid))
  WITH CHECK (EXISTS (SELECT 1 FROM public.interrogation_schedules s WHERE s.id = schedule_history.schedule_id AND s.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid));
ALTER TABLE public.ticket_comments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS ticket_comments_tenant_isolation ON public.ticket_comments;
CREATE POLICY ticket_comments_tenant_isolation ON public.ticket_comments
  USING (EXISTS (SELECT 1 FROM public.tickets t WHERE t.id = ticket_comments.ticket_id AND t.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid))
  WITH CHECK (EXISTS (SELECT 1 FROM public.tickets t WHERE t.id = ticket_comments.ticket_id AND t.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid));
ALTER TABLE public.remediation_plan_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS remediation_plan_items_tenant_isolation ON public.remediation_plan_items;
CREATE POLICY remediation_plan_items_tenant_isolation ON public.remediation_plan_items
  USING (EXISTS (SELECT 1 FROM public.remediation_plans rp WHERE rp.id = remediation_plan_items.plan_id AND rp.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid))
  WITH CHECK (EXISTS (SELECT 1 FROM public.remediation_plans rp WHERE rp.id = remediation_plan_items.plan_id AND rp.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid));


-- =========================================================================
-- MISSING INDEXES ON TENANT-SCOPED READ PATHS
-- (Core audit 2026-08-09, WP-E — SQL-5)
--
-- Each of these backs a query that is issued per request (or per ingested
-- finding) and had nothing to work from but a sequential scan.
-- =========================================================================


-- asset_history had NO secondary index at all — every asset-timeline read
-- scanned the whole tenant's history. The lead columns match the access
-- pattern: one asset's history, newest first.
CREATE INDEX IF NOT EXISTS idx_asset_history_tenant_asset_created
    ON public.asset_history USING btree (tenant_id, asset_id, created_at DESC);


-- discovery_findings is indexed on job_id/target_id/hostname/protocol but not
-- on the column every RLS policy and tenant query filters on first.
CREATE INDEX IF NOT EXISTS idx_discovery_findings_tenant_id
    ON public.discovery_findings USING btree (tenant_id);


-- external_connections: the sensor_id and source_asset_id lookups (which
-- sensor observed this / which asset originated this) had no index, unlike
-- every other access path on the table.
CREATE INDEX IF NOT EXISTS idx_ext_conn_sensor_id
    ON public.external_connections USING btree (sensor_id)
    WHERE (sensor_id IS NOT NULL);
CREATE INDEX IF NOT EXISTS idx_ext_conn_source_asset_id
    ON public.external_connections USING btree (source_asset_id)
    WHERE (source_asset_id IS NOT NULL);


-- Login and invite flows look users up case-insensitively within a tenant.
-- idx_users_email is on the raw column, so lower(email) could not use it.
CREATE INDEX IF NOT EXISTS idx_users_tenant_lower_email
    ON public.users USING btree (tenant_id, lower((email)::text));


-- =========================================================================
-- Partition-aware views must run with the querying role's RLS context, not the
-- view owner's, so the parent-table policies above actually apply through them.
-- (`assets` and `asset_endpoints` are queried through the partitioned parent
-- directly, with no wrapper view, so there is nothing to flip for them.)
ALTER VIEW public.sensor_discoveries SET (security_invoker = true);
ALTER VIEW public.crypto_implementations SET (security_invoker = true);


-- ============================================================================
-- RLS ROLE SPLIT (ADR platform-0001, Phase 2)
-- ============================================================================
-- Today the app connects as crypto_user, which OWNS every table (the
-- schema-migration Job runs as it) — and a table owner BYPASSES RLS. These two
-- non-owner roles make RLS an enforced boundary without any FORCE:
--
--   crypto_app    — NOBYPASSRLS. Services' normal per-request path connects as
--                   this role, so every tenant_isolation policy applies. It must
--                   set app.tenant_id (via shared/database.WithTenantTx) or its
--                   tenant-scoped queries fail closed (zero rows).
--   crypto_bypass — BYPASSRLS. The deliberate cross-tenant paths (platform-admin
--                   aggregations, background workers, and auth lookups where the
--                   tenant is the query's OUTPUT) connect as this role.
--
-- Roles are created NOLOGIN here; the deploy layer grants LOGIN + a password out
-- of band (psql \set from a secret) so no credential ever lives in this file.
-- crypto_user (owner) and the schema-migration/seed Jobs are unchanged.
-- Idempotent: CREATE ROLE has no IF NOT EXISTS, so it is wrapped; GRANT and
-- ALTER DEFAULT PRIVILEGES are already idempotent.
DO $$ BEGIN CREATE ROLE crypto_app NOLOGIN NOBYPASSRLS;    EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE ROLE crypto_bypass NOLOGIN BYPASSRLS;   EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- Schema + object access for both roles.
--
-- NOTE: the blanket `GRANT ... ON ALL TABLES/SEQUENCES` used to live here, and
-- that was a latent bug. `ON ALL TABLES` is expanded ONCE, against the tables
-- that exist at the moment it runs — so every table CREATEd further down this
-- file got no privileges at all on a FRESH SINGLE APPLY. The chart's
-- schema-migration Job runs the file exactly once on install, so nine tables
-- (alerts, alert_events, legal_documents, legal_acceptances, …) shipped with
-- `permission denied for table` for the NOBYPASSRLS crypto_app role that
-- services connect as under serviceRls. A second apply masked it, which is why
-- it survived: by then the tables existed when the GRANT ran.
--
-- ALTER DEFAULT PRIVILEGES (below) does not cover this either — it applies only
-- to objects created by crypto_user AFTER it runs, and this file is applied by
-- whatever role the Job connects as.
--
-- The blanket grants now live in the ROLE GRANTS block at the very END of this
-- file, after every CREATE TABLE. `scripts/audit-schema-grant-order.mjs`
-- (in `make audit`) fails the build if any table-creating statement ever lands
-- after it again.
GRANT USAGE ON SCHEMA public TO crypto_app, crypto_bypass;
GRANT USAGE ON SCHEMA audit  TO crypto_app, crypto_bypass;
GRANT EXECUTE ON FUNCTION public.set_tenant_context(uuid) TO crypto_app, crypto_bypass;
GRANT EXECUTE ON FUNCTION public.clear_tenant_context()   TO crypto_app, crypto_bypass;


-- RBAC permission checks (#916/#917-class fail-closed fix): these read RLS-scoped
-- user_tenant_roles / tenant_roles, so under the non-owner crypto_app role with no
-- app.tenant_id set (middleware runs before any WithTenantTx) they returned zero
-- rows -> every RBAC-gated action 403'd. Make them SECURITY DEFINER (run as owner)
-- so the parameterized (user, tenant) lookup is correct regardless of tenant
-- context; they filter internally by the passed ids so no cross-tenant leak.
-- EXECUTE locked to the app roles (SECURITY DEFINER + PUBLIC execute is an
-- escalation surface).
REVOKE EXECUTE ON FUNCTION public.user_has_permission(uuid, uuid, character varying) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_user_permissions(uuid, uuid)                   FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.platform_user_has_permission(uuid, character varying) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION public.user_has_permission(uuid, uuid, character varying) TO crypto_app, crypto_bypass;
GRANT  EXECUTE ON FUNCTION public.get_user_permissions(uuid, uuid)                   TO crypto_app, crypto_bypass;
GRANT  EXECUTE ON FUNCTION public.platform_user_has_permission(uuid, character varying) TO crypto_app, crypto_bypass;


-- audit partition management (#917): these are SECURITY DEFINER (run as the
-- owner so the app role can materialize partitions without owning the table).
-- Lock EXECUTE down to the app roles rather than the default PUBLIC, since a
-- SECURITY DEFINER function executable by PUBLIC is an escalation surface.
REVOKE EXECUTE ON FUNCTION audit.create_activity_logs_partition(integer, integer) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION audit.ensure_future_partitions(integer)                FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION audit.create_activity_logs_partition(integer, integer) TO crypto_app, crypto_bypass;
GRANT  EXECUTE ON FUNCTION audit.ensure_future_partitions(integer)                TO crypto_app, crypto_bypass;


-- Future objects the owner creates in later migrations are reachable too.
ALTER DEFAULT PRIVILEGES FOR ROLE crypto_user IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO crypto_app, crypto_bypass;
ALTER DEFAULT PRIVILEGES FOR ROLE crypto_user IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO crypto_app, crypto_bypass;
ALTER DEFAULT PRIVILEGES FOR ROLE crypto_user IN SCHEMA audit
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO crypto_app, crypto_bypass;
ALTER DEFAULT PRIVILEGES FOR ROLE crypto_user IN SCHEMA audit
  GRANT USAGE, SELECT ON SEQUENCES TO crypto_app, crypto_bypass;


-- ============================================================================
-- RLS HYBRID-TABLE POLICY REFINEMENT (ADR platform-0001, follow-up to Phase 0)
-- ============================================================================
-- These tables mix per-tenant rows with platform/built-in rows that carry
-- tenant_id IS NULL (industry-default alert rules, built-in port-heuristic
-- service-identification rules, the default onboarding workflow, platform-level
-- SIEM integrations and cost/log aggregates). The strict canonical policy would
-- hide those NULL-tenant rows once the app connects as the non-owner crypto_app
-- role, breaking the features that depend on the defaults.
--
-- Fix: USING allows the caller's own rows OR the global (tenant_id IS NULL) rows;
-- WITH CHECK stays strict so a tenant can only WRITE its own rows — the global
-- rows are seeded by migration/owner or written via the crypto_bypass role.
-- Idempotent (DROP POLICY IF EXISTS + CREATE).
DO $$
DECLARE t text;
BEGIN
  FOR t IN
    SELECT unnest(ARRAY[
      'audit.alert_rules','audit.siem_integrations',
      'public.service_identification_rules','public.workflow_configurations',
      'public.aws_cost_data','public.aws_cost_sync_jobs','public.platform_log_metadata'
    ])
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %s',
                   split_part(t,'.',2)||'_tenant_isolation', t);
    EXECUTE format($f$CREATE POLICY %I ON %s
                     USING (tenant_id IS NULL OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
                     WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)$f$,
                   split_part(t,'.',2)||'_tenant_isolation', t);
  END LOOP;
END $$;


-- =========================================================================
-- Platform in-app notifications (admin-ui bell / operator inbox)
-- ============================================================================
-- Platform-scoped (tenant_id IS NULL) alerts previously had no in-app path —
-- the delivery service rejected them. This is the operator inbox behind the
-- admin-ui topbar bell. Global table (no RLS), same model as the other
-- platform_notification_* tables. Idempotent.
CREATE TABLE IF NOT EXISTS public.platform_in_app_notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_platform_notification_type CHECK (((type)::text = ANY ((ARRAY['alert'::character varying, 'discovery'::character varying, 'compliance'::character varying, 'system'::character varying, 'billing'::character varying, 'security'::character varying, 'audit'::character varying, 'other'::character varying])::text[])))
);


CREATE INDEX IF NOT EXISTS idx_platform_in_app_notifications_created_at
    ON public.platform_in_app_notifications (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_platform_in_app_notifications_unread
    ON public.platform_in_app_notifications (created_at DESC) WHERE read_at IS NULL;


-- ============================================================================
-- Stateful alerts + append-only evidence events (issue #943)
-- ============================================================================
-- An alert is a stateful condition demanding attention: severity + lifecycle
-- active → acknowledged → snoozed → resolved. alert_events is the append-only
-- evidence chain (who acknowledged/snoozed/resolved, when, and — for
-- auto-resolves — the system's observation that the condition cleared).
-- Owned by compliance-engine. RLS tenant-isolated. See
-- docsv4/internal/developer/design/NOTIFICATION_ALERTING_ARCHITECTURE.md §9.
CREATE TABLE IF NOT EXISTS public.alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    tenant_id uuid NOT NULL,
    alert_type character varying(100) NOT NULL,
    source character varying(50) NOT NULL,
    subject_type character varying(50),
    subject_id uuid,
    subject_label text,
    severity character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    title character varying(500) NOT NULL,
    message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    acknowledged_by uuid,
    acknowledged_at timestamp with time zone,
    snoozed_by uuid,
    snoozed_until timestamp with time zone,
    snooze_reason text,
    resolved_at timestamp with time zone,
    resolved_by uuid,
    resolution character varying(10),
    resolution_note text,
    resolution_observation jsonb,
    ticket_id uuid,
    first_raised_at timestamp with time zone DEFAULT now() NOT NULL,
    last_event_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alerts_severity_check CHECK (((severity)::text = ANY ((ARRAY['critical'::character varying, 'high'::character varying, 'medium'::character varying, 'low'::character varying, 'info'::character varying])::text[]))),
    CONSTRAINT alerts_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'acknowledged'::character varying, 'snoozed'::character varying, 'resolved'::character varying])::text[]))),
    CONSTRAINT alerts_resolution_check CHECK ((resolution IS NULL OR (resolution)::text = ANY ((ARRAY['manual'::character varying, 'auto'::character varying])::text[])))
);


-- One OPEN alert per (tenant, type, subject): repeated raises escalate the
-- existing alert instead of fragmenting into duplicates.
CREATE UNIQUE INDEX IF NOT EXISTS idx_alerts_open_dedup
    ON public.alerts (tenant_id, alert_type, COALESCE(subject_id, '00000000-0000-0000-0000-000000000000'::uuid))
    WHERE ((status)::text <> 'resolved');
CREATE INDEX IF NOT EXISTS idx_alerts_tenant_status ON public.alerts (tenant_id, status, last_event_at DESC);
CREATE INDEX IF NOT EXISTS idx_alerts_snoozed_until ON public.alerts (snoozed_until) WHERE ((status)::text = 'snoozed');


CREATE TABLE IF NOT EXISTS public.alert_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    alert_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    event_type character varying(30) NOT NULL,
    actor_type character varying(10) DEFAULT 'system'::character varying NOT NULL,
    actor_id uuid,
    details jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alert_events_type_check CHECK (((event_type)::text = ANY ((ARRAY['opened'::character varying, 'severity_changed'::character varying, 'acknowledged'::character varying, 'snoozed'::character varying, 'unsnoozed'::character varying, 'ticket_linked'::character varying, 'resolved'::character varying])::text[]))),
    CONSTRAINT alert_events_actor_check CHECK (((actor_type)::text = ANY ((ARRAY['system'::character varying, 'user'::character varying])::text[])))
);


DO $$ BEGIN
  IF to_regclass('public.alert_events') IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'alert_events_alert_fk' AND conrelid = to_regclass('public.alert_events')) THEN
    ALTER TABLE public.alert_events
      ADD CONSTRAINT alert_events_alert_fk FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;
  END IF;
END $$;


CREATE INDEX IF NOT EXISTS idx_alert_events_alert ON public.alert_events (alert_id, created_at);


-- Ticket ↔ alert bridge: a ticket created from an alert records its origin.
CREATE INDEX IF NOT EXISTS idx_tickets_alert ON public.tickets (alert_id) WHERE (alert_id IS NOT NULL);


ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS alerts_tenant_isolation ON public.alerts;
CREATE POLICY alerts_tenant_isolation ON public.alerts
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
ALTER TABLE public.alert_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS alert_events_tenant_isolation ON public.alert_events;
CREATE POLICY alert_events_tenant_isolation ON public.alert_events
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);


-- ============================================================================
-- Tenant alert catalog settings (alert-type registry, §8.2)
-- ============================================================================
-- Per-tenant state over the registry catalog: enable/disable a type and
-- optionally replace the product baseline rung with the tenant's own
-- preference rung ({"days": 45} for time ladders, {"percent": 90} for
-- quota ladders). Absence of a row = registry defaults apply. Policy rungs
-- (from activated frameworks) are additive and are NOT stored here.
CREATE TABLE IF NOT EXISTS public.tenant_alert_settings (
    tenant_id uuid NOT NULL,
    alert_type character varying(100) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    preference_rung jsonb,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now(),
    PRIMARY KEY (tenant_id, alert_type)
);


ALTER TABLE public.tenant_alert_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_alert_settings_tenant_isolation ON public.tenant_alert_settings;
CREATE POLICY tenant_alert_settings_tenant_isolation ON public.tenant_alert_settings
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);


-- Detector-internal score history for the compliance_score_drop alert.
-- tenant_framework_scores keeps only the current score; this lightweight trail
-- lets the compliance-engine score-drop scan job compare against the value
-- ~24h ago. Written and pruned only by that job (no tenant-facing API, no RLS
-- policy — every query filters by tenant_id explicitly).
CREATE TABLE IF NOT EXISTS public.alert_framework_score_snapshots (
    tenant_id uuid NOT NULL,
    platform_framework_id uuid NOT NULL,
    score integer NOT NULL,
    captured_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_alert_framework_score_snapshots_lookup
    ON public.alert_framework_score_snapshots (tenant_id, platform_framework_id, captured_at);


-- Digest/batched notification delivery. Rules with frequency 'digest_*'
-- accumulate matched notifications here per (scope, channel); a flush worker
-- composes one batched notification per group when the oldest item's window
-- elapses. tenant_id NULL = platform scope (mirrors notification_history).
CREATE TABLE IF NOT EXISTS public.notification_digest_queue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    channel_id uuid NOT NULL,
    channel_type character varying(50) NOT NULL,
    notification_type character varying(50) DEFAULT 'alert'::character varying NOT NULL,
    alert_source character varying(50) NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    message text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    flush_after timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notification_digest_queue_flush
    ON public.notification_digest_queue (channel_id, flush_after);
ALTER TABLE public.notification_digest_queue ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS notification_digest_queue_tenant_isolation ON public.notification_digest_queue;
CREATE POLICY notification_digest_queue_tenant_isolation ON public.notification_digest_queue
  USING (tenant_id IS NULL OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);


-- Platform maintenance windows (storm control §10.3): while an active window is
-- in effect, notification-service suppresses delivery. Platform-scoped (no
-- tenant_id, no RLS — like platform_in_app_notifications); managed by platform
-- admins via /notification-service/platform/maintenance-windows.
CREATE TABLE IF NOT EXISTS public.platform_maintenance_windows (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    reason text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_platform_maintenance_windows_active
    ON public.platform_maintenance_windows (starts_at, ends_at);


-- =========================================================================
-- LEGAL DOCUMENTS & ACCEPTANCE TRACKING (Terms of Service / Privacy Policy)
--
-- Platform admins author versioned legal documents (Settings -> Legal in
-- admin-ui). Each publish creates a NEW immutable version row; the previously
-- current row for that doc_type is demoted. Tenants accept the current version
-- at signup (enforced server-side) and are re-prompted on next login whenever
-- a newer version is published. Acceptance rows are an append-only legal
-- evidence trail: exact version + content hash + server-observed IP/UA + time.
--
-- legal_documents is platform-global (no tenant scope, no RLS) — the same
-- document text is shown to every tenant and must be readable unauthenticated
-- (signup page). legal_acceptances is tenant data and RLS-isolated like scopes.
-- =========================================================================


-- Platform-authored, versioned legal documents. Immutable per (doc_type, version).
CREATE TABLE IF NOT EXISTS public.legal_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doc_type character varying(50) NOT NULL,          -- 'terms_of_service' | 'privacy_policy'
    version integer NOT NULL,                          -- monotonic per doc_type, 1-based
    title character varying(255) NOT NULL,
    body text NOT NULL,                                -- document content (markdown/plain)
    content_hash character varying(64) NOT NULL,       -- sha256 hex of body; pins acceptances
    is_current boolean DEFAULT false NOT NULL,         -- exactly one true per doc_type
    effective_date timestamp with time zone DEFAULT now() NOT NULL,
    published_by uuid,                                 -- platform_users.id (NULL = system seed)
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT legal_documents_pkey PRIMARY KEY (id),
    CONSTRAINT legal_documents_type_version_unique UNIQUE (doc_type, version),
    CONSTRAINT legal_documents_doc_type_check CHECK (doc_type IN ('terms_of_service', 'privacy_policy'))
);
-- At most one current version per doc_type.
CREATE UNIQUE INDEX IF NOT EXISTS idx_legal_documents_current
    ON public.legal_documents USING btree (doc_type) WHERE (is_current = true);
CREATE INDEX IF NOT EXISTS idx_legal_documents_type_version
    ON public.legal_documents USING btree (doc_type, version DESC);


-- Append-only acceptance ledger. One row per (user, document version) acceptance.
CREATE TABLE IF NOT EXISTS public.legal_acceptances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    doc_type character varying(50) NOT NULL,
    document_id uuid NOT NULL,                         -- legal_documents.id (which version)
    version integer NOT NULL,
    content_hash character varying(64) NOT NULL,       -- copy of the accepted version's hash
    accepted_at timestamp with time zone DEFAULT now() NOT NULL,
    accepted_ip character varying(45),                 -- server-observed, IPv4/IPv6
    user_agent text,                                   -- server-observed
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT legal_acceptances_pkey PRIMARY KEY (id),
    CONSTRAINT legal_acceptances_user_document_unique UNIQUE (user_id, document_id)
);
CREATE INDEX IF NOT EXISTS idx_legal_acceptances_tenant_user
    ON public.legal_acceptances USING btree (tenant_id, user_id);
CREATE INDEX IF NOT EXISTS idx_legal_acceptances_tenant_time
    ON public.legal_acceptances USING btree (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_legal_acceptances_document
    ON public.legal_acceptances USING btree (document_id);
-- Tenant isolation. This table is created below the canonical RLS HARDENING
-- block, so unlike every other policy it must be declared here — the block
-- cannot reference a table that does not exist yet.
--
-- DROP + CREATE, not the old DO/EXCEPTION duplicate_object form: that form
-- cannot UPDATE an existing policy, so on an already-installed database it
-- would hit the duplicate and silently leave the previous definition in force.
-- That is why this policy stayed USING-only through several releases (#1297).
--
-- WITH CHECK is safe here: every writer uses the BYPASSRLS crypto_bypass handle
-- (auth-service handlers.go signup paths, ee/sso platform_sso.go, and
-- AcceptLegalDocuments, which router.go wires with bypassDB), so the check is
-- never evaluated against them and ToS/Privacy acceptance is unaffected —
-- verified against a real Postgres, contrary to the original #1297 analysis.
ALTER TABLE public.legal_acceptances ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS legal_acceptances_tenant_isolation ON public.legal_acceptances;
CREATE POLICY legal_acceptances_tenant_isolation ON public.legal_acceptances
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);


-- =========================================================================
-- Cryptographic-key inventory producer (Keys lens) — unique dedup identity.
-- The key producer (services/inventory-service/internal/services/key_producer.go)
-- upserts one public-key row per discovered certificate public key, keyed on
-- (tenant_id, public_fingerprint) so the same key across renewals/hosts
-- collapses to a single row (which drives the lens "used by N assets" count).
-- This partial UNIQUE index backs that ON CONFLICT target. Idempotent; the keys
-- table had no producer before this, so no pre-dedup is required.
-- =========================================================================
CREATE UNIQUE INDEX IF NOT EXISTS keys_tenant_public_fingerprint_uniq
    ON public.keys USING btree (tenant_id, public_fingerprint)
    WHERE (public_fingerprint IS NOT NULL);


-- =========================================================================
ALTER TABLE IF EXISTS public.service_accounts
    ADD COLUMN IF NOT EXISTS token_lookup text;

CREATE INDEX IF NOT EXISTS idx_service_accounts_token_lookup
    ON public.service_accounts USING btree (token_lookup)
    WHERE (token_lookup IS NOT NULL);

-- crypto_configurations (the TABLE — distinct from the crypto-configurations
-- API routes, which serve crypto_implementations): its only writer was the
-- unrouted, never-constructed CryptoConfigurationService. Nothing else reads or
-- writes it; keep existing installs from retaining the dead table indefinitely.
DROP TABLE IF EXISTS public.crypto_configurations CASCADE;
DROP FUNCTION IF EXISTS public.update_crypto_configurations_updated_at();

-- Widen valid_certificate_role to accept the roles the code actually writes.
-- Existing installs may still have the original CHECK, which rejected 'leaf'
-- and made every sensor-discovered leaf certificate fail to link to its crypto
-- configuration.
ALTER TABLE IF EXISTS public.crypto_implementation_certificates
  DROP CONSTRAINT IF EXISTS valid_certificate_role;
ALTER TABLE IF EXISTS public.crypto_implementation_certificates
  ADD CONSTRAINT valid_certificate_role
    CHECK (certificate_role IN ('leaf', 'primary', 'additional', 'intermediate', 'root'));

-- Converge crypto_implementations.certificate_id onto the junction table.
--
-- The junction is the ONE source of truth for the certificate↔configuration
-- link: every reader that asks "which certificates belong to this asset /
-- endpoint / configuration" walks it (shared/findings.AssetSubjects' certificate
-- descendant path, the asset/cert · endpoint/cert · crypto_configuration/cert ·
-- certificate/asset shapes in shared/query/sql, the location roll-up, the
-- crypto-risk certificate-expiry bands). `certificate_id` is the leaf
-- denormalisation beside it.
--
-- They were written apart and diverged: the column by the ingest INSERT/UPDATE,
-- the junction row by a later best-effort call the CHECK widened just above used
-- to REFUSE ('leaf' was not an accepted role). The writers are now atomic, but
-- rows written before that landed still carry a certificate_id with no junction
-- row, and their certificates are invisible from their own asset.
--
-- Must run AFTER the CHECK widening above: on an install still carrying the
-- original constraint this INSERT would be rejected outright.
--
-- Idempotent by ON CONFLICT on unique_impl_cert, and by construction — the
-- certificate is read out of the row, so re-running converges rather than
-- inventing links. A row whose junction already names the same certificate under
-- a different role (the demo fixtures write 'additional') is left as it is;
-- nothing reads certificate_role, and rewriting a seeded row's role would buy
-- nothing.
DO $$
BEGIN
  IF to_regclass('public.crypto_implementation_certificates') IS NOT NULL
     AND to_regclass('public.crypto_implementations') IS NOT NULL THEN
    INSERT INTO public.crypto_implementation_certificates (
      crypto_implementation_id, certificate_id, certificate_role, certificate_order
    )
    SELECT ci.id, ci.certificate_id, 'leaf', 0
      FROM public.crypto_implementations ci
     WHERE ci.certificate_id IS NOT NULL
    ON CONFLICT (crypto_implementation_id, certificate_id) DO NOTHING;
  END IF;
END $$;


-- ============================================================================
-- W2-2 SELF-CHECK: no tenant-isolation policy may survive on the old,
-- unindexable `(tenant_id)::text = current_setting(...)` predicate.
--
-- This is deliberately a WARNING and not an exception: a stray old-shape policy
-- is a performance regression, not a correctness or isolation failure, and
-- failing the schema-migration Job over one would take a customer's upgrade
-- down for a reason that does not warrant it. The message names every offender
-- so it is actionable from the Job log.
--
-- Mutation-tested: reverting a single policy to the old predicate makes this
-- block emit the WARNING naming exactly that policy.
-- ============================================================================
DO $$
DECLARE
    stale text;
BEGIN
    SELECT string_agg(format('%s ON %s', p.polname, c.oid::regclass), ', ' ORDER BY p.polname)
      INTO stale
      FROM pg_policy p
      JOIN pg_class c ON c.oid = p.polrelid
     WHERE pg_get_expr(p.polqual, p.polrelid) LIKE '%tenant_id)::text = current_setting%'
        OR pg_get_expr(p.polwithcheck, p.polrelid) LIKE '%tenant_id)::text = current_setting%';


    IF stale IS NOT NULL THEN
        RAISE WARNING 'W2-2: % RLS policies still use the unindexable (tenant_id)::text predicate: %',
            array_length(string_to_array(stale, ', '), 1), stale;
    END IF;
END $$;


-- =========================================================================
-- =========================================================================
-- RETAINED: legacy-table retirement drops
--
-- These are the one part of the old POST-MIGRATIONS block that is deliberately
-- NOT collapsed, because it is not expressible as base DDL: you cannot express
-- "do not have this table" in a CREATE statement. Nothing in this file creates
-- or references a *_legacy relation any more, so on a fresh install all three
-- are no-ops — they exist so a cluster installed before the partition
-- conversion loses the drained residue and everything stale that pinned it
-- (junction FKs that broke populated re-applies, views that made CMDB sync and
-- the remediation queue silently empty, FKs that kept
-- external_connections.source_asset_id NULL forever).
--
-- scripts/audit-legacy-residue.mjs enforces BOTH directions in `make audit`:
-- nothing may reference a *_legacy relation, and these three drops may not be
-- deleted. Do not remove them to tidy the file.
-- =========================================================================
DROP TABLE IF EXISTS public.crypto_implementations_legacy CASCADE;
DROP TABLE IF EXISTS public.sensor_discoveries_legacy CASCADE;
DROP TABLE IF EXISTS public.network_assets_legacy CASCADE;

-- Retired 2026-08-17: the experimental source-code crypto scanner was removed
-- from the product (unreachable — it had no UI, no feature flag and no consumer
-- outside its own handler). Nothing in this file creates or references
-- crypto_code_findings any more, so on a fresh install this is a no-op; it
-- exists so a cluster installed before the removal drops the orphaned table.
DROP TABLE IF EXISTS public.crypto_code_findings CASCADE;


-- ============================================================================
-- VIEW ISOLATION HARDENING (close the security_invoker gap left by Phase 4)
-- ============================================================================
-- A plain view executes with its OWNER's privileges, and the owner
-- (crypto_user) both owns the base tables and is exempt from their RLS —
-- so every view below was a cross-tenant read path for the NOBYPASSRLS
-- crypto_app role. Only the two partition-wrapper views (sensor_discoveries
-- and crypto_implementations, flipped above) had
-- security_invoker. Flip every remaining view whose base tables carry a
-- tenant_isolation policy, so RLS applies to the querying role exactly as it
-- would on the tables themselves. Deliberately NOT flipped: v_tenants,
-- platform_administrators, platform_metrics_aggregations and
-- audit.partition_info (no RLS base tables — platform/catalog data), and the
-- materialized views (security_invoker does not exist for matviews; they are
-- handled by REVOKE + tenant-scoped wrapper views below).
--
-- This block must stay AFTER every CREATE OR REPLACE VIEW / matview
-- DROP+CREATE above so a re-apply always leaves the flag set.
-- Idempotent: ALTER VIEW ... SET is a plain reloption write.
ALTER VIEW public.active_resource_alerts        SET (security_invoker = true);
ALTER VIEW public.aws_daily_cost_summary        SET (security_invoker = true);
ALTER VIEW public.aws_daily_service_cost_summary SET (security_invoker = true);
ALTER VIEW public.aws_tenant_monthly_cost_summary SET (security_invoker = true);
ALTER VIEW public.current_resource_usage_summary SET (security_invoker = true);
ALTER VIEW public.health_metrics_aggregated_view SET (security_invoker = true);
ALTER VIEW public.platform_integrations_summary SET (security_invoker = true);
ALTER VIEW public.tenant_health_summary_view    SET (security_invoker = true);
ALTER VIEW public.user_tenant_permissions       SET (security_invoker = true);
ALTER VIEW public.v_ci_inventory                SET (security_invoker = true);


-- Materialized views hold cross-tenant data by construction (populated by the
-- owner at REFRESH time; RLS and security_invoker are structurally
-- inapplicable). Give the app role a tenant-scoped face instead:
--
--   1. A wrapper view per consumed matview, executing as the owner
--      (deliberately NOT security_invoker — it must read the matview after
--      the REVOKE below) with the same fail-closed predicate the
--      tenant_isolation policies use: no app.tenant_id context => zero rows.
--   2. REVOKE direct matview access from crypto_app. crypto_bypass keeps it
--      (BYPASSRLS is the deliberate cross-tenant lane).
--
-- Created here, after the matview DROP ... CASCADE + re-CREATE above, because
-- that CASCADE takes the wrappers with it on every re-apply.
CREATE OR REPLACE VIEW public.mv_location_finding_summary_tenant AS
  SELECT * FROM public.mv_location_finding_summary
  WHERE tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid;

CREATE OR REPLACE VIEW public.mv_remediation_queue_tenant AS
  SELECT * FROM public.mv_remediation_queue
  WHERE tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid;

-- The REVOKEs that keep crypto_app off the raw matviews, and the SELECT grants
-- on these wrapper views, are NOT here: they must run AFTER the blanket
-- `GRANT ... ON ALL TABLES` (which covers views and matviews too), and that
-- block now lives at the very end of this file. See ROLE GRANTS there.

-- The refresh functions are SECURITY DEFINER (REFRESH requires matview
-- ownership — see their definitions). Same hygiene as the other definer
-- functions: not executable by PUBLIC, only by the app roles.
REVOKE EXECUTE ON FUNCTION public.refresh_operational_views()  FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.refresh_tenant_cost_summary() FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION public.refresh_operational_views()  TO crypto_app, crypto_bypass;
GRANT  EXECUTE ON FUNCTION public.refresh_tenant_cost_summary() TO crypto_app, crypto_bypass;

-- ---------------------------------------------------------------------------
-- agent_addresses: indexes, isolation, and the device_agents primary-address
-- column. The table itself is defined next to `sensors` in the body above.
-- ---------------------------------------------------------------------------

-- Existing databases predate the column; fresh ones already have it from the
-- CREATE TABLE. Both paths converge here.
ALTER TABLE public.device_agents ADD COLUMN IF NOT EXISTS ip_address character varying(45);

-- Owner foreign keys. Guarded rather than DROP-then-ADD so re-applying never
-- momentarily removes a constraint other objects depend on. ON DELETE CASCADE:
-- an agent's addresses are facts about that agent and have no meaning without it.
DO $$ BEGIN
  IF to_regclass('public.agent_addresses') IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agent_addresses_sensor_id_fkey' AND conrelid = to_regclass('public.agent_addresses'))
  THEN
    ALTER TABLE ONLY public.agent_addresses
        ADD CONSTRAINT agent_addresses_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.sensors(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.agent_addresses') IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agent_addresses_device_agent_id_fkey' AND conrelid = to_regclass('public.agent_addresses'))
  THEN
    ALTER TABLE ONLY public.agent_addresses
        ADD CONSTRAINT agent_addresses_device_agent_id_fkey FOREIGN KEY (device_agent_id) REFERENCES public.device_agents(id) ON DELETE CASCADE;
  END IF;
END $$;

-- An agent reports each address once per interface. The partial indexes are
-- split by owner because a plain UNIQUE over (sensor_id, device_agent_id, ...)
-- would not constrain anything: NULLs never conflict, so every device-agent row
-- would be trivially unique on the sensor side and vice versa.
CREATE UNIQUE INDEX IF NOT EXISTS agent_addresses_sensor_iface_addr_key
    ON public.agent_addresses (sensor_id, interface_name, address)
    WHERE sensor_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS agent_addresses_device_agent_iface_addr_key
    ON public.agent_addresses (device_agent_id, interface_name, address)
    WHERE device_agent_id IS NOT NULL;

-- At most one primary address per agent. Enforcing it here rather than in Go
-- means a reconcile bug surfaces as a failed write instead of a fleet view that
-- quietly shows two primaries for the same host.
CREATE UNIQUE INDEX IF NOT EXISTS agent_addresses_one_primary_per_sensor
    ON public.agent_addresses (sensor_id)
    WHERE sensor_id IS NOT NULL AND is_primary;
CREATE UNIQUE INDEX IF NOT EXISTS agent_addresses_one_primary_per_device_agent
    ON public.agent_addresses (device_agent_id)
    WHERE device_agent_id IS NOT NULL AND is_primary;

CREATE INDEX IF NOT EXISTS idx_agent_addresses_sensor ON public.agent_addresses (sensor_id);
CREATE INDEX IF NOT EXISTS idx_agent_addresses_device_agent ON public.agent_addresses (device_agent_id);
-- Coverage lookups ("who sees this address/segment?") scan by address.
CREATE INDEX IF NOT EXISTS idx_agent_addresses_address ON public.agent_addresses (address);

-- Tenant isolation is inherited from whichever owner the row hangs off, mirroring
-- sensor_health_metrics / sensor_commands. Both arms are needed because the owner
-- may be either runtime; the CHECK constraint guarantees exactly one is set.
ALTER TABLE public.agent_addresses ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS agent_addresses_tenant_isolation ON public.agent_addresses;
CREATE POLICY agent_addresses_tenant_isolation ON public.agent_addresses
  USING (
    EXISTS (SELECT 1 FROM public.sensors s WHERE s.id = agent_addresses.sensor_id AND s.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    OR EXISTS (SELECT 1 FROM public.device_agents a WHERE a.id = agent_addresses.device_agent_id AND a.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.sensors s WHERE s.id = agent_addresses.sensor_id AND s.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    OR EXISTS (SELECT 1 FROM public.device_agents a WHERE a.id = agent_addresses.device_agent_id AND a.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  );

GRANT SELECT, INSERT, UPDATE, DELETE ON public.agent_addresses TO crypto_app, crypto_bypass;


-- ---------------------------------------------------------------------------
-- agent_config_*: keys, indexes and isolation (feature #1785)
-- ---------------------------------------------------------------------------
--
-- Foreign keys live here rather than inline for the reason agent_addresses
-- gives above: this file follows pg_dump layout, so sensors/device_agents have
-- no primary key yet at the point the tables are declared.

DO $$
BEGIN
  IF to_regclass('public.agent_config_overrides') IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agent_config_overrides_sensor_id_fkey' AND conrelid = to_regclass('public.agent_config_overrides'))
  THEN
    ALTER TABLE ONLY public.agent_config_overrides
        ADD CONSTRAINT agent_config_overrides_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.sensors(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF to_regclass('public.agent_config_overrides') IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agent_config_overrides_device_agent_id_fkey' AND conrelid = to_regclass('public.agent_config_overrides'))
  THEN
    ALTER TABLE ONLY public.agent_config_overrides
        ADD CONSTRAINT agent_config_overrides_device_agent_id_fkey FOREIGN KEY (device_agent_id) REFERENCES public.device_agents(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF to_regclass('public.agent_config_state') IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agent_config_state_sensor_id_fkey' AND conrelid = to_regclass('public.agent_config_state'))
  THEN
    ALTER TABLE ONLY public.agent_config_state
        ADD CONSTRAINT agent_config_state_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.sensors(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF to_regclass('public.agent_config_state') IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agent_config_state_device_agent_id_fkey' AND conrelid = to_regclass('public.agent_config_state'))
  THEN
    ALTER TABLE ONLY public.agent_config_state
        ADD CONSTRAINT agent_config_state_device_agent_id_fkey FOREIGN KEY (device_agent_id) REFERENCES public.device_agents(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF to_regclass('public.agent_config_defaults') IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agent_config_defaults_tenant_id_fkey' AND conrelid = to_regclass('public.agent_config_defaults'))
  THEN
    ALTER TABLE ONLY public.agent_config_defaults
        ADD CONSTRAINT agent_config_defaults_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Widen the audit scope to admit 'bootstrap'.
--
-- Two edits, as an enum would need: the CREATE TABLE above carries the widened
-- list for a fresh install, and this re-states it for a database created before
-- the value existed — where the CREATE TABLE is a no-op. Postgres has no
-- ALTER CONSTRAINT for a CHECK, so it is dropped and re-added; a CHECK has no
-- dependents, so unlike a primary key that is safe. Existing rows are all
-- 'device' or 'fleet' and satisfy the wider list, so this cannot fail on a
-- populated table.
DO $$
BEGIN
  IF to_regclass('public.agent_config_audit') IS NOT NULL THEN
    ALTER TABLE public.agent_config_audit DROP CONSTRAINT IF EXISTS agent_config_audit_scope_check;
    ALTER TABLE public.agent_config_audit
        ADD CONSTRAINT agent_config_audit_scope_check
        CHECK (((scope)::text = ANY ((ARRAY['device'::character varying, 'fleet'::character varying, 'bootstrap'::character varying])::text[])));
  END IF;
END $$;

-- One override row and one state row per device, whichever runtime owns it.
-- Partial unique indexes rather than a plain one: the unused owner column is
-- NULL on every row, and NULLs do not conflict in a unique index.
CREATE UNIQUE INDEX IF NOT EXISTS agent_config_overrides_one_per_sensor
    ON public.agent_config_overrides (sensor_id) WHERE sensor_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS agent_config_overrides_one_per_device_agent
    ON public.agent_config_overrides (device_agent_id) WHERE device_agent_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS agent_config_state_one_per_sensor
    ON public.agent_config_state (sensor_id) WHERE sensor_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS agent_config_state_one_per_device_agent
    ON public.agent_config_state (device_agent_id) WHERE device_agent_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_agent_config_audit_tenant_changed
    ON public.agent_config_audit (tenant_id, changed_at DESC);

-- Tenant isolation. The two device-scoped tables inherit it from whichever
-- owner the row hangs off, exactly as agent_addresses does; the defaults and
-- audit tables carry tenant_id themselves.
ALTER TABLE public.agent_config_overrides ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS agent_config_overrides_tenant_isolation ON public.agent_config_overrides;
CREATE POLICY agent_config_overrides_tenant_isolation ON public.agent_config_overrides
  USING (
    EXISTS (SELECT 1 FROM public.sensors s WHERE s.id = agent_config_overrides.sensor_id AND s.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    OR EXISTS (SELECT 1 FROM public.device_agents a WHERE a.id = agent_config_overrides.device_agent_id AND a.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.sensors s WHERE s.id = agent_config_overrides.sensor_id AND s.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    OR EXISTS (SELECT 1 FROM public.device_agents a WHERE a.id = agent_config_overrides.device_agent_id AND a.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  );

ALTER TABLE public.agent_config_state ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS agent_config_state_tenant_isolation ON public.agent_config_state;
CREATE POLICY agent_config_state_tenant_isolation ON public.agent_config_state
  USING (
    EXISTS (SELECT 1 FROM public.sensors s WHERE s.id = agent_config_state.sensor_id AND s.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    OR EXISTS (SELECT 1 FROM public.device_agents a WHERE a.id = agent_config_state.device_agent_id AND a.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.sensors s WHERE s.id = agent_config_state.sensor_id AND s.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    OR EXISTS (SELECT 1 FROM public.device_agents a WHERE a.id = agent_config_state.device_agent_id AND a.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  );

ALTER TABLE public.agent_config_defaults ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS agent_config_defaults_tenant_isolation ON public.agent_config_defaults;
CREATE POLICY agent_config_defaults_tenant_isolation ON public.agent_config_defaults
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.agent_config_audit ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS agent_config_audit_tenant_isolation ON public.agent_config_audit;
CREATE POLICY agent_config_audit_tenant_isolation ON public.agent_config_audit
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.agent_config_overrides TO crypto_app, crypto_bypass;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.agent_config_state TO crypto_app, crypto_bypass;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.agent_config_defaults TO crypto_app, crypto_bypass;
-- Audit rows are append-only: no UPDATE, no DELETE, mirroring scopes_audit.
GRANT SELECT, INSERT ON public.agent_config_audit TO crypto_app, crypto_bypass;

-- agent_config_overrides gains the restart-request columns (#1785). ADD COLUMN
-- IF NOT EXISTS is idempotent, and both are nullable, so this is safe over a
-- populated table — a row that has never been asked to restart simply holds
-- NULL, which ShouldRestart reads as "never asked".
ALTER TABLE IF EXISTS public.agent_config_overrides
    ADD COLUMN IF NOT EXISTS restart_requested_at timestamp with time zone;
ALTER TABLE IF EXISTS public.agent_config_overrides
    ADD COLUMN IF NOT EXISTS restart_requested_by uuid;

-- discovery_auto_approval_rules.created_by must allow NULL: segment saves made
-- under HMAC service auth (no user context) still need to create the rule the
-- discovery-processor auto-approves from. With NOT NULL, such saves persisted
-- auto_approve_discoveries=true on network_segments but silently never created
-- the rule, so the flag and behavior desynced (observed live on a dev
-- cluster; PR #1288 "Known follow-up"). The CREATE TABLE in the pg_dump body
-- was updated in the same change; this ALTER upgrades existing databases.
-- DROP NOT NULL is a no-op when the column is already nullable, so this is
-- safely re-appliable.
ALTER TABLE IF EXISTS public.discovery_auto_approval_rules ALTER COLUMN created_by DROP NOT NULL;


-- Backfill: give the seeded "Default activity feed" rule the `info` severity.
--
-- seedDefaultNotificationPack shipped this rule as ARRAY['medium','low'], and
-- nothing covered 'info'. That is not a spare band — asset_limit_approaching
-- opens there at its 80% rung, billing notifications are emitted there, and
-- notification-service's NormalizeSeverity degrades ANY unrecognized producer
-- severity to 'info'. An unmatched notification is written status='sent' with
-- channels_used={}, so it looked delivered while reaching nobody.
--
-- The create-time fix (services/auth-service/internal/auth/service.go) only
-- helps tenants created after it ships; every existing tenant keeps the broken
-- rule. Hence this backfill.
--
-- Scoped deliberately narrowly: it matches only rules that still carry BOTH the
-- shipped name and the exact shipped severity array, so a tenant who edited
-- their routing — including one who removed 'medium' or 'low' on purpose — is
-- never overwritten. Re-appliable: after the first run no row matches the WHERE
-- clause, so subsequent applies update nothing.
UPDATE public.tenant_notification_rules
   SET severity_filter = ARRAY['medium','low','info']::varchar[]
 WHERE rule_name = 'Default activity feed'
   AND severity_filter = ARRAY['medium','low']::varchar[];


-- Tenant-triggered compliance re-evaluation: the persisted per-tenant cooldown.
-- One row per tenant, holding the last ACCEPTED manual re-evaluation request.
--
-- Persisted, not in-process, deliberately: compliance-engine runs multiple
-- replicas and its Deployment rolls on every config change, so an in-memory
-- timer resets on restart and disagrees between pods — a tenant could retry
-- until it hit a fresh pod. The claim is a single conditional upsert, so the
-- database arbitrates and two concurrent requests on two pods cannot both win.
--
-- Platform-admin re-evaluation (/admin/tenants/{id}/reevaluate) deliberately
-- does NOT touch this table: it is the unbounded escape hatch after an engine
-- fix or a bulk import (owner decision, 2026-08).
CREATE TABLE IF NOT EXISTS public.tenant_reevaluation_requests (
    tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    last_requested_at timestamp with time zone DEFAULT now() NOT NULL,
    last_requested_by uuid,
    request_count integer DEFAULT 0 NOT NULL,
    CONSTRAINT tenant_reevaluation_requests_pkey PRIMARY KEY (tenant_id)
);

ALTER TABLE public.tenant_reevaluation_requests ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_reevaluation_requests_tenant_isolation ON public.tenant_reevaluation_requests;
CREATE POLICY tenant_reevaluation_requests_tenant_isolation ON public.tenant_reevaluation_requests
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);


-- ============================================================================
-- AT-REST ENCRYPTION POSTURE — crypto_applications natural key
-- ============================================================================
-- crypto_applications is the at-rest sibling of crypto_implementations: one row
-- per managed resource (S3 bucket, RDS instance, …) per encryption context.
-- inventory-service's at-rest producer UPSERTs on re-discovery, so the table
-- needs a unique key to conflict on; without it every discovery run appended a
-- duplicate row for the same bucket.
--
-- (tenant_id, resource_identifier, encryption_context) is the natural key: a
-- resource ARN is globally unique, and the same resource can legitimately carry
-- separate at_rest and in_transit rows. Partial on deleted_at IS NULL so a
-- soft-deleted row never blocks re-discovery of the same resource.
CREATE UNIQUE INDEX IF NOT EXISTS uq_crypto_applications_tenant_resource_context
    ON public.crypto_applications (tenant_id, resource_identifier, encryption_context)
    WHERE deleted_at IS NULL;


-- ============================================================================
-- ASSET SUPPRESSION — denied-discovery fingerprints (B-42)
-- ============================================================================
-- inventory-service has read and written `asset_suppressions` since the deny
-- flow shipped, and the table has never existed in any commit — no DDL, no
-- seed, no chart file. Both call sites hid it: the read collapsed every error
-- (including relation-does-not-exist) into "not suppressed", and the write's
-- error went to a bare stdout Printf while DenyAssets still returned nil. So
-- deny appeared to work, and the customer-facing promise in
-- docsv4/core/features/asset-approval.md ("suppressed from rediscovery") was
-- unbacked.
--
-- What it is for: the primary deny guard is `asset_status = 'denied'` on the
-- `assets` row itself, which holds as long as that row survives. The
-- fingerprint here is the fallback for when it does not — a denied host that is
-- subsequently deleted from Inventory would otherwise come back on the next
-- discovery as a fresh pending_approval asset.
--
-- suppression_key is md5(hostname|ip|port) computed in Go
-- (buildSuppressionKey), stored hex — 32 chars, hence char(32)-width varchar.
-- It is a deterministic dedup fingerprint, not a security primitive.
--
-- (tenant_id, suppression_key) is UNIQUE because addSuppression's
-- `ON CONFLICT (tenant_id, suppression_key) DO NOTHING` needs an arbiter; a
-- plain table without it would raise 42P10 on every deny.
CREATE TABLE IF NOT EXISTS public.asset_suppressions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    hostname character varying(255),
    ip_address character varying(45),
    port integer,
    reason text,
    created_by uuid,
    suppression_key character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT asset_suppressions_pkey PRIMARY KEY (id),
    CONSTRAINT asset_suppressions_tenant_key_unique UNIQUE (tenant_id, suppression_key)
);

CREATE INDEX IF NOT EXISTS idx_asset_suppressions_tenant_id ON public.asset_suppressions USING btree (tenant_id);

DO $$ BEGIN
  IF to_regclass('public.asset_suppressions') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_suppressions_tenant_id_fkey' AND conrelid = to_regclass('public.asset_suppressions')
     ) THEN
    ALTER TABLE ONLY public.asset_suppressions
        ADD CONSTRAINT asset_suppressions_tenant_id_fkey FOREIGN KEY (tenant_id)
        REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;

-- RLS, like every other tenant-scoped table. The Go call sites go through
-- database.WithTenantTx accordingly — a plain-pool query here would silently
-- return zero rows under the default serviceRls=on, which is the same
-- fail-open shape this finding is about.
ALTER TABLE public.asset_suppressions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_suppressions_tenant_isolation ON public.asset_suppressions;
CREATE POLICY asset_suppressions_tenant_isolation ON public.asset_suppressions
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);


-- ============================================================================
-- B-57: aws_cost_data unique index superseded by idx_aws_cost_data_unique_v2
-- ============================================================================
-- idx_aws_cost_data_unique_v2 (created earlier in this file, alongside the
-- aws_cost_data table) replaces idx_aws_cost_data_unique. `CREATE UNIQUE INDEX
-- IF NOT EXISTS` matches by name only, so redefining the original name in
-- place would silently keep the old (buggy) index on every database that had
-- already applied a prior version of this file — hence the new name plus this
-- drop, rather than an in-place edit.
--
-- The drop belongs HERE and the de-duplication that unblocks the v2 index
-- belongs UP THERE, next to the CREATE: dropping the old index early would
-- leave the table unprotected if a later statement in the same run failed,
-- while the dedup must precede the CREATE it exists to make succeed.
DROP INDEX IF EXISTS public.idx_aws_cost_data_unique;



-- ============================================================================
-- GENERAL ASSET INVENTORY — ADDITIVE SCHEMA (phase 0, BUILD_PLAN workstream 0.2)
-- ============================================================================
-- The tables the general-asset-inventory initiative adds. Column design is
-- docsv4/internal/developer/design/asset-inventory/DATA_MODEL.md §1–§4; the
-- decisions behind it are ADR-0002 (identity and class taxonomy), ADR-0003
-- (relationships), ADR-0005 (facts, findings, risk) in that directory.
--
-- Phase 0 added these tables additively; phase 1 (workstream 1.1) removed
-- `network_assets_partitioned` and `devices` and made `assets` +
-- `asset_endpoints` THE unit of inventory. Phase 3 (workstream 3.1) replaced
-- `compliance_findings` with `findings`; `cbom_artifacts` is still to come
-- (ADR-0007 D2). Every table below is created EMPTY except asset_classes,
-- whose platform rows come from the generated region in seed.sql.
--
-- Owner decision 2026-09-11 (ADR-0007): there are no existing installs, so
-- there is no backfill, no compatibility view, and no migration of the old
-- shape into these tables.
--
-- Conventions followed here, per CLAUDE.md's schema idempotency invariants:
--   * CREATE TABLE IF NOT EXISTS, CREATE INDEX IF NOT EXISTS.
--   * Constraints that must be added to an existing table go in DO blocks
--     gated on pg_constraint; constraints that can live in the CREATE TABLE
--     body do, because IF NOT EXISTS makes the whole statement a no-op on a
--     re-apply.
--   * Policies are DROP POLICY IF EXISTS + CREATE (not the DO/EXCEPTION
--     duplicate_object form), matching the RLS HARDENING block: that form
--     cannot UPDATE an existing policy, so a policy change would silently not
--     apply on an installed database. These tables are created BELOW the RLS
--     HARDENING block, so — like legal_acceptances — their policies must be
--     declared here rather than up there.
--   * USING and WITH CHECK are both stated. Postgres reuses USING as the
--     WITH CHECK when the latter is omitted, so this is legibility, not a
--     security fix — and TestIntegration_RLS_EveryTenantPolicyHasWithCheck
--     requires it.
--   * NO ENUMS for class_key / source_kind / status-shaped columns. They are
--     text with a CHECK, so a new value is one edit rather than the two the
--     enum rule demands (and cannot half-apply: an `ALTER TYPE ... ADD VALUE`
--     missing from POST-MIGRATIONS fails SILENTLY, psql exit 0). protocol_type
--     on asset_endpoints is the EXISTING enum and is reused as-is.
--   * Tenant-scoped tables carry a FK to tenants ON DELETE CASCADE so a tenant
--     delete (and testdb.NewTenant's cleanup) takes their rows with it.


-- ----------------------------------------------------------------------------
-- asset_classes, assets and asset_endpoints are defined ABOVE, in the pg_dump
-- body, where network_assets_partitioned used to sit
-- ----------------------------------------------------------------------------
-- They moved there in phase 1 (workstream 1.1) for one concrete reason: the
-- operational views in the body — mv_location_finding_summary,
-- mv_remediation_queue and v_ci_inventory — now read them, and a view cannot
-- reference a table this file has not created yet. Their policies, triggers and
-- the rest of the inventory tables stay here.

-- ----------------------------------------------------------------------------
-- Foreign keys for the three tables defined in the pg_dump body above
-- ----------------------------------------------------------------------------
-- They live here and not next to their CREATE TABLE because every PRIMARY KEY
-- in this file is added in the CONSTRAINT section further down the body: at the
-- point those tables are created, `tenants(id)` is not yet a unique key and the
-- FK is refused with "there is no unique constraint matching given keys".
DO $$ BEGIN
  IF to_regclass('public.asset_classes') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_classes_tenant_id_fkey' AND conrelid = to_regclass('public.asset_classes')
     ) THEN
    ALTER TABLE ONLY public.asset_classes
        ADD CONSTRAINT asset_classes_tenant_id_fkey FOREIGN KEY (tenant_id)
        REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'assets_tenant_id_fkey' AND conrelid = to_regclass('public.assets')
     ) THEN
    ALTER TABLE public.assets
        ADD CONSTRAINT assets_tenant_id_fkey FOREIGN KEY (tenant_id)
        REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.asset_endpoints') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_endpoints_tenant_asset_fkey' AND conrelid = to_regclass('public.asset_endpoints')
     ) THEN
    ALTER TABLE public.asset_endpoints
        ADD CONSTRAINT asset_endpoints_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- asset_identifiers — every identifier ever observed for an asset
-- ----------------------------------------------------------------------------
-- DATA_MODEL §2, ADR-0002 D3. The identification engine (workstream 0.4) reads
-- this table; the unique index below is the whole mechanism.
--
-- UNIQUE (tenant_id, kind, value, coalesce(scope,'')) is ACROSS ASSETS, not per
-- asset: an identifier value maps to at most one asset. A conflict on insert is
-- not an error to swallow — it is the signal that produces a merge proposal in
-- Approvals (ADR-0002 D3, outcome three). Never auto-merge on conflict.
--
-- `kind` is validated against the registry in Go (shared/assetclass's
-- identifier kinds), not by a CHECK: the class registry owns the vocabulary and
-- the per-class precedence order, and duplicating the list here is a second
-- source of truth that can drift. The column is deliberately plain text.
CREATE TABLE IF NOT EXISTS public.asset_identifiers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    kind text NOT NULL,
    value text NOT NULL,
    scope text,
    source_kind text DEFAULT 'measured'::text NOT NULL,
    source_ref text,
    confidence numeric(3,2) DEFAULT 1.00 NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT asset_identifiers_pkey PRIMARY KEY (id),
    CONSTRAINT asset_identifiers_source_kind_check CHECK (source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text])),
    CONSTRAINT asset_identifiers_confidence_range_check CHECK (confidence >= 0 AND confidence <= 1)
);

CREATE UNIQUE INDEX IF NOT EXISTS asset_identifiers_value_uniq
    ON public.asset_identifiers (tenant_id, kind, value, coalesce(scope, ''));
CREATE INDEX IF NOT EXISTS idx_asset_identifiers_tenant_asset
    ON public.asset_identifiers USING btree (tenant_id, asset_id);

DO $$ BEGIN
  IF to_regclass('public.asset_identifiers') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_identifiers_tenant_asset_fkey' AND conrelid = to_regclass('public.asset_identifiers')
     ) THEN
    ALTER TABLE ONLY public.asset_identifiers
        ADD CONSTRAINT asset_identifiers_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- asset_management / asset_credentials — the two halves of `devices`
-- ----------------------------------------------------------------------------
-- DATA_MODEL §2, ADR-0002 D5. A device is an asset of a hardware or cloud class
-- with a management address and, optionally, credentials. `devices` is removed
-- in phase 1 (workstream 1.6); these two tables are its replacement and stay
-- empty until then. The Devices page becomes "assets with management
-- configured", i.e. a filter on asset_management.
--
-- One row per asset: PRIMARY KEY (tenant_id, asset_id). tenant_id is present
-- (DATA_MODEL lists asset_id alone as the key) because the composite FK into
-- the partitioned assets table needs it and because it lets RLS be the plain
-- tenant_id policy rather than an EXISTS over the parent.
CREATE TABLE IF NOT EXISTS public.asset_management (
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    management_url text,
    management_protocol text,
    tls_insecure_skip_verify boolean DEFAULT false NOT NULL,
    connection_status text DEFAULT 'unknown'::text NOT NULL,
    last_interrogated_at timestamp with time zone,
    interrogation_error text,
    interrogation_schedule_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT asset_management_pkey PRIMARY KEY (tenant_id, asset_id),
    CONSTRAINT asset_management_connection_status_check CHECK (connection_status = ANY (ARRAY['connected'::text, 'disconnected'::text, 'error'::text, 'unknown'::text]))
);

CREATE INDEX IF NOT EXISTS idx_asset_management_tenant_status
    ON public.asset_management USING btree (tenant_id, connection_status);

DO $$ BEGIN
  IF to_regclass('public.asset_management') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_management_tenant_asset_fkey' AND conrelid = to_regclass('public.asset_management')
     ) THEN
    ALTER TABLE ONLY public.asset_management
        ADD CONSTRAINT asset_management_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;

-- password_enc holds CIPHERTEXT, always. The name is the contract, and it is
-- the reason the column is not called `password` the way devices.password is:
-- `devices` stored the interrogation password as the caller handed it over.
-- Writers MUST go through shared/security/credentials (the shared encryption
-- helper); scripts/audit-credential-encryption.mjs enforces that on the Go side
-- by requiring any file writing a credential-shaped column to import the
-- helper. It reads Go, not SQL, so this comment is the only thing standing
-- here — there is no writer yet, and workstream 1.6 is where the rule bites.
--
-- credential_id is a loose uuid, not an FK: it points into the tenant's
-- credential store the same way devices.credential_id does, and that store has
-- no table in this schema to reference.
CREATE TABLE IF NOT EXISTS public.asset_credentials (
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    credential_id uuid,
    username text,
    password_enc text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT asset_credentials_pkey PRIMARY KEY (tenant_id, asset_id)
);

CREATE INDEX IF NOT EXISTS idx_asset_credentials_credential_id
    ON public.asset_credentials USING btree (credential_id) WHERE credential_id IS NOT NULL;

DO $$ BEGIN
  IF to_regclass('public.asset_credentials') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_credentials_tenant_asset_fkey' AND conrelid = to_regclass('public.asset_credentials')
     ) THEN
    ALTER TABLE ONLY public.asset_credentials
        ADD CONSTRAINT asset_credentials_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- 3. asset_relationships — one typed, directional edge table (DATA_MODEL §3)
-- ----------------------------------------------------------------------------
-- ADR-0003 D1/D2. Stored once in canonical direction; the reverse label is
-- derived from the vocabulary and never stored. The same pair may carry several
-- types, hence the unique on (tenant_id, from, to, type) rather than on the
-- pair.
--
-- `type` is one of the ten vocabulary keys (runs_on, hosted_on, virtualized_by,
-- depends_on, connects_to, member_of, contains, manages, sends_data_to,
-- impacts) and is registry-validated in Go, not by a CHECK — the vocabulary is
-- owned by the relationship registry, and a CHECK here would be a second copy.
--
-- Both direction indexes exist because impact traversal (ADR-0003 D5) is a
-- depth-capped recursive CTE that walks edges backwards as well as forwards.
CREATE TABLE IF NOT EXISTS public.asset_relationships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    from_asset_id uuid NOT NULL,
    to_asset_id uuid NOT NULL,
    type text NOT NULL,
    source_kind text DEFAULT 'measured'::text NOT NULL,
    source_ref text,
    confidence numeric(3,2) DEFAULT 1.00 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    observation_count integer DEFAULT 1 NOT NULL,
    created_by uuid,
    approved_by uuid,
    approved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT asset_relationships_pkey PRIMARY KEY (id),
    CONSTRAINT asset_relationships_source_kind_check CHECK (source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text])),
    CONSTRAINT asset_relationships_status_check CHECK (status = ANY (ARRAY['pending'::text, 'active'::text, 'rejected'::text, 'stale'::text])),
    CONSTRAINT asset_relationships_confidence_range_check CHECK (confidence >= 0 AND confidence <= 1),
    -- A self-edge is never meaningful in this vocabulary and is always an
    -- identity bug upstream (the same host matched twice under two identifiers).
    CONSTRAINT asset_relationships_no_self_edge_check CHECK (from_asset_id <> to_asset_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS asset_relationships_edge_uniq
    ON public.asset_relationships (tenant_id, from_asset_id, to_asset_id, type);
CREATE INDEX IF NOT EXISTS idx_asset_relationships_tenant_from
    ON public.asset_relationships USING btree (tenant_id, from_asset_id);
CREATE INDEX IF NOT EXISTS idx_asset_relationships_tenant_to
    ON public.asset_relationships USING btree (tenant_id, to_asset_id);
CREATE INDEX IF NOT EXISTS idx_asset_relationships_tenant_status
    ON public.asset_relationships USING btree (tenant_id, status);

DO $$ BEGIN
  IF to_regclass('public.asset_relationships') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_relationships_tenant_from_fkey' AND conrelid = to_regclass('public.asset_relationships')
     ) THEN
    ALTER TABLE ONLY public.asset_relationships
        ADD CONSTRAINT asset_relationships_tenant_from_fkey FOREIGN KEY (tenant_id, from_asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.asset_relationships') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_relationships_tenant_to_fkey' AND conrelid = to_regclass('public.asset_relationships')
     ) THEN
    ALTER TABLE ONLY public.asset_relationships
        ADD CONSTRAINT asset_relationships_tenant_to_fkey FOREIGN KEY (tenant_id, to_asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- 4. asset_facts — the extensible key/value fact store (DATA_MODEL §4)
-- ----------------------------------------------------------------------------
-- ADR-0005 D2. A fact is a statement with provenance, not a judgement. Keys are
-- namespaced (`os.name`, `hw.serial`, `eol.os.date`) and registered in
-- standards/fact-keys.yaml; there are no free-form keys, and validation happens
-- in Go against the generated registry rather than a CHECK here.
--
-- UNIQUE (tenant_id, asset_id, key, source_ref) — PER SOURCE, deliberately: two
-- sources may hold DIFFERENT values for the same key, and the reconciliation
-- precedence (ADR-0002 D4) chooses the displayed one. Collapsing this to
-- (tenant, asset, key) would make the last writer win and destroy the
-- disagreement the precedence rule exists to resolve.
--
-- source_ref is NOT NULL and defaults to '' rather than being nullable: it is
-- part of the unique key, and a nullable component would let two rows from
-- "unknown source" coexist for the same key.
CREATE TABLE IF NOT EXISTS public.asset_facts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    source_kind text DEFAULT 'measured'::text NOT NULL,
    source_ref text DEFAULT ''::text NOT NULL,
    confidence numeric(3,2),
    model_id text,
    observed_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT asset_facts_pkey PRIMARY KEY (id),
    CONSTRAINT asset_facts_source_kind_check CHECK (source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text])),
    CONSTRAINT asset_facts_confidence_range_check CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 1)),
    -- ADR-0005 D2: an inferred fact must say what inferred it and how sure it is.
    CONSTRAINT asset_facts_inferred_needs_provenance_check CHECK (source_kind <> 'inferred'::text OR (confidence IS NOT NULL AND model_id IS NOT NULL))
);

CREATE UNIQUE INDEX IF NOT EXISTS asset_facts_key_source_uniq
    ON public.asset_facts (tenant_id, asset_id, key, source_ref);
CREATE INDEX IF NOT EXISTS idx_asset_facts_tenant_key
    ON public.asset_facts USING btree (tenant_id, key);
CREATE INDEX IF NOT EXISTS idx_asset_facts_expires_at
    ON public.asset_facts USING btree (expires_at) WHERE expires_at IS NOT NULL;

DO $$ BEGIN
  IF to_regclass('public.asset_facts') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_facts_tenant_asset_fkey' AND conrelid = to_regclass('public.asset_facts')
     ) THEN
    ALTER TABLE ONLY public.asset_facts
        ADD CONSTRAINT asset_facts_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- asset_class_history — every class an asset has held, and who decided
-- ----------------------------------------------------------------------------
-- A reclassification used to leave no trace a consumer could read. The class
-- lives in one mutable column on `assets`, so once a printer became a
-- multifunction device the fact that it was ever a printer was gone: the
-- producers that key their findings on class could not tell "this asset was
-- always a printer" from "somebody changed its class this morning and every
-- finding I wrote yesterday was about a different thing", and a reviewer
-- looking at a surprising class had nothing to read but the current value.
--
-- `asset_history` is not that record. It carries a `created` row whose
-- `changes_json` happens to mention `class_key`, and nothing at all for the two
-- paths that CHANGE one — the proposal acceptance and the manual edit both
-- wrote the column and moved on. Reconstructing a class timeline from it would
-- mean parsing a free-shaped jsonb blob per action kind, which is exactly the
-- "derive it later" that never survives the next writer.
--
-- So: one row per TRANSITION, with both ends of it named.
--
--   * `from_class_key` is NULL only on the row a CREATE writes. Every other row
--     has both ends, so a reader never has to look at the previous row to know
--     what changed — a self-contained row survives a page boundary and a
--     filtered query, and the one that does not is how "the class before this
--     one" becomes "the class before this one THAT I HAPPENED TO SELECT".
--   * `source` is the mechanism, not the actor: `classifier` (the asset was
--     created with a class the rules argued, or an intake path stated one),
--     `proposal` (a reviewer accepted a class proposal in Approvals), `manual`
--     (someone edited the asset), `import` (a connector or spreadsheet stated
--     it). It is a closed set because a consumer branches on it.
--   * `actor_user_id` is the person when there was one, NULL when a machine
--     did it. NULL means "no person", never "person unknown" — every path that
--     has a session passes it, and the ones that do not are machine paths.
--   * `evidence` is the argument, copied at the moment of the change: the rule
--     ids, the model id and probability, the proposal id. Posture only — it is
--     built from the class proposal's own recorded fields, which carry no
--     hostname, no address and no credential by construction.
--
-- Append-only by convention and by grant shape (no UPDATE path exists in Go).
-- No unique key beyond the surrogate: the same asset can legitimately move
-- A → B → A, and a unique (asset, from, to) would swallow the second move.
CREATE TABLE IF NOT EXISTS public.asset_class_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    from_class_key text,
    to_class_key text NOT NULL,
    source text NOT NULL,
    actor_user_id uuid,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT asset_class_history_pkey PRIMARY KEY (id),
    CONSTRAINT asset_class_history_source_check CHECK (source = ANY (ARRAY['proposal'::text, 'manual'::text, 'import'::text, 'classifier'::text])),
    -- A "change" from a class to itself is not a change. Writing one would put
    -- noise in the one table whose whole value is that every row means
    -- something moved.
    CONSTRAINT asset_class_history_moves_check CHECK (from_class_key IS DISTINCT FROM to_class_key),
    CONSTRAINT asset_class_history_to_class_nonempty_check CHECK (to_class_key <> ''::text)
);

-- The asset timeline read: newest first, for one asset.
CREATE INDEX IF NOT EXISTS idx_asset_class_history_asset
    ON public.asset_class_history USING btree (tenant_id, asset_id, created_at DESC);
-- The producer read that motivated the table: "what was reclassified since X".
CREATE INDEX IF NOT EXISTS idx_asset_class_history_tenant_time
    ON public.asset_class_history USING btree (tenant_id, created_at DESC);

DO $$ BEGIN
  IF to_regclass('public.asset_class_history') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_class_history_tenant_asset_fkey'
         AND conrelid = to_regclass('public.asset_class_history')
     ) THEN
    ALTER TABLE ONLY public.asset_class_history
        ADD CONSTRAINT asset_class_history_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- software_products / software_installs — the software inventory (DATA_MODEL §4)
-- ----------------------------------------------------------------------------
-- software_products is a per-tenant catalogue deduped by identity; installs
-- link a product to an asset. SBOM ingestion (workstream 2.6) and the
-- vulnerability producer (3.4) are the consumers.
--
-- version_sort is a normalised component-wise sort key computed ON WRITE
-- (QUERY_LANGUAGE §5.5), NULL when the version does not parse — so a version
-- comparison against an unparseable version evaluates UNKNOWN rather than
-- silently ordering it as a string. Do not backfill it with the raw version.
--
-- The unique expression differs from DATA_MODEL's literal
-- `coalesce(purl, cpe, name||'@'||version)`: `name||'@'||version` is NULL
-- whenever version is NULL, which would make the whole coalesce NULL and let
-- unlimited duplicate rows coexist (NULLs do not conflict). The inner coalesce
-- on version closes that.
CREATE TABLE IF NOT EXISTS public.software_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    vendor text,
    version text,
    version_sort text,
    cpe text,
    purl text,
    license_id text,
    source_kind text DEFAULT 'measured'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT software_products_pkey PRIMARY KEY (id),
    CONSTRAINT software_products_source_kind_check CHECK (source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text]))
);

CREATE UNIQUE INDEX IF NOT EXISTS software_products_identity_uniq
    ON public.software_products (tenant_id, coalesce(purl, cpe, name || '@' || coalesce(version, '')));
CREATE INDEX IF NOT EXISTS idx_software_products_tenant_name
    ON public.software_products USING btree (tenant_id, lower(name));
CREATE INDEX IF NOT EXISTS idx_software_products_cpe
    ON public.software_products USING btree (cpe) WHERE cpe IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_software_products_purl
    ON public.software_products USING btree (purl) WHERE purl IS NOT NULL;

DO $$ BEGIN
  IF to_regclass('public.software_products') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'software_products_tenant_id_fkey' AND conrelid = to_regclass('public.software_products')
     ) THEN
    ALTER TABLE ONLY public.software_products
        ADD CONSTRAINT software_products_tenant_id_fkey FOREIGN KEY (tenant_id)
        REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.software_installs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    product_id uuid NOT NULL,
    install_path text,
    source_kind text DEFAULT 'measured'::text NOT NULL,
    source_ref text,
    status text DEFAULT 'active'::text NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT software_installs_pkey PRIMARY KEY (id),
    CONSTRAINT software_installs_source_kind_check CHECK (source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text])),
    CONSTRAINT software_installs_status_check CHECK (status = ANY (ARRAY['active'::text, 'stale'::text, 'removed'::text]))
);

-- One row per (asset, product, path). The coalesce is the same NULL-collision
-- point the endpoints key makes: most installs report no path, and without it
-- every re-observation would append.
CREATE UNIQUE INDEX IF NOT EXISTS software_installs_identity_uniq
    ON public.software_installs (tenant_id, asset_id, product_id, coalesce(install_path, ''));
CREATE INDEX IF NOT EXISTS idx_software_installs_tenant_product
    ON public.software_installs USING btree (tenant_id, product_id);

DO $$ BEGIN
  IF to_regclass('public.software_installs') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'software_installs_tenant_asset_fkey' AND conrelid = to_regclass('public.software_installs')
     ) THEN
    ALTER TABLE ONLY public.software_installs
        ADD CONSTRAINT software_installs_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;

-- The product FK carries tenant_id, like every other FK in this block. A bare
-- product_id FK is satisfied by ANOTHER tenant's product row, and two things
-- follow from that: the install joins to a product RLS then hides, so it
-- renders with no product and no error; and ON DELETE CASCADE lets the other
-- tenant's deletion take this tenant's install row with it. The composite form
-- makes the mismatch unrepresentable rather than merely unlikely.
--
-- It needs a unique key on (tenant_id, id) to reference — the PK is (id) alone,
-- and an FK must point at a unique constraint or index.
CREATE UNIQUE INDEX IF NOT EXISTS software_products_tenant_id_uniq
    ON public.software_products (tenant_id, id);

-- The single-column form shipped first on this branch; drop it before adding
-- the composite so a database that applied the earlier revision converges
-- rather than keeping both.
DO $$ BEGIN
  IF to_regclass('public.software_installs') IS NOT NULL THEN
    ALTER TABLE public.software_installs
        DROP CONSTRAINT IF EXISTS software_installs_product_id_fkey;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.software_installs') IS NOT NULL
     AND to_regclass('public.software_products') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'software_installs_tenant_product_fkey' AND conrelid = to_regclass('public.software_installs')
     ) THEN
    ALTER TABLE ONLY public.software_installs
        ADD CONSTRAINT software_installs_tenant_product_fkey FOREIGN KEY (tenant_id, product_id)
        REFERENCES public.software_products(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- findings — one table, every producer (DATA_MODEL §4, ADR-0005 D3)
-- ----------------------------------------------------------------------------
-- THE findings table. Workstream 3.1 moved the compliance producer onto it and
-- DROPPED compliance_findings outright (POST-MIGRATIONS, below) — no view, no
-- backfill, no dual-write, per ADR-0007's no-migration decision.
--
-- The workflow columns (assigned_to/at/by, remediation_notes, resurfaced_at,
-- is_stale) came over from compliance_findings rather than being dropped with
-- it. None of them is compliance-shaped: any producer's finding can be assigned
-- to a person, annotated, go quiet and come back. They are the finding
-- LIFECYCLE, which is the half of compliance_findings that generalised.
--
-- `producer` and `kind` come from standards/findings-registry.yaml and are
-- validated against the generated Go registry, exactly the way alert types are
-- — NOT by a CHECK constraint. `subject_type` uses the registry's subject
-- vocabulary (asset, endpoint, certificate, key, crypto_configuration,
-- software_install, relationship, control, framework) and is likewise
-- registry-validated: ADR-0005 D3 says "No CHECK", because
-- compliance_findings.asset_type's three-value CHECK is named there as the
-- single hardest chokepoint for any non-crypto finding.
--
-- control_id is NULLABLE and is present only for producer = 'compliance'. The
-- CHECK below states exactly that, which is the part a CHECK can carry without
-- freezing the producer vocabulary.
--
-- severity is the registry's lowercase ladder, not compliance_findings'
-- capitalised Low/Med/High/Critical. `info` is included for the Informational
-- band models.RiskBands reports at score 0.
--
-- The partial unique index is on OPEN findings — everything not ARCHIVED, which
-- is the same predicate compliance_findings' idx_findings_identity used, and
-- deliberately NOT `detection_state = 'ACTIVE'`. The distinction is the
-- INACTIVE state: a condition that stopped being detected keeps its row, and
-- the reconciler flips that row back to ACTIVE when the condition returns.
-- Keying on ACTIVE alone would leave the INACTIVE row unmatched, so every
-- resurfacing would INSERT a second row for the same subject and
-- occurrence_count / first_seen — the very columns that exist to carry a
-- finding's history — would each describe only one episode of it. ARCHIVED is
-- the soft-delete state and is excluded so a genuinely retired row never
-- blocks a fresh one.
CREATE TABLE IF NOT EXISTS public.findings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    producer text NOT NULL,
    kind text NOT NULL,
    subject_type text NOT NULL,
    subject_id uuid NOT NULL,
    subject_label text,
    control_id uuid,
    severity text NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    summary text NOT NULL,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_kind text DEFAULT 'measured'::text NOT NULL,
    detection_state text DEFAULT 'ACTIVE'::text NOT NULL,
    workflow_status text DEFAULT 'NEW'::text NOT NULL,
    assigned_to uuid,
    assigned_at timestamp with time zone,
    assigned_by uuid,
    remediation_notes text,
    occurrence_count integer DEFAULT 1 NOT NULL,
    first_seen timestamp with time zone DEFAULT now() NOT NULL,
    last_seen timestamp with time zone DEFAULT now() NOT NULL,
    resurfaced_at timestamp with time zone,
    suppressed_until timestamp with time zone,
    suppression_reason text,
    is_stale boolean DEFAULT false NOT NULL,
    last_evaluated_at timestamp with time zone,
    evaluation_version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT findings_pkey PRIMARY KEY (id),
    CONSTRAINT findings_severity_check CHECK (severity = ANY (ARRAY['info'::text, 'low'::text, 'medium'::text, 'high'::text, 'critical'::text])),
    CONSTRAINT findings_detection_state_check CHECK (detection_state = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text, 'ARCHIVED'::text])),
    CONSTRAINT findings_workflow_status_check CHECK (workflow_status = ANY (ARRAY['NEW'::text, 'NOTIFIED'::text, 'RESOLVED'::text, 'SUPPRESSED'::text])),
    CONSTRAINT findings_source_kind_check CHECK (source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text])),
    CONSTRAINT findings_score_range_check CHECK (score >= 0 AND score <= 100),
    CONSTRAINT findings_control_id_compliance_only_check CHECK (control_id IS NULL OR producer = 'compliance'::text)
);

-- The workflow columns, for a database that already has this table.
--
-- `CREATE TABLE IF NOT EXISTS` above is a NO-OP on such a database, so a column
-- added to the literal above never reaches it — the columns arrive only on a
-- fresh install, and the first query naming one fails at runtime with "column
-- does not exist". That is not hypothetical here: `findings` shipped in Gate 1,
-- so every database created between then and workstream 3.1 has the table
-- WITHOUT these five. Same treatment tenant_framework_scores gets a few hundred
-- lines up, and for the same reason.
ALTER TABLE public.findings ADD COLUMN IF NOT EXISTS assigned_at timestamp with time zone;
ALTER TABLE public.findings ADD COLUMN IF NOT EXISTS assigned_by uuid;
ALTER TABLE public.findings ADD COLUMN IF NOT EXISTS remediation_notes text;
ALTER TABLE public.findings ADD COLUMN IF NOT EXISTS resurfaced_at timestamp with time zone;
ALTER TABLE public.findings ADD COLUMN IF NOT EXISTS is_stale boolean DEFAULT false NOT NULL;

-- `control_id` is part of the identity, with NULLS NOT DISTINCT (PG15+).
--
-- Without it the compliance producer cannot write: its finding is one per
-- (control, subject) pair — two controls failing on the same server are two
-- separate things to triage, assign and ticket — so keying on the subject alone
-- would make the second control's finding collide with the first's and
-- overwrite it. Every other producer leaves control_id NULL (the CHECK above
-- makes that a rule, not a habit), and NULLS NOT DISTINCT is what keeps their
-- identity exactly what it was: Postgres treats NULLs as DISTINCT by default,
-- so the plain form would have let one asset accumulate unlimited duplicate
-- `eol/os_end_of_life` rows — the dedup this index exists for, silently off for
-- six of the seven producers.
CREATE UNIQUE INDEX IF NOT EXISTS findings_open_subject_uniq
    ON public.findings (tenant_id, producer, kind, subject_type, subject_id, control_id)
    NULLS NOT DISTINCT
    WHERE detection_state <> 'ARCHIVED'::text;
CREATE INDEX IF NOT EXISTS idx_findings_tenant_subject
    ON public.findings USING btree (tenant_id, subject_type, subject_id);
CREATE INDEX IF NOT EXISTS idx_findings_tenant_producer_severity
    ON public.findings USING btree (tenant_id, producer, severity);
CREATE INDEX IF NOT EXISTS idx_findings_tenant_workflow_status
    ON public.findings USING btree (tenant_id, workflow_status) WHERE detection_state = 'ACTIVE'::text;
-- The readers compliance_findings' own indexes served, renamed onto this table.
-- Deliberately NOT reusing the old names (idx_findings_detection_state,
-- idx_findings_resurfaced, …): an index name is database-global, so reusing one
-- would collide on any database that still had the old table when this file ran.
CREATE INDEX IF NOT EXISTS idx_findings_tenant_detection_state
    ON public.findings USING btree (tenant_id, detection_state, last_seen);
CREATE INDEX IF NOT EXISTS idx_findings_tenant_resurfaced
    ON public.findings USING btree (tenant_id, resurfaced_at) WHERE resurfaced_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_findings_tenant_assigned_to
    ON public.findings USING btree (tenant_id, assigned_to) WHERE assigned_to IS NOT NULL;
-- The compliance rollup path: score a framework by walking its controls'
-- findings. compliance_findings served this with idx_findings_active_rollup;
-- without an equivalent here the rollup would have moved onto a sequential scan
-- the moment 3.1 landed. Partial on the producer that is the only one with a
-- control_id (the CHECK above guarantees the rest are NULL) and on the rows a
-- rollup counts.
CREATE INDEX IF NOT EXISTS idx_findings_tenant_control
    ON public.findings USING btree (tenant_id, control_id)
    WHERE producer = 'compliance'::text AND detection_state <> 'ARCHIVED'::text;

-- Free-text search on the Findings page (`GET /findings?q=`) has NO index, and
-- that is a measured decision rather than an omission.
--
-- There were two trigram GIN indexes here (idx_findings_summary_trgm,
-- idx_findings_subject_label_trgm), dropped in POST-MIGRATIONS below. The
-- predicate the page builds (findings_service.go, searchClause) is ONE OR over
-- four arms: `summary ILIKE`, `subject_label ILIKE`,
-- `replace(kind, '_', ' ') ILIKE`, and an `EXISTS` over `assets` that searches
-- the HOST. Postgres can only turn an OR into a BitmapOr when EVERY arm is
-- index-eligible; a correlated EXISTS never is, so the whole disjunction falls
-- through to a filter and the two GIN indexes were never consulted.
--
-- Measured on a 50,000-finding tenant: the plan is
-- `Index Scan using idx_findings_tenant_workflow_status` + `Filter: (summary
-- ~~* … OR subject_label ~~* … OR replace(kind …) ~~* … OR EXISTS(SubPlan))`,
-- byte-identical with the indexes present and dropped. Adding a third trigram
-- index on `replace(kind, '_', ' ')` did not change it either — the planner
-- still preferred the tenant btree. In isolation the index IS usable
-- (`SELECT … WHERE summary ILIKE '%host-42%'` alone gives a Bitmap Index Scan,
-- 3.7 ms vs 55 ms), so the reason is the query SHAPE, not a broken index.
--
-- They were not free: 11 MB + 7 MB on that tenant, maintained on every producer
-- upsert — and a producer pass upserts the whole population. A GIN index that
-- costs write amplification on the hottest write path in the system and serves
-- no read is worse than none, because it also reads as "search is indexed".
--
-- If search becomes slow enough to matter, the fix is the query, not an index:
-- lift the host arm out into a UNION of id sets so the trigram arms form an
-- OR the planner can BitmapOr. That is a change to a WHERE builder three
-- queries share (page, count and facets, which must describe the same set), so
-- it is deliberately not bundled with the index removal.

DO $$ BEGIN
  IF to_regclass('public.findings') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'findings_tenant_id_fkey' AND conrelid = to_regclass('public.findings')
     ) THEN
    ALTER TABLE ONLY public.findings
        ADD CONSTRAINT findings_tenant_id_fkey FOREIGN KEY (tenant_id)
        REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.findings') IS NOT NULL
     AND to_regclass('public.users') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'findings_assigned_to_fkey' AND conrelid = to_regclass('public.findings')
     ) THEN
    ALTER TABLE ONLY public.findings
        ADD CONSTRAINT findings_assigned_to_fkey FOREIGN KEY (assigned_to)
        REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.findings') IS NOT NULL
     AND to_regclass('public.users') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'findings_assigned_by_fkey' AND conrelid = to_regclass('public.findings')
     ) THEN
    ALTER TABLE ONLY public.findings
        ADD CONSTRAINT findings_assigned_by_fkey FOREIGN KEY (assigned_by)
        REFERENCES public.users(id) ON DELETE SET NULL;
  END IF;
END $$;

-- The three finding_id foreign keys that used to point at compliance_findings
-- (compliance_finding_history, remediation_plan_items, tickets) are re-pointed
-- at this table in POST-MIGRATIONS, not here. Two reasons, and both are the
-- reason the phase-1 re-parenting sits there too: `findings` is created near the
-- end of this file, so a guarded ADD placed beside the referencing table would
-- run while `findings` did not exist yet and silently do nothing; and the guard
-- is by constraint NAME, so on a lab database still carrying the old table it
-- would find the name taken by the constraint pointing at compliance_findings,
-- skip, and then be destroyed by that table's CASCADE drop — leaving no foreign
-- key at all.


-- ----------------------------------------------------------------------------
-- producer_assessments — which producer has LOOKED at which asset
-- ----------------------------------------------------------------------------
-- DATA_MODEL §3.1, ADR-0005 D4. `assets.risk_assessed_by` is the answer a
-- reader needs ("has anybody evaluated this?"); this table is the RECORD the
-- answer is computed from, one row per (asset, producer) with the instant of
-- the last completed pass.
--
-- Two tables rather than one array, for two reasons neither of which is
-- tidiness:
--
--  1. ONE writer of `assets`. Six producers appending to an array on `assets`
--     would be six writers racing on the same row, each doing a
--     read-modify-write of a text[]; the risk rollup recomputing the score is a
--     seventh. With the record here, the rollup is the only statement that
--     touches `assets`, and it derives the array set-based from these rows.
--  2. A pass that FAILED must mark nothing. These rows are written inside the
--     producer's own write transaction — the same one that carries its upserts
--     and its sweep — so a run that dies half way rolls back its coverage claim
--     along with its findings. An array written afterwards, outside that
--     transaction, could survive a rollback and claim an assessment that never
--     happened.
--
-- `assessed_at` is not read by the rollup; it is here because "when did the
-- vulnerability producer last look at this host" is the question a support case
-- opens with, and an array cannot answer it.
--
-- Coverage is NOT the same question as risk, and the two sets differ. THIS
-- table holds every producer, `hygiene` included; `assets.risk_assessed_by` is
-- its RISK-FEEDING subset, derived by the rollup from the registry's
-- feeds_risk flags. The array means "the RISK score here is a real answer", so
-- an asset only the hygiene producer has visited must still read NOT ASSESSED
-- for risk. Anything that needs the full record reads this table directly —
-- which is what compliance-engine's `finding` measurement shape does
-- (`EXISTS (SELECT 1 FROM producer_assessments pa WHERE … pa.producer = $3)`),
-- so a hygiene control reads "not assessed" rather than "clean" for an asset
-- the hygiene producer has never visited.
--
-- Retention: the FK below is ON DELETE CASCADE, so a hard-deleted asset takes
-- its coverage with it. A SOFT-deleted or archived asset keeps its rows on
-- purpose — the record is "did this producer look", which stays true, and an
-- asset restored from archive must not come back reading NOT ASSESSED. The
-- rollup's own scope excludes soft-deleted assets, so those rows feed nothing;
-- they are reaped with the asset, by the same phase-3 reaper that owns
-- findings on deleted assets (DATA_MODEL §3.1).
CREATE TABLE IF NOT EXISTS public.producer_assessments (
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    producer text NOT NULL,
    assessed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT producer_assessments_pkey PRIMARY KEY (tenant_id, asset_id, producer)
);

-- The rollup's own access path: every asset in a tenant, with its producers.
-- The primary key already leads with (tenant_id, asset_id), so the rollup's
-- join is covered; this one serves "which assets has producer X assessed",
-- which is how a stale-coverage report and the admin producer status page read
-- it.
CREATE INDEX IF NOT EXISTS idx_producer_assessments_tenant_producer
    ON public.producer_assessments USING btree (tenant_id, producer, assessed_at DESC);

DO $$ BEGIN
  IF to_regclass('public.producer_assessments') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'producer_assessments_asset_fkey'
         AND conrelid = to_regclass('public.producer_assessments')
     ) THEN
    ALTER TABLE ONLY public.producer_assessments
        ADD CONSTRAINT producer_assessments_asset_fkey
        FOREIGN KEY (tenant_id, asset_id) REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- software_install_lifecycle — what the eol producer resolved, per install
-- ----------------------------------------------------------------------------
-- The lifecycle analogue of `producer_assessments`, one level down. That table
-- says the `eol` producer LOOKED at an asset; this one says what the lookup
-- CONCLUDED for each of the asset's software installs. Without it the absence
-- of a `software_end_of_life` finding collapsed four different situations —
-- the catalogue has no entry for the product, its entry publishes no date, the
-- date is further out than the warning window, and the install is not active
-- so the producer skipped it — and the Software surfaces could only say "not
-- assessed" for all of them, giving a supported package no credit and making
-- it indistinguishable from one the catalogue has never heard of.
--
-- `assessment` is the producer's own conclusion, RECORDED rather than
-- re-derived: `supported` (a catalogue row with a date beyond the warning
-- window), `end_of_life` (a row whose date is inside the window or past — the
-- finding is written in the same transaction), `no_date` (a row that publishes
-- no date; endoflife.date mirrors both "support ended, date unknown" and "not
-- announced" as NULL) and `not_in_catalogue` (a recorded miss). A list query
-- reads these words. It never re-runs the resolution, which would be a second
-- opinion about what the catalogue says — the shape this codebase keeps paying
-- for.
--
-- The shape CHECK is the vocabulary made structural: a `supported` row with no
-- date, or a `not_in_catalogue` row citing a catalogue id, cannot be written.
-- `catalogue_id` is a citation, not a foreign key — the finding's evidence
-- carries the same id the same way, and the platform catalogue is rewritten by
-- the mirror job, whose deletes must not be blocked by tenant rows.
--
-- Written by the producer from INSIDE its write transaction, beside its
-- findings, facts, coverage claim and sweep, so a failed pass records nothing
-- and a completed one records a full statement: rows for installs the pass did
-- not assess (removed, stale, or gone) are deleted in the same transaction. No
-- row therefore means exactly "no completed pass has assessed this install
-- since it was last active", which the Software surfaces render as
-- `not_assessed`. A non-active install needs no row of its own: the producer's
-- skip rule is reproducible from `software_installs.status`, the same way the
-- vulnerability axis reads the product's purl and CPE.
--
-- Keyed by the INSTALL. The `eol.sw.date` fact is keyed by asset and source
-- row, and cannot be mapped back to one install without re-resolving. The FK is
-- composite for the reason every FK in the software block is: a bare
-- install_id is satisfied by another tenant's row. ON DELETE CASCADE, so a
-- merge that deletes a duplicate install takes its record with it, and the
-- surviving install's record rides along with the row it is keyed on.
CREATE TABLE IF NOT EXISTS public.software_install_lifecycle (
    tenant_id uuid NOT NULL,
    install_id uuid NOT NULL,
    assessment text NOT NULL,
    catalogue_id uuid,
    eol_date date,
    assessed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT software_install_lifecycle_pkey PRIMARY KEY (tenant_id, install_id),
    CONSTRAINT software_install_lifecycle_assessment_check CHECK (assessment = ANY (ARRAY['supported'::text, 'end_of_life'::text, 'no_date'::text, 'not_in_catalogue'::text])),
    CONSTRAINT software_install_lifecycle_shape_check CHECK (
        (assessment = ANY (ARRAY['supported'::text, 'end_of_life'::text]) AND catalogue_id IS NOT NULL AND eol_date IS NOT NULL)
     OR (assessment = 'no_date'::text AND catalogue_id IS NOT NULL AND eol_date IS NULL)
     OR (assessment = 'not_in_catalogue'::text AND catalogue_id IS NULL AND eol_date IS NULL))
);

-- The composite FK below needs a unique key on (tenant_id, id) to reference;
-- software_installs' primary key is (id) alone.
CREATE UNIQUE INDEX IF NOT EXISTS software_installs_tenant_id_uniq
    ON public.software_installs (tenant_id, id);

DO $$ BEGIN
  IF to_regclass('public.software_install_lifecycle') IS NOT NULL
     AND to_regclass('public.software_installs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'software_install_lifecycle_install_fkey'
         AND conrelid = to_regclass('public.software_install_lifecycle')
     ) THEN
    ALTER TABLE ONLY public.software_install_lifecycle
        ADD CONSTRAINT software_install_lifecycle_install_fkey
        FOREIGN KEY (tenant_id, install_id) REFERENCES public.software_installs(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- Platform catalogues — eol, vulnerability, classification rules
-- ----------------------------------------------------------------------------
-- DATA_MODEL §4. Platform-scoped, admin-curated, offline-bundle importable.
-- NO RLS, exactly like `algorithms` and `platform_frameworks`: they carry no
-- tenant_id, every tenant reads the same rows, and write access is a
-- platform-admin decision made in the API layer, not a database role. Adding a
-- policy here would be a new pattern, not the existing one.

-- endoflife.date is the seed source; rows are admin-curated and shipped in the
-- offline bundle for air-gapped installs (ADR-0005 D3).
CREATE TABLE IF NOT EXISTS public.eol_catalogue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_kind text NOT NULL,
    vendor text,
    product text NOT NULL,
    cycle text NOT NULL,
    release_date date,
    eol_date date,
    extended_support_date date,
    source_url text,
    source_kind text DEFAULT 'imported'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT eol_catalogue_pkey PRIMARY KEY (id),
    CONSTRAINT eol_catalogue_product_kind_check CHECK (product_kind = ANY (ARRAY['os'::text, 'software'::text, 'hardware'::text])),
    CONSTRAINT eol_catalogue_source_kind_check CHECK (source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text]))
);

CREATE UNIQUE INDEX IF NOT EXISTS eol_catalogue_identity_uniq
    ON public.eol_catalogue (product_kind, coalesce(vendor, ''), product, cycle);
CREATE INDEX IF NOT EXISTS idx_eol_catalogue_product
    ON public.eol_catalogue USING btree (lower(product));

-- NVD and OSV, mirrored by a platform job (workstream 3.4). cve_id is the
-- primary key because it is the identity; there is no surrogate.
CREATE TABLE IF NOT EXISTS public.vulnerability_catalogue (
    cve_id text NOT NULL,
    cvss_version text,
    cvss_score numeric(3,1),
    cvss_vector text,
    severity text,
    published_at timestamp with time zone,
    modified_at timestamp with time zone,
    description text,
    source_kind text DEFAULT 'imported'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vulnerability_catalogue_pkey PRIMARY KEY (cve_id),
    CONSTRAINT vulnerability_catalogue_severity_check CHECK (severity IS NULL OR severity = ANY (ARRAY['none'::text, 'low'::text, 'medium'::text, 'high'::text, 'critical'::text])),
    CONSTRAINT vulnerability_catalogue_cvss_score_range_check CHECK (cvss_score IS NULL OR (cvss_score >= 0 AND cvss_score <= 10)),
    CONSTRAINT vulnerability_catalogue_source_kind_check CHECK (source_kind = ANY (ARRAY['measured'::text, 'declared'::text, 'imported'::text, 'inferred'::text]))
);

CREATE INDEX IF NOT EXISTS idx_vulnerability_catalogue_severity
    ON public.vulnerability_catalogue USING btree (severity);

-- How a CVE matches an installed product: by CPE match string or by PURL range.
-- Exactly one of the two is set — a row with neither matches nothing and a row
-- with both is two rules wearing one coat.
CREATE TABLE IF NOT EXISTS public.vulnerability_matches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cve_id text NOT NULL,
    cpe_match_string text,
    purl_range text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vulnerability_matches_pkey PRIMARY KEY (id),
    CONSTRAINT vulnerability_matches_one_matcher_check CHECK ((cpe_match_string IS NOT NULL) <> (purl_range IS NOT NULL))
);

CREATE UNIQUE INDEX IF NOT EXISTS vulnerability_matches_identity_uniq
    ON public.vulnerability_matches (cve_id, coalesce(cpe_match_string, ''), coalesce(purl_range, ''));
CREATE INDEX IF NOT EXISTS idx_vulnerability_matches_cpe
    ON public.vulnerability_matches USING btree (cpe_match_string) WHERE cpe_match_string IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_vulnerability_matches_purl
    ON public.vulnerability_matches USING btree (purl_range) WHERE purl_range IS NOT NULL;

DO $$ BEGIN
  IF to_regclass('public.vulnerability_matches') IS NOT NULL
     AND to_regclass('public.vulnerability_catalogue') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'vulnerability_matches_cve_id_fkey' AND conrelid = to_regclass('public.vulnerability_matches')
     ) THEN
    ALTER TABLE ONLY public.vulnerability_matches
        ADD CONSTRAINT vulnerability_matches_cve_id_fkey FOREIGN KEY (cve_id)
        REFERENCES public.vulnerability_catalogue(cve_id) ON DELETE CASCADE;
  END IF;
END $$;

-- The rule-based classifier's evidence (ADR-0004 D6, workstream 2.10). Platform
-- rows, read by every tenant, proposing a class from a vendor OUI, an SNMP
-- sysObjectID, an EtherNet/IP identity, a cloud resource type, a banner, a port
-- profile, a model prefix or the collector platform that reached the device.
-- class_key is an FK by value to asset_classes.key for the same reason
-- assets.class_key is.
--
-- The rows are generated from standards/classification-rules.yaml into a region
-- of seed.sql; a platform admin adds their own through Catalog ▸ Classification
-- rules. Engine: shared/classify.
--
-- `class_key` is NULLABLE, which is the whole posture of the table in one
-- column. Most OUI rules assert a VENDOR and no class, because Dell, HP,
-- Netgear and Ubiquiti each sell things from four different classes under one
-- assignment and picking the most common one is a guess wearing a decimal. A
-- wrong class is worse than none: an absent class shows as unclassified and
-- invites someone to look, a wrong one shows as a fact and gets bulk-approved.
--
-- `cdp_capabilities`, `lldp_capability` and `mdns_service` joined the list in
-- workstream 2.10b, with the passive class signals they read; `model` and
-- `platform` joined it in workstream 2.10a, when
-- the in-package class hints of shared/deviceinterrogation moved into this
-- table. `model` carries product-id prefixes (a Cisco PID family, a UniFi
-- device type); `platform` carries what the collector reached — "it answered
-- the FortiOS API", which is a far stronger claim than "its MAC is in a
-- Fortinet OUI" and is why the Fortinet OUI rules assert no class at all.
CREATE TABLE IF NOT EXISTS public.classification_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rule_kind text NOT NULL,
    pattern text NOT NULL,
    class_key text,
    vendor text,
    model text,
    -- No DEFAULT. The engine accepts 0.50-0.95 and refuses anything outside it
    -- (shared/classify: below even money is noise in the approval queue, and
    -- 1.00 would claim a measurement where every row here is an inference), so
    -- a column default of 1.00 was a way to insert a row that classify.New
    -- would then reject -- and it rejects the whole SET, not the one row. An
    -- INSERT has to state what the rule asserts.
    confidence numeric(3,2) NOT NULL,
    source_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT classification_rules_pkey PRIMARY KEY (id),
    CONSTRAINT classification_rules_rule_kind_check CHECK (rule_kind = ANY (ARRAY['oui'::text, 'sysobjectid'::text, 'enip'::text, 'cloud_type'::text, 'banner'::text, 'port_profile'::text, 'model'::text, 'platform'::text, 'cdp_capabilities'::text, 'lldp_capability'::text, 'mdns_service'::text])),
    CONSTRAINT classification_rules_confidence_range_check CHECK (confidence >= 0 AND confidence <= 1),
    -- A rule that asserts nothing is a row that can only waste a reviewer's
    -- time. At least one of class, vendor or model has to be populated.
    CONSTRAINT classification_rules_asserts_something_check CHECK (
        class_key IS NOT NULL OR vendor IS NOT NULL OR model IS NOT NULL)
);

CREATE UNIQUE INDEX IF NOT EXISTS classification_rules_identity_uniq
    ON public.classification_rules (rule_kind, pattern);
CREATE INDEX IF NOT EXISTS idx_classification_rules_class_key
    ON public.classification_rules USING btree (class_key);

-- The mirror jobs' bookmark and health, one row per feed (workstreams 3.3/3.4).
-- Platform-scoped like the catalogues it tracks: no tenant_id, no RLS.
--
-- `cursor` is per-feed and deliberately opaque — NVD stores the last
-- `lastModEndDate` it consumed, OSV a per-ecosystem import marker, and
-- endoflife.date the date it last completed a full pass. Keeping it text rather
-- than a typed timestamp is what lets three feeds share one table instead of
-- each carrying a column nobody else sets. (CURSOR is a NON-reserved keyword in
-- PostgreSQL, so it is legal unquoted as a column name; the double-apply and the
-- integration test both exercise it.)
--
-- last_status starts at 'never' rather than NULL because "this feed has not run"
-- and "this feed ran and the outcome was lost" are different answers, and NULL
-- renders as the second. A feed error is RECORDED here and never fatal — see
-- catalogfeeds.Runner: a mirror that cannot reach NVD must not take the admin
-- console down with it, and an operator must be able to see that it failed.
CREATE TABLE IF NOT EXISTS public.catalog_feed_state (
    feed text NOT NULL,
    cursor text,
    last_run_at timestamp with time zone,
    last_status text DEFAULT 'never'::text NOT NULL,
    last_error text,
    row_count bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT catalog_feed_state_pkey PRIMARY KEY (feed),
    CONSTRAINT catalog_feed_state_last_status_check CHECK (last_status = ANY (ARRAY['never'::text, 'running'::text, 'ok'::text, 'error'::text])),
    CONSTRAINT catalog_feed_state_row_count_check CHECK (row_count >= 0)
);

-- The Enricher seam's two tables (ADR-0008 D1 / D3, workstream 4.5b).
-- Platform-scoped like the catalogues they serve: no tenant_id, no RLS.
--
-- These exist because of D3: "AI output is a proposal, and proposals go through
-- approval." A generative enricher never writes eol_catalogue. It writes HERE,
-- pending, with the source URL it cited and the model that said it; a platform
-- admin accepts or rejects, and only an accept puts a row in the catalogue —
-- with source_kind 'inferred', so the catalogue row says forever where it came
-- from.

-- One proposed eol_catalogue row, awaiting review.
--
-- subject_* is what was ASKED about (the miss that triggered the proposal);
-- proposed_* is what came back. They are kept apart because they are different
-- claims: "we could not answer for Cisco IOS-XE 17.9" and "the model says cycle
-- 17.9 leaves support on 2027-04-30" have different lifetimes, and a reviewer
-- comparing them is the whole review.
--
-- source_url is NOT NULL and has no default. ADR-0008 D4.4 is cite or refuse:
-- an enrichment fact without a source URL is commentary and is never persisted,
-- so a proposal that could not cite never reaches this table. A nullable column
-- here would make the rule a convention.
--
-- confidence defaults to 0 and the generative enricher writes 0: we never ask a
-- model to score itself, and a number we invented would read as a measurement.
-- The column exists because D4.1 requires it beside model_id, not because
-- anything currently has an estimate to put in it.
CREATE TABLE IF NOT EXISTS public.eol_catalogue_proposals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_kind text NOT NULL,
    subject_vendor text,
    subject_product text NOT NULL,
    subject_version text,
    proposed_cycle text NOT NULL,
    proposed_release_date date,
    proposed_eol_date date,
    proposed_extended_support_date date,
    source_url text NOT NULL,
    model_id text NOT NULL,
    source_kind text DEFAULT 'inferred'::text NOT NULL,
    confidence numeric(3,2) DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewer_id uuid,
    reviewer_email text,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT eol_catalogue_proposals_pkey PRIMARY KEY (id),
    CONSTRAINT eol_catalogue_proposals_product_kind_check CHECK (product_kind = ANY (ARRAY['os'::text, 'software'::text, 'hardware'::text])),
    CONSTRAINT eol_catalogue_proposals_source_kind_check CHECK (source_kind = 'inferred'::text),
    CONSTRAINT eol_catalogue_proposals_status_check CHECK (status = ANY (ARRAY['pending'::text, 'accepted'::text, 'rejected'::text])),
    CONSTRAINT eol_catalogue_proposals_confidence_range_check CHECK (confidence >= 0 AND confidence <= 1),
    -- A reviewed proposal names who reviewed it and when. Without this a row
    -- could read "accepted" with nobody attached, which is the shape of an
    -- approval that never happened.
    CONSTRAINT eol_catalogue_proposals_reviewed_check CHECK (
        status = 'pending'::text OR (reviewed_at IS NOT NULL AND reviewer_id IS NOT NULL))
);

-- At most one PENDING proposal per subject. Partial on status so the history of
-- accepted and rejected proposals for the same subject is kept — a rejected
-- proposal is the record of a model having been wrong about something, which is
-- worth keeping — while a repeated enrichment pass over the same gap cannot
-- stack duplicates for a reviewer to wade through.
CREATE UNIQUE INDEX IF NOT EXISTS eol_catalogue_proposals_pending_uniq
    ON public.eol_catalogue_proposals
       (product_kind, lower(coalesce(subject_vendor, '')), lower(subject_product), coalesce(subject_version, ''))
    WHERE status = 'pending'::text;
CREATE INDEX IF NOT EXISTS idx_eol_catalogue_proposals_status
    ON public.eol_catalogue_proposals USING btree (status, created_at DESC);

-- A lookup that found nothing, and how often.
--
-- This is the gap list: the enricher's rule default records every subject it
-- could not answer for, and the generative enricher works the top of this list.
-- Counting rather than logging is the point — a product asked about four
-- thousand times is a different priority from one asked about once, and a log
-- line cannot be sorted.
--
-- last_proposed_at is how a pass avoids re-asking a model the same question
-- every day. It is set whether or not the ask produced a proposal: "we asked and
-- got nothing usable" is an answer, and re-asking hourly would spend an
-- operator's tokens re-deriving it.
CREATE TABLE IF NOT EXISTS public.catalog_lookup_misses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_kind text NOT NULL,
    vendor text,
    product text NOT NULL,
    version text,
    miss_count bigint DEFAULT 1 NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_proposed_at timestamp with time zone,
    CONSTRAINT catalog_lookup_misses_pkey PRIMARY KEY (id),
    CONSTRAINT catalog_lookup_misses_product_kind_check CHECK (product_kind = ANY (ARRAY['os'::text, 'software'::text, 'hardware'::text])),
    CONSTRAINT catalog_lookup_misses_miss_count_check CHECK (miss_count >= 0)
);

-- Identity folds case on ALL THREE name columns, version included.
--
-- Version is a name here, not a number: it is whatever a device or an operator
-- reported. "17.9.4A" and "17.9.4a" are one gap, and counting them as two
-- splits the number this list is ORDERED BY — so the product actually costing
-- the most answers sinks below one asked about half as often. The same argument
-- that folds vendor and product folds this.
--
-- The stored value stays verbatim (see RecordMiss); only the identity folds.
CREATE UNIQUE INDEX IF NOT EXISTS catalog_lookup_misses_identity_uniq
    ON public.catalog_lookup_misses
       (product_kind, lower(coalesce(vendor, '')), lower(product), lower(coalesce(version, '')));
CREATE INDEX IF NOT EXISTS idx_catalog_lookup_misses_rank
    ON public.catalog_lookup_misses USING btree (miss_count DESC, last_seen_at DESC);



-- ----------------------------------------------------------------------------
-- RLS for the tables above
-- ----------------------------------------------------------------------------
-- Most of these tables are created BELOW the canonical RLS HARDENING block, so
-- their policies are declared here (the block cannot reference a table that does
-- not exist yet — the same reason legal_acceptances declares its own).
-- asset_classes, assets and asset_endpoints are defined ABOVE that block since
-- phase 1, and their policies are declared here too, with the rest, rather than
-- split across two places by an accident of ordering. The form is identical:
-- DROP POLICY IF EXISTS + CREATE, USING and WITH CHECK both stated.
--
-- Partitioned tables carry the POLICY on the parent only, which is where every
-- query goes — the same shape crypto_implementations_partitioned and
-- sensor_discoveries_partitioned use. A policy per partition would be eight
-- copies to keep in step, and Postgres applies the PARENT's policies to any
-- query that names the parent, so the copies would never be consulted.
--
-- They do, however, each get RLS ENABLED with NO policy of their own, which the
-- older partitioned tables do not. Naming a partition directly
-- (`SELECT … FROM assets_part_3`) is a separate relation reference: the parent's
-- policies do NOT apply to it, only the partition's own. With RLS off on the
-- partition, the blanket `GRANT … ON ALL TABLES IN SCHEMA public TO crypto_app`
-- at the foot of this file therefore hands every tenant an unfiltered read of
-- every other tenant's rows, one identifier away from the policy. Measured on
-- PG17: tenant A saw 3 rows through `assets` and 4 through the partitions,
-- including tenant B's.
--
-- RLS enabled with zero policies is default-deny, so the direct path returns
-- nothing for crypto_app while the parent path is completely unaffected
-- (verified: parent SELECT/INSERT/UPDATE/DELETE all unchanged, partition reads
-- 0). Deny rather than a copied policy because nothing should be naming a
-- partition in the first place — no Go or TypeScript in this repo does — so the
-- correct answer to a direct partition reference is to refuse it, not to serve
-- it correctly.
--
-- The two surviving pre-existing partitioned tables get the same treatment in
-- the phase-1 block further down (`network_assets_partitioned`, the third, is
-- dropped outright). Recorded in DATA_MODEL §9.
ALTER TABLE public.assets_part_0 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assets_part_1 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assets_part_2 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assets_part_3 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assets_part_4 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assets_part_5 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assets_part_6 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assets_part_7 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asset_endpoints_part_0 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asset_endpoints_part_1 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asset_endpoints_part_2 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asset_endpoints_part_3 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asset_endpoints_part_4 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asset_endpoints_part_5 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asset_endpoints_part_6 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asset_endpoints_part_7 ENABLE ROW LEVEL SECURITY;
--
-- asset_classes is the hybrid case: a tenant must SEE the platform rows
-- (tenant_id IS NULL) it classifies against, but must only WRITE its own
-- subclass rows. Platform rows are written by the seed (as the owner) or
-- through the crypto_bypass role.
--
-- TWO policies, not the one-policy `USING (tenant_id IS NULL OR …)` form the
-- RLS HYBRID-TABLE block uses, because that form does NOT hold for DELETE.
-- WITH CHECK constrains the NEW row, and a DELETE produces no new row — so
-- DELETE is governed by USING alone. With the admitting USING, any tenant
-- session could `DELETE FROM asset_classes WHERE tenant_id IS NULL` and take
-- the platform class registry out from under every other tenant on the
-- install. (Verified against PG17: the delete succeeded as crypto_app.) The
-- hybrid tables in that block share the hole; fixing them is its own change,
-- but this table is the registry the whole inventory resolves class_key
-- against — and class_key is an FK BY VALUE with no constraint, so the rows
-- would go without a single database error.
--
-- Permissive policies are OR'd WITHIN a command type and AND'd ACROSS types,
-- so: SELECT sees own ∪ platform (both policies apply); INSERT, UPDATE and
-- DELETE consult only the FOR ALL policy and are therefore own-rows-only.
ALTER TABLE public.asset_classes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_classes_tenant_isolation ON public.asset_classes;
DROP POLICY IF EXISTS asset_classes_platform_read ON public.asset_classes;
CREATE POLICY asset_classes_tenant_isolation ON public.asset_classes
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
CREATE POLICY asset_classes_platform_read ON public.asset_classes FOR SELECT
  USING (tenant_id IS NULL);

ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS assets_tenant_isolation ON public.assets;
CREATE POLICY assets_tenant_isolation ON public.assets
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.asset_endpoints ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_endpoints_tenant_isolation ON public.asset_endpoints;
CREATE POLICY asset_endpoints_tenant_isolation ON public.asset_endpoints
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.asset_identifiers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_identifiers_tenant_isolation ON public.asset_identifiers;
CREATE POLICY asset_identifiers_tenant_isolation ON public.asset_identifiers
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.asset_management ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_management_tenant_isolation ON public.asset_management;
CREATE POLICY asset_management_tenant_isolation ON public.asset_management
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.asset_credentials ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_credentials_tenant_isolation ON public.asset_credentials;
CREATE POLICY asset_credentials_tenant_isolation ON public.asset_credentials
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.asset_relationships ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_relationships_tenant_isolation ON public.asset_relationships;
CREATE POLICY asset_relationships_tenant_isolation ON public.asset_relationships
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.asset_facts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_facts_tenant_isolation ON public.asset_facts;
CREATE POLICY asset_facts_tenant_isolation ON public.asset_facts
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.software_products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS software_products_tenant_isolation ON public.software_products;
CREATE POLICY software_products_tenant_isolation ON public.software_products
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.software_installs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS software_installs_tenant_isolation ON public.software_installs;
CREATE POLICY software_installs_tenant_isolation ON public.software_installs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.findings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS findings_tenant_isolation ON public.findings;
CREATE POLICY findings_tenant_isolation ON public.findings
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.producer_assessments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS producer_assessments_tenant_isolation ON public.producer_assessments;
CREATE POLICY producer_assessments_tenant_isolation ON public.producer_assessments
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.asset_class_history ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS asset_class_history_tenant_isolation ON public.asset_class_history;
CREATE POLICY asset_class_history_tenant_isolation ON public.asset_class_history
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.software_install_lifecycle ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS software_install_lifecycle_tenant_isolation ON public.software_install_lifecycle;
CREATE POLICY software_install_lifecycle_tenant_isolation ON public.software_install_lifecycle
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

-- eol_catalogue, vulnerability_catalogue, vulnerability_matches,
-- classification_rules and catalog_feed_state are deliberately NOT in the list
-- above. They are platform catalogues (and the mirror jobs' own bookkeeping)
-- with no tenant_id, and RLS on a table with nothing to isolate by would be
-- theatre. See the note at their definitions.


-- ----------------------------------------------------------------------------
-- updated_at maintenance for the tables above
-- ----------------------------------------------------------------------------
-- Every table above carries `updated_at timestamptz DEFAULT now() NOT NULL`,
-- and a DEFAULT fires on INSERT only. Without a trigger the column silently
-- keeps its insert time for the life of the row, so "when did this asset last
-- change" answers "when was it created" — wrong in a way no query errors on.
-- These are ingest tables: last_seen_at moves on re-observation, updated_at
-- must move on actual change.
--
-- public.update_updated_at_column() is the house function (52 existing tables
-- use it). CREATE OR REPLACE TRIGGER is the idempotent form per CLAUDE.md;
-- Postgres has no IF NOT EXISTS for triggers.
--
-- asset_history is absent because it is append-only and has no updated_at.
-- Partitioned parents take the trigger on the PARENT: a row-level BEFORE
-- trigger on a partitioned table is propagated to every partition by Postgres,
-- so it fires for parent-routed writes without eight copies.
CREATE OR REPLACE TRIGGER update_asset_classes_updated_at BEFORE UPDATE ON public.asset_classes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_assets_updated_at BEFORE UPDATE ON public.assets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_asset_endpoints_updated_at BEFORE UPDATE ON public.asset_endpoints FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_asset_identifiers_updated_at BEFORE UPDATE ON public.asset_identifiers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_asset_management_updated_at BEFORE UPDATE ON public.asset_management FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_asset_credentials_updated_at BEFORE UPDATE ON public.asset_credentials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_asset_relationships_updated_at BEFORE UPDATE ON public.asset_relationships FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_asset_facts_updated_at BEFORE UPDATE ON public.asset_facts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_software_products_updated_at BEFORE UPDATE ON public.software_products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_software_installs_updated_at BEFORE UPDATE ON public.software_installs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_findings_updated_at BEFORE UPDATE ON public.findings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_eol_catalogue_updated_at BEFORE UPDATE ON public.eol_catalogue FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_vulnerability_catalogue_updated_at BEFORE UPDATE ON public.vulnerability_catalogue FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_classification_rules_updated_at BEFORE UPDATE ON public.classification_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE OR REPLACE TRIGGER update_catalog_feed_state_updated_at BEFORE UPDATE ON public.catalog_feed_state FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- ----------------------------------------------------------------------------
-- asset_history — repointed at `assets` (DATA_MODEL §2, BUILD_PLAN 0.6)
-- ----------------------------------------------------------------------------
-- asset_history is an EXISTING table whose composite FK referenced the old
-- asset table, so a history row for one of the new `assets` rows was refused
-- outright:
--
--   ERROR: insert or update on table "asset_history" violates foreign key
--          constraint "asset_history_tenant_asset_fkey"
--   DETAIL: Key (tenant_id, asset_id)=(…) is not present in table
--           "network_assets_partitioned".
--
-- That made the table unusable by the identification engine (workstream 0.4),
-- which records a `merge_proposed` entry when an identifier conflict opens a
-- merge proposal, and by the 0.6 writer generally.
--
-- Repointing rather than dual-keying is safe because asset_history has never
-- had a writer — not a trigger, not Go, not the seed (ADR-0002 "asset_history
-- has no writer") — so there are no rows anywhere to preserve or migrate. The
-- old constraint is dropped and the new one added, both guarded, so a database
-- carrying either shape converges on one apply.
DO $$ BEGIN
  IF to_regclass('public.asset_history') IS NOT NULL THEN
    ALTER TABLE public.asset_history
        DROP CONSTRAINT IF EXISTS asset_history_tenant_asset_fkey;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.asset_history') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'asset_history_tenant_asset_fkey' AND conrelid = to_regclass('public.asset_history')
     ) THEN
    ALTER TABLE ONLY public.asset_history
        ADD CONSTRAINT asset_history_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id)
        REFERENCES public.assets(tenant_id, id) ON DELETE CASCADE;
  END IF;
END $$;

-- assets.metadata for an install created before phase 1 added it (the CREATE
-- TABLE IF NOT EXISTS above is a no-op there). See the column comment for what
-- it holds and why it is not `attributes`.
DO $$ BEGIN
  IF to_regclass('public.assets') IS NOT NULL THEN
    ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}'::jsonb NOT NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_assets_discovery_source
    ON public.assets USING btree (tenant_id, (metadata->>'discovery_source')) WHERE deleted_at IS NULL;


-- `seq` for an install that already has the table (the CREATE TABLE IF NOT
-- EXISTS above is a no-op there). bigserial is not valid in ALTER TABLE ADD
-- COLUMN, so this is its longhand: the column, the sequence, the default and
-- the ownership that makes the sequence go away with the table.
DO $$ BEGIN
  IF to_regclass('public.asset_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_attribute
       WHERE attrelid = to_regclass('public.asset_history') AND attname = 'seq' AND NOT attisdropped
     ) THEN
    CREATE SEQUENCE IF NOT EXISTS public.asset_history_seq_seq;
    ALTER TABLE public.asset_history ADD COLUMN seq bigint NOT NULL DEFAULT nextval('public.asset_history_seq_seq');
    ALTER SEQUENCE public.asset_history_seq_seq OWNED BY public.asset_history.seq;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_asset_history_tenant_asset_seq
    ON public.asset_history USING btree (tenant_id, asset_id, seq);


-- `action` was unconstrained text, so any string was accepted and a typo in a
-- writer would land silently and be invisible until someone filtered the
-- timeline by an action that never matched. The vocabulary is DATA_MODEL §2's
-- list plus `merge_proposed`, which ADR-0002 D3's third outcome needs: an
-- identifier collision does not auto-merge, it opens a proposal, and the
-- proposal is the thing the history has to record.
--
-- A CHECK rather than an enum, for the reason the rest of this block gives: a
-- new action is one edit here instead of the two an ALTER TYPE needs, and it
-- cannot half-apply.
--
-- WIDENING THE VOCABULARY, and why this is one block with one list.
--
-- The obvious form -- `IF NOT EXISTS (the constraint) THEN ADD` -- fires only
-- when there is no constraint at all, so on a database created before a value
-- existed it is a no-op and the narrower list survives. Because
-- recordAssetHistory LOGS a failed insert rather than returning it, every row
-- carrying the new action is then rejected IN SILENCE: the row simply is not
-- there, and the first person to notice reads the timeline months later.
-- `sbom_imported` (workstream 2.6b) was the first value to land after the
-- constraint shipped and found exactly that.
--
-- A CHECK has no dependents, so widening one means dropping the stale
-- definition and adding the current one. Two things decide the shape below:
--
--   * The list is written ONCE, as a DO-block variable used both to decide
--     whether the deployed constraint is stale and to build the new one. A
--     second copy -- a `NOT LIKE '%<newest value>%'` gate beside the list, or a
--     whole second ADD -- is a copy that drifts, and it drifts in the direction
--     that fails silently: the next author adds a value to the list, forgets
--     the gate, and a FRESH database takes it (there is no constraint to skip)
--     while every upgraded one rejects it. The parity test below runs against a
--     fresh schema, so it would pass. That is the same trap one layer up.
--   * The convergence is gated on COVERAGE, not on a value name, so it needs no
--     edit when the vocabulary grows. It is gated at all because ADD CONSTRAINT
--     revalidates the whole table, and asset_history is append-only and grows
--     without bound: once the deployed constraint already covers every action,
--     this does nothing.
--
-- identity.AllHistoryActions() and
-- TestIntegration_SBOM_HistoryActionCheckCoversEveryGoAction compare the
-- DEPLOYED constraint against the Go vocabulary, so a value added on one side
-- and not the other fails loudly.
DO $$
DECLARE
  actions text[] := ARRAY[
      'created', 'updated', 'merged_from', 'merged_into',
      'merge_proposed', 'approved', 'denied', 'classified',
      'endpoint_added', 'edge_added', 'edge_removed',
      'edge_accepted', 'edge_rejected', 'archived',
      'sbom_imported',
      'class_proposed', 'class_accepted', 'class_rejected'];
  def  text;
  list text;
BEGIN
  IF to_regclass('public.asset_history') IS NULL THEN
    RETURN;
  END IF;

  SELECT pg_get_constraintdef(oid) INTO def
    FROM pg_constraint
   WHERE conname = 'asset_history_action_check'
     AND conrelid = to_regclass('public.asset_history');

  IF def IS NOT NULL THEN
    -- Every action already accepted? Nothing to do. quote_literal wraps each
    -- value in the quotes pg_get_constraintdef renders, so a short action name
    -- cannot match inside a longer one.
    IF (SELECT bool_and(position(quote_literal(x) IN def) > 0)
          FROM unnest(actions) AS x) THEN
      RETURN;
    END IF;
    ALTER TABLE public.asset_history DROP CONSTRAINT asset_history_action_check;
  END IF;

  SELECT string_agg(quote_literal(x) || '::text', ', ' ORDER BY ord) INTO list
    FROM unnest(actions) WITH ORDINALITY AS t(x, ord);
  EXECUTE 'ALTER TABLE public.asset_history ADD CONSTRAINT asset_history_action_check '
       || 'CHECK (action = ANY (ARRAY[' || list || ']))';
END $$;

-- One PENDING merge proposal per contested observation, not one per poll.
--
-- The identification engine's floor — every identifier already belongs to some
-- other asset and none of them may decide for this class — opens a proposal and
-- creates nothing. Nothing about that changes between polls, so a cloud
-- collector on a 15-minute schedule wrote the SAME proposal 96 times a day, and
-- the Approvals queue filled with identical work items nobody could clear by
-- deciding one of them.
--
-- The fingerprint (`changes_json->>'fingerprint'`) is computed by the writer
-- over the observation asset, the candidate set and the matched identifiers —
-- in Go, because sorting a JSON array inside an index expression would need an
-- immutable helper function for no gain. A RESOLVED proposal carries
-- `status` and drops out of the partial predicate, so once a human decides one,
-- a later recurrence can open a fresh proposal rather than being swallowed
-- forever.
--
-- Partial and expression-based, so it costs nothing on the 99.9% of
-- asset_history rows that are not proposals.
CREATE UNIQUE INDEX IF NOT EXISTS idx_asset_history_pending_merge_proposal
    ON public.asset_history USING btree (tenant_id, (changes_json ->> 'fingerprint'))
    WHERE action = 'merge_proposed'
      AND changes_json ? 'fingerprint'
      AND COALESCE(changes_json ->> 'status', 'pending') = 'pending';

-- One PENDING class proposal per (asset, proposed class), not one per poll
-- (workstream 2.10b).
--
-- Same shape and same reason as the merge index above. A rule-derived class
-- proposal is the engine's answer to evidence that does not change between
-- observations: a printer that advertises `_ipp._tcp` advertises it every time
-- the sensor's coalescing window closes, and without this the reviewer would
-- find the same "we think this is a printer" question a hundred times a day and
-- could not clear it by answering one.
--
-- The key is the PROPOSED CLASS and not a fingerprint of the evidence, because
-- the question a reviewer answers is "is this thing a printer", and two
-- different rules arriving at `printer` are one question. The evidence that
-- CHANGES is still recorded — accepting or rejecting stamps `status`, the row
-- drops out of this predicate, and a later recurrence can open a fresh proposal
-- rather than being swallowed for ever.
--
-- A rejection is deliberately NOT covered here: `class_rejected` is a different
-- action, so the suppression check that stops a rejected class being proposed
-- again is a read, not an index. An index cannot express "and nobody has said
-- no to this" without also preventing the row that records the no.
--
-- # Why the key is not `proposed_class_key` alone
--
-- A CONFLICT proposal names no class: the rules disagreed, so the writer stores
-- `proposed_class_key: ""` — present (the partial predicate needs it to be) and
-- empty. Keyed on that column alone, EVERY conflict on an asset collapsed onto
-- the one key `(tenant, asset, '')`, and the second one was swallowed by the
-- `ON CONFLICT DO NOTHING`. So an asset that the catalogue argued over twice —
-- `printer` vs `multifunction_device` on Monday, `switch` vs `router` after a
-- new rule landed on Friday — showed the reviewer the FIRST disagreement and
-- silently dropped the second, for as long as the first stayed pending. The
-- suppression that is right for one repeated question is wrong for two
-- different ones.
--
-- `conflict_key` is the sorted, joined list of the classes that tied, computed
-- in Go by the writer for the same reason the merge proposal's `fingerprint` is
-- — sorting a JSON array inside an index expression would need an immutable
-- helper function for no gain. The COALESCE falls back to `''` rather than
-- NULL: NULLs do not conflict in a unique index, so a row missing the key would
-- silently opt OUT of deduplication, which is the failure this index exists to
-- prevent arriving by a different door.
CREATE UNIQUE INDEX IF NOT EXISTS idx_asset_history_pending_class_proposal
    ON public.asset_history USING btree (
        tenant_id, asset_id,
        (COALESCE(NULLIF(changes_json ->> 'proposed_class_key', ''), changes_json ->> 'conflict_key', '')))
    WHERE action = 'class_proposed'
      AND changes_json ? 'proposed_class_key'
      AND COALESCE(changes_json ->> 'status', 'pending') = 'pending';

-- The Approvals queue's own read, which the unique index above cannot serve.
--
-- `ClassProposalService.ListPending` filters on `action`, `changes_json->>'kind'`
-- and the pending status — and says nothing about `proposed_class_key`. The
-- planner can only use a partial index when it can PROVE the query's predicate
-- implies the index's, and `? 'proposed_class_key'` is not implied by anything
-- the queue query states, so every page of Approvals seq-scanned an append-only
-- table that grows without bound. This index's predicate is the queue's
-- predicate, verbatim, and `created_at DESC` is the order it pages in.
CREATE INDEX IF NOT EXISTS idx_asset_history_class_proposal_queue
    ON public.asset_history USING btree (tenant_id, created_at DESC)
    WHERE action = 'class_proposed'
      AND changes_json ->> 'kind' = 'class_proposal'
      AND COALESCE(changes_json ->> 'status', 'pending') = 'pending';

-- The decided class proposals a reviewer has already answered, which the intake
-- consults before proposing again. Partial, because `class_rejected` is a
-- handful of rows beside an append-only table that grows without bound.
CREATE INDEX IF NOT EXISTS idx_asset_history_class_rejected
    ON public.asset_history USING btree (tenant_id, asset_id, (changes_json ->> 'proposed_class_key'))
    WHERE action = 'class_rejected';

-- ============================================================================
-- POST-MIGRATIONS: phase 1 — retire the port-as-asset model (workstream 1.1)
-- ============================================================================
-- ADR-0002 D1/D5 and ADR-0007 D2. `assets` + `asset_endpoints` replace
-- `network_assets_partitioned`; `asset_management` + `asset_credentials`
-- replace `devices`. Owner decision 2026-09-11: there are no existing installs,
-- so there is NO backfill and NO compatibility view — the old tables are simply
-- gone from the body above, and these drops exist so a LAB database carrying
-- the old shape comes up clean on re-apply rather than keeping orphaned
-- relations, policies and FKs.
--
-- CASCADE is required, not tidiness: on such a database the old table is still
-- the target of composite FKs from asset_history, crypto_applications,
-- database_encryption_states, external_connections and ssh_keys. CASCADE drops
-- those; the guarded ADDs below then recreate them against `assets`. That
-- ordering — drop, then add — is why these FKs cannot live in the pg_dump body:
-- the body's guard is by constraint NAME, so on the old shape it would find the
-- name already taken (by the constraint pointing at the table about to be
-- dropped) and skip, leaving no FK at all after the CASCADE.
DROP TABLE IF EXISTS public.network_assets_partitioned CASCADE;
DROP TABLE IF EXISTS public.network_assets_part_0 CASCADE;
DROP TABLE IF EXISTS public.network_assets_part_1 CASCADE;
DROP TABLE IF EXISTS public.network_assets_part_2 CASCADE;
DROP TABLE IF EXISTS public.network_assets_part_3 CASCADE;
DROP TABLE IF EXISTS public.network_assets_part_4 CASCADE;
DROP TABLE IF EXISTS public.network_assets_part_5 CASCADE;
DROP TABLE IF EXISTS public.network_assets_part_6 CASCADE;
DROP TABLE IF EXISTS public.network_assets_part_7 CASCADE;
DROP VIEW IF EXISTS public.network_assets CASCADE;
DROP TABLE IF EXISTS public.devices CASCADE;

-- The four-value taxonomy the class registry replaces (ADR-0002 D2). Dropped
-- only after the tables whose columns used it, or the drop fails with a
-- dependency error.
DROP TYPE IF EXISTS public.asset_type;


-- ============================================================================
-- POST-MIGRATIONS: phase 3 — one findings table, every producer (workstream 3.1)
-- ============================================================================
-- ADR-0005 D3 and ADR-0007 D2. `findings` replaces `compliance_findings`: the
-- compliance producer now writes rows with `producer = 'compliance'` and
-- `kind = 'control_noncompliant'`, and the old table is gone from the body
-- above. Owner decision 2026-09-11: there are no existing installs, so there is
-- NO backfill and NO compatibility view. This drop exists so a LAB database
-- carrying the old shape comes up clean on re-apply rather than keeping an
-- orphaned relation, its policy and its foreign keys.
--
-- CASCADE is required, not tidiness: on such a database the old table is still
-- the target of finding_id FKs from compliance_finding_history,
-- remediation_plan_items and tickets. CASCADE drops those; the guarded ADDs
-- below then recreate them against `findings`. That ordering — drop, then add —
-- is why these three FKs cannot live in the pg_dump body: the body's guard is by
-- constraint NAME, so on the old shape it would find the name already taken (by
-- the constraint pointing at the table about to be dropped) and skip, leaving no
-- FK at all after the CASCADE.
DROP TABLE IF EXISTS public.compliance_findings CASCADE;

-- The open-row unique index gained `control_id` (with NULLS NOT DISTINCT) when
-- the compliance producer moved onto this table: its finding is one per
-- (control, subject) pair, so keying on the subject alone makes the second
-- control's finding overwrite the first's through ON CONFLICT — silently, with
-- no error, losing a violation.
--
-- `CREATE UNIQUE INDEX IF NOT EXISTS` in the body above is a NO-OP on a database
-- that already carries the five-column form (every database created between
-- Gate 1 and workstream 3.1), so widening it has to be an explicit drop. The
-- check is on the index's actual shape rather than a version marker, so this is
-- a no-op on a fresh install and on any later re-apply.
DO $$
DECLARE
  cols text;
  nulls_not_distinct boolean;
BEGIN
  IF to_regclass('public.findings_open_subject_uniq') IS NOT NULL THEN
    SELECT string_agg(a.attname, ',' ORDER BY k.ord), i.indnullsnotdistinct
      INTO cols, nulls_not_distinct
      FROM pg_index i
      JOIN pg_class c ON c.oid = i.indexrelid
      CROSS JOIN LATERAL unnest(i.indkey) WITH ORDINALITY AS k(attnum, ord)
      JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = k.attnum
     WHERE c.relname = 'findings_open_subject_uniq'
     GROUP BY i.indnullsnotdistinct;
    IF cols IS DISTINCT FROM 'tenant_id,producer,kind,subject_type,subject_id,control_id'
       OR nulls_not_distinct IS DISTINCT FROM true THEN
      DROP INDEX public.findings_open_subject_uniq;
    END IF;
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS findings_open_subject_uniq
    ON public.findings (tenant_id, producer, kind, subject_type, subject_id, control_id)
    NULLS NOT DISTINCT
    WHERE detection_state <> 'ARCHIVED'::text;

-- Rows left pointing at a finding that no longer exists.
--
-- `DROP TABLE … CASCADE` drops the dependent CONSTRAINTS, not the dependent
-- ROWS: on a lab database that carried compliance findings, the history entries,
-- plan items and tickets that referenced them are still there, now naming ids
-- that resolve to nothing. Re-adding the foreign keys below would fail on them —
-- which is the honest outcome, since a dangling reference IS a broken one.
--
-- Each orphan is treated the way its own foreign key says it should be. History
-- and plan items were ON DELETE CASCADE, so they go: the history OF a finding
-- that no longer exists is not history of anything, and a plan item is a pointer
-- with nothing behind it. Tickets were ON DELETE SET NULL and are kept with the
-- link cleared — a ticket is a person's own work and must survive the table it
-- happened to be filed against.
DO $$ BEGIN
  IF to_regclass('public.findings') IS NOT NULL THEN
    IF to_regclass('public.compliance_finding_history') IS NOT NULL THEN
      DELETE FROM public.compliance_finding_history h
       WHERE NOT EXISTS (SELECT 1 FROM public.findings f WHERE f.id = h.finding_id);
    END IF;
    IF to_regclass('public.remediation_plan_items') IS NOT NULL THEN
      DELETE FROM public.remediation_plan_items i
       WHERE NOT EXISTS (SELECT 1 FROM public.findings f WHERE f.id = i.finding_id);
    END IF;
    IF to_regclass('public.tickets') IS NOT NULL THEN
      UPDATE public.tickets t
         SET finding_id = NULL
       WHERE t.finding_id IS NOT NULL
         AND NOT EXISTS (SELECT 1 FROM public.findings f WHERE f.id = t.finding_id);
    END IF;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.findings') IS NOT NULL
     AND to_regclass('public.compliance_finding_history') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'compliance_finding_history_finding_id_fkey'
         AND conrelid = to_regclass('public.compliance_finding_history')
     ) THEN
    ALTER TABLE ONLY public.compliance_finding_history
        ADD CONSTRAINT compliance_finding_history_finding_id_fkey FOREIGN KEY (finding_id)
        REFERENCES public.findings(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.findings') IS NOT NULL
     AND to_regclass('public.remediation_plan_items') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'remediation_plan_items_finding_id_fkey'
         AND conrelid = to_regclass('public.remediation_plan_items')
     ) THEN
    ALTER TABLE ONLY public.remediation_plan_items
        ADD CONSTRAINT remediation_plan_items_finding_id_fkey FOREIGN KEY (finding_id)
        REFERENCES public.findings(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.findings') IS NOT NULL
     AND to_regclass('public.tickets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'tickets_finding_id_fkey' AND conrelid = to_regclass('public.tickets')
     ) THEN
    ALTER TABLE ONLY public.tickets
        ADD CONSTRAINT tickets_finding_id_fkey FOREIGN KEY (finding_id)
        REFERENCES public.findings(id) ON DELETE SET NULL;
  END IF;
END $$;


-- device_jobs.device_id -> asset_id and database_encryption_states.device_id
-- (dropped; asset_id was already there). On a fresh install the CREATE TABLEs
-- above already carry the new shape and these are no-ops.
--
-- The values are NOT carried across. A device id and an asset id named
-- different rows in different tables; copying one into the other would produce
-- a column full of ids that resolve to nothing, which reads as data.
DO $$ BEGIN
  IF to_regclass('public.device_jobs') IS NOT NULL THEN
    -- The CHECK names the column, so it has to go before the column does. Only
    -- drop the OLD spelling of it: the body above already carries the new one,
    -- and dropping/re-adding a valid constraint on every apply costs a table
    -- scan for nothing.
    IF EXISTS (
      SELECT 1 FROM pg_constraint
      WHERE conname = 'valid_job_assignment'
        AND conrelid = to_regclass('public.device_jobs')
        AND pg_get_constraintdef(oid) LIKE '%device_id%'
    ) THEN
      ALTER TABLE public.device_jobs DROP CONSTRAINT valid_job_assignment;
    END IF;
    ALTER TABLE public.device_jobs ADD COLUMN IF NOT EXISTS asset_id uuid;
    ALTER TABLE public.device_jobs DROP COLUMN IF EXISTS device_id;
    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint
      WHERE conname = 'valid_job_assignment' AND conrelid = to_regclass('public.device_jobs')
    ) THEN
      -- NOT VALID, and only on this path. A fresh install gets the validated
      -- constraint from the CREATE TABLE above and never reaches here (the
      -- guard finds it). This branch runs only on a database carrying the OLD
      -- shape, where the third arm was satisfied by `device_id` — a column
      -- this block has just dropped without carrying its values across, on
      -- purpose. Every in-cluster interrogation job already on such a database
      -- therefore violates the new arm the instant it is written, and a plain
      -- ADD CONSTRAINT aborts the whole apply:
      --   ERROR: check constraint "valid_job_assignment" of relation
      --          "device_jobs" is violated by some row
      -- NOT VALID enforces the rule on every row written from now on and
      -- grandfathers the legacy ones, which name a device that no longer
      -- exists and can never run again. Deleting them instead would destroy a
      -- record of work that did happen; validating them is impossible, because
      -- there is no asset id to give them.
      ALTER TABLE public.device_jobs
        ADD CONSTRAINT valid_job_assignment CHECK ((((agent_id IS NULL) AND (job_type = 'cloud_discovery'::public.device_job_type)) OR ((agent_id IS NOT NULL) AND (job_type = 'device_interrogation'::public.device_job_type)) OR ((agent_id IS NULL) AND (job_type = 'device_interrogation'::public.device_job_type) AND (asset_id IS NOT NULL)))) NOT VALID;
    END IF;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.database_encryption_states') IS NOT NULL THEN
    ALTER TABLE public.database_encryption_states DROP COLUMN IF EXISTS device_id;
  END IF;
END $$;


-- =========================================================================
-- device_jobs.valid_job_assignment: the host_inventory arm
-- =========================================================================
-- MUST come after the device_id -> asset_id convergence above, and does.
--
-- Ordering is the whole of this block's correctness. Placed BEFORE that
-- convergence it is wrong twice over: on a fresh install it would re-add a
-- CHECK naming `device_id`, a column the new CREATE TABLE does not have, and
-- abort the apply under ON_ERROR_STOP=1; on an upgraded one the convergence
-- would then find `%device_id%`, drop the constraint and re-add ITS three-arm
-- version, silently discarding the host_inventory arm — so every host
-- inventory would fail its INSERT much later with a constraint violation.
--
-- Guarded on the arm rather than on the constraint's existence. The
-- convergence above only re-adds when the constraint is absent, so on a
-- database that already converged it is present, correct for assets, and still
-- missing this arm — an existence check would find it and do nothing.
--
-- NOT VALID for the same reason the convergence uses it: a database that took
-- that NOT VALID path carries in-cluster interrogation rows whose asset_id is
-- NULL, already grandfathered. Re-adding VALID would re-check them and abort.
-- Widening cannot invalidate a row that was legal before, so nothing is being
-- waved through that a VALID constraint would have caught.
--
-- A host_inventory job is ALWAYS agent-assigned: local collections are
-- agent-originated (the agent posts them; there is no queued job) and remote
-- ones are executed by an agent that can reach the target.
DO $$
BEGIN
    IF to_regclass('public.device_jobs') IS NOT NULL
       AND NOT EXISTS (
         SELECT 1 FROM pg_constraint
          WHERE conname = 'valid_job_assignment'
            AND conrelid = to_regclass('public.device_jobs')
            AND pg_get_constraintdef(oid) LIKE '%host_inventory%'
       ) THEN
        ALTER TABLE public.device_jobs DROP CONSTRAINT IF EXISTS valid_job_assignment;
        ALTER TABLE public.device_jobs
          ADD CONSTRAINT valid_job_assignment CHECK (
            ((agent_id IS NULL)     AND (job_type = 'cloud_discovery'::public.device_job_type))
         OR ((agent_id IS NOT NULL) AND (job_type = 'device_interrogation'::public.device_job_type))
         OR ((agent_id IS NULL)     AND (job_type = 'device_interrogation'::public.device_job_type) AND (asset_id IS NOT NULL))
         OR ((agent_id IS NOT NULL) AND (job_type = 'host_inventory'::public.device_job_type))
          ) NOT VALID;
    END IF;
END $$;

-- The index on the column the block above adds. It cannot sit with the other
-- device_jobs indexes in the pg_dump body: on a database that already has the
-- table, the body's CREATE TABLE IF NOT EXISTS is a no-op and `asset_id` does
-- not exist yet at that point.
CREATE INDEX IF NOT EXISTS idx_device_jobs_asset_id ON public.device_jobs USING btree (asset_id);


-- The endpoint links of DATA_MODEL §2. Added for installs whose CREATE TABLE
-- IF NOT EXISTS above was a no-op; `crypto_implementations_partitioned` takes
-- its ADD COLUMN at its definition instead, because the view immediately below
-- it selects the column.
DO $$ BEGIN
  IF to_regclass('public.external_connections') IS NOT NULL THEN
    ALTER TABLE public.external_connections ADD COLUMN IF NOT EXISTS source_endpoint_id uuid;
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.ssh_keys') IS NOT NULL THEN
    ALTER TABLE public.ssh_keys ADD COLUMN IF NOT EXISTS endpoint_id uuid;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_crypto_impl_endpoint
    ON public.crypto_implementations_partitioned USING btree (tenant_id, endpoint_id) WHERE endpoint_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_external_connections_source_endpoint
    ON public.external_connections USING btree (tenant_id, source_endpoint_id) WHERE source_endpoint_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_ssh_keys_endpoint
    ON public.ssh_keys USING btree (tenant_id, endpoint_id) WHERE endpoint_id IS NOT NULL;


-- Asset references into the hash-partitioned `assets`. Composite
-- (tenant_id, asset_id) rather than a single column because the partitioned
-- table's only unique key is (tenant_id, id) — with the welcome side effect
-- that a cross-tenant asset reference is unrepresentable at the database level.
--
-- asset_history's own FK is NOT repeated here: it is added a few blocks above,
-- at the table, where the unconditional DROP + guarded ADD converges a database
-- carrying either shape.
--
-- Each ADD is preceded by a clear of the references that no longer RESOLVE.
-- On a lab database carrying the old shape these columns are full of ids that
-- named rows in `network_assets_partitioned`, which the CASCADE above dropped:
-- the CASCADE takes the constraint, not the rows, so the ids survive pointing
-- at nothing and a plain ADD CONSTRAINT aborts the whole apply with
--   ERROR: insert or update on table "…" violates foreign key constraint
-- Setting them NULL is what the declared ON DELETE SET NULL would have done had
-- the constraint still been in place when the parent went, and it is the same
-- rule the device_jobs block applies one screen up: an id that resolves to
-- nothing reads as data and must not be kept. The UPDATE sits INSIDE the
-- constraint guard, so it runs on the one converging apply and never again.
DO $$ BEGIN
  IF to_regclass('public.crypto_applications') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_applications_tenant_asset_fkey' AND conrelid = to_regclass('public.crypto_applications')
     ) THEN
    UPDATE public.crypto_applications t SET asset_id = NULL
     WHERE t.asset_id IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM public.assets a WHERE a.tenant_id = t.tenant_id AND a.id = t.asset_id);
    ALTER TABLE ONLY public.crypto_applications
        ADD CONSTRAINT crypto_applications_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id) REFERENCES public.assets(tenant_id, id) ON DELETE SET NULL (asset_id);
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.database_encryption_states') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'database_encryption_states_tenant_asset_fkey' AND conrelid = to_regclass('public.database_encryption_states')
     ) THEN
    UPDATE public.database_encryption_states t SET asset_id = NULL
     WHERE t.asset_id IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM public.assets a WHERE a.tenant_id = t.tenant_id AND a.id = t.asset_id);
    ALTER TABLE ONLY public.database_encryption_states
        ADD CONSTRAINT database_encryption_states_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id) REFERENCES public.assets(tenant_id, id) ON DELETE SET NULL (asset_id);
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.external_connections') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_connections_tenant_source_asset_fkey' AND conrelid = to_regclass('public.external_connections')
     ) THEN
    UPDATE public.external_connections t SET source_asset_id = NULL
     WHERE t.source_asset_id IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM public.assets a WHERE a.tenant_id = t.tenant_id AND a.id = t.source_asset_id);
    ALTER TABLE ONLY public.external_connections
        ADD CONSTRAINT external_connections_tenant_source_asset_fkey FOREIGN KEY (tenant_id, source_asset_id) REFERENCES public.assets(tenant_id, id) ON DELETE SET NULL (source_asset_id);
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.ssh_keys') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ssh_keys_tenant_asset_fkey' AND conrelid = to_regclass('public.ssh_keys')
     ) THEN
    UPDATE public.ssh_keys t SET asset_id = NULL
     WHERE t.asset_id IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM public.assets a WHERE a.tenant_id = t.tenant_id AND a.id = t.asset_id);
    ALTER TABLE ONLY public.ssh_keys
        ADD CONSTRAINT ssh_keys_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id) REFERENCES public.assets(tenant_id, id) ON DELETE SET NULL (asset_id);
  END IF;
END $$;

-- device_jobs gains the asset link `devices` used to provide. ON DELETE SET
-- NULL, not CASCADE: a job is a record of work that ran, and deleting the asset
-- it ran against does not unmake the job.
DO $$ BEGIN
  IF to_regclass('public.device_jobs') IS NOT NULL
     AND to_regclass('public.assets') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'device_jobs_tenant_asset_fkey' AND conrelid = to_regclass('public.device_jobs')
     ) THEN
    ALTER TABLE ONLY public.device_jobs
        ADD CONSTRAINT device_jobs_tenant_asset_fkey FOREIGN KEY (tenant_id, asset_id) REFERENCES public.assets(tenant_id, id) ON DELETE SET NULL (asset_id);
  END IF;
END $$;


-- Endpoint links. ON DELETE SET NULL so removing one endpoint of an asset
-- leaves the crypto configuration attached to the asset rather than deleting
-- evidence: the roll-up target is asset_id, and it is unaffected.
DO $$ BEGIN
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL
     AND to_regclass('public.asset_endpoints') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'crypto_implementations_tenant_endpoint_fkey' AND conrelid = to_regclass('public.crypto_implementations_partitioned')
     ) THEN
    ALTER TABLE public.crypto_implementations_partitioned
        ADD CONSTRAINT crypto_implementations_tenant_endpoint_fkey FOREIGN KEY (tenant_id, endpoint_id) REFERENCES public.asset_endpoints(tenant_id, id) ON DELETE SET NULL (endpoint_id);
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.external_connections') IS NOT NULL
     AND to_regclass('public.asset_endpoints') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'external_connections_tenant_source_endpoint_fkey' AND conrelid = to_regclass('public.external_connections')
     ) THEN
    ALTER TABLE ONLY public.external_connections
        ADD CONSTRAINT external_connections_tenant_source_endpoint_fkey FOREIGN KEY (tenant_id, source_endpoint_id) REFERENCES public.asset_endpoints(tenant_id, id) ON DELETE SET NULL (source_endpoint_id);
  END IF;
END $$;

DO $$ BEGIN
  IF to_regclass('public.ssh_keys') IS NOT NULL
     AND to_regclass('public.asset_endpoints') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'ssh_keys_tenant_endpoint_fkey' AND conrelid = to_regclass('public.ssh_keys')
     ) THEN
    ALTER TABLE ONLY public.ssh_keys
        ADD CONSTRAINT ssh_keys_tenant_endpoint_fkey FOREIGN KEY (tenant_id, endpoint_id) REFERENCES public.asset_endpoints(tenant_id, id) ON DELETE SET NULL (endpoint_id);
  END IF;
END $$;


-- ----------------------------------------------------------------------------
-- Partition-direct access on the two surviving pre-existing partitioned tables
-- ----------------------------------------------------------------------------
-- A policy on a partitioned PARENT is applied to queries that name the parent.
-- Naming a partition directly (`SELECT … FROM sensor_discoveries_part_3`) is a
-- separate relation reference and consults only that partition's own policies —
-- so with RLS off on the partition, the blanket `GRANT … ON ALL TABLES IN
-- SCHEMA public TO crypto_app` at the foot of this file hands every tenant an
-- unfiltered read of every other tenant's rows, one identifier away from the
-- policy. Measured on PG17 during the workstream 0.2 review: 1 row through the
-- parent, 2 through the partitions.
--
-- `assets` and `asset_endpoints` closed this at their definition. These two
-- tables are the rest of the instance, and `network_assets_partitioned` — the
-- third — is dropped above, which removes its instance outright. RLS enabled
-- with ZERO policies is default-deny for the direct path and leaves the parent
-- path untouched; deny rather than a copied policy, because nothing should be
-- naming a partition and no Go or TypeScript in this repo does.
ALTER TABLE public.sensor_discoveries_part_0 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_discoveries_part_1 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_discoveries_part_2 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_discoveries_part_3 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_discoveries_part_4 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_discoveries_part_5 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_discoveries_part_6 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_discoveries_part_7 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crypto_implementations_part_0 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crypto_implementations_part_1 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crypto_implementations_part_2 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crypto_implementations_part_3 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crypto_implementations_part_4 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crypto_implementations_part_5 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crypto_implementations_part_6 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crypto_implementations_part_7 ENABLE ROW LEVEL SECURITY;


-- ============================================================================
-- POST-MIGRATIONS: assets.class_source_kind gains `rule` (workstream 2.10b)
-- ============================================================================
-- A class argued from a curated classification_rules row had nowhere honest to
-- be recorded: the CHECK allowed measured / declared / imported / inferred, and
-- a rule-derived class is none of them. `measured` would claim we measured the
-- MAC-to-class mapping (we measured the MAC); `inferred` is ADR-0008 D4.2's
-- "something a model proposed", and a deterministic rule that cites a source is
-- not a model. Both are false provenance on the one field a reviewer uses to
-- audit a class, which is the opposite of what ADR-0004 D6 wants.
--
-- BOTH edits are required and this is the second of them. The first is the
-- inline CONSTRAINT in the pg_dump body above, which covers a FRESH install;
-- `CREATE TABLE IF NOT EXISTS` does nothing to a database that already has the
-- table, so without this block an existing install keeps the four-value CHECK,
-- psql still exits 0, and the failure surfaces much later as a constraint
-- violation on the first rule-classified INSERT.
--
-- DROP + ADD rather than the guarded ADD the house style uses for most
-- constraints, for the same reason the classification_rules block below does
-- it: this REPLACES a constraint of the same name with a wider list, and a
-- CHECK has no dependents to break. On a fresh install it drops and re-adds
-- what the body just created, which is a no-op.
--
-- Widening a CHECK cannot fail on existing rows: every value the old list
-- allowed is in the new one.
DO $$ BEGIN
  IF to_regclass('public.assets') IS NOT NULL THEN
    ALTER TABLE public.assets
        DROP CONSTRAINT IF EXISTS assets_class_source_kind_check;
    ALTER TABLE public.assets
        ADD CONSTRAINT assets_class_source_kind_check
        CHECK (class_source_kind = ANY (ARRAY['measured'::text, 'declared'::text,
            'imported'::text, 'inferred'::text, 'rule'::text]));
  END IF;
END $$;

-- ============================================================================
-- POST-MIGRATIONS: classification_rules gains `model` and `platform` (2.10a)
-- ============================================================================
-- The table shipped in workstream 2.10's data-model slice with six rule kinds
-- and a NOT NULL class_key. Workstream 2.10a migrated the in-package class
-- hints of shared/deviceinterrogation into it and needed two more kinds
-- (`model`, `platform`) and a nullable class_key, because most OUI rules assert
-- a vendor and deliberately no class. Both changes are in the pg_dump body
-- above, so a fresh install is already correct; this block is for an install
-- that already created the table.
--
-- DROP + ADD on the CHECK rather than the guarded ADD the house style uses for
-- most constraints: this one has to REPLACE a constraint of the same name with
-- a wider list, and a CHECK has no dependents to break (the hazard the style
-- note warns about is a PK with FK dependents). Both statements are idempotent
-- on their own, and on a fresh install they drop and re-add a constraint the
-- body just created, which is a no-op.
DO $$ BEGIN
  IF to_regclass('public.classification_rules') IS NOT NULL THEN
    ALTER TABLE public.classification_rules ALTER COLUMN class_key DROP NOT NULL;

    -- And the confidence default goes. The engine refuses anything outside
    -- 0.50-0.95, so DEFAULT 1.00 was a way for an INSERT that omitted the
    -- column to produce a row classify.New then rejects -- taking the whole
    -- rule set with it, not just that row.
    ALTER TABLE public.classification_rules ALTER COLUMN confidence DROP DEFAULT;

    -- The kind list is widened here and in the inline CONSTRAINT in the body
    -- above, and BOTH are required: the body covers a fresh install, this
    -- covers one that already created the table. Workstream 2.10b added
    -- `cdp_capabilities`, `lldp_capability` and `mdns_service` to the eight
    -- 2.10a shipped.
    ALTER TABLE public.classification_rules
        DROP CONSTRAINT IF EXISTS classification_rules_rule_kind_check;
    ALTER TABLE public.classification_rules
        ADD CONSTRAINT classification_rules_rule_kind_check
        CHECK (rule_kind = ANY (ARRAY['oui'::text, 'sysobjectid'::text, 'enip'::text,
            'cloud_type'::text, 'banner'::text, 'port_profile'::text, 'model'::text,
            'platform'::text, 'cdp_capabilities'::text, 'lldp_capability'::text,
            'mdns_service'::text]));

    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint
      WHERE conname = 'classification_rules_asserts_something_check'
        AND conrelid = to_regclass('public.classification_rules')
    ) THEN
      ALTER TABLE public.classification_rules
          ADD CONSTRAINT classification_rules_asserts_something_check
          CHECK (class_key IS NOT NULL OR vendor IS NOT NULL OR model IS NOT NULL);
    END IF;
  END IF;
END $$;

-- ============================================================================
-- POST-MIGRATIONS: retire tables with neither reader nor writer (2026-08-21)
-- ============================================================================
-- Each was verified to have zero Go/TypeScript references, or to be superseded
-- by a table that carries the data instead. Their CREATE statements were removed
-- from the pg_dump body above, so a fresh install never creates them; these DROPs
-- remove them from installs that already have them. Both halves are required.
--
-- CASCADE: an unused table may still be the target of an FK from another table
-- in this batch, and this list is alphabetical rather than topological.

DROP TABLE IF EXISTS audit.audit_logs CASCADE;
DROP TABLE IF EXISTS audit.alert_instances CASCADE;
DROP TABLE IF EXISTS audit.retention_jobs CASCADE;
DROP TABLE IF EXISTS public.compliance_checks CASCADE;
DROP TABLE IF EXISTS public.compliance_reports CASCADE;
DROP TABLE IF EXISTS public.compliance_framework_status CASCADE;
DROP TABLE IF EXISTS public.compliance_requirements CASCADE;
DROP TABLE IF EXISTS public.dashboard_metrics CASCADE;
DROP TABLE IF EXISTS public.dashboard_cache CASCADE;
DROP TABLE IF EXISTS public.tenant_usage_tracking CASCADE;
DROP TABLE IF EXISTS public.pending_sensors CASCADE;
DROP TABLE IF EXISTS public.system_health_metrics CASCADE;
DROP TABLE IF EXISTS public.ai_models CASCADE;
DROP TABLE IF EXISTS public.ai_analysis_results CASCADE;
DROP TABLE IF EXISTS public.access_pattern_analysis CASCADE;
DROP TABLE IF EXISTS public.threat_detection_rules CASCADE;
DROP TABLE IF EXISTS public.api_security_monitoring CASCADE;
DROP TABLE IF EXISTS public.feature_adoption_metrics CASCADE;
DROP TABLE IF EXISTS public.feature_usage_events CASCADE;
DROP TABLE IF EXISTS public.health_insights CASCADE;
DROP TABLE IF EXISTS public.resource_permissions CASCADE;
DROP TABLE IF EXISTS public.resource_tracking_config CASCADE;
DROP TABLE IF EXISTS public.api_format_preferences CASCADE;
DROP TABLE IF EXISTS public.tenant_cost_analysis CASCADE;
DROP TABLE IF EXISTS public.sync_outbox CASCADE;
DROP TABLE IF EXISTS public.agent_ca_certificates CASCADE;
DROP TABLE IF EXISTS public.security_events CASCADE;
DROP TABLE IF EXISTS public.discovery_approval_queue CASCADE;
DROP TABLE IF EXISTS public.identity_link_requests CASCADE;
DROP TABLE IF EXISTS public.ci_relationships CASCADE;
DROP TABLE IF EXISTS public.platform_integration_secrets CASCADE;

-- Functions that existed only to query the tables above. No Go/TS caller, no
-- seed reference, no trigger. Dropped so nothing is left pointing at a table
-- this file no longer creates.
DROP FUNCTION IF EXISTS public.calculate_tenant_cost CASCADE;
DROP FUNCTION IF EXISTS public.cleanup_expired_dashboard_cache CASCADE;
DROP FUNCTION IF EXISTS public.get_system_health_summary CASCADE;
DROP FUNCTION IF EXISTS public.update_tenant_usage CASCADE;

-- ============================================================================
-- POST-MIGRATIONS: materialize the activity-log partitions for TODAY
-- ============================================================================
-- audit.activity_logs is RANGE-partitioned on occurred_at, and the pg_dump body
-- above carries a FIXED set of monthly partitions — whatever existed when the
-- dump was taken. An INSERT whose occurred_at falls outside every attached
-- partition does not fall back anywhere: Postgres raises
-- `no partition of relation "activity_logs" found for row` (23514), and the
-- write that fails is an AUDIT write.
--
-- So the dumped partition list is a wall-clock expiry date baked into the file.
-- It expired: the last dumped partition ended 2026-09-01 and every fresh apply
-- from 2026-09-01 onwards produced a table that could not accept a row stamped
-- `now()`.
--
-- audit.ensure_future_partitions() has existed since the partitioning went in,
-- is granted EXECUTE to both roles a few sections above, and had NO CALLER
-- ANYWHERE — not in this file, not in Go, not in a trigger. audit-service's
-- PartitionManager job calls create_activity_logs_partition directly on startup
-- and weekly thereafter, which is why long-running deployments self-heal and
-- the gap stayed invisible: it only bites where the schema is applied but that
-- job is not running, i.e. a fresh install before audit-service's first tick,
-- and every DB-integration test database.
--
-- Calling it here makes the file self-sufficient: current month + 3, the same
-- horizon PartitionManager uses, so the two agree rather than one silently
-- depending on the other. Idempotent — the function skips any partition already
-- in pg_class — and it must stay ABOVE the ROLE GRANTS block so the partitions
-- it creates are covered by the blanket `ON ALL TABLES IN SCHEMA audit` grant.
SELECT * FROM audit.ensure_future_partitions(3);



-- =========================================================================
-- SAVED VIEWS — general asset inventory, phase 1 (ADR-0006 D2, workstream 1.8)
--
-- A saved view is a NAMED QUERY STRING. That is the whole object: the facet
-- rail writes the query, the user names it, and the name is how they get back
-- to it. It is the beginner's surface for the query language — you learn the
-- language by reading what your own views say.
--
-- `target` is the collection the query is a predicate over (§4.1), out of band
-- because the URL and the endpoint already carry it and putting it in the text
-- would make every stored predicate carry a redundant, forgeable prefix (§11
-- Q2).
--
-- `is_shared` makes a view visible to the whole tenant; otherwise it belongs to
-- its owner. RLS isolates the tenant; the owner filter is applied in the query,
-- because "my views" is a product rule and not an isolation control.
-- =========================================================================

-- TABLE: saved_views
CREATE TABLE IF NOT EXISTS public.saved_views (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    -- The collection the predicate is over: asset, endpoint, certificate,
    -- crypto_configuration, finding, software_install, relationship.
    target character varying(64) DEFAULT 'asset'::character varying NOT NULL,
    -- The query, stored in CANONICAL form (§10). Two spellings of one
    -- predicate stored verbatim are two rows a diff cannot match.
    query text DEFAULT ''::text NOT NULL,
    owner_user_id uuid NOT NULL,
    is_shared boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT saved_views_pkey PRIMARY KEY (id),
    -- Unique per OWNER, not per tenant: two people may each keep a view called
    -- "Mine", and a tenant-wide unique name would make the first one to save
    -- block everybody else.
    CONSTRAINT saved_views_unique_name_per_owner UNIQUE (tenant_id, owner_user_id, name)
);
CREATE INDEX IF NOT EXISTS idx_saved_views_tenant_target ON public.saved_views USING btree (tenant_id, target);
CREATE INDEX IF NOT EXISTS idx_saved_views_owner ON public.saved_views USING btree (tenant_id, owner_user_id);
CREATE INDEX IF NOT EXISTS idx_saved_views_shared ON public.saved_views USING btree (tenant_id) WHERE (is_shared = true);

-- A SHARED saved view's name is unique tenant-wide, case-insensitively.
--
-- The table's own constraint is per (tenant, owner, name), which is right for a
-- PRIVATE view: two people may each keep one called "Mine", and a tenant-wide
-- unique name would let whoever saved first block everybody else. But the error
-- copy promised tenant-wide uniqueness, and for a SHARED view it has to be true
-- — a shared view is a name everyone in the tenant reads off one list, and two
-- rows called "Production" from two owners are indistinguishable there.
--
-- Partial (only shared rows) and over lower(name), because "Production" and
-- "production" are the same name to the person reading the list.
CREATE UNIQUE INDEX IF NOT EXISTS idx_saved_views_shared_name_uniq
    ON public.saved_views (tenant_id, lower(name))
    WHERE is_shared = true;

DROP TRIGGER IF EXISTS update_saved_views_updated_at ON public.saved_views;
CREATE OR REPLACE TRIGGER update_saved_views_updated_at
    BEFORE UPDATE ON public.saved_views
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

ALTER TABLE public.saved_views ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
    CREATE POLICY saved_views_tenant_isolation ON public.saved_views
      USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
      WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- =========================================================================
-- POST-MIGRATIONS: scopes and approval rules carry a QUERY, not JSON
-- =========================================================================
-- The pg_dump body above declares the new columns for a FRESH install. A lab
-- database created before this change still has the jsonb columns and none of
-- the new ones, and CREATE TABLE IF NOT EXISTS does nothing to it — so the
-- ALTERs below are what make the file converge on either shape in one apply.
--
-- The old columns are DROPPED rather than left in place. ADR-0007 D2 is the
-- no-migration path: there are no installs to carry forward, the predicate
-- shapes are gone from the API with no deprecation window (ADR-0007 D2.4), and
-- a column nothing reads is a second place for a scope's meaning to live.
-- Translating the old jsonb into a query string here is deliberately NOT done:
-- it would be a third implementation of the compatibility mapping (§8), in SQL,
-- untested, for rows that by decision do not exist.
-- `scopes` and `scopes_audit` are handled EARLIER in this file, immediately
-- above `scopes_audit_trigger` — the trigger's WHEN clause names the `query`
-- column, so the column has to exist before the file reaches it. See the
-- comment there.
ALTER TABLE IF EXISTS public.discovery_auto_approval_rules
    ADD COLUMN IF NOT EXISTS query text DEFAULT ''::text NOT NULL;
ALTER TABLE IF EXISTS public.discovery_auto_approval_rules DROP COLUMN IF EXISTS conditions;


-- =========================================================================
-- POST-MIGRATIONS: heartbeat counters with no column of their own
-- =========================================================================
-- The pg_dump body above declares sensor_health_metrics.extra_counters for a
-- FRESH install. A database created before this change has the table without
-- the column, and CREATE TABLE IF NOT EXISTS does nothing to it — this ALTER is
-- what makes the file converge on either shape in one apply.
--
-- Nullable and no default, on purpose. NULL is "the sensor reported no such
-- counters" (an older build, or host observation switched off); `{}` would be
-- "it reported an empty set", and the two are different facts about the
-- segment. Backfilling every historical row with `{}` would assert the second
-- about heartbeats that predate the feature.
ALTER TABLE IF EXISTS public.sensor_health_metrics
    ADD COLUMN IF NOT EXISTS extra_counters jsonb;


-- =========================================================================
-- POST-MIGRATIONS: a network segment is scoped to its cloud network (2.4)
-- =========================================================================
-- `network_segments` was unique on (tenant_id, value). A CIDR is not unique in
-- a cloud account: two VPCs created from the same Terraform module both get
-- 10.0.0.0/16, and their subnets both get 10.0.1.0/24. Under the old key those
-- two subnets SHARED one segment row, so two instances at 10.0.1.20 in two
-- different VPCs resolved to one scope — and `ip_address` then matched them to
-- one ASSET, silently, with no merge proposal. Reproduced on PG17 before the
-- fix: one asset carrying two `cloud_resource_id` identifiers.
--
-- The fix is to make the cloud network part of the segment's identity. A LAN
-- segment carries NULL and behaves exactly as before, which is why the key is
-- over `coalesce(cloud_network_ref, '')` rather than over the bare column —
-- NULLs are distinct in a unique index, so a bare column would let a tenant
-- accumulate unlimited duplicate LAN segments for one CIDR.
--
-- A constraint cannot be declared over an expression, so this is a unique
-- INDEX and the old constraint is dropped. The index name deliberately keeps
-- the old one's stem so anything grepping for it still finds the rule.
ALTER TABLE IF EXISTS public.network_segments
    ADD COLUMN IF NOT EXISTS cloud_network_ref text;
ALTER TABLE IF EXISTS public.network_segments
    DROP CONSTRAINT IF EXISTS network_segments_value_unique_per_tenant;
CREATE UNIQUE INDEX IF NOT EXISTS network_segments_value_unique_per_tenant_idx
    ON public.network_segments (tenant_id, value, coalesce(cloud_network_ref, ''::text));

-- asset_endpoints.bound_local (workstream 2.11b). The column is also in the
-- CREATE TABLE body above, which covers a FRESH install; this ALTER is what
-- carries it to a database that already has the table, because the CREATE is
-- `IF NOT EXISTS` and silently does nothing there. Both edits are required —
-- see the two-edit rule at the top of this file.
--
-- Nullable with no default, deliberately: NULL is "nobody established this",
-- which is the truth for every endpoint a network scan found. See the column
-- comment for why a false default would be a fabricated measurement.
ALTER TABLE IF EXISTS public.asset_endpoints
    ADD COLUMN IF NOT EXISTS bound_local boolean;


-- =========================================================================
-- POST-MIGRATIONS: connector connections, runs, and segment provenance (2.7)
-- =========================================================================
-- The connector registry gains a third store (see connector_connections in the
-- body above). Everything here is the half an EXISTING database needs: the
-- pg_dump body covers a fresh install, this covers an upgrade. Both are
-- required — an ADD COLUMN that lives only in the CREATE TABLE silently
-- no-ops on an installed database.

-- network_segments provenance. Nullable with no default, so existing rows keep
-- "no provenance recorded" rather than being retroactively labelled: a segment
-- drawn by hand two years ago was not imported, and saying it was would be a
-- fact this migration invented.
ALTER TABLE public.network_segments
  ADD COLUMN IF NOT EXISTS source_kind character varying(20),
  ADD COLUMN IF NOT EXISTS source_ref  character varying(200);

DO $$
BEGIN
  IF to_regclass('public.network_segments') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
        WHERE conname = 'network_segments_source_kind_check'
          AND conrelid = to_regclass('public.network_segments')
     )
  THEN
    ALTER TABLE public.network_segments
      ADD CONSTRAINT network_segments_source_kind_check
      CHECK (source_kind IS NULL OR source_kind IN ('measured', 'imported', 'declared', 'inferred'));
  END IF;
END $$;

-- Foreign keys for the two new tables. Tenant-scoped rows cascade with the
-- tenant so testdb.NewTenant's cleanup takes them with it; a run cascades with
-- its connection, because a run of a connection that no longer exists is an
-- orphan nothing can interpret.
DO $$
BEGIN
  IF to_regclass('public.connector_connections') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
        WHERE conname = 'connector_connections_tenant_id_fkey'
          AND conrelid = to_regclass('public.connector_connections')
     )
  THEN
    ALTER TABLE ONLY public.connector_connections
      ADD CONSTRAINT connector_connections_tenant_id_fkey
      FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF to_regclass('public.connector_runs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
        WHERE conname = 'connector_runs_tenant_id_fkey'
          AND conrelid = to_regclass('public.connector_runs')
     )
  THEN
    ALTER TABLE ONLY public.connector_runs
      ADD CONSTRAINT connector_runs_tenant_id_fkey
      FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF to_regclass('public.connector_runs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
        WHERE conname = 'connector_runs_connection_id_fkey'
          AND conrelid = to_regclass('public.connector_runs')
     )
  THEN
    ALTER TABLE ONLY public.connector_runs
      ADD CONSTRAINT connector_runs_connection_id_fkey
      FOREIGN KEY (connection_id) REFERENCES public.connector_connections(id) ON DELETE CASCADE;
  END IF;
END $$;

-- RLS. Declared here rather than in the RLS HARDENING block for the same
-- reason legal_acceptances is: DROP POLICY IF EXISTS + CREATE is the form that
-- can UPDATE an existing policy, and both USING and WITH CHECK are stated
-- because Postgres silently reuses USING as WITH CHECK when the latter is
-- omitted (TestIntegration_RLS_EveryTenantPolicyHasWithCheck requires it).
ALTER TABLE public.connector_connections ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS connector_connections_tenant_isolation ON public.connector_connections;
CREATE POLICY connector_connections_tenant_isolation ON public.connector_connections
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE public.connector_runs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS connector_runs_tenant_isolation ON public.connector_runs;
CREATE POLICY connector_runs_tenant_isolation ON public.connector_runs
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);


-- =========================================================================
-- POST-MIGRATIONS: measurement_types.extraction_query is gone (ADR-0005 D5)
-- =========================================================================
-- The column stored the SQL a measurement type "runs". Nothing ever executed
-- it — every extractor was hand-written Go — and ADR-0005 D5 drops it rather
-- than honouring it: a seeded query is an injection hazard and an upgrade
-- hazard at once, and a column holding SQL that nothing runs is a standing
-- invitation for someone to start running it.
--
-- What replaced it is standards/measurement-types.yaml, where a measurement
-- type declares a whitelisted SHAPE, a selectable VALUE and a query-language
-- predicate, and the compliance-engine composes the statement from those.
ALTER TABLE IF EXISTS public.measurement_types DROP COLUMN IF EXISTS extraction_query;


-- =========================================================================
-- POST-MIGRATIONS: the pending-class-proposal index keys on the conflict too
-- =========================================================================
-- `CREATE UNIQUE INDEX IF NOT EXISTS` never WIDENS an index that already
-- exists — it sees the name, does nothing, and says nothing. A database
-- carrying the old two-column key would therefore keep collapsing every
-- conflict proposal for an asset onto one row for ever, while the file above
-- read as though it had been fixed.
--
-- So: drop it when its definition is not the current one, and let the body's
-- CREATE (which runs BEFORE this block on the next apply) put it back. Dropping
-- it here rather than unconditionally means a database already on the new
-- definition pays nothing.
--
-- A unique index, so the drop-and-recreate can fail on a database that has
-- already accumulated two pending conflict proposals with the same key — which
-- cannot happen, because the OLD index is what prevented exactly that.
DO $$
DECLARE def text;
BEGIN
  IF to_regclass('public.asset_history') IS NULL THEN
    RETURN;
  END IF;
  SELECT indexdef INTO def
    FROM pg_indexes
   WHERE schemaname = 'public' AND indexname = 'idx_asset_history_pending_class_proposal';
  IF def IS NOT NULL AND position('conflict_key' IN def) = 0 THEN
    DROP INDEX IF EXISTS public.idx_asset_history_pending_class_proposal;
    CREATE UNIQUE INDEX idx_asset_history_pending_class_proposal
        ON public.asset_history USING btree (
            tenant_id, asset_id,
            (COALESCE(NULLIF(changes_json ->> 'proposed_class_key', ''), changes_json ->> 'conflict_key', '')))
        WHERE action = 'class_proposed'
          AND changes_json ? 'proposed_class_key'
          AND COALESCE(changes_json ->> 'status', 'pending') = 'pending';
  END IF;
END $$;


-- Drop the two decorative trigram GIN indexes on `findings`.
--
-- See the long note where they used to be created (search for
-- "Free-text search on the Findings page"): the Findings-page search predicate
-- is one OR containing a correlated EXISTS, so Postgres cannot BitmapOr it and
-- never consulted either index. Proven by EXPLAIN on a 50,000-finding tenant,
-- with the indexes present and absent: the same plan, to the node.
--
-- Unconditional DROP ... IF EXISTS, because a database that never had them is
-- the normal case on a fresh install (the CREATEs are gone from the body above)
-- and IF EXISTS makes that a no-op rather than an error.
DROP INDEX IF EXISTS public.idx_findings_summary_trgm;
DROP INDEX IF EXISTS public.idx_findings_subject_label_trgm;


-- =========================================================================
-- POST-MIGRATIONS: SCT delivery-route tracking (RFC 6962 §3.3)
-- =========================================================================
-- Certificate Transparency SCTs can arrive by three routes: embedded in the
-- certificate, the TLS "signed_certificate_timestamp" extension, or OCSP.
-- has_sct / cert_has_sct already answered "was one seen"; these columns add
-- "by which route" (embedded | tls_extension | ocsp | none), so a passive
-- capture that only checked the embedded route can leave the column NULL
-- ("not observable") rather than a false "none" that would claim all three
-- routes were checked. See shared/discovery.RefineSCTFlags.
ALTER TABLE IF EXISTS public.certificates ADD COLUMN IF NOT EXISTS sct_source character varying(20);

-- external_connections never persisted the sensor-level certificate quality
-- flags (cert_has_sct, cert_no_subject, cert_validation_status="untrusted_ca"
-- /"incomplete_chain") anywhere except as free text folded into weak_reasons —
-- which is the bug this migration accompanies: those are certificate-hygiene
-- observations, not cryptographic weakness, and conflating them inflated the
-- "weak crypto" dashboard tile with TLS 1.3/AES-256-GCM connections whose only
-- flaw was a missing SCT. cert_hygiene_flags is their new, non-scoring home;
-- cert_sct_source mirrors certificates.sct_source above.
ALTER TABLE IF EXISTS public.external_connections ADD COLUMN IF NOT EXISTS cert_hygiene_flags text[] DEFAULT '{}'::text[];
ALTER TABLE IF EXISTS public.external_connections ADD COLUMN IF NOT EXISTS cert_sct_source character varying(20);


-- ============================================================================
-- POST-MIGRATIONS: merge asset_endpoints rows the IP-literal-fqdn defect wrote
-- ============================================================================
-- Before this release, an intake path that did not know a listener's name
-- could write the scan TARGET into `fqdn` even when the target was an IP
-- literal — it has dots, so it passed a naive "contains a dot -> fqdn" check.
-- That produced a SECOND asset_endpoints row for a listener already recorded
-- with fqdn NULL from a passive observation: same address, same port, same
-- transport, "duplicate" only because one row's name field held an address
-- spelled as text. Every duplicate then carried its own crypto configuration
-- and its own findings, doubling counts on the asset page.
--
-- New writes are fixed at the source (asset_identity.go's findingEndpoint) and
-- at the funnel (identity.EndpointObservation.Sanitized, consulted by
-- Observation.Sanitize, the engine's stampEndpoints, and
-- postgres.Repository.UpsertEndpoints, which now matches an incoming
-- address-bearing observation on (address, port, transport) — not the full
-- (address, fqdn, port, transport) tuple asset_endpoints_identity_uniq still
-- keys on — and merges into the existing row rather than inserting a second
-- one). This block merges rows the defect already wrote, on every existing
-- install, once.
--
-- Identity for this merge is (tenant_id, asset_id, address, port, transport):
-- an endpoint identified by an address is identified by that tuple, and fqdn
-- is an ATTRIBUTE of it, not part of what identifies it — see the doc comment
-- on identity.EndpointObservation.Key. Endpoints with no address (fqdn-only)
-- are untouched: fqdn IS their whole identity, and the unique index already
-- prevents duplicates among them.
--
-- Survivor: the OLDEST row by first_seen_at (tie-broken by id), because it is
-- what every dependent already points at most often and what a user has been
-- looking at longest. Its fqdn is kept if it has one; otherwise it is
-- backfilled from any duplicate that does — "empty never wins", the same rule
-- [mergeEndpointByAddress] applies on the live upsert path. Dependents
-- (crypto_implementations, external_connections, ssh_keys) are re-pointed at
-- the survivor before the losing rows are deleted.
--
-- The backfill and the delete are ONE statement (step 5 below), not two, and
-- the ordering is load-bearing rather than cosmetic: a loser row due to be
-- deleted for having fqdn = 'host.corp.example' can ALREADY be the value the
-- survivor (fqdn NULL) needs backfilled to. Writing that value onto the
-- survivor with the loser still present would give two rows the identical
-- (address, fqdn, port, transport) tuple — an immediate
-- asset_endpoints_identity_uniq violation, not a race, since Postgres checks a
-- non-deferred unique index at the end of the writing statement regardless of
-- what a later statement in this DO block was going to do. A single
-- `WITH deleted AS (DELETE ... RETURNING ...) UPDATE ... FROM deleted` makes
-- the backfill provably run against the POST-delete state — the UPDATE cannot
-- produce a row without first consuming `deleted`'s output, which requires the
-- DELETE (and its index removals) to have already completed — while still
-- letting the backfill value be READ from the row before it disappears, via
-- RETURNING.
--
-- The (tenant_id, asset_id, address, port, transport) grouping is recomputed
-- identically in the FK-repointing statements below rather than cached in a
-- temp table: nothing those statements write changes those five columns, so
-- every recomputation sees the same groups and the same survivor, and the
-- repetition costs one extra `GROUP BY` pass over what is normally a small
-- table rather than a code path this file has never used before. They must
-- all run BEFORE the delete: each depends on the loser row still existing to
-- name what it should be re-pointed away from.
--
-- Idempotent: a re-run finds no group with more than one row — the DELETE
-- already removed the rest — and every statement affects zero rows. Tested by
-- applying schema.sql twice with populated asset_endpoints,
-- crypto_implementations, external_connections and ssh_keys duplicates
-- between the two passes
-- (TestIntegration_Schema_MergesDuplicateAssetEndpoints).
DO $$
BEGIN
  IF to_regclass('public.asset_endpoints') IS NULL THEN
    RETURN;
  END IF;

  -- 1. Re-point crypto_implementations.endpoint_id at the survivor.
  IF to_regclass('public.crypto_implementations_partitioned') IS NOT NULL THEN
    WITH dupes AS (
      SELECT tenant_id, asset_id, address, port, transport,
             (array_agg(id ORDER BY first_seen_at, id))[1] AS survivor_id
        FROM public.asset_endpoints
       WHERE address IS NOT NULL
       GROUP BY tenant_id, asset_id, address, port, transport
      HAVING count(*) > 1
    ),
    losers AS (
      SELECT e.tenant_id, e.id AS loser_id, d.survivor_id
        FROM public.asset_endpoints e
        JOIN dupes d
          ON d.tenant_id = e.tenant_id AND d.asset_id = e.asset_id
         AND d.address IS NOT DISTINCT FROM e.address
         AND d.port IS NOT DISTINCT FROM e.port
         AND d.transport = e.transport
       WHERE e.id <> d.survivor_id
    )
    UPDATE public.crypto_implementations_partitioned ci
       SET endpoint_id = l.survivor_id
      FROM losers l
     WHERE ci.tenant_id = l.tenant_id AND ci.endpoint_id = l.loser_id;
  END IF;

  -- 2. Re-point external_connections.source_endpoint_id at the survivor.
  IF to_regclass('public.external_connections') IS NOT NULL THEN
    WITH dupes AS (
      SELECT tenant_id, asset_id, address, port, transport,
             (array_agg(id ORDER BY first_seen_at, id))[1] AS survivor_id
        FROM public.asset_endpoints
       WHERE address IS NOT NULL
       GROUP BY tenant_id, asset_id, address, port, transport
      HAVING count(*) > 1
    ),
    losers AS (
      SELECT e.tenant_id, e.id AS loser_id, d.survivor_id
        FROM public.asset_endpoints e
        JOIN dupes d
          ON d.tenant_id = e.tenant_id AND d.asset_id = e.asset_id
         AND d.address IS NOT DISTINCT FROM e.address
         AND d.port IS NOT DISTINCT FROM e.port
         AND d.transport = e.transport
       WHERE e.id <> d.survivor_id
    )
    UPDATE public.external_connections c
       SET source_endpoint_id = l.survivor_id
      FROM losers l
     WHERE c.tenant_id = l.tenant_id AND c.source_endpoint_id = l.loser_id;
  END IF;

  -- 3. Re-point ssh_keys.endpoint_id at the survivor.
  IF to_regclass('public.ssh_keys') IS NOT NULL THEN
    WITH dupes AS (
      SELECT tenant_id, asset_id, address, port, transport,
             (array_agg(id ORDER BY first_seen_at, id))[1] AS survivor_id
        FROM public.asset_endpoints
       WHERE address IS NOT NULL
       GROUP BY tenant_id, asset_id, address, port, transport
      HAVING count(*) > 1
    ),
    losers AS (
      SELECT e.tenant_id, e.id AS loser_id, d.survivor_id
        FROM public.asset_endpoints e
        JOIN dupes d
          ON d.tenant_id = e.tenant_id AND d.asset_id = e.asset_id
         AND d.address IS NOT DISTINCT FROM e.address
         AND d.port IS NOT DISTINCT FROM e.port
         AND d.transport = e.transport
       WHERE e.id <> d.survivor_id
    )
    UPDATE public.ssh_keys k
       SET endpoint_id = l.survivor_id
      FROM losers l
     WHERE k.tenant_id = l.tenant_id AND k.endpoint_id = l.loser_id;
  END IF;

  -- 4. Every dependent is re-pointed; delete the losing rows and, in the same
  -- statement, backfill the survivor's fqdn from whichever deleted row had
  -- one (the earliest-seen such row, for a deterministic pick when more than
  -- one duplicate carried a different name) — see the long comment above on
  -- why this has to be one statement rather than two.
  WITH dupes AS (
    SELECT tenant_id, asset_id, address, port, transport,
           (array_agg(id ORDER BY first_seen_at, id))[1] AS survivor_id
      FROM public.asset_endpoints
     WHERE address IS NOT NULL
     GROUP BY tenant_id, asset_id, address, port, transport
    HAVING count(*) > 1
  ),
  losers AS (
    SELECT e.tenant_id, e.id AS loser_id, e.fqdn AS loser_fqdn, e.first_seen_at AS loser_seen,
           d.survivor_id
      FROM public.asset_endpoints e
      JOIN dupes d
        ON d.tenant_id = e.tenant_id AND d.asset_id = e.asset_id
       AND d.address IS NOT DISTINCT FROM e.address
       AND d.port IS NOT DISTINCT FROM e.port
       AND d.transport = e.transport
     WHERE e.id <> d.survivor_id
  ),
  deleted AS (
    DELETE FROM public.asset_endpoints e
    USING losers l
    WHERE e.tenant_id = l.tenant_id AND e.id = l.loser_id
    RETURNING l.tenant_id, l.survivor_id, l.loser_fqdn, l.loser_seen
  ),
  best AS (
    -- An IP literal is NOT a candidate name. The rows this block merges are
    -- exactly the rows the defect wrote, so the losing row's fqdn is USUALLY
    -- the address spelled as text — backfilling that onto the survivor would
    -- re-create the very value this release exists to stop writing, and it
    -- would be permanent: [mergeEndpointByAddress] fills fqdn only when the
    -- row's is empty, so a real name arriving later would never replace it.
    -- The predicate mirrors [identity.EndpointObservation.Sanitized]'s
    -- netip.ParseAddr, including the IPv6 zone suffix netip accepts and inet
    -- does not (see the go-netip-vs-postgres-inet note) — hence split_part.
    SELECT DISTINCT ON (tenant_id, survivor_id) tenant_id, survivor_id, loser_fqdn
      FROM deleted
     WHERE loser_fqdn IS NOT NULL AND loser_fqdn <> ''
       AND NOT pg_input_is_valid(split_part(loser_fqdn, '%', 1), 'inet')
     ORDER BY tenant_id, survivor_id, loser_seen
  )
  UPDATE public.asset_endpoints e
     SET fqdn = best.loser_fqdn, updated_at = now()
    FROM best
   WHERE e.tenant_id = best.tenant_id AND e.id = best.survivor_id
     -- Also overwrites a survivor whose OWN fqdn is an IP literal: the
     -- survivor is the oldest row, which is the active-scan row whenever the
     -- scan saw the listener before anything named it. The losing rows are
     -- already gone by the time this UPDATE produces a row (it cannot run
     -- before it consumes `deleted`), so the group holds exactly one row and
     -- this cannot collide with asset_endpoints_identity_uniq.
     AND (e.fqdn IS NULL OR e.fqdn = ''
          OR pg_input_is_valid(split_part(e.fqdn, '%', 1), 'inet'));

  -- 6. Clear every remaining IP-literal fqdn on an address-bearing endpoint.
  -- Steps 1-5 only touch groups that HAVE a duplicate; the defect also wrote
  -- single rows — an active scan that reached a listener nothing had named —
  -- and those keep an address in their name field with nothing to merge them
  -- into. Left alone the value is permanent, for the same reason as above.
  -- Restricted to `address IS NOT NULL` because for an address-less endpoint
  -- fqdn IS the whole identity, and blanking it would leave a row identifying
  -- nothing. Runs after the delete, so each address-bearing group holds one
  -- row and clearing cannot collide.
  UPDATE public.asset_endpoints e
     SET fqdn = NULL, updated_at = now()
   WHERE e.address IS NOT NULL
     AND e.fqdn IS NOT NULL AND e.fqdn <> ''
     AND pg_input_is_valid(split_part(e.fqdn, '%', 1), 'inet');
END $$;


-- ============================================================================
-- ROLE GRANTS — THIS BLOCK MUST BE THE LAST THING IN THIS FILE
-- ============================================================================
-- `GRANT ... ON ALL TABLES IN SCHEMA x` is not a standing rule: Postgres
-- expands it once, right now, over the tables that exist at that instant. A
-- table created later in the same file therefore gets nothing.
--
-- That is exactly what happened while this block sat in the middle of the file
-- (RLS ROLE SPLIT section): nine tables defined below it — alerts,
-- alert_events, alert_framework_score_snapshots, legal_acceptances,
-- legal_documents, notification_digest_queue, platform_in_app_notifications,
-- platform_maintenance_windows, tenant_alert_settings — had zero privileges for
-- crypto_app after a fresh single apply. Since serviceRls defaults to ON,
-- services connect as crypto_app, and the chart's schema-migration Job applies
-- this file ONCE on install, a brand-new install answered `permission denied
-- for table alerts` on the whole Remediation → Alerts surface, the notification
-- digest queue, the platform operator inbox, and the ToS/Privacy acceptance
-- write on the signup path. A second apply hid the bug, which is why it lived
-- so long.
--
-- Keeping the grants LAST is the only shape that cannot silently regress: a new
-- CREATE TABLE appended to this file is, by construction, above them.
-- `scripts/audit-schema-grant-order.mjs` (run strict by `make audit`, and by
-- the pre-commit hook) fails if any table-creating statement appears after this
-- marker, so the invariant is enforced rather than merely documented.
--
-- Idempotent: GRANT/REVOKE are unconditional writes to the ACL.

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO crypto_app, crypto_bypass;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA audit  TO crypto_app, crypto_bypass;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO crypto_app, crypto_bypass;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA audit  TO crypto_app, crypto_bypass;

-- Deliberate narrowings. These MUST stay after the blanket grants above, which
-- cover views and materialized views as well as tables.
--
-- Materialized views hold cross-tenant data by construction (the owner
-- populates them at REFRESH time; RLS and security_invoker are structurally
-- inapplicable to them). crypto_app reads them only through the tenant-scoped
-- `*_tenant` wrapper views created earlier in this file; crypto_bypass keeps
-- direct access, since BYPASSRLS is the deliberate cross-tenant lane.
REVOKE ALL ON public.mv_location_finding_summary FROM crypto_app;
REVOKE ALL ON public.mv_remediation_queue        FROM crypto_app;
REVOKE ALL ON public.tenant_cost_summary         FROM crypto_app;

-- REVOKE first: the blanket GRANT above covers views too, so on a re-apply the
-- wrappers pick up INSERT/UPDATE/DELETE they must not have. (This used to be
-- masked by a matview DROP ... CASCADE that deleted the wrappers before the
-- grant ran — an accident of ordering, not a decision.) Read-only, stated
-- outright.
REVOKE ALL ON public.mv_location_finding_summary_tenant FROM crypto_app, crypto_bypass;
REVOKE ALL ON public.mv_remediation_queue_tenant        FROM crypto_app, crypto_bypass;
GRANT SELECT ON public.mv_location_finding_summary_tenant TO crypto_app, crypto_bypass;
GRANT SELECT ON public.mv_remediation_queue_tenant        TO crypto_app, crypto_bypass;